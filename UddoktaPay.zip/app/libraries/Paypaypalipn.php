<?php //ICB0 74:0 81:275c                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv/vYsZPUN1FqoKUIx2uiwF6wdC7sC1BV+HJz31l2Ls78itZZGllNAB5XxZW4s4LRrfRxerd
vGPzG80/E31/iL8cvV1t3q+kSDKIwQlZ4fMVUE8mQrt5P6GzuAq89mEQpl4LAJhgirZeXn8ZOhY3
UmupqhkgsN9qZp+QBy2j1sXeZdw6eL/SRDW+utMJcs5xomVYtUaIbdxlGrRqQgHycTioA9X1etVa
t/amEYhD/N44FbyQ4kiniw/W+iVtwwb5fwErrG1iPKggoQJG3oBzBCJfpyOdOgkXM0JABbMRcIlY
5jSo8clDj3hHMUrtBRkepQZC1eXYIda3kGWOvKBFj5l9G/jL9hTENwVv4f/ArBx1o46IPx9C2YNo
5EChik0SttJPqE8/ZjYqzh4IwDss/FpNiXaf490VNdK0LJrFvss8BrSB9uXJbdlAaKQByPumnZVX
Ytfyy0eLKrdSsRFs3QjXIih6DIfI1rOFRI3PHP5oksdEiynPNa4RMh42wxYWgJ66KjlCkWleh77w
5eXFczShouvgoZu7xwOWXdEZzE5XmnWZ6lQ+AmYBKz4gCArOkPc30hpxCUy9eav5f5/MH4F5NpOg
8AkMn/Jdn80ZXLErz5g9fRXZBZS4hnsboL7k4fIO0HqPSXAG1x3F3xRrKKXLPcTrBlo+VoLZar3n
ys3br39TCSyA2lnWSuyjCr84EHf7oFzz6P9MKQZIMKvXAUJitYhW9uTDXPQlPPiKRkFU3HvWGEoc
XxSCts2NysL4159G6MTEUwFBPhkB5O1W4oGBw/pNc5ICdNv4uZk09MX7j1aTLNJXupktPSLgeBhY
/8yJosipJ/yQf77/z3Wg1viK4Z4pmqa8lvSVDDj7OdAzMq4HYtIni2erltDj06QaSTF6x1qZd+wd
qQAQG39w2nrYC45GOAyJqy92bMocxik2SjuQ7dV1ErzqLDOMICxwEU4pJBv6TS7IbOFlNPQ+2I/v
lrspGe3tVnbT6J37iqdgKrXC4JxdDlXqvqM7EmJTYDchOlz51LmvS7vSQxphJc+qPNppZFaV4Njp
Ly8k6Gskn3xhdkkpnFGpVFcGcz78yfZ1iXuBEA2mWzew9kVqlhgYImWnFx6ICkrlaxPotUZ9drWs
SrH1LmP6B1TZW6vIthS9iuoWomf0j/0SoigclzDtH9VsTRQtJMdNYl/FnQHLeriK+vBztFbBdZjE
As6KPbp459if8hJOXmsO+WoQrDNAMTILyksJKO9YE+cA/JctuTFdiUDpxonVJNMVMOOfeLOF7uxM
NHU2/CkwYaAeyTxBFYKbKmpkTkc/uYp/bI0spXXWLq7RPLWr/Ek/jXzNY3Uq9HfwUxniViIi9OJY
s5Exr/H0/ogyHGwUIRdAJA1AXdCMYFbVmi0Y6eCqQPlIoxRwRHngewxJlLPup56lLWWQWAj64skx
8S8coVSLWKIgf8m9/S3eoBf0pGovhomgNLVauDqn0Y53Ea6aUVG+HJQaLgnTtw+bV99CAaVZ/Kz4
5LJEUUx6XjG9ijkJKSORCRkiSjNESCHlV2BHzyIYpwJf2RKkPMkBI/SF6xn6Zly9QfeXnrh5MCyp
NYCW7nJl1k5xBd6HJ+VQpYZz1A9QBxe9G3WPU7hd6+Z0BpiETaVnTUWtk6Tz3coAPOy19AFSNGRM
qF9xgSCT5ciYglZokqZva2HH3KOHTgg9OeDJds5g45B8IL3/ZF4tC9zHx+CTbrT6lD0UaQ2r36H5
3q2FErv3vyS+90v4azrN5cm/aDzNjdOY8unb7F+hb7c0C7QBrLmMlt/1j51qFmJe0KdiuMr53+hP
l6lDf5GOC3xXbu/8q7oHIBHHXRrr4ig07skU/RzUPCsjGqWXIXx2f7skCd8xqBRlEZEZA0w/8r8k
oRr1qB8utwQBAgwBf+D3hm7PYmPOlVAbJ89xE7Ss8Yk4gAN5MPZSMTLcJdSQ6txonPUUmw36O1mR
Ilci3X0i066rYk5ZBmPKIKzSeKn5m0yILoRxa8Z0o9+P7WOc9XzTTJyMmO+H92N6aBxcy0hYn0j2
P2/0Hrf2QV+nRYF7Gj2JU6gcvH58GMAyzOrjPucJ5Jxcj3Vzr+P75zbXXuSnQf7g9f705S9PxQMp
wXlQakFkMkJaNOxR+18hJzfBPMMuZRK3gOnt5fnYq46d6ekY8cnW2D0kYIuC8jUanOgw+pOPppl4
t3cCwcytHpDQ/0+A3ryGZSCcNO41sJSReACqNW/OtgexeVz0QvelHw3XyCmFfLIwjyg5+OXZ+MBB
OpYxss2v7K5kqqczgfSgsI6EItebXUz20/kkuw5w8X3GDp1nXe4FlQNJgfjD2gCuJ1mqS3YW9krh
zFQU7X5QHh5bNsRiK7kGG8fQx8SqL2b2vfhr/4lSSD0+b9rt/vMEaHlHNphf9mNtJp/tRMHy2Ao1
htbALByGoLdTqfnb6GQntlKV7piZvUMrnHxTCIzKvSX1jG1M3c/HZriViia1T8q9EBYqCpbHbAxo
ne1iwyhR8V0CETUH7w8jjbHKj1UNEW2kAT4I8djEMPA65nHJYybIS9ACPMC2cczNJvxiqcSw29Sp
LdU9wiFKLiNFEr2dlIyIdNQaQ4NwE7qtXj5SnFZqu04TeiS+OkoC+eZ/68nHZtgprGnOtJbIdAts
hp1pH5Y53PBia7GlC6q+xWfIwi40xSuTg+nrvxUoieYBQU6o62I3TLYO1C7nZ3X1tVfmqWZe9oqk
IF2tJiOTKNV/KV8CwzSM37pxpeDGthih5L4gxBedXPlBI3Rjr0NJty9KtmrtP/DHZaXyHvcXjhd8
VEVs8xE6KknL6ASNVT7LJU2wONBNWioW0Jgk5ITjxtbJtko2xJ+7yqN/nMQPQ1NgCapWrLTfZio4
VxHnZPqSzeQSLnrspnBj2oBAjg4mqoHQjzCMjofmec8ldAqnj6W9/2rBJULbIv31774MCFJT1h+c
Pc1ytVNtn5MfjKk/OOJdoljmn8ma3fH01cnOs3DBJmd+V/GNR4yP1eMyXLfrkiOxc0afnXckxTKR
pO197MB77OpcTj6oBVvmAYKe5DYXFSMhau2wg+DsUEJgUbkhBmC0Z0UFuaA80R//ZGKWQJT3crP9
hSvqfv7NXjzLH+Yuw3ql2c3Z6ElMiHcRmvhY+bZLLP+JIeWJ9nl1lIPNhnHaW3jQZtGDWr55YkCD
gIfnwLMClQljEZbWeZ+I8l+YMrOpbx8Nxr5mXUpmsEZoCjbeVyA6LJflnUoNXyIhPWL3TBjeKk9N
GWLBSurNVt9bi8AtIdByw3RGhWk/p9CcynUAfeobGrNAb12U5GDPnkzjfAAdQY46sSB0PSOhIEQu
J/FIacAzxTJPqp08j35H3CalChkDehjW1Srrjrb8aQGuSLCj8McSHH7BafIFH88LC59xGI/5wUTo
AmezyQi/xC/+r8S5eyP1gAn51v82A6Q5oRd5M+k8swvo5JL1kQyO+NNtrdyMKLAFjYwoiEDn7Cn9
BRW2lCNMCeBVO8HnTjWiqp05/JzC0POOT6Ir3iGXZApqVvLnFmb2mn9Rr/rM0nNPyROeGaKG2daH
S/kPSOtqVVxJ78f72BC4k4RI12swlxAgzZzQk1cXq3xk0pDpralEndOgRPLZpSb6SV+CWFA1mSnF
lPre8Spcc3KSAMv66O6n2rOCKyKRVCF96/07RjI7uuYgdr2Ia6xvaf5rHV3XH8xS0N7qNhKUXxSo
2ubYsSaeiIToARuMEn/wKaxA0n5qzevg+m2PQ+NVCfq+1L+R6NmXIgtI4P7MvagCUA1DEHFuqXaa
M6kJdN8nNZkh2JPmJQAYG2T+bnRisACTW+yVh6P5vsK3n25hKEjJcCTZGTstxs8ujnqVUpetHmNY
gR4TN29fxxzYaRlGQQFkqXiMH/p6fFnQtbZwPNVHU92TXNL+LPGknAC4foY4wM13b3wNkydJs2Np
0PsGfSivfZOZLJw3iO2mgbEA0Zjov7uu8BcBD+c8WsAxHRJLJxxGYo+HD05S/SfT/QoLlc8kee6Y
ueYIq0xZybOBECURXxwL1TLyGDUah7qcVmmO1/kq7nShxA9h2qAC9FonBf5P2zZoML0NHqUPSfBB
HNtS8r0hD01NUDU3a2YxPfyoLOJzTZsalZ4SDme3tCCp7FqQhb2bV/9A0AuFlmvBz2RJAVel8WTe
TexWa43W0IZ5/2UWBOjnQvVD4+Vf7CqNOsLJbePvcLOq7iqwL/Ubp213Dz6EBV/YGkIfjAT+KkVs
iiR4E2WmDY+N+EU5VeoPRLGGwuZW5VcBlupfEQVduOGmZ/ZhiEKwo4pkmdc1ljnXZrMGZmsDa3h/
6R9Z5sSzbeu3I6mzKgytmz+AzTmW1a4tAEpm7nR4GBAHUgJOJAt1//OKUT/yGk8Ny9fIwNYWqW9n
B8vDPHZE1AD1YPmQ49dm92Ttg9hcDPdkwCQ2KU6wpbT6FvNqe57UAivDz1jn5SLxn5DzWg6RHv92
ozPpVWhY2CDw1qrmbFKugvHtB+Ay+97enwc3fi0eAk0KScLrOzzsri9FvduoEJNip0aOYMY7IgHe
qo+MqeAMLcUaLW7S0vp3hGs2WJyV01dyzw/vl5W6NCZ89WTG70Rtk99xwHdUzifdiMD/GlkKcAqu
xY7P5uCVcRBONEyQJ4eUOnesS0KFMgVUKO0fsxgN8IFz7Pu57X7git16Obu1l79nsBYmxd6CJ+CG
gIha+E/p6UwB9+8i6xWk+un2s9/PlqGYk3OxUDr8fbhRWdL1CvXr4BfHh/Yp4laDqx2p1j0HmO/d
3J6yGwPnPMIoKrmDwG7SiZYoBqEk3t1jD1+dVbXrTYh/cdl+bm7gg1ZmeawTviMM2LSPHsefLslo
jGoO/I99ODam47ZtqyxKo0eracz4GSHvTnU+jPVykXPaOI8OzTqOvfFlFZiJrcRZlkKEkeRRvNN4
aIn/KaCkylI/5yzvh2HkiT/2oh93voW46p8w/lM8hn5wWIdq0+A1jX1y/DXwam6mBcWBX2GcHMSe
DQkuW7gMWmE/+76no1TWNj3VJtEXxuYr5Y2KDeWeuSjpmVjad2WBDCRm1pqWU9pzVPx0wt/Bni/n
SNi/JRMd6MIxGg4Ir9+BSM2fKHA0xugw8e8C3pHTN9q6VAiAXPgne1TpLjN0NTnYr12DLyxCJ74A
CZQyDWhTFcKb0goH4/hUbjzrSq23gsyi2Y04w+Ws/rJB9J6kQrH9QsXT0ocJ6LuGt0uuYTBH0IZ+
GDkLdGPfrN+U/HPlTXh8wlRPCby9+F7sCPAglrsWNBQwQo0kZzDpm52nclq9BIuOr4vUHfdozAfn
5VnXax0SoLJKIpk732Z8LnEoD66LPYA0H09y7nl1Kg27/srx5rLPc5BIV9BoXKBips39wsGu2FDH
a9H3QHH3nMxA8qWJMnG4JGkSvPN6LvaGrY15ElfGFOLNflEhqkSRGUNrTfN3pmKw9pNxgM2gKNdJ
j9O2SCRm4EAiyz+YS37neG+zZFJv5sfjnfnU50uVTLgM7jn2uZKXb+eiJFdiyseMox3f0UoDEjtu
JxVSgWKo7EQY9eRyaRPMWMXNT9woRqQDaDOY/4egkem9tRxUj0lzoNe6pWD+0i6jsqH3iC3jaUWK
AC73IygnU3Ny8SjgYE5YlPFxSQaYZ5n0Md1ccEgcYd4SE9ZgD96HdmDtyUY4NW2+DWepMZ2kGV/s
uR7+eAgz0xu/U1hrjy7Woao/EJ+1eNXdWDjRLWfMCDGeilhz5jf4wBHd3SsH5XVMhUN3eQ3Cq5op
Z9BHeFoYQYtEnpyxr8UFOPXhcHBpJICNxSvWqfwkwX8dYACwunk4+TNNkw84449NruBKYD5TXCFb
/s9CmEIn6+2Npk6z+3S15PUUChXVSpGYdo6pdstjuF7JamGsDQ13iJcRkXnmsSjp54ea3WQLWeTh
VsJ0JZZ4WYSv73+xPgZvWEIo19TEav8b/bF7FlrpnizQKP4iEjMjD0TID0bbpASNyQhLlAkIMQCm
4ugsC9eQDoJ4m+z/WEmg3Q1seSW3P5mQhcGI9wSDCAt2z/vVT+9OOUMjo6Wa2F3WPYzXhPsoMyt8
KdZnvQjCBf0tcgpqpUuGN+uE3TWilhBiofZen+EiwAheaZC7H7Iyh4AkIqXJMV33sM/WUsGPXn3J
2OoYUukVtK9EDroA8vbhl7CrhBxcDgP/boIXYrT2k96XCt0txDLN+5M9K8+pQseFNK9WGeBnQKJq
uMbCaaK/FxFra+MsVXo4lykZFxDyvI+RiBtSeX9ybu7BlLnxCMzkkZOdM9ZKwps3AIsYxssXo0sG
KqMTgLKjD0wUHc6g8lLBfvQKT2RDn7PHWiODESa4ZsHo9bWg/GWx/NrKN0ZIme9CJkSqbM5W7oNC
FP8GQD6IxMSBddiFESWvPkvJCg7QKy0PE09Vl4Q0QNXkp0MvZpFxSf6g4UQk8YR3Hw/CqbAIIlkt
kMzU9BB1xK0DAVPxz8rXOCoQfJ2cg52s4qMrdKFCBUI75KJgOJYwkb8QCbGx93zwEvYHi3NuRweO
4j0niDTsXrL9g3z2s9aNwfxW3XtFFhdVutWW0ZvoQPg2ELp0zEh+ns9Ofv6hLJPcRQius9u5jYPN
BlRvukkrsuJYTVRfJMpO9ATCgDruwU54Cj/OCL6LZcvpEYS4dBwzeEZAFOSxhCOIzrPiqT8sm/pw
gnl2DHEajAtjIfeL0Kf3lWbza/fHbwo8I5if=
HR+cPt/dEPbwP8BUT2gikbyNfXmd9P4che1sow7FQm4m3ifAasvo6MJjsasWx4HVbq+n2TcigiWI
KCg9S8DoHG/1HfzYsjWBK9kccJFL6VNhgONQXg++Dc1ncZZ+rU+5SfNgId304FD0fmK81wHjtwI0
bgaHorc73Paepe9pG4Poo++JTbT53pvljDMY5qWLwq9F+JfJxCiWjxqSooPhUOO52h1G3ZsoKlwS
yk30eHDxHLBE/LAfASPFAxQf1+yimUVKDK7YVyT+xDYLuVEikn+Qhu4lmS0jSWikQZ4K0zRGR5Q5
aMZyYcI0Xo9Ro7DLbfLP1JCYi6wiQbhaUM7/DvArvAPVCxNIN30eG1W1KhMR2en68nTvO/zbJdb2
b52WMAbEsKp+/BCBpLgp690IosXQevVob10Sw3Tm5/6omVSi6sYGnrt/+DkcARJJUA1Xzd1Jt6eh
AbhQjYlK3NjrHqJ0Jh58k5yGp072VCUJy8gaIVg1Tmx1LPVS8XwNmPD0gMh8GnOE+mVgDbQYnuAx
nfBtxawRaaUB3awJsIE+vQyr7sNFiKh9hAkz0F3neDmXg0NUeMZv9Im20QzBkwSIJyyCYYbU9vxk
MHd6X7eWZ3K/nfLG8qKTFsb2A9Rez5UoZAU5u/sdYBc28+dvGBW+nhj/IoyLCF8MTVTlR3HRDoli
eij6f6k4da1/GwtOFrtjI0HAR4+kucuirQ8w/fzz9vSnAS/bykCDbk4NbqeBqsYLSZfrGQMu4hp6
w53gIea7g4RXMhc0X6IDmaSNHN27WdscqC6tis2RjOxPdAzLSa3IX110oBqD7SrNrCIaeFPEitOm
H3lUUkZ8Oq7qoAcKivVDbmWEMU9jSf8vLAH5IVL5ZfPXDhmV3M/7P5dwLM/23joWuoziV1pN35H7
dvKREeyLggZniA3Pa4QVwJ8/MtrxtJ5z0HCwcWNRVRGGeXhs9iDn6+JtssgdY1FAUBvdrUCx4zxv
mTjuTN9X428CO8wWOue3gUa2KuJT4CnGaxWglePMJuy+w/kzsO9XPwlV1Ld2mSNqCTHofzGh6alQ
gQkAb5CPJUfmBQqkWrBruCSTKiqQhE+k9Ib9Q4vUddk4fUK6nNYtqSL1jFJw4atSlwIgKo+MVawl
BHrzMKfOCSw9ITRfms599WL/vTkBlDBnvyLs09STUfzAQMQqX/BvYXNK2OWIKiB4qjLOxA0gmb5t
24PbNktoym8+yk+ntolrB2nsBsvIVd3VWx90wE9CYA1uI1InYu58z7zXAhDhElGn46vCs8rsj5jU
Mel9zRPMMksSeOw6bWMGC9ylZDgsmCm0MmKxsbXeJNRbHrAwvQI/PIlKABrenvsa2aySgZ4U9DvS
mV4TS7lsdchJ01sTcs8aZNVNA8QJCSomFghH4jSTmGGFwvIZpgWgh+l64/RjoPg8jP4Th7V7GsmD
NDQtY2AO1YxxOwAqbg4hnDjhPhr2thouCY6uml7RSuzkTBlaORXshEM71/nDO0vwnYJIj+w2Z3k+
1/kvCSJCe3Z+y1DHW/Wrs9i+r1un8w83v2ziGF5gzvR3estLdcY43GyZUvSUbFbM63AqDoSciG5Y
OsYqxJOEcyVjvUiBUp4NsRKHOnQPG3rh/wSV+tsE2cS4CDA/NwyKEWxgov5MASELZRwrH2es9V3m
zockGmsNHx79M3IXslxcZ+B46pXxCsc0cwSd28IwpMOHHz0A1/y2KY9/C/84xVp35VJ6Z7L9hQin
PHW40YxCkoIPyYpIZCXgqqR4otIjhhr2LVJYknTJ8Y4qVXgDns9vwRSZdEG5SvjU1rlOk6Mq23fS
T/aDYHAe8BlCc5WOEYUmO8F56h9O/46NXFerEc1O66lPztab1yRawEuU7C3rxKIyFwvad/vvY6/Z
/+jnsbdg+SzOYRFIQk/otswDpcsXAvC6G+h6zE/PJn0ceE0tnMRxFvQpWz6GBC4fIA8j43Lfd6hg
j0R82Ql/qW0RHUA49n6EpkNtgcoD5k94WAwEzMEk4vG4nyYd7zFdMniJzEooN6LMzMJjrRkKfNGJ
Ny+QMjos6av2MKNhj+tf8ImXXuT6rttCKlnWNKd65MmhFPOBphJSbJMjWO5YoeZrsddPOYoRB5Yn
plD44gbkhodbGmCkNPCURu1US6bGUZtFCgWCXGO+Gjh2sRpHT/JlL1rwWgWYK9qBd1aSqVpAbW9K
2Qoc4cdMkfn10EfHRh+3mXHeObhgvcXb/Cczp23+MwYnTADZ5P/U28FtOU14aYP7ZHskNhzug+Iw
Q6xoPPCWcWauv1xuWkH9BgKV7+O24P/7rwNMo7wFGCVO2zI/9Nvl6WvqdVRMCytoOSGSNnpMGYV7
ir77kLA9g2ubwIJDfuS+ZoM5joD7+BTNM8eD33LglimArgiVOSQdbCbyrxmVWHYQRXfyLli7dX6P
hS3u720xl3d1mwAswq8ReRsleyexWAKMADzU3yJa4DjRxXXQJlhFZOscSBKjhqCcfPmYj6UiYP/j
CDaEDU0YhYvHPf5lpu852W30Qnjq79jzx65ejn55tHOLIx3yDyzRPePOdwvNgmUH6vZP9HuYcQGA
g8hB0vsJmDt5MqTDNVA5DsPNGAyZBplxS9KxaiOBFfW6FsH61SaqjxGxGU7Yk5Gm13SvYNa6OW7Y
RT/v6hSjWRMFtR9M6qBJvzRBwBvVWr9qptR9ZYG44hU7Hl2or9Qz42E5+CT3J2CN5O8ZpiHj6tJc
9roWwnFxVuo7P8YA5XIs0dews8eoSlzr7kWVMME24SwvIQpUhypveps9NOoAeR+gCU3QwLn3xtcX
Fk3sGf+1hX8OMvhsGvM3Xb7N1L9hKUNAeb9kdDWk0hycNWVlR+xIKjJITWl3XmvnKA5+YWw3YYnC
iYe3lw3zKhw5RVaJJQiHxYqSy7Eia/iPJvciZVJREumNVx9VCXqie3z4ZCIt63XXY7wZKQb3RDGa
yFqT9PvQX0h2hLd1AJvFf86rfgY20EJR+JrnEtJoZXNfB0vIlBav6WpcHi9XN5/d2ns1djWMR+t1
8nne8Gxboc+wACdf/QvYeYnNp2rPOJuCkG2L9D+cxKZpqeOH2MYG3QzT9zciO6iMwFvUvOwlR1fv
KLQQjpxJ/eydqiAe5OBu1McyZf/ldtb+OT8jZrEcN86gCOZVQbIqqHHL3A5qGcROeXvW01QoAoJn
moJ2xsjGLwrUZTMFje/7KUweHIorJ5lFn7B3ZqrO3tvSUCxb7KIdW0aONWu6fNVDdsuhsOBjDX4p
GewvzYx/3FkxPPXSwemoZTktH2ALLjNE4+Sv99+VZcetcVB6h7tji9IJP1cFA96XnPjYBDcJkMEH
urKeXwBQd20EQHFJX8ZniSbAQ9kpuekkvNJ7VAekZe6M0ssPgBeAq0YawjXDsB8N8DILCw2Ug4KD
oTroDwl067LcOnA03uKG3Gj1Fu3yTKU//+i+ks3/3Xu9ITJ7iCMaf6095iBMZUhbCTBU81wg7GPo
4zgg6S/2qmDqEP2SFxc6e09jh9c1TLYtVMG8N5NfdwaGm+2KgiWlcz9YGV7wMUj7WtrMSlvwbq/G
j8wtBttDYcLaNvDM5Ip//gnnRJKxpwaSEGYuJjPmPOP2/LC0QiwOKXvJ65RRJid0OvErPJbSPYSR
zwFrzPFjpuTxzBivYMPCAOOdZ+yK8xCX6ILY+RdlluiOcrZJApT71hcwZoqT/lpQ6NQ2jUw64lGt
YIatosIRmT9HTuA54Vfl+Pz0bOERFdSVsAgUwXopLiItdXASInwGcPTMjAR1TPXF82pnPy+PW8pO
HlyQfTeo1bHY8sOU/VrywAkjE+RdUCNMwZCzwoF+A61knbAOVj/50V362JfoOjW7hjxxCXS/rqlt
pEvOGNY4WtvDfSwhUo8YWewkJHtWE3txVRz/vAV2W2QMynrsozq6W6McYIgI2kNxgGegAXOK3K9Y
4olRupQQrnIpai1dRAWfZpZcqpXFYNmSpLSGUILAT9LrzDRuXIgAjHueBPT/R+2yAwWTc5tXa6Sf
d9tIMUHRTU3gaEld0Y/a7DSCVRiuZCavm+LgPkEkpkrX9QVxKI8NcC+98hsWUnVB8I1O/OkLM3JD
hsNB14n+jcOSR7I1RpSTBsRU4d3dGhHrHZPSRm5c8LbNdf2NJ43LTK5jMV8OY7qYMHyYRr0lCqtJ
PAiosQ1MoeOM9o8Nw99iChD0fnc4fCFKz2kktYRG2f4ZiTzL4I30fWRKKEmAXueNkfpcu+jEzU5Z
6bEleaD42Wq4ya5Y7GhXC3fUnyWUKgEkU+YkpFh8JH6ier0s0zpeal6qjAmS7ekfQb+1gw4Uh9j4
ZlPQp/+rZBzDUHNlfOnxewRXvWPTNB7hMTDaWId7hgrlYoYZKCmSYNo3noFIzLqlw2prb/iKwZh2
zTsjUM6I0eYr23r/uz/LTMDHR0WKJIentCFlTOkVgxv08fCIvCJ8y4BFppFLVFwUpapTYFuKmsyU
cnfheqfLT3t/mxfJVnjPweJwR++u/nzo7aU7EfeK6lOFie9ae5OoCigAfzzHJawW9fx+Vh7aqgW8
bkIB1RuLju54NOx9EBIqRkL5IKR6XzE+xXlNXEyzNysnAUSIpMuYknrPJxZFw7Mw8a2ezvgNS5NT
o2rdLNeTlhM9AckV+jYQsGSI3z3m2GRm/Qz2epsbzLTZxjscnNlvKwoSqgvwaiS+jkPHPMkRdJZ0
pKkaRo0WlZRhkmg6oqptno0eocNZxzdmkCUy6qyRQO9bMZB/lyWYydzRwmWhQsgQGVBV6ktogpBP
0uholJwL7xxMw26pb93xptdMBiQc2v8LieGBoFBtotzLjw301MjXYmWIg5/1JRkpvlosF/fnje4K
iOqNUfZQSvRJsbtLHTZJ37kH00SbiKTQoNaHe2YkB5Xfj05jfSyPyjo6a5YZ84l1cYtD5DORjRCc
UU4s3AB6IIN54vto2QCpPCOj1I4fKrIWM+pG9E9iGONyJvFPQ3zeo9xutU3/buzvkZ3Ts44xcJqY
H9iLTOEl5THgldiOE56JXYYVObNBPAFZTYxxRDXAEUkSnFqdsGWJ9B2atCrPCi3oRmEqzq311ltp
x8QdOUQeN/x2qubdo3CWmOAtcydk26MxFLiKFU69ggKtpwdLZ8mnNENeEsT1uUmLwR4x3wlnb+I9
/ZjekvWdSo200xbI//oPC53MdxTsTDZPUIQ71UKnPMHQ1pEc09MazwMlmMvsax00/a3MvYfAWAka
X1oW5TTyYZrANZKq3m3rOK3Qv+77QVYM8/nqVtJvBkPSI+p+jFVR17hvek0i3R5FaXmrV1qh+LhD
Tdf1xeCrpNJQovdCSaI4JmgNZZUsCvfK0nbzBQtWQHdYj36GEzeemfBkh4WfDbxug921vl4JLeQh
f08iCHyBw0Q4yl3i/OYP0LJe98eDINBonrb4dhHTrRuVY942CA64REtjfBZ28DnAKr9ZeY1YHFre
oFoliusI/RmdfGY6NOOJzCWhLuQQX6IKqbxwg3Sqenb2sNDQLv+egXF/2n7NnbM+Ut4NDVMey0IP
zI89Nkh1QJsiKEG2MwLBI5cMNlRgVm1+f43JTlXm3KeOeX6w9r3Gy3q8195cEh4TUkJfUj9uiSb+
KvfVDogXDMc4exZM3Dz/g8C7AL1+nyi7ylCActwUuthUdwYgCDH6ALYwhgjG8Ap9TINF7qllJ5/r
W8iONzCw/HYCd6eN8Yj+Req9wdkO111roCF48OwKoi9T2YNLlW9d4rkTeyt19XA8ZHx2ZMmJmjgi
1wM2apE9b0JQKwGiugdG3A8PXU1xAiJ6byRkGgxC5kUOQbeVpabr5cCpV9VKfo4hagQh8p3tnl1v
A5g9RNXhV5r56JToTNp/pMLxEyvLEp4BK7EOV03SaaQa+6D7t60Zxc0zxc4O4F1J5BicZCGA0qdY
E9GB0x9yL0d8C0IuL2EQa4DvtneV5mV4EBDPIRFaMRS9jUtewqPVttyDhER72Dbl8rdlpKenXfSz
kIY/TarwxE4v9g2e4TGJ1Zif9Bh8yialhtfUr8i=