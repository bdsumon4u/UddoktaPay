<?php //ICB0 74:0 81:2257                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvFkqmOQO2Wfb2v69K9hxYxl9K73+4fbc/47jW2wAlkvPPp7MtjPPt0jtmlxtuTO5o5Ar7KF
bEtEJlhyHGHwV8WDgXgCJBOITLPBCi7TmLj3XEOloOUh7J5MDQpdwDnwcwvT6Eyw3hCKywnCzLVI
cWAfw9suV0w2miBha6+jy1VaDsw7if1RfY/LbdBTc/GKYqOVmEILxxAKS6D9yYfdXjouuiX18b2A
750c9xzAMIBjOmxSwgIPpkHwiWtttP9EM5Cacg5mFTNtI7yLyKi0TXAmnzqirqdOyETY316If2Ul
e5Z3Xw4nOilby3HtmqDv++FcSuio6kagkmWutBZVJOC+wLAeeQoGWKl8yDvYvGDzkENWmaOGE01Q
E/pADhghloxtUQsWWPwfwG88theSQ44Bjyyze9GS3ZS5j0GEt7fte5id4CtyLTLItKLuPBkohe0P
mZ/BnAwgIlxS2pUrONF9FpC7yV4DNHKSh9T/L9nEO8Q3laGT6kDNiL8Qx+fOEzVRfSn0iYMMYkdY
YH9IDU/F9GLjOWJp5hrQUXHbqBCwTY5Q+T2smsO5KoRlvEeBfoWVje0uUmqasgSFdn0QR/wFpqMv
CMnXjB2lqB6Zti/Xts4lJ01IKK6OTHyYgEnoMgsQz7FAtDPHXG1AiSMz4LmSRV9+5SbyX5Pp84Ff
5MfIOIY0jEHi+jbAinVP+zP9ujoTjPCMfuYOdG3eh/M9im8m+Spfy6+hnmPWq+4TcLgvrhjguMXW
PN4f2qTpNLz9hD0pI9wYn4Tg6XfWeoJ3hRMuyuh7NAntq7i7hamWW/PyKtAg74Cw7dSUVf25/fzO
ynAmKjN+Jr8EEowvwqt5/mZVUUol0DdutMkWyz78ZOn/eka+A4kluo8Ki2LCBxaAEX70Aeizl+b8
9NAR8Hc0WLMxWDQq/dvAyy6NqY7IvxdGVsa1EiDOoaXKCFZ7qaF4HIS6/4mE9pYRIe5XA7yvwZQM
xc/WcK+IQ9oV1b8kW09QCz2nQfxdVVi9MtXkGFEUyRK4PYEHBc9SJx0JSMvp8Ila5KC8IU9dcsgo
ohi9Kwefd4gUczQOm8QQMYoBrsiEvZchCOaCzbL/5v/025J/cGQmYCANmzliM/ZEEyYq4SGNARCA
P8IqJvhODgBNbDIYZsUQ2P4q2zKg9rXgivvLuUPURdcZWSca3szvW5eDqdhNURnMq7yIzw4HxuA8
GKnQJG4Rd/lO/QCUz7J7y4ZKMqskNyMmgxmkp1oY9ytiTGlqsgrTnb1elQEhXkQPHg/kG9VOIeGO
gjAmBdFcWSd51ebFkLKzDGdJGC4atJgNtkv6z5ksuEqv8qNKauEON79MMoR5Cv9t2qNhtQKGk0YM
H7eBcQ8Bkn5oRlJO/tGP/vlaXwb2jo5NWc38EuYjaKGL0iav8tmgk6Tv4C/Q3QFIiTeS11Y/QPC4
m5f+87CTb/k6DsPbQWv0PzSQIxqpjg7LOafXV7uEZjwDtwGtzMWsmgytxf2sUUGkz09yj7OQryYe
VjMLpDzPf1ETFYgs96EiQuKCwfmUk9NZ5sKSEiAsPtWE28Vf9fGgK9AymiJY3WUX3xF0U2OlbpTp
7RhAaNlyTKfF+C0QvRG8nDfs/cHvTu+u72UmLR7XK5CYJnTAt+iTilLYnoDk6jhTaZO/BN9VI5/4
Ye0J0SMKnFK+KOLBvyi7R3qzYs9CJBSjRWvfsjOSXq6eQMLn20CoEK7pPb7/irVxOVXbr+HvWTd9
2P9mVFkF5TMsBbxBjF6ljuf7abWqFqrU//0qkyJru4n9aJzyxKvv1xlZqQiC2tMax7ui59bTHqGv
DPzW7qongUE5fm+0uDUI5LJPEbHqZ6j+J4mqYMzbfpyn1LOKqrMV0EqLFYvwVZDo8N24IVBJc5vQ
EACeKBlldE5d1mqtjixAa5OoN5TIryfSHCRJJAnA4GeFAMOme2QxypPKAMIvo+JW7xFvWIoVvCvK
XdSABd3Vd8HsqcRWXna61E9NXdVZMVVuyTZmS7Aw0t5wFbwADXlBjebovfTv2QqDyZer1KzOI393
+WwOsblAS8kBFua0Yo751l/2d9iWHyenWvNR28rRMuVQimz7VpSrg00802cO0EeTQW/dCbq1VOXQ
R2EJrrjb40uhuWGx5mYkEe2ZhMFAQ4CxEHgNTRq4vGSPAxEfVPi9Hp7CLD3ri+6K34LsdlLTDOG5
FeUKaWRThdw7p7s0gNSKQalO/+ACcdn4AS8aenmrFnJBSLqxiUq4Ybrd4zSDjcjRAq+IT0Iv1VwF
KX0qxmXAxmkvMH8d8+h/BNbH3meKxuEc5I/DAQSzGCiwii/iRiklNUKoJkM05OAP7ibcqtRu3wI9
eLQk1WnrabpXk7LxMe1WFoUZtcZyw7P1svr8fIS2K98+st3eMzktY3Z9+A01wqIhH0demBbdRNiX
l5PPz8QyhkLysuZoCKDNPdR9XScSDl3zTXQZFfom0kMyxZq0ibsZD7ZF4B97Fb7A2MumePX3qJgc
AmMiE9Io20Ra1zpTq7FRZ2GiTd96zYGbtVJCftm5wpIGILEip41dNK5g/se67yV2bUnwZ+Nsaogm
JexkFiRogi+J6LSiuzC4U2ufrWnEljAH74LhQB45+WllpHRb47x03TJ7u0bI+ufoNyQbcbWZcDQE
oRMxA/xKml/Vmrm/1YeWsGXFWCSA/JhnBXZF+dMLI8AGyVmYJmqHQzC/1vtBmWMb6205TCM1sqaJ
PY7tj42/IGVEfhAFDBBs2bzFOoZ/pSfCGwuhDqiXQORts9FOwUYutWE8pWQ/UxdDMd7df9uHzAG+
AY7QsnGdYDgrCgD5PQnBfgNybu4l0KT8I8noFyzZeo2L4Z30OGVR/ZeJvBxO22wBVLfSNHwJHb60
9vqUDh9649iprdr7GorVv4ce0xanHera4Pm8Pf1HvW9OagtuIU1dO8VLkjHA/UzZjKaUekP1Y6zl
5zxxCEYXb8FsbBz38ussJ182CyNpsqPI/G9Y7IXQLt3BtAOMTyy1CVPX8wqFFPjvlHDrkhXvnXPo
sOlqWvSI4Sg6dH1CRm6XFw8e1e5/OSMZaoNXzPHCpHitZ4LcnSapH3BXoxrAlKU5O06PW1vVY53M
wxJSGZz5o/APY1S9/CMguG/ABhktG8D69PyrjYF0qUcoGMq3/39445desXBt6Ydd9awKGivVjfto
+9HBdCGob7Deos/OJGNBwKHUZMK7gEb4rhkBz5gbG67HulzNNQlO96ACixM4088TjOb1lJwoI6mi
6+4w9oGur216ziA8Eyp3RKJMGT6VWtbqpxXsS2rUVu3+QW15P8EN3Dh27UBN3B2B4WWcnGOvFxNb
gVBmYB7vPx2Ig+mtUGw3tvO0R59sz93Q70FtIgqdHHuFEa7FnBi56KoQ3E5tGOwTofW+DwhYcDY3
5jYUFwVHBfnZFKxL77Eh6ZJegydX4R5wsdrpTBbb0RNvwS5WqlsXWEePy+P79/ApHSc9vpNM1DAJ
WeCkLvAs04X6TpOTS9owDxtOo8P6cfwTssi6aO1h3y9thp9RaO5Ek0k4hrB7sb8miAd/jiYAN8y9
g3gHt9DzGFpSe84r1/WUKoa1uitI6pb5N4EFrs79a+z3Yl0MVjDPe+BhjJI1AAf8G1nlZY5od/8v
cysQvBdXfxF/KOzB5uPo4eMGWh+mFQT5JzSZFjIHai1amwg6w/ERgHHuzhL1ssu9dUEX6Iw4H2Wi
qvqd7fajKhmMbhBCb7RfM/h4IIZw6NYV+FqgnHjZSw9mMkZC89fCA05vcDNvquXh9KYr9d8w080A
fLx5veT4Jh2INOriRbv4PJviqYp/nhDP9W8ijeBaiaN4TyNfRk2WKf5ZXCCiuIjXor39DXse982N
5tL9+aSwP6P1WrOYv03M6eFe6jwX8IGnN/HxY2jlxEC4s25Ucu4V5PlE/m1+i2lhOM5RUoIfo9eT
cDaTK4uTazIiWIu78+LukEjVEwPPzJ1BGVTEb+RM/TE21ZRch/Dczff7X8kuP195cgD/IWg3A7oO
GB0pMXwLdd/5JzY9JsY5cyjNoxVtzxc1f6D3iIQU+oWv7y5fL3s+fYpEo690o+phN22PDKclHdpI
C3dRJYfuiMTvAo8hQ8NA05AfvbyMnMIbXLhOta7m0yMNBDABCT8q4TJ93rpOZeoqbA0G/bLdoxbl
hyPvfKO8yqFZWjWZXHZEy+naXheSsytHr+cydb2LKjFdHXkRahkZQRQleEobSyST/TkSbbAfhypC
SxGiywLnFnMkgU9A7QKt7NqFUhgsMCbx4rIihuYu48ex7Xx4VFGYPI3eK5LQvw/qa070KcfqtuWA
GogvEwq3Y1e81BwN6vG/toLG8z9AUPUasfRU1l+AYvR0KTgeTXfIHR/UHoPlh3YP9ueKiVyXIn2w
tdc5MLTnbGUyK9GeqJsqd72CnmOi/bL5sSq9g8AWn0fyWTRVydfc/PtvwBSTEmhC1l5s1GsPuaJA
3zd2bQupTMSC//0kxC+/YKxRn/mHYhCTLekGodgajUQ8Oq5umyIhTfUoW66v941ySKeFQZknJi2r
gPOgt6uGxTTXHJKAFMOBaTrza6f76vFVMw4MKx9/imkRSgSCS4Wx8/E5R11mIMXTSJsvrFsFULs3
grRf3dhdfkaGvuTAyX5rT28g97YuDIjvmD7GFxQxc4PoZCzHbBnaRreTWcHm3oezejPm5T3l8Ir4
0DzXjH8sfh9z/ADbdHwNhTJu7Ty22Cm25wQ0kcvnNJeom8zRV21bzPBjV9/gyXqQahnBx/nX8JLk
pGyS+M8oNWiFS9YAMUm62k7YV24/RSgT7djc45CbQ2FLnuXT3qY1l9SMLiN1zkuwJa0hR7zV87Rf
pOUN6rBLbdFFn6xaxhHcMIeTdOP9zMABppcsAroFIxqlzDKmcBQo3IohY+nRBuaMuOfrnk8gfAwX
tmKFjmI0/OihBi7aLGs7W50rrDBaYE/Gvc9Oq6G+ycseKznEqQIDUq4tCcbrZruY0yi1VSyIYBT5
SOzL2/Q+2ELDZkIodbz6/kt6OrqT3SugLz0nSpATDCLqowR7rmxHDGcD40tl6FveK95uxdP6tq6h
07jHG9uEvmRsZs7p+08royu4tiCrUylSMBmDiBe6h5ZGLFvXaXvTT9Xa6AusCDRsRcPnftoVksE0
XGjZ1zk17XYfI3E3r7G3wcYhSBq0ro/NmnXh3SWDWDqL9cAlODsIlyxTPjPeHBVJEOIVEPASEsea
kJwkwypFx3LRqYPUpngovVZLBc9VatwYrYc337bRg45M2VsPSWSxagyhGcF4KI1HzKotYlkKnzi5
laMeQyCEUYEeDGxFK+L6S3Wfd27/nWHxQIUA/1e5O1j4jq81c2kwhsR74Ij7LjfilA7PH+fJiLGE
TfO+fN6nE6UKdbNpJqbW32FORW9QbwYQpwcIKGON2T5WGY/b5KkpDbNFrW===
HR+cPtNNwzIXFj0RosH+zpV+UDfvsjCDoEz25xNF9mDSiC3CTt6Qm/I3ZneYDt3u+D756tNjTOdS
0AUhHa7ipX7pZmztWjDE1CkYD4foVgF40xToP9imeMyU9LBnHAP7Ham9SMChv2dUwNt8V54tQNtd
mlwFs55y9wE988e4x7cp0wU1Ts2kUjEv3lAhWEweEQA6m869KYBWRNPvPngDYl/j2GlpDN21yTHN
tGj7YPvM+DoojdnY3ov5aJ3NswkraIcuG+3AkTIWBAkZwhYt2QuV7JKBwhhmjCm7GIAB3IIqeOMG
aWUvVT1KrrGvj7Z097LJ1+XYSCmwMbxkboT0e5ndww20I2TcRfF3IaECz/6P3kRpYg+ZJWxTVrJI
A2zInL9DL49IGr6yQRH//9dh2AcNdw1nZ6vnMN+fujBQceSYTJaAfNtdPwIzfd6xjxbSw7G6J1tP
nPNRNJH2h0ClMmvk9vs6eBPt12ggPHnEzRl3b54XFR/rVkLB4asLi6zqNR5zBbnb//OPMz09nkvc
v4mTv3HUx/XXbmwHCyZER3/V0ShANdPy6GHneFXciLvoXSM4aC/jU5UBd/JXf+YaKXUKe5V/YTOx
fdklEPLyuInRP1wuJF1qGmTDhHcz6kxTGQ533LpeKpEElQICb8I10RBf282FpHGFZ7u6rUzRBjJd
IdoYfDlsHl/9fvmfTCqlgAigTLYW72uhVU52BmeqFx1AxJrCKLxio+D3UKERSxgoDLHQoNcb6rwW
qE3xpNytDY9ViZCZqrsPojq7ZDtAki2CppueDbY6B5n6I2n4dk/udlJz9sRwJ+OcMDmKZgK10kIN
szyV2Cld2JZrn70t7T+JvK9VNxyB9RxBaRoGiSKxwX34COFgZODUwPSOdxqIz6Gbj7G02rG1y1j0
HRjTjpr++sZ+/r+HiiiWfBpkX5cDBXdq9ZNKZ9CpyNxO0/18+n1PVoNlJzAipbCg9+9dhlrMAI9i
ZqClUQEPoXgIQl9gOAFgJ1eWTA6xKcOl/SnyLuT2pUgkmo4c/yEpT+CbjtwBkUr358aF1AFXLjTm
SRfugkZQUcEJzCxv0W8/NaJcPJNbMesy1tcVHYy6dTUI9FoLRAo+QG1mSBDgksLM2lN9k8qtuxe9
pMaOnrOzONPNXVDGvhNe1HzdUhsCCOYLm+GhBB0Bepd6xus7d8wkuBfslJcVcVz26TG+2v+bjpO6
+2EiE2GvfzaVmehUtrAMFW1QUVZ3EtqvDcgvW2IQBoaoCK9AC20+CeUcLfaAnz8tulfpbqx/lTpt
Gj0JXGY1+HL6e9uVIP1B7NggeNm9vFC+eGJoWg664HSBVwHAqhRrWR+W0W/vvQbbrOxuWB4Isc2w
qEfGHF8vlGPwQSidH+z6cYpF90ky+3doW/zGvLPqi34jAnABiimKt0CegM7NC6iBrUvsv9g3Ep5G
Rzvmz6QkvimVdmPl2VpwPsJCgOI3KVHpSTWgjf1MLHgH4JtJHnTaLQfdWSW/tIb9jg6EfuFR1mEB
Ab/a8d7IcbwOX/vkTFt9iSI6e79CpWhyYgmq526Q24A6IMOZ158cYFFFvCL40WSk3yG4PP8+Hv80
bKvngDfmgYYxu+VTdp/cmbTnTWojpl53GpJLdutFD6/bCn3hY14qGvB5HJVInUUbBb8NRoH21dun
rQf7mCbHB8r/HLJZSxKi5A9eRFHZs1ot0bHjnvkLvm331zVR7UHZpkwmPZK1C2yeARoGYaOtmyBE
WtN5fAGBFzPG5liEcB93wxeRbTorA2U9lo09Se626jkItHfm1t6FbuOpIC634VVJYEeUu5nu68AB
dSUnNUgDt1keFdUQdy0n9ydtOGM8WL/D4Zg1eY/RNBP1hwRfrrJjADUf51ZHN7AhSPHorgRlrdA6
akQ4VPsSIVIK0d3xi3Ly3G0VHdm/wWS4lRQiakK4V+l52LooHyvvuhImvmhzXCz1QiwexczLM364
BowG4BRhEemfCYuBXRcgx6/zZeq81sTnotzqN1WIExmBZmZot0qgKMgaW1nhvFKCizQstNe/JlpU
c+JYcrYLY6ZYYDy+1nhm15shFtLaJshvnMPrg0FhGtz9InXpU0DiKoZhm8M9yuX0I3vyOAxP0u6O
lvCdytYfHVIPylIJfNGbFlajR/LFPjJN4IJOzL9bTLfIxbiwJ8S17Wi2AZE4m06T4itOHiT5ooJ4
v8NMl5vBM72gN2bu2GkV4bDz4EDtG8VCgK+MoWPaXjXivk7Yiajum4bw7MKjulaBJ4P7KaJU/uuZ
T0n2HSWRUoC3CWZGMlOwNeBi7PkbOm6ynfTZl4LrxnuEcCdcaQy3jv8j1C1JQLJb2rGEHDt/wT6x
w6wehJd0JJQE3M0OqPC/cNJPGOsBl5pQC5qYCjyOO9kuLu7yMX70bj2O9DK/bKsYb43NT+hEj3CD
Un+OWdUgFxHt2o+wEvCPD/4DmI2ub245gElt+uCd3W2H/LSSJR5scGQqulFXjjx8kXx2jcAmuwaz
NiWGQHJblB3R6Cnp9xi/vkNHhbK9Fwrox6IdBUOQz9WUTiZpkIM6vino6blwsf7FObMiQywId14m
gHS16EXrc8CwARHkPYdEl7a9rf66uisEY2deIuL6Q9k109JdP0fJWovGtW0FZPVeN4QK+DBSaRvU
60LlryaBxhkVehpZkyaapnhLUuQcefF/4Kuf9/LenvmPcasn941oSzIpR/qi6rlvH7jP4fDrK5HQ
yZ+mEMicfg4R+OSWAblOtrSeWc/uRV53I3S7OYnI57CJd0BdaOBj9YoHlbEyoFOTZZOJQZ4cX/7e
6yPqHWDE36RCNu8rN0/XAIzZcot9S9YtX+A14fYLUKkZci26o8Tt5959cWYvziD0uWY29v1/Mcmh
JW/nJnY9B1P9OhsLLRni6OQ2KSBeO31unUAnqg3UNFlDbAHjYq6GfoQjkdEHg9V5nqIDa28OD8sj
y1A8KLO5CErA9uzW0DVw9mZKruR41KE+BzvbQlE/tdJssPtpgOlGmqDXygJ89+b/PTiTmJljoB2X
w8ekrLw0EUS4f9fD43eB/KxP4dqedp+t943uGQZxu9P9d4gNFbAbMeLMa+YRQcUzH0SrvCoQfRlK
H1CZ8wS3ADOBb0qUkRGtTy03ccr9ytDYlegTrQho1TRXzmywNOlrdNecXWIlKIo3rNrykNGw+ZER
sU7uq9nl8Ggv3x3oR4sTcm640bGh8cVMVDKJ2Sor3lxb/wSb/BCvqDt2f3XZ9P9HtRW+qokP5hwP
LgPrDLk0BHgaDM5X3Li9gF59lIV3Ct6694MuOakrGpW/sADslXXRybHoTnsU3iKgY+eFTvlPMO3I
cBQ3XfqFS15aKrUxgXc8kybuzbWMbUsZyf2C9qSfT8LxRRY1YFHFAKUGmAkN7VKb777v54GF+D0f
+zwrdF/4lSji+OMtfJGZFwICCCzvqm+/Celudt1rbaxxsEnZ0gPmbmKm6qE4oemFg5j76yBQBjIa
TddHLzly43MLxEsEs3Zj6ir/mL+y0IU6B2z6qrvPqybwwRgPLCzsqRZ2aXBbtHA91n/pkTb7NR6x
5LawKZWBlh8QWZV8tj8JXC2JhPt+KDcuS5cBru9SMdjeGnQjQFBv3OV0j9+9einf/0ZuLyPP4XUb
YZdPHCigWyqaUfsvAHsQbSIehr17dsHs2+6nkxDmv1UwMp9Ou/21h2jRF/VU0KTLAtq/0KGSuqS0
0AZqvvw3McxpksznQhfKDLfEWKIzUcLj19dt6MQfQvcirGwcB68Qe8ehYftt2YLaPAzfQNTfGFpD
xNA4wFXY297i4GU6fLfol7PxR/+kc6wbeL8/dqDe7f3AdqA16Hcq5NWBQriSZ5XWca6Jp8UpB/5i
Z5htyr1MLRvcTHElvsw+OBwoScT9hpsw0h4MqArhrlUItuOHhPe0RJLqAJH8Sl0gGSaR7x+wT+Jl
ttt/tLqafwZkYlMzAUj1+rcCgpBrIOGEiCckbQBaJ6zIHlwIkNJw/q03bzqEXsPpwSX5KT16MuKs
r1NSo3TRlMHnUyaoJrGq0RzOG6GZBMUZYV5AkM9Ue8S8bZVg9yeNTlp7RFM2mYNNmB1MkFBuClOK
8Yr8L1oWV73xNGrd+CNGYUlIM68koLQHeVqsQbA9qMwEfLHmX2eq8eI5veHExy5Q4ZCY5H8a4QRh
nSt+SLaHxDiQRPeW5CpQmGRkLSHVxtSftJdMJs0v+faRZZVxKEIJVsNIWKt37hL6NWJNuEhbMqHN
lj8zHQCChZUGnMYNnukzscxiyrVJfYQ4koC/xNRmQQ+dfLuE9wBPXMQ7z5a0J2YDKE2Pt3/BDvTd
3RS4PRvjvSK2GWTyn83cy474ZFRlyswmWuH+uAPAuuB3yxqhI/MxYvaXoXAYe1Wiky06spW4nxpf
XqldRyPb9cdLg7atBtBUGmFZ4rgkbav/YEaaXVtuDhAqQJcPT/QqFGUV7wgJIqpKUt8VuQ4FWwaY
00NyXCCF8mv7AxKrBmM69cFvYrsJtdaT/a0tim+Semw7TcH6RSMYjPSiD/8qvzESOyG+yU02ugwL
yAwlpbyvpO9mn4TYYJYf9D6lHQT8Yn+3NO3H7rd/410LMtKhvBaimyWf55kYQh+kezL7GRf4E219
iL5AAR4WjkGN1KsShpqFE/AFhYrGPN47m7XrPdR4lb12AIpz6ku+S2wqNcT4Vcyt/vjsFZ1CsaCF
674OiPyD2srnk0QaEPg/SHj0tOzHfwboMCSXY1p9Sbav0I4CbunPrUatQCFEiS3qmBx30Sb5gWnI
i3CINuu2Hrp26wwN6lXYwr0U5O8AZU54ELaZyCJTw+wPea6IdvgcdYC9m839iFU+ALmSvjzhZVav
UNxsSVK3yGBhWr3Sap1Y8oIFcZIMP4TysTx202a7SP+QTRcRFI9FV/7t03t0wu4528e9WeUVXsD2
jXS0ds3RguPmopsDnA6jDxNmfyxQ0xNn0hzA0nNNWHzRecMIdWD20KFI0yopWdg1QXYTM7Eij2uj
ktjeadj4yegOGxXBAcqkcfmXC2TYDh1kSI31scBCBB3mdHD2amT4VSv9cYcfnWSaDbnoYhmEQiHg
4KJahrj3roBj6W9FkkUpJPHU8ozxsaPJmtd4K/iGQW3KikUIKE4x+NQrtwpZj3JYaM5f/bg14cBy
bPDMRCStG4hTqkq8QFchJkoAPjxtexHT2eeS