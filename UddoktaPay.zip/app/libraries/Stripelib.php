<?php //ICB0 74:0 81:22cd                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt8rqAWJhYYFdVH5Y+9MXOVsmKWsU77V7ftFMtUjPXzBHK65ZFe7Arpvn5ccLwNR2CiRhsTo
9VF0PXdGXiHJdwkN0CWmCHEYgbH5WOXNHx3DPXKvZXCujJss2yin0FlhbeB1YGvdz3CY9my+j3+A
/HgVKerQVkd8ZdwdnBnDgpwPJQrVSPrRDqcSURv9hx89HNUoCnBdywxDBa0aHcd78en4f+78zpdl
0PP/UKc4YEHhhoqlB8A0gn0oZMMSweq2iWbIkQ1/CPhyJ2eCMLIw+mv0o7/VIBXpz5957GCvuK/T
BKwqA+nIf6ls9c+Q4yodkzj1GFmOCIkw20jrn1knmAOFMnY50CJmLu3YNvtujLCkNmPEXEDx10/m
JtXXu7q7dVFTUUEjL2bM9RrKwSSVG1hRPFQVvVhZm3vwQmlgZ24pguIpv1jA2uFlbWZhB8YY7r6d
iKLGn+fX5Y1hOX56jxUeXMr7cWZDh6v6f13Z6Si2YyHQYQJpzv8qKrHwoH9wE5NMrBqrnlxCx3Gu
fKwv3hmz5GtouCnKmVxDBl1cezWzVRiuuLUVWQUMcVUt9uFcMn2qgqBWBqDA7Fu7HRfbOPSF33XF
L5rba/Fyzl15ZFBT1VnLYjkxZsSOPBqka78Jeyb8l7EWsw0Vw45mKgZoL5FkG/AKhOyWmEeCFkwF
BX653xRG2/HAqTTcySFR5oApD8vNFUtawwEAnUZ8EfLZYgSYokcJVXw0zE5h/zAabOG97ugzf0De
NRLP7WiFtzO2CvsP0m2SqSXB8x8B+wAo97Oqz9BJHfU0Q1f2UovKvkW8PUQgxi2KvioMjDeHYGZC
yw3LTMx3fyaU5vNCCmZR6ZhIyG4hf+w7v6obY4bxQOk8bLmRMGL9CAubRWKZrCKsy82soDRxIYfk
23VH09SNgae1hYqNE0XYvSiscw7En7CpP/FW59ejZWf8CeYgh8d9xklr8Ym9atSL0N0gdd/qrUtx
Ek8Tp+LL/MT0wf4KqY8UkGEDQe9/y7ACh8TwiNLBXbaLOUMyUm2DCZClcrxZXQ+OkoU7oUgYPu9Q
sdQXPwYVnNdiTnWnLCEjo7mTZ7Hlveq6BjevOVLwKDIgZi8+aZKFOqNo6K8PKE0r154YEG6C9lKh
r+QC2v4StekRqOaIYgVybfQLO5O79VSNDKZhYPPxAfKqKVdRDEjZAAiZrxWX4a71UkHawvkFvZtk
YGsm1e7fb+34gEpagiGQjXBacLinZmLwit7xJjm/Lfnrg8AWuRDncbkN6Z37Gjsqaj0X5vPkbap0
VJaPr+ddyydasiMJWWdcgLZyok9j8609gyb16IHowvyzI292HgLxr/0AWmFAy27f3C2dkwHmu5ez
AtyapnVATGRyJ4s4BUOm4UksSKHndrNE35Bjj8ihyrCqyd0rC2HRoPGZ2S3jhi/LRW/5wtP+oFJ3
j1Qeif4x3nHVaoFMLd6V9lth6Izt/3dCE8T6LSkDQdAXeJUuQxC+MmjxYske3aKmJT8Mkyk+qNbs
V3lAL+/x2MZI8OJcgXANNMz9qucwioLD1qECHYJhZR8cTrbrZXNEtkxxKBCWBNUGr6UIJE/EI6nq
Px+mDlExvWm2WhFRmLHdk/bh1AI6K6MkDpMFDSdqqe6sJ+HPqDona9h9uBGPbVl/IPZRk9z9SE6x
lu3TX8C4FqLWg9lF9yqkB/dfCUM6daxmIWxr55LunIBLFbM25cnLXfqe0faM1V/x+uHBKx6vQYo8
Nf5cqR2ajtDYaP96XS0Tjrwqc5jG1JgKrg3q2S0oqhlW5V4NGhUePdYxphI14C3K/6/6ACDtTbja
0HWb3mf58fEB8jvwfdqiTrQ5GyyHZ3HEDncRPYOiw5o3ooKKdtcTXbw6n/F1DCUGZzrc1yICtRYP
NnR49W/aKqLFaHL+ZKBC8R7nHmyJzph+/HBlqFO5zWcwgNRhLnghfG+5lQ9NfbWu0ziDQZr1mgvb
HOi3YajJZDWxKfJpsx3Ykpz6FYtWeawDRUNdGxye8m3sLbs4fnBPfGBRtgSJG88mPrTDXYu58foM
1WMrEEUHr25xmPPK0ggWguSREfT5N8vab/U9ShwQHHe9Fa8snaFgnfe0eo/+AsuS501WrHEHmfKv
K/nJ2JcKrK4PT/b8Fcm2M9u6wnwR8aOT4dvBKryDK4ry/n8oSdoe9k0Wm4LUpo7E6NZQCR26JtUc
5Y0tDAB5w/cJ2A0jfg7vdE68B5EBBDmf3avyPsb8hl+FBz1DNPOpm1M35Kdu57KT7h/JUahmNGiK
29NU3OfDg42dKgQp+gKltkOYmktUM8YLumvk3MyT83kq5mMP5vd+Vnyk1EfVzR5avsAFRnJC/18B
nDeDL/BFYk95/1jEGfD36XKo8xdSGdWuVS+cicVIdeqpUyFus4cJGDHQHq+rNUzRrcbvHGjL6yGO
Yqb+9ggyLrT5YAfSpA4l8T7n/36NSkppgMdIpSoHxsgJu5vlGbOX81EXcJB2T0nsHh4/jmUhQCfN
iNterKxaH3TbjezCb0t8shbhbaJ1J68cG8jULZO6x5mU8nvuuV3+2ybaxuNaZuHUSkW1ki96vJ10
7QD68sLZm9Z9O4q4w+nkqds0YQPs/ewCOHYMXrzozL2naLicY+tflEGSuOlIZ4VlIa/rs520zs9K
owSTCcxj32uFYDbcOzje/Zb8TCSYRUqBbQM2GX8hz0eLJz32ODT5ZQ0xZISp/jv2g3ANZj5HzKn2
UcDX0MF6WGjWw1ek1Ba4Hfwauy3pSG5MGkQLpPlHAV+HOuZ1mSlPGBZHDjRsDFddgQ9G4QTB1uNC
MXfAn9TWpB5E3NANoZLXhLppuR4BC+qs9BdF1fawG4xFmExJAKbWHouAjlB52zdpnlk6Ft3ztIY5
jmvgwyqZO3Iqb2oYR4KwnD5wI2nDPg5vMmQ7711FoxKIt35EbWXpBMjvK1jWzjILE9YzeTvyqHUp
0oFsBmrSubTDFaRF7r3OsSWWz8hq9Vo14KIeTgVFSuzJ6MmeR4ou/IvgLP2m3zn2BsKDQTcZ8imX
0Hlxjs1fGo/UYMgHwrXF9BcT21adSHkytdDj1tj9Ay4l/GvzLq2dBQzgLWOisk9JqwxpOAYWZ4x2
ziL1RFZB7uEv2z9a17Mofei27jPoFpBkdHCvZK3hGbVBcfkk3A3M1AJvnYcNMKnlXdwK4HhqCrZI
tEqDabdkiW3rybDvMjQf/9FljllXIquRIGejTbJwN2lYV55JhoSLyYBtXf4feKPnyBi/k4MrkO49
M98OFqSLy7bwGI1Hpxo+kuqgGHDT+aKaLWeQqhs0JfWJKUMQ5DeMUow99uxK/V/1srz1PZTftTlR
MD0JgVlJrVHx5Vwc9QT7MdAXrjLCwKfpJnBemDqKMss3Re113tqbPJS8DFynkBKHkLf+lUOmCgNy
bU6ImYiBngjJ5YjAuIe80NZQZpq9mB4eljz4QejK2eVpmcck27ipG7YSeHWTQpsVDw4TsMBJ8EE8
NB26pFFbNbvwykwjRkNx3I87AIlKi+YsIKrRXKOrsFcodpz3OJQflbzMvvJ0O3uPeKHbqgyfOVkT
ZEYItBffGGAqd42qIOyjhK3KsKAUsmnTeyPanhbO1rDvHOsEXtyqPQ1JTi3YAo/V4CARHl64lkpC
KWmo4b73nf+iChR8BN4peyuGyXSPbpRMGmrwOaNT95NQrulR48pVYVGnK0RUZkM2jTX5rzwF0QEJ
ms0Yi+Ilhcv0QqxM6QfG3s62l7vuSQKErrhkT8tscIlagCDcUqkzHrGLjor1u31LwPA7UtYRu+Lu
hEdFTCIRCj4j2WiLS/55NMbxNfXXD8hhE/DnwX8tdy37HH7QshbnhuNy/O3n2ckcJyPlrrJswP6b
GZk8VNdlwwW2eikH7oH6OXAV5M40HQ7xcEYufVl5/2IrmCjg86ZjEtMnMw+KwKaZTzJZqPLwuca3
DtTipWTfS9t3jgZoqwQmNZcpr2iuUKZNPL2/4CuxWhERvGqCzs9lzpemYk4k7cGOQcXZWA6WLoSG
cmgWYSvYDMHbZC3SUptAVvtQqQJ3xxFVtOj3bL3qhL6PI0Wrf5EtvBvJstXkTekWI4HJIoWGVftN
bIFoEbv2Yi2fFrC/9lcUCYuzXzJhFq78GGcWyk4gz0xHqw9ALDKCAAbfK9PdySxiKphPlbEDMyfK
zASAOnO2/9fy93TMvyi/wNc7lim0jq7dX6WFfzXy54ZPddSWoqybxtEqFzlzS6xG/XFFzvjP65UP
ibfm+jmi1ONjYVGsDK3XkAIRRVXaCHYrt4RJOA/WYANNEo+ndfb0UnlwwpRyj8C4LqeFbEgIEpc4
izJYxK5LpkpDbjbJU67k59+lIO36N1HquAQ2GFbGaVmPj970QMnX8JzNRb3Ibw9EQBmwj4W4e2Ho
rmSzaMLniiD86p2IticY1rvgmQ3Fr6gJSTIeWhNVvm6cLsF2q0+m4RgTWPoPf47ATXU+XBugsQck
vZ9bO+93gOzu/aGr0diYzcFp9bsjMyRJsD0cOpEXwy0k3FTUkThHVhUEUsH8Lg4+bTxNmLvrq6Wu
PmYfFnkXj7WQC0DzrlFGhEtvRLH5AGd47FsLjzU1B4WH2I6uZPRG5+qwOawquVov1Diq6rZkegkQ
5SxAB4zDTN55bILZaRaX1B7VYEW+izRhFGINb7lA9JhZUzKo9HPaUq4Hrq57galn6tRjz2+HGS1C
nzAHLJByGLWQqLHLaMu9QJMozfshvQkTk3jHDUtm3vWDJKV8y/zMbi9tTiVb5Q36JbONsFxmv5Hf
TgDVtNuQdtBxA/dYrl/nJFxI5KsR9GinKa4UHzQ2nPltwqT1KrKD6NkHzOB2yd9YX4HxUGi5aA+s
Ktr70/ss3vbfO/EWVNSQyjbX9UHYYwtruJiU6yxY6ZqpbwkX2RleXRI+k7WfFsdXIJl36C57pzhg
b+8AjJCTcP4LAv1g9IBhXzDnRY5gm15CzicdvIJnbr2ZoTZHFgYQjJc6OtYQ3lOFiao1VP9JAxcZ
l/yqrmFFn7i+Q5prktHcqInRDjpIBaWqXNkololJsQ1kdiwDZdzZY4yCSVA3dQrd03lTnB+o6Gj5
i7eZURGYLMFK/8XRxM74rP0B/1h+E9MuVh1wrwy1QB+0F+FuFXGwGEi4ITjU+hVpfDTvoTQdsfmg
t6CtqNTumskbufSKzR8jKPkZaepb2K3YJwbj/yBqEwqgPi2k56PzepiDNpSXoIhC3QMKHD8rxtRO
+GmYc+Iw4tqKfiGMSouOAkB1xCmZiWVEkPZY7BwTpbcVy+6intDTXkKxmUsuE0nq06R6T3BZJjjK
aQVSsLsFtwQlRob0/sJoV8AYsNqaej93KIb/mvsv6DPl2qF+RlELPHbwfSqVz9RCucERunQcS35b
4gXNi0oa8+NNrhmZYKYdDKhq/xHCiuEv/oj5GXAThn+knR/nhbQdyZ6TuleNgeF1dkIpbu/eFnGt
MPlf+RdIq9/ZjGXUwz/AIfrvS3KJzesyzFjJzqcNQY/T7bqQUTaWPq8CNqHf3OvRhXeSHxAZlIyC
SqTUCVzGHItgklm4kYgjT8e==
HR+cPsa/mP280Jgd8enKipXlA+rg4ELXiUAZxjzvI4t+2nSemWIO8JL8e/HmeEyAbo0n18i97nov
S6tO4TRsGDlJGJQFLtrutKbsvTsBWPq6ncKDjsihT2AcNeb9bm6CoJkjYjQ82EuTn2+KG+ZGfKwo
sggrWVHP/lQoqd1q8H9vhpPKs579ytGj2Qbo6EUWoar+CZrsMfHLCfJN2y9oovS2So6B/9RZnV/g
FsPK3+QF8DIJxAdkAsSCtsDUhCvHI4xdDjZrSZa9tiK92xr4oTwqMWJxEQwo+UKcMeFFK9yQTTjX
SJ8whiqDSreMeCDp5oVt197MIiU0A/hQv7b3/x+7cfqepImin2Z0nLAd8Dp1lzhzTr0xxdXSaGur
tAetix40yhFIkjXaOrtevIPzC9IJ5ZQ2QqClusisGiP/XtTbeJY1ZlaSkskdlN2mrn98Fi+tYm4G
GU1AXTv67MJ1A10QCW7tH0w/Ww52adUpWq622RDpuGaMge96AeHaAc11e1W92Y6KG4KvAULVA44Z
CgImVMWsW1g+y/2gALa6pLvrAgMEQjblcgaeIpNg6h5ch9ieS4vzM4StHRTRs5jaUM880GqcxP8a
ELmWH8JuvSeBj+vOePv0tWFRtFU5OcrK7b9hULJpICO0Kouz0yOl06FbwfssXwbPHbkadKISyKna
ntIO8UDaw8UGek0XIuNcL9UKO440RvUttOyPtPJ8jnnZ5PkEfXZ4w+0bZ2+PY3gHcRiUafnHGvqz
hFexWzlpJ4Et/+7DnbPW6Z6OvU8NuZ+zGzOJCgQQnwLY8uTzY9RWzLBqqeplT9hCEsjgNJMZEXNo
EAoLi/JxR318coTEsqUCZx8Zj+AD7gAX7DmnfWa9P5NQ4BP3RZ7ReOLFhlzJYY5Mqd/93g9q/K0i
YqV3iKMqdtbLWhgENxh6OgJ+kZ/tl6imFrUeYLvCoXSu9POIRyYGSFaLYyFTylko4LIMehV4AAlw
CmSzWIWh6bgCZFFHfkzt0jZ39Lq4MMdDkdpgTeOLR/zINDXk4pcaucLVzvB6VfpxeG021D500o2B
NXjPxBWrAFBOK5Vn8+lG5q1/VjD1kW1cFXOHOETMKd/+i74OFab9M/F+Tptv3l3PEK+2fbdpgtn1
0iTp/WWONajgTfwNrXfgSvUtLtpb9yiJBxjSi8/9joUMplNQ0NNnhdTgqDPtJjeLa6oRBopYyCIX
wco5UsddfsF42ZwlL6hSElVJb+mKNQCnU6kQwI4N4Pl3+6zcEINr5CsstU/s+xE2HfV3FIa4k0Ux
WeTNXIjF+w1IXqt3jU6ek4baJG3Y0+isrwvSHc54d276H29mZR49XBwJU5BpebX8nt3a1VlGJ0pI
6+CwJx94EsvJetKtbqbofUSSZGxfQ7V92L3BSiU41ZYvjv7URuRk+JYtUiK6XL/yJO7o24+1bKXn
YQECVTxcBsrof+ddmho+XSmJBYQz/zQ1LYgQX5cl6GyTr9qYfF0Lks+hBFm3wLT3JMRHFvm4hxQx
agZxn4FwzJzDBF+aQUKikP9V6ybfwuheBebRELrbwnW4EEwNZKBhYPP+75XYo1iwn11Ex76FALvq
7XtBWhhCU1Y5Udc3kz6QbZFwgudR+gcUM9lWHbesZuA+Q19kzZgszgPUVHjiZ2+mEqFgx8k0CBYJ
h2mbfUW09bHipi7wkj1+tw0DHFCJQGdWcLZ0bT02wnpXhN87bEsAvELYFvBwKOF1LbQ3bObtngF4
ldhH/fiBbpjhaMBunptEFaS4tvFuOpbbV2SLmmor+M+VKf35NunaWIeqZmKM/FpW5cnMkQrRGjGl
UH0Wt9Wr2+gyZP87odmGrCr9zByskbTd/d0fbyn8FG2R87Jata5F7mSSU9I3iVMGEi9Y2QgCrRad
Mfc5434kGv4mM7D1GRXUbmV53w1bdmqV1C23kgH+1iQD281ioTz3M+8PCyTC5Mgc4cnfdZvZzTxp
tbC7jHi52xozxNaCXWFBWx+nvSMA7TS9bjbquJ9Yf+PmMDRKyroO0qnIzl3moiJg2478wsoU76/1
SjzGtsUVksftpEUuD/yhKFicS+9+B8oOP9PKcZhKgVA5V8Apc9dEPOfYcRvZAUteZBxwYoUJzBv2
bk1FuOpno1ye7xMnw4RbyEaYP8IxCByszA7HYvTTOvItdagBQYBws2VZhZMCIcd7uC6Bf1ZznX8e
sjl2iI6PZhIo15PRwmx6CPi0mA8X/nfpvg5TPckPisYhcaSTfiT0wQeuBmXfrMEWbT0qqTCEHmYP
FWkTpCAtjsXeNJqf5DfWUcEC3r7qdci9DHe71ntuE87siM6x8xK5eSUj5fNcYji80g/VJ0MJ1Scz
xxsX1TSSrpWKpU4N6OS5yROX7SjHs6kTG4g3S7oipZg+wNqGUG5ZEnmK//nt7/2CRf9lWSq07Rz5
VQIRrNycnzjMQttk1SUXc8xpyBMae3IBKm8otfspoutWeNMprHC8uXYKiEDZXfd7tLV94FypRub/
u62+/w/IJAt2qyPSZ/Cu4z1+XZSW0RExRS7jym+0KXg22bSi5QC1PAs2PpBTKEE3AZ2Yqk0BRegB
XR1nm4/xN2yuGH0rRKZYHR9pN+uxuEjz4aQvw+I1hPAhmFhZ0AEH15JYZfF6cUjqsm+NviZNbRij
QV9O+tMvA17fyH0S9lvLWWc0NtCeRzjE6QuO6xV4HCIv07qdJ3LrsPnCu7oHsDzslqO3de+XyK4V
RDvBmo2oJyeiXi+TEJhxoKTe2CusNlvzghXuYgGUZUi6bvhBQmKfoa6y3Sc2tbnvAfmpZtoZ/z46
DcPyH5O8r9fKuY/LX8Od9oHHdevYGtJ9/qHIvhl6gJlK0/aU2E1UwiuMsAzQEjwzK++6tsXgcReY
qVQ3Xeg5sWPAyZOUTX4fLseYGiMDKxhD9OXozuH6FQka+cz/uOobZH7k91u1PgFX04YovHmwhqAZ
9LpAyyEbV05E76cz68M2IOuo9ZY9qWJGdt02fKlRMjPVJzJEuRLDFYFq9khvOU2Zw1rb0wMGRcnA
jJiGYXtE32Z6u6QLgKLJi8BaqsKVXPcLZcSvt8Sbj2nqtXxlFisQ70O3pvXLDHBRGxHjStHoN/1A
eSd/TG2EAWMLQNyusxEPX3XAGlx1vZC+cmMhY7i5ZJbyUa/K0+SNJgAp6jiVtAFFZ1+c6CweNvyc
TgOiaRV8unGPKOYV2K1bZ8NElrsB9Ozj8baW1gBfkJjj5u3rfXG+ZoHSetdJA2Aq7K42jdGqpiME
HoJ//mQxytDDEVYlUJgC2CgP0cfG1XbAfZ+5YsRIGBIoRxCqJ50hawlTyKbS9FNgoYggs0DrZOMk
xlA0l3T7mI9fVRDTPhS2j3goHzuP7UZ64+iO4DmU1Q5yBM3NVVT2k8ZKlyVR9Mblvn2D3EM40Uk4
a/0K4Vn3zStey0F848Suo3AUZVYNkZW5UkWa16bb/uNwCBYJT61r43GHOu8XxTydTRE11zSwN8wy
Xc2ty+rrPvmwMKcKG4K71erZOB4XmGtn/ulQJ0GcUgIwsNo1RY3R29YHirjbi0rm6kvs9hGJ7qw2
iQGC8u1pDyQhQIaWuzIv93un/NGTWrTYv3jRHcWp4gxCuXlJKua/CLE0QPGYXd5qwre/+lSCKOCB
OZcwLGrCiWqHvWBTmhoatGL4jbvzce60MFKqRt5HHYqpgABn+F6ZWHnnNhXFPqZQTtRPpPi7MsrN
aNmNNgs/hsuhWCXUSATqm7e1z5eVzGDDVEyLkvfYnWkRiPCcuYlN7h1CM/O1nZ9+ETX5uSztegw8
QYSeAXob3n2D7l/OttgOVPba1ngYRaF/UVXTII5I2n06Asu2korw7f5eDeVI69tfUbcZeicgSh4b
EsbQIj4gfwZkmcKtpVPewGQO5/4vdqt0L4GXL2hFFNRW5snIGoNM9dzuH47uQiAPQr8mMQRJYNc0
Vs9iKCa9Jv3q0TSeDiJ1x/+NywzkaZAXHNEBGQCBjqBj2BUN5G8mNHztsF2+ZcrtsFJ+A0L5gQrs
eaCp+Nh3DHHtPf/88FxrhtAVcvUTWtI8FSvOIxZE6tzkcEelE7n3qFRTp2rGG2/8kIeGgw4tW3PH
DqCh6jkc10n3KFR3ASmrlwCNzvjkIsFn3ykdk5uNK6LpZrMpJ/+hmhY3nAwYW77M2YejqOb6X4XR
i8DBGKkvWAltjA0it9meQ+Xf5Z8C5ZM+tTvqp5zSpG5KKH2AKuU7eDafjn1D8jhaQxeGXseo2HFT
780XaVIGQUSr5EQ4lPDsLhI1WsCrLXym2b+SYbkhoJXNXVgh8n0dddHSbYYHfN8SetTcN84JsQEb
01n5AOxKtYuTrArxIEJi3d4w4WOQwHZH7MZHrXW1At3tC4jKflEt/kv+q1msHTDcHq3YqR8qp77B
3+Y3e5qdoCE8QQZlBUOLNL/AIYsr/9umzG4Ycz2lTbLQM3PDoZjRfsWxUNaOPv6XACbcgEwVAxtb
yeSuu3rkIVz53Jk2HCtGsOno5YcscWE5OdvBv9cG2vxsVQQ3r+ddw8D48GQUeqLUUTAza2noRp64
seEhnKmbFqw+LQ22zjqtBdQOZ3sMMUufkXCMn3QIkgZ1zes70E4J+YmLG+opdfTgfM7Byc/9Z+bY
0OSzQLoO7ji6coGo/xaDM00VJR8BkwADmTjrV8nt+bVIEPjvczJ1UMXgeXRWatW4rLRj5Vml/YIh
g/bIosAVOst+HQUSxFUT0EzyfPAbi61yjJBwYRv7P/E6KUQAkGQyg3xnUwrL09BEy/oQlJsbOoKr
Q0Up/N1lKHUpvIXw8rtWJ7bB0pgyVgbsfCpJjuMaSQBHUEm3im8Ja8si548RnfZgxDUWMk8AaLkX
Vu0qWWO8gkXfGfnE0+OqWjbWCtCVusAt6NbKBJKrD26j8nx2tiEIR1J/5kUZnhxRZw95vdArOi6E
XZBLxCj0WuOZvwJiYO003Az5BHEvq4aO9a/IXGCeHKS7xSJ2dyst2g7c8HZGrvWoLZVdX62qwio/
RT9LpuGayAEdlnmrnAfZ6ttcaEZ5gcYB8Sc12aCh9UUiJMoxjW4r/ennAsggynsl2RZIB981TGKX
8jqco9eTDmsVUQpMcs79ffywZvoXWPxzMOItHwXibRlVXnfwN7d4d8rNblAf4DqpMCj2yFV8GTij
AHUYJJBrH1gUusBKXZtmE/s9Gx9/FZHf952ps601e+FQOtBj/qbo6zDpmMkyZawTPH2nsrV8onln
S9nPl4/cTt+yXqg7V7QORgZ7i8uYZpe=