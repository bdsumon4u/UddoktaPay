<?php //ICB0 74:0 81:3161                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtP81l1R3/l7LPEJqo3GfwLefu+ZkQmPCAdFgmdYjRKClbsAJtcEVSAWGl2+Xyr2TVnI4G7q
FoHOH7cdEj78c26x2tmAXoZR1S675VVL2Ya4pWLX0NG3rrfbc3t0QwcbbBP7EPuHYKkfUq4fOHXM
bzSbzSiDHHJQARcbvMZh2/+5oBiQKckR5oN9rOdX6ff22+4U55iv3rJwKbIAuJLr99HCL1JIDKqD
sxVW9ZKhI4/LZ0WNDw0gPPldswx104na8kg1lvzrdp/XNS+bHbF6nhABSDfT6llt2+ZR2kaUpYe3
ETMm2jyNT12bbMteZBjKhhNzauGiOIYy21//3x7fW8tjAVBiqYwngR7sB+i47f+e7hqZZE3ZMI05
r/cqyBO0hRlzb5vfXWBhZPguz3T1HsktzzvZvLjSSyHR7lH2vXCR6ma34w3cH3ZXcg0Avl84VDPk
zeHjW3qvSAsrt+rHzE2NguV5xWXk9xi0SxIQBB5jlXGI6xOoOmcZwDbgkclYxhiAw1ohNHs/YpBR
y1i0Cz7Fd0Vd2g2HgethL9RwQIkCgvwD9lk/1YtYjuQVZBF+uQhb9d0fq30dMSLMlILkgcfyWqeF
5az0iQFBanqa0fKAu287doIW+WyRspTvdCLzEk4aZrFkP+X5ZrwtkUfwUBKW/yaSlPUP3nBvV+3U
esIvkMs8Cfpg/wj5TWH5sf7qB94zHod/Y0ZsdqC264gv9tA0474QSGE/C3Vx8cKt5eQO3l2sdem7
hRnbc1PcCAYU8+8WiWsW5gK6JdQu5eFjt+CE+xxjTCvRJTppTotu9WesOChcq6RgLw5g+UwgmEb5
EFurAWKjb28dPRSpJu9HkKOJoMFxViQPu99RUhl786gu1bGD4fOpMf6CVAskRP3WHcwiUuW34nyR
WJY+5iFAfJ8zIJhiE8/Gc5RlZMNDz8DFvh9qObGiZZ3rd5mWZ5KNCMFc7ahXWHa25lt2XP/OD0wO
xLEoQ2WlYMQ+bS54lPI/DGzyhtqi+um7RScggcvzzaGADa79Bq/q4TTEH1bUmwSQ4wFLNXExN3av
xCNRXqCZ+qFlnQ0+QH1Vt9FIVE+YfaZvS3ttBjP3NOgp3iWA1QaDBhEj3ZsddOVJ1GO2pzFuoItz
Yb6+w94LKXwCklO8JGBTtBgaaRnAVInAyNVHj1gKhRObMFeXoIME/PWSEnZC892kglVFqcMa3CQp
BhZXLbhttLByi/KDZZu+7EkrjzTULqv3/I/WkhMxvAtCiatS3aMeiKKikNPZmSMHlPA5FWUPhAko
ZN5t41Idf+UcLsr6M6kA2vfdNSNE5sD/4ZLArHfyrMSqd8Ak1pLGVR6o4qXp0+C+sFct0qaxPFc9
CXvsy+zqpth/XXwDUrJtdgtAlmfYpt8E468vw8yHnbfrG/RQZmPiEyNIFs7VxS2UzKMkAr+ZyJhr
ohbpDtF2yCtehax/YLdbFJ+agAy51BDOFlgJJfkuGqpboKdtu5VvO7joFrC/xHzhBSH6XoiO4Nsg
7HV43B9bGccQusu7QhK0FH25AvMnIgzRrcxnhuUrCh7SHilmfu14MkViUxFbK8aIcL4DOhMRQAnQ
kv63sHamoXpRtU+YKnlLngjl7qppHwZ/JLP34SQyMe/FXYZl2VqeYIMana/BCLqJVZ3ZH+OfAlLC
uTnT00NXCvQP9JBd7OHT+Y3OcpYb9O4RHr3fLgHFV7mQk8L1Ll/ItO8Z9S7rGswr9TusTeY4ho3B
ltrFS8b2PsS29dKHQi/LgA1/iPDgW0oLYClw50VzdMitRFn2kBbwwEk2/Z0J8+0uuwiUbyYG8OWc
+KWC0IzE5mB1vVv25NxzWRYi+dN3a2UZUJtnbuvvKI9MXEkKAj8MPZ3hxFOfJR5ngHluRGCqaWd1
0ZDDVyP52LwJJs/2a2W7SRRmajLvgcFJGvvpZGaYLcDztOIIKgA/79XN2d/0ukXObyb+/PZ6Kpg5
b82xRPL7yW7c6WWqDYE6EnwEcW8c1Wtu5gtF3pa1Jtg1K9yPZ5uSajrp5WzBHkLFdwRAM+C+KxeN
WUXs9/MgBrL7/uRdPcMIqFwCUVLjlEfuC1Fyow+EaxrYR1kV6cuQCWHgkYyphsfG7M7xyKLKqrm9
FOhqoitCP652szHgqhWmWh+vjrVP/2YQeB/yuZXNiPO+U4LOE19oQBieHRHvH31vjGNfRnT71Bo0
rx/bdr6kL6lNgf/fCE9hznU6fDWeh9yMcWVI9B2TvFVDlwTNEOH1S8ndCIbx699gBUNMXlk2Y5+7
y7n75G/kByEQot2EKAlvI+K6PoTy/NCXtSOPX15fVwn30sKRtf8GcDDPjmgEFyIfwiMFAkRtYFV3
KZy5Aiev/Vo7lmJiApdHkO+kkOe4H8qDzQXxF+7PofXLkou4NX/bLof08bPm8nBzgA4sNf0It8ss
/p5pjLOO32C3mj7vuPAylyg0zNIbKMRSz9O9k39eKcjINkugYZ8zMVcE76aJrvnok/7HIQohXNZZ
488boV/2mRU5nWPZl+fvryF15Dum3DK3ZuoGwfWTB5EwEq9Nv162eDkvqwS7XB1P07dzgPak+qDZ
670PBALWvg1LbDjt6oUJ3u9LMNu3wm0PUmypvulbZMo+RDyVCzMgdMfmSApRXUoOSPq4c0f8GSdW
1gNPuRZOb1+SAbDoOTX7Thbx6OWLMcBOvjcOuLsClxV+98YMGoInS9ySN1d+25sQ+mxtc54nhyQ/
+fvaNSjtB28/KPnsQl+ps6e7hiEdIUTULyabc9KSNMFCs/XzzOA2D2YQlqjlX1KzQgvA4LqAlNDd
YfheoriISy8X0XDVARPzJE9wh6HejL+kyRS9Wgsu0ZgQ4vy5bxW9ixQs6fJ1LuUF4ygzFqo+UODp
NYeRdzFHYTfn3qVgeerbQZMjkYzYH8l3zjhNIZA6hP2d97CE4JsKGev74l5gxgCTui7/ZBWnAoz3
C6XTMKbxovuXLwolV4YPkfQMemkPVXiNFtxIBnB+q0yHGYMNTeVZCDRIxk8AVAimOJWXS4UXJ5z/
Aor5KqhL0NW6ELUgD4htLc5P8wqQUEpRJ1UkK+T6T71Jv4QhkuqnHo8L//RZbGLWWrTYcTpIiX57
uM3WIvdILPHp+JV49PhMBy4RI317WYmcccLDhflx8Qa4++b+QGqZqjYsEIUc8qmNFsioZHmun8i1
bzt+RLhkjJgv7YIy0Gd5U6JJIoYhztptZ+fyWIzg0VpgibwutaTKeG8fpzUbCgmFwjFNhBcGBKit
TBSMuEHerrH2CmJ3oLuectr4YbWgfEYdHOEmWlPxvUqwRk3fM7gWfNdtm0gjqr/gbedYOXkZ+FCD
ZH76p3MDYgpdPmfdPpyezLOzXZ7jKZGNQfMe/RJ2q7j/JE9pvl2Jxpki07KkJGaEP+LvuieBBrvI
mgm/LvrytfmcQl2/EZl/HRbvGvJ0OPz7uCJihpcat/oudZg/POq0SYegQJ4uIxr+kQkWdaXlAsWV
iPNLbGqSansw5zbM2FZF0+VM9l/I5pHzTEhe3uJn5puHx+awysk2dFSrzhU/Qqn7IZvjgHXcdlMT
990x+Vc+pO96DHpm0s4wTNKjhklw3I0wbfqjLNfcSRUdGdQhfuuN4LEbD0SzA+EuxVmrnsF4gSuf
dGvyQ/Qj+elhRN8SHBW3oKS9eIBlCvIFmbfJs+8hYSb/7BkkV9uOGUBveMtEliG3J06mvKWcnhtf
tL+BxO6bMano3xMUc/UkGkKZSw7qn5PVbzkeWbsaxjwO6TkVa9W6Ly10CVPHognemEkpYDy7JJCI
hhRE/EoMkZ1NLq1gybTXz54ilnZELVY1x4ip4QuFrw7/RSWDunU7TRHH6vJlU0om5ZWf3KJBupMs
48ok0il92ClcGXvjHc0zDJxktCMhu66xkrltjm58I2UiVY1gflCdiONCFebmW/9EsIbggG+yJktL
+kdUrrAcIOT5MEYStpCxRmcxshsO3nreqrSP5GiBsUH9JZb6Cvsb9Ugq0637ugoCa8w+BNQjZqQG
IKyLINVjDZXgUrMeCGETfcwsIXPAXzkD0pfyCOeLHKAjtBJVqmJi8MZjQ9X7oibY1rSmh80L9iD0
Ob3+To6HUou8aQe+Dnp5g3CI/pWBHjb0bC2HOvkz7GzgJskC8aSD/p/bJ109KVmfBRmcymTuNmpm
5PsbtNgijB4Oopqn9gP3c/hMUlMUiRU/g+RsvNwG00gMOJ2FMf/fbBnjO5qLzNSsmqKqez3jwWYg
wJjLa7DRrUzoFrO3MvXdN/31Fqg+M9iIaSb6+yRRZPr2at/lCFH9sT1nDHLN7mHirNdd1aRTqdj1
C9Gq9QHzgV/PkG9QpeFGCRZ8bVkZOJ5krgjwu1QOsC/pGEBv7ud0XtlloH/duBJBC8mOe/JQtMKM
pP6fl5H6EI1UUPfIDv3ov8oCOhBqHeKuKyiOAU6tLElKMFAKQZarz5oyVd8aHJuChwi6N9paQTmu
FnhbdaSJd25Kv5hNZQxNCWxIZ2i54+dhkP6ApC2hnBj6tVhm/789ZFsDGh5+TKRd6s6cUSpvgk7Z
ulq7DNBpUH6M6uEwTn/iGtTH9NFcViygKFcL1uTtlQePzDJr6s6iGamEH50X+UE9gMueRuspcya7
/3zDJcAZm2/9ESlt2fJIcDXTXal9tjXzx2oACyCeIoNDGus9pNx/pE+iawPGzlOKNPCMUbE7UuaU
0sljvwquK7CMbPFlabyfqaWbjE6b8KfRJp4wTLIJr/59SIL8lgV1biFQlKhrZPqGBYwqRYidEbx/
cP0IOCvXPezMXNF7tGYgZT0P5eASMPgBA05SPPq9AK1Pr7qxHK1X+NUj1tfmAVzRAIMEqBtd2zL+
HXwNyjytPJghch86IvzqhH03sOrrN6uKZ96QX5Mlstv/D3wIYMKMrdWkDQiVDYlg/MZYw0Lvf0CU
Ix9LybVTZt3iZn8rGDBhsY2MsZO7toF6HXZfTaoQRghND1ue4cuLVTx6P9Er2l3xmePs3t+BZhzY
zdlrY1GiyfAWPbvNV/YwXHi0AAQF1RG4wLkD4VcqSOFBhuQaEqQJWTTp+7wbfXS/+m1K+yeQcIXC
uV60qamueJzZsmUssfC5a1QVwGb6khK97c4A+b3LvL3dt5S/fvHAPtIm4UqSTOgTcd9J0IZ98lYT
7075I/uS/+PgP7ep7nCv6b1710K9PquGGq2Jiv2DdvctY5JVh5dmlaxHHnaML43d8XCNPmnp01+w
qVF/5iB21zgS6mBSsHM6l9b6NcUL9bweB9lkL+aep2IQNozbI02/BDgUOYuT1T4L3FPo45UwX9TF
EKFoZVzl5pQsSYkEn3eO4O2x2QwpmNvOajnaWp0IrM5l0sm6BhWgDUw8wgUVQO6lpC+/S+gci7SI
LVVuErbKmuA1uuRtWlY6NYBMezb0QFCY8DS4NW1KB/MmxlwxOlQe17ANoh58HuZMw8c6dvVtwlYu
0EW3qSu0ZPAv4T56S+UQ9ZN3v85sisdZ1Xvni23Qmnhpn5l/VVHivp3NPEf+2Cw+xu3Iuae9i6yk
G+Gjr5daJbZAfYdOXts58ETmcPBcJ6ljb2qJk4D8VD4sr6Xn9etxoF+ObBqWMEGUp4PO4qei24x5
EQ8NjevnPEdT5BbZz3SmeYw9MWrPTqbNPjzgoN4gj5SeUNzuPZYuGQu1iOG+pOIiFf7EGpC034iS
pSM3ecaT4TpuU02wC5fPQJej0oaVz0fjFt9ubdY5pRdTiGR3g/DG84bEHPjS1T/NQ2Na3bXbP5je
yIHbAvNX+OyfV9kRdG6hko2/4Ci5pGGp6a7GHaky97Hhizd8fAb76cJXcI9X7hIVwf/w/UNvGo3R
8k3sA7sjSOYsIkdK+hs92AUpADxg3Vo2VO6DKtbrphaA4P5kO1r6hRYd8/BC0kqwQH/R6dbQfIRz
6Fn7sebrlquhy65v+JrZ2iWoOeVKTNK1SF9yOVCgjf6JL+YhhuzxRTJ9st826PWdLEDx7NPmcuS6
TE8n9DcMbhhQwdVBJm8smlXY6QYHWzIuwftCRSRiqNjUTeRNfu+doy5unEQ9ht22j+6BBKQjbvbj
T40mVf5czHlERT+F492Qjlfh+pLiJuezRSVlBCz9Zu9fL6SWKyP76SV202mz9VAt/xnHexwJnH+b
NoVKhC4mmVPdU02f+MMVqTpGJZTnhP9fIKP9YO27vjuVYtq4Lmb6/qL7PW4rg4mtAwi0vecCU4g6
fnRt2wf3InF9TRfhlvflEER0n05A76gnbaq1UUvqLny7fFbhtkH1On8KL11i8/qGZax/M4hJNPQk
EAR7SjXrQl63YNQr+QPRn2oxGIWjRay0dnEVCJcF2FVmfMzXCAgjMvVFTx5O5YiHaojO6VcN6vVy
lbUNNgHgq3RpwWE2TWJDGU8/iVs3yTCSJT6GE4rjvMvuLx6Kghh1uhrA0F92BL8uQ+D8vw83jl72
Q1sJnHeUQwiqxxmtAxRdBX57FKzjxijk1X73/i+HNH0n3qcqTimoYf8D68L33K3u4CUhKye6P9NI
r4wo0VeQaNwWaGR/RFvFjI7rv3QDaqVPT/vi5cdWX3OB+CkLx+0RJ/kHE9Zeg5P/CLDFSg3tcjOB
G7rNrwEeabCFZxqcqHNQ0QfVm7ro72aMs8T6/on+/XB4VI/EUQN7pEs7DxfqXvtMbEK+x80RQ1g6
SMyIINEzkR4+Kb88prW3nAi3oo6tfZq37Rq29xeLrZ8RwZtnZ+/xreSLKJgfb6NxXghZmbGrKOxf
UvFdj5Z3JACLEfoYstjm6C0AAnHT8oEgZerpjVOKwNSItqOdO039LIjee+KNhR04zhSlzwQWPCHS
xTXQEaXhYL1Ggn6M804OY/xWxc8EPkx/WcK1nRTT54fo2N3bHJsj9DiI4XMqQMm0kcYurowrJhdb
iKkVjcw6L1DRC1JPevswj0SwJIBfe3BiGDAdtbDGW9J/+q2hUgqa+zxpjNqjz7DTlxD7dZ5peJSY
5tJ/zfi2WcMsQIjRWZAT/HSB2OMt1/cFY7LagzmkO/UH9UFECHhSFWQoryLNOU7rdXr/uXOVc/MR
buiFPwwKhhO2laOoGvKA3Q9Uu6wOkDS91Dtqg96vnafs4no54nn6FdmswJj3Xonob2mf+kcmwAwy
r3lpUZQh8pMBv40Jf6jOUkM1Tc+tjBPBhjBN2vopUCU4vdqZFqdgKDJlSpe75WJijwpK3VIh8HJM
2hQ0GUncozf97Vcz/2XAZb0n+0zrvdocChiB44LokvX76ZQJMerFzsLT9puXwZfx2BSYkvVUELY1
ihdz40c/QD8INTtneeieXHGKpXfx9AVwLuYh6IqWqEl38FgvmDBgSDn+qd3T1IZz6Ufh37H527qQ
EYkBN7vyX6dsSofqVtzIoZZD6MwRhXwBEfJQLlOSYTal9SYXNuAxXwr3PEkAiaHmPi8Mnsv5u8DT
4KeMtJ0H0KhGJ++k7Z3ABw745h4+3irI8DA+KWnVjszewqJE0JKGPat92wszgvH+kZ7UYAWMN/+W
OSdCFdxB9jKBPOWtC2dr3gImNx+c+FIYCShnxiB7T8fO2lg/zLboiFO+3j7NL0l/qEnL/LB1B0+r
XUT7c9TBCCl6hqm8zxDT7aQH5lulFpeVc7sHn4f6qCB96Pbgh8D3mKeilvLOyF1HRrQOw85vaGcF
Ut9W/m5P/gFBvibPKM5cBAis7DDIg3GaAgtqvwKqnq1NlXZ5LftIKCN8AFvarq0lhdSwqZPq/+Hr
sHIZOObmHyHmBRftROPE5iSv0Dhi21gQx7U5EIOsKdbfjqxwC+RYCJA4ph5Kdyt+u7yvETMMZdya
lJRvR59fMpVmUjkGttpcXnjLvzQpaDBP5bBy/43Tg0vzxkvY3TtfyaEn8sr1GqVXJAM6IDSz/Swq
4KiLBNQzAv0Qj+SO2HOWr5n1AOHF86xOTrr/qDU+WBCxZ+Z0lVD43iEh9Pn25WBEX9V2T2ispTAK
oW0wbaA+W55DpwZBoFh9y/VkrkccKYqKhTtkC3+ssu2qc55hxoHSNkJU35F5Ue4oHt/1h+xNuVw6
iX9YkLIlWkwbXHmIGJuzpjDQ0aWNJUdMFUqR7OwfpN3nfgz8D4I9lmDwNSWOnIUiFRcqFouj2NFh
IAlITBknJSWljKCLAlwciO+Ae3ynFUuJvimHBvWTFxULU6s8wCbGlaZxM/eLR11Gy4SDrau0HlVb
XsxCb6zTXSx1W4JfAIRhPDjlKblAjS5SM0xZpgG4ClUuxKuXRMHG6JNrPEKdfzAifjXJ/vyrxuCn
URX7qP6DnapVoluHhXY3o8RkKct0JEEHuAdDv7sTexY7dRu92kZaQIaQvjwO0v52zvdrLHjSqQY+
tLNOSbTfXw92KpDaOehgGQ7GcCte1SSSXUxfHLvxuH9O50uXTj5/rukUV08fDX2saLuk9B01RC4n
qvB0iPkHKvG0wPran5EL0cKh9ZL3Ai14m0t/O67dEOkWrUJ72ob8fgnMReErYPhb0Kyj8MNe5vkZ
8SFbysJ4/FdQ9423MRAr3HhuLApIKYc1Lvw0ijCN1JHn8O6dCiclyIHpH+/0leU+dBLhrPzdWU9S
Teqa9/eQc+QDXqbLgTBWqNoWQLSnpYCwUjl25AZ3zteqj1LsrVGPQ/j8YjJK8apuzDgMRarAtJVd
5p0r5i9X5sJ0qDENFK09K2VanhyWiItqD8FE7yG9DcicSe+ezsw+y3V6go/iFMzNL8XwvUFpcGDL
XhJ05/y34Fx+6JCnYJbQds3eRitIlu/cJ5GHvzSH0bAKgX53Bw+NT9YEkQcJuv2OpAk7AQ6lgiFt
MCyiN6TX9ersvF7xtev/JXpyU2gqTjGfZhESsHB754pjdrWHRHzg0Ly1tpextnBBIOTIM5oiC+pv
DDxeYd+4kKNPL2Xah9MQmTXA+ejbAZaThl880JMTecTl7UtQWnqsynAVZerTb1Mh0E0x8pfwEjIy
23XdDC6h54/raP6aXY5+bUR0zyfXi8H4Irtey4EL15YkEfZAX//e6JMeX4YedVR6LXbUD+am/0sD
dI2AgYk+zltXqiObbb1j/wyCFiQnyz15GKQq8qJQDx/aNqhAWtZXsEc7ggBcvtnvCTAVxOjn3nBe
hdUxbLJQFMfQT1Udxb5N6kJBaQqnm5lg1rCsNdsi9Zhw400bQnKzQdEuB72aLeLHwV4DlJDoWFBr
Fj5je1h2Fj9D7dkUAKzXoIy+gA4HqKInS/h4qWJPwuntwkvtv98HBxZA00je=
HR+cPsQsMdWF8hz/eN3FMmi3O2GYCldqoH0AKVXHaBbGZwwgzZTwXQ3kQ0Q89VcOq5R2GY0s6+7W
EcvKrZCwCFTt7uf5uzhbTqhgKoR4kLjlQ22PA0k1PXK/VFl2onpDEzWgnJJnodlqB4e4WruCcNtA
30F6lrqal8AzbNU9bVsfzUC4O4QiKFA9UNPloa0uTP3zVxtsfyX8La9dupBX3Gy3XdCNhPuodfvL
AH0JZj+QRKBjNAj8/gQDMjNSoBWg2/eitmZC47Mq+YWiFmOfbSjmh4h2VSMa6eesNv6zdUjrgkXH
Neztvvq1sbw58MLoYxfVYUWvQfZPQ1hSyfTM7dQu3Wajsi9R0COErtzxJHGlsnZQGvvhQdjW6B1v
69PeMk04EUG1sEgIOt6CeZ6JUj4EDPsjV3ef0WI+NkLd3VCwU2kf0KV0L5IcIgt3yKdPvK7vTNxE
ehElI7T34G2BBFJyvVOLIvHEE4Bh062XY5s8UJO3dmNGSUCwPGF5oQL5+rIpERin/MtTLOzQjA8/
Ov+nmyr1xhSReNMAzGAeIJc//ocFPbmHLx1LfDjTI1c7Ek1Wqy2XIZuZG6oxg+yS5TzwvBTKpk7n
3D800NlLum0H/Qm86ybqU6A2Zg3rBHxjYc/WN7GzoXEMh2CXT4kS/pYG28mk+y74e/6u/wXu8RhI
QpccwBMQk1k9hR2rATYaHx5KreMRzh7PphXQ7bQW8i2zcnfqkf0/kh8AKC/1BfHCYRGg4tfbMUoL
LJjca7DlLP06Te+o5VbBtdEPSh8/tuxKOfuiNylQMUC+0I6gxrdOUxxvYOdvnuFqV8RLER0O2IH0
1/YeQaxtqkv3Nz2aihQa3GR6KjDv/ScBGCV8w5MLPSJnRBC4lvDPpRCkjA8kfyePbtZ2r6ZHJfdS
ArWD3IIysaUewjjJUOp2JerNYkp8T/0gqjFq+OsZSSsBC8/I8ADwywVI/yrZxvlxRr0dLQK3P6QQ
Zdz4QDi844EUs68w3dt6XrhuNW4+oA8wAk3SpxEOLnPlPICGdxTqiD9qTmx/eggztDEK27+5DbKr
noD+nvYqgP+MVtdUE8Nd1jirHjSGWfuAsVjC1JVoVeyX9SywyRHx1jKiTCzCLlal3IpFqtZvoSjS
LifgbVqI3VZLaGAQBGOeC5iHlmWiumq45cFDETfqC8wTzjWNbGndQzJsJQ3LbDEteWO2V3xWoXO5
UZQf3ssfUuA4wbnwCtl0GE3NxRdd9M7nItnRWWBF2YttIjY+TD5tcWugSh9eoxQXVBbo/B5RGZlV
SbADbYrYLnSrIurr5idNP661cYgcWgnN9+15dcYEy4kwx06UjA1HbsuPQVZk7NP6s38/sX9tHkNq
26po1M2n5gXaas8atmtJEv+emKF5+f8MnR/J8gjx567PxrSPgykVQ36MwsSg5a0hiqOk5Xm5jza1
9uGSA6gLI2jR/GxDtFrhYsrQb8E9jBDJ8IkyJZFRJbX2beILLRrBgOsno86AANzPzgu7qqwGa38k
BwwoLZD4VPy94xz0w/VAk2QEptaU8gZc6R7e3W511so0Q6p5bQr39yWkI8HQTsisJyDwDfrh/SkP
/duiDh0Tsci6zk75s/HHOTOP0P83PY+OyeTDTR3xxsP/2BKgodpWnnwllPBvWdaYxDVYwkNIjoA5
N7xJpyn7A0LNvXAohcu5L3z0nJ+lD/G+mshczB045iQwdCOnktiYt2ltmMFtdFvKIHx4hlFqjvao
UM+EjpYDyGN8CMl2eryrp/hMeWvPPNdVQhlMKy7m+E2SFkfgsPqFRuls7uruL+Lpx68k9RxP3Nnj
0F0cuTOhUA0D88EoCfjDMWbCydHrdxk5xZlravUgFfO/IhL+vyPwj0knRUXx5OGe+iVeAnnyazDQ
FKzyH2H9W2u/lu8PuAr4VmclYB4SJcOkiXq4iu7sVFg123KIj0rAmGL/gj1kzM60c8XZBRnw86mJ
Ihlsd9rHiK1GWx7eAwHWbKMS0wqDV1B+CK7T3zd0jNeqkqkrsR7gEm/lbbAM148mawbr1C8q/yHv
rl2uDelH9GTKA/3bZqfxDV/wK2NjHnCvK1vms5AyQLtLaWqKSvZSvqS+Q2R/drdFR3yZGOH8nvTT
3/+UYao8IfLI0WcipBdCI6o1BEbTJZ2Sy3RhNB6jf9pHJjIRAnHPFQE65EJ8x/J8iIdAwZEqh3JZ
lIP3g7BGjrws2cgduUVkg/EZ62Ez6/lR/2H/W4VwmBVYO970CdMsL03V8jSui6bSU4SzBYe5e/YF
Q68M0DZc8Psa9Zufvig0I/t833igHCaI+cpjulXdySnTUp292QrI81drMBh8ZlUzoX8VoVbW6Rd+
Er2o+894mPopfXxOXZO5XG7h1+gE9KM/irr3Dq1nwDjTerl2Ouj9t+7SeWvu1A9VAWwOc6L4R9qk
+9PkwCUUAkQXmXJrlOhFBeUEuJKOjA0EU4yq+UbrdPUOwebS5JX2wym+xFP8pPmXe9ihy8N/3Qbs
+sMaak/NNiY59NUroDtEDuyE+NEdJ9yXDi1kynQowATchN1WkrLNpPKAudosxTsYPEFDtK+79iFg
nneiIFG5243oLnhe1oShstDl1bEWpZyIZVicZ1FUwNd50B62kSJPSwRfts9RNcHOu5Xu6hjQiw84
r60NgzbolFD0xVBw8ryuAVF1glrTbuDnUSHmW+dzcBi3R4LOnoX0uFP3EqyMKhgJ2XKjKBRWVoqA
24OQduBsYHIhLNba4Dm3HdfmO/8ekn8DnpHIjRPtre0W+nE9/v8rM/7JQ8OaXFd9hjDp+2BIV+zw
MEEZmXUazkt8JSgVV3ix3qFM2HHJg3jblNBoleAtn6jj07udxeTcChxi9vo4b0btVlbVqdkMfNiW
KdyAZEZt2Gs3D4yvcfK2WiNu5U81X2Vyrk+Ola2iSVpjENBnwjZbFYZ0T/YpDJEB1nA6/qYcAgRI
t+q0xSBH9CDzN+POT4GLATi51PWak3uY+M954PWihf0DGtst9qdkE/reO9moboa0o3P0+WieBV5t
nEOueD24z2OdZKytJ15vrJA3nQN+zCBlbx6gKU9zuzAwl3aVjD+GZOXHk1PGc+yqFMFziaIR9gff
72HGaUHvtAFIE8h0fuSsrPNkP+RmIpG4MzJOAG8FnLYjrQsunKZn+MpOMhu7rRm+Ocr02u8mZjxg
lb5SceH/66jSNKzsQuxPznsMWQ1LoF1MIbuDnDKsEkvlW2a4PWQIyizpWdl0o3a8fhKl9obyM9ny
ORIIl3J+NJv7bUpT8kiXqUicNuwMWtYeYDtONdeZe4Cf/ULH+JNHu2MRJaZ5GSSBqnSb0hGfv8OV
6HDVAVl6QMelU7iwAP4BS6Lr4AQycU1iG8v2nYmAa7bhgSHPBdrm+cnIdrrTaVvRf9YUkuVxhSjG
ra5ooayJvn9jrDVjT5lebt8m8aWq9OMr22xRxgBLM8zK/sdXo/cZgZUf4lNqlqmfaY44VgNTExIE
mMQw2p14QdE6xLjvk4JpDDNUOTlIOwKP1ZHUn/Jehkygr/Fch/dBd1vilajKCaIrg0zHd9Dws7BM
hZYDLXLY8DBYz6oTma+/0m8LiAxqY/VWeIa8URF3dz6xmGtcEnppIEAtcyDQg9jOoAXMPjNql5k3
I8HWnUTCgSFjfKZBNnAYb8sVaCk/mYDtsaMZyuM3nMVXyhCga1RddxhCzK4XQnUGrqWkqf2nAqbA
+Vv1roF8/x96dvrLzfbICmR5Rpffnz2b46BlKd2BP3dPqwa3qS3h2uL0e8ve0AOO6c14GoQQGj2b
Ja1S/4h/9s/gt1HiE6k+fx29SKxPXal3oYfT636cJcTrukLLCFF2MG5CmUqx0cGMkzwt+5l4M5CO
QAgKmWpiCs4bIaX8SOEolFYknn/PxgaWBaPti8CrnCOncsc8gfPq8sOUshiTIYa/jrMLsPZyrgV3
Mrg2hfZb9YyXY44NKWdEWJITqP6sHt59p3lhSe/Lu6MfIieIrRdolaqEbe1fmpUAe30dfvaFjIQm
ktfnipeWDi3qg8774TxWRERzgEt2WyCa2QUXpUifpADFBYNr5WuVoM/wAgOz4GimrJAdNbb+nz7G
lYoGRImYjO+gPdlZUYeeQi5GrkvrkBQ58z4pSgaIBF3WGFzXoqCcu7aJ8TKDviwkKGTH2CaZNt8T
xIJjZO9kz5WnM4qEH+GVAbTBExx1IwMRZR/VwCxU37l0qOYT9VnbBRAsR4L+LtgRRMONia8P2iV9
3bPGs2YB1/dJp9zesQenp8mcvJPZUlO6HqFG3gbtlfvZ3lzvtlA3CiYVXghUP7q4lTFCiG0giB92
Jp2byUlIj9qZhKQkQo25lTjmlwcvrx0+TGIG7Iqtso8JJypaXhDAOtXUpdyrMfF5d1Fa0Q5dP32w
BcLoi8+ExzsVXcVDq5XA4JlElSRSmO032Ntu+GD7H+78KSL621wsptWaXip94dO/7t0uvW0KGJkp
xi+lzLCY/qxIQctj8hgbKR5dj50Sku1zm6G1dQplukCa0Ahw+Vm/YnkGzfT2/OAajhG6uuYyzn48
0zcKK5f3we8dc+Rd0C5WsODWIlVYqyKwxqqct6sTQxPGdmXptvja1K8EEwtB33Prsl0B2zj2hUbN
C8wFAAD1wURB6mySPcR17zDTp2K0RqCo0nt5sbBVnYmav/7A+BeIz2QmFfhYJDPoCEkf1pcrQ0MZ
p69lzOl+kSPXIdyKHGERGd93nc1doBaCMOcbDuBFave1AtAO83FcCRAR3GFzmdYLe3RsEOfySdYV
pgxVOXMZDzDIWEyx/9g8BKQhHv5BPncg4mcRlTfotZNVAtvZHGNQQg0fWp/uQQs2xlXH0ZLHak3Q
2dniq0JZlO1R/6nyYmBDWUH5nCGHWxc2vJ+gn638yXijw+7t8X5CZNXyo7gUs2IFLYSRNbABQLYd
ImInOH6AZ1IMurQN40m5BuSCtPlMdcDw89GOn/ZofJPMmXzPuorWyL6TFKY0r2T+ZhBWGB8k+Hs5
cijsUfsSbtGm+LMDxnSz4n52Z+ATwjid0PWCBgI/2GJoKU0ID6j3jA1FjWjYcYj8ssDz0ZVOxmzF
nSFY/Uktk56uCRU6Jg/fhKD5omPTvYce43G6QKpOfPO9Etr62ocktTAxulDOFjlD1VMzXmk6DQ/s
ent0JWGo3XVeji1cIYbuM4LvJvEqtPWMd9WC6Seaq9zB9XpbDDsknKUub7Im4UgwmARORKLHIugw
6XLdhFY+P/JXrSLwR/aDr8h7cw5PFIgQG2I/kPcgK/TKVwWcQ7Fw+svGiqHFyqv+r2yBZlynsXo7
MB+m/udWcPvJ6K+vJ4VvD+LgrvoRUZxGAu9WOk8Zx0YOzjKUSBM5B94iMGKxYp8qHxiam9pPpvyV
aLYuhbMN+PSlvA+il81IyVuR/7N1Hx1WRu2fdEU8O2mF3BmILAvUeNHBL09jpaqUbkNJa8zjyQkt
MqIg9CFSdiWvDgQxpd6tZAgeRwi/Z9mTedS+uXX8rrdA6F3b1NFrxSv7LwdKpM4V/nr2Y0jriyF6
4jV4oV2gwYOctBtD4LWpyVuE7r13L6s+Wz/Rkk0bJWiTbuSMO1hWJVVy0Oauimj7QA2qLi+0HufG
UsEXbqla4KZzQTzifCRPaOcV5awwOc2QvMJ3VdcbcX7lAUqw91afs93mxZ75vFm0IsZZdG4F46ue
LiNeMRYq7FqGv1n3gZ8WH1h5vurCI4LdqYocyOzlHWC3iKjZRRO+/Z3/hgYVU4rIUvSEX/agd40G
tun8TCfp9DmBVK0nSxrbn18AHnYu8nu/ZWoangxr6mzkhvAhDvFX1CSr/nXpirRlEcK084f1v0H+
/Op8jYOzdMKh5Q5sbajycYXXi4h/oiRRBEzsB3H7rHIAbQDNgV9qMd1eN0eDfvQiZL9wG6JHvJgt
yTd3VW4qL4NtzBliqxOH2Wa0ALhiGZqcaRjm6P1pcLZhHbccPR8jlhYTBoGBSxAhf32/MZxHy/vC
1DjUNDiNKRI2NSUWJfYdjQdQkKj7xKcNBKiqKW6R9kpxei9ozbY0s0+dmR5i8o6oCh/1f1QygIE8
2RnPqfW7C53q/zXAMtwmY95c8kgt3PDRDQPtJxOG3BoCzVULGGE2OhAR67Ld3OB3KCmJVIm3ofP3
Lc27IoYLJ+MauopsCEZ0nevrvmr0fmY2+TUD1+bPcsZtvPy2lHuMnc9OceZdpcbl1V+EVj46jFx0
IjL5TR/7S1T3aASQPaV+ibSq9O3D2uVFROzFNVsuGNY1dtUESkRcVfymcnhpj/+EkQzWuAT2BiTP
1siqVs82Glr8p7hohyAhKM+ieO245grTD32GOz9iOKV3cAbbNidTZPAbN2w74epyZUn+wJ7ocDk5
GccLq5Bv+T3uPaSrmEliKHXoubAGz6V4MnxsA0JQ6g/gz2VK7lC2zBno15BYAqFZYUa3GcD6Iqal
LuvPUT5JbdPLwiOiINrg8zeuPN0QU62wgZU0wksbPG0ZHQigdrW0X4uXCjbXDhp/GaZ2YOCowtxt
SheXaGX/Q55OYBrKXIwzcYTrMk0S/vVr/9rXr40Dl5FmkLCAE4ZwVhqQ4aljNuKZxBJZXghzO1VI
2FuQCxmNh6Gf3iBdhtCEVvbzTlOu7weRJLU0oSTC3XUYNAJ6+tMAJMa91mBAuRhpaqJlTSF3czkV
9rvA7eIzGFdDE+M7qHpHtByfbrz35U//VabDaDuKMOwyZ/UpSfnWse/vtPlDGJkXPsOzyVhmyU2F
0ZbLwhBH78RxxOzUNyx3/nn01C6yvGnWEHZQ9PukdhPbBW+ycHvlRowikCoOm4iMt/b/CVek0bd1
RRlVESvM84H9+Lr8puBqCWUDUe1F+iqhEqc9eghcYrBJibjft8VYQePNcGNondY22NF/EQmsldMx
VocQ1Ubawyj62AWoL9igT1hA+6NiuA7oWWl8fbQYFMt4myE2msQlG1vtxbtvw9O7rvX/wUVpR/tT
aKo0dAJI594kr5znWxGsK1zUuP67RbdJYMLJvqHfbx1+rEIfCmUHvox+e60W8PocyHMhzMhWxJYQ
yN/bYVjCuulnoInCkWmxSun1IVVCl1ky/aVAOX2ffjm4Iy/5tq1rHOymT32EjNfRvFfnUGkP+c1X
NiqJ5wuwDKcVhELOtZk6q8F5G2U9Fp9QrhR8j//lk+i6CM5XRr5Kt0GTBtoqay7PSn5NWgeP9CoK
OhWISPq0P3SHIX8Yd6wbc8hoHRGbB/yPSvBstm9t0Ob7uCMYaLMKj8HeBYsReWWDcR2XN+eOGluw
bnYJTfQiyQgMn0tQb7BSU7qYa52NtBqHgPDfJwZPDOTp18NV5hsRk3aBaxftl2Ezc/E6oTioBzWg
GxPF/QxNVM9I7ybvurjgrQktC73SEVRv5V2KTw/i2lafARp9H8xd/8c2Dx/US3OTgaxD41dqxvCp
1FBGwo19Jt2KCvGI19Y24gxe4ONuxZGQHoq03hDCaDTUtaQP2T0MqKkIPghofCcg7QP6TyVb5g2G
pWm9mxciAQs8qHi+FHJq3b0Z2qbA3cYk2Rdxq/l1+AmnSRBeoXr533F9Y2yoVlnuSLLr/p1KNdKE
XgQ3ZIn5wSfwHxLvW2vEUXYVRKZUAGiWd4i0qoyd8aPNsiaNMYT5SQtiFtP+UOO//cSPPowGrDJB
nKVVWNlqayQwtTmAvFG35YO9ZT0UDTRZBwUUdMoaVNAGuBDpTNI1k2WQfVZBn1X7SCNSrhVrQGdJ
E/aiso6h06UDVY56K/5U4JV1erxAShUYug3eWVeXYNpT4rkYeziCsRMjIuUvwnuuKVNwAnuszIIA
v1YmylQzpKefYPQHplXysMX5CzHpOxvdoKb9taezSibnEmXutLfmJDUPtAyPkwJMuWEOSxHxvMTB
JUWiKrlk0crcgYaEMUIuIA+g6Nmpns8jW6YZlFaO6Cr9DroTdkYdGKkUFu0T+G/tmcRorUl0rIpe
1sjKyyFPGj6cwxAWWaS9HPQXVqM2B64jBWpfVOdij4Gncr/kbVGJWqkRYNbI4KF/kqdINBKciWOR
RBHStXx/zUZptPjGm1Ehz4NqechpK/lvGoKUBudoSOiRDTbebFh+itXKLiwhCbIgiZq8bsysexyo
pZZZ2eTrMiKD6guLicGfybKUAkfUrpTQ3r+3cx4n/+7gGOgyaumgwZlYpcicZiW3uueEqyi+NN4z
biOn0T7MevIavcjPBcLvNqv9iOy1xbJZ4S886sdtsXGruLjIRMX7YHsFCXZBFU53qtzAGyJERW6e
RftWIC2QBgvIe4egBqSCvE0ZvZckyVSxTMAptXsRFtrGsftS1dFnR+YkmN/n7ToejdJIpSxJ5jDD
oPzE59UXkprCl7+T+QHjfyxlNjjCYXXF7dYtASScNiXw26jOH/ZzjD60kSIG1I7IDe0clPsFXHv3
97vIj00bWiOa751RsomcuWtLN3/nNcn/A3JFmGqbzKUK68yIwJ9/irHnH3B/ZjP4OLNqUH3WA3Xf
Gss7q/xNOZStTn22lUDAcWr5+USeeQMuvvX++okMqZBOmvW90/Fj8FJIHSkzLXEteN7DKvfaFGcH
iDLRfWGeEv7xDcx2oiL7fkdfIX74v7ije2zV9KGzh4v+g9TSlaFowNrZyeAgKTxWmMAU1j7T2mxA
xStYvnC8RG+cQAkb3QVN7Q41tvRKKk8oBY6GZ9Uj3aV9iIvWetd0RcVX/6l7tOMJVtenmgg4pHs/
fOybxAY30Es+3ICBwAKtIRNZsmLcvSZ8vnrVQLnzow8mpj91x4N07++6P36RHLefXgCIsQTyDbUs
uv6ypeq+BQlQsQ6zJwtPRkj/vFUOazmUyK0zXWjt3w6+cy1h