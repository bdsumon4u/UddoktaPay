<?php //ICB0 74:0 81:15a5                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt0HPKtHi5rZszxmRkjS54PyMDa2hrKzzB7FWrE1Y9MvYGNbqge39NF/SUgWYc4/7AXVp1p5
CSFF6sTdu3G0lAwefjBOGUQ5tA/RDaGwuXcJHDYM0ybnYb97OOphTsAaTkPBo3PeRoTc10OIzONI
wsllbwFlyvaExCKUyy0NiGR1aGfdBQQ795fdokGMGbrJ/AyVxDXJVfakzw3sJht6LyPwPGEI9Rr5
xlaeh99K9KPNy/Kif5DijZqaUKo1R96E4yEvTsXT9Fzws39FPtxAXHe7rK78ZVHTb7S2lTd+zOD+
lRaE7/XLDNVTYdSCloPqarKb8y5XUGEw22c40HTbVqQixd+TXiF3WNCIsMFOo0dJ7hj8ZlyaygKG
YiMlfZfz2a9KGBRKatXhfQwCIben7I/5Z9gMzKPP4EkUVg1NW7vMhTlptI8tIepGsGW6v1yv1OwN
Rb72nN4R0BpRBLyYblGmxYJ4av8tGPPNkv9XV2Qz2FlFZR1vZ5FaG3XC54t6YTbUUa3Yo821tdGD
tvVkDvkZthk44cV2aQsTapGGkiF+cLgUGKPGM9j6iCa2Q8cGYUOxW141hexVW1L4OE97sULMCCGb
6AVxHPqh2DQAJsqGv19BzrOC6rq8D1GBYijCeZ+MN7T5/YVyHJ5PGXtQ7v5edX9h35wzpMwM2uwq
9RrcXyoG9IbYAE/ZYuIaxeXiZOsOsuvNykbymCWSrzWNUTSUVF7bS7qbsRLzzp6GwKyjBXAMexOu
vkhEe2P4yG15z2Edpa7RFbobtSrbtJQbRJqaycs1eV0PRIUS2fGnfDdiKLqoRXlhkec7nABMlZqi
hjFZWcfV8tuIwHjdpZbiodGH/SSUcSqVP8JgnPxKgsacolzY0905t9jzGe0kUZqsAmo0v8rPJX2O
HTZV+rx9nGOrM5pJ5qdkp5ohcJc5TZ11JzXcmtMgg0dOpw1oK/60/K2eYm4Nu6NPtP9M0I1umXlk
hP40BCjd0qv6YSsqLQ4Cs1BHrzDQMBmaADrfr7WBKHmUYGJTxCoKiHp6IoUost32ory5632Ylrxa
id8KpYSumChvzos+geW3/47rpJVtJ8hz7+sfpnl3UwY8puusimQbMxwGS2y4VmKwsX6FedOpd1zc
6tIPkDCElcoZeAsV9r8Pqq9LQD6y4ct4NhI/Au6pvrG0jFWKpcKIqybFbbXSbQo1tkK6wKY1/Xa8
dXnuTLv9aCFwbKW5K5NFxF+fapXrjM5tJEzDryJ8tpu5ZZQe738LuqS9yASwl7zx0qzjokKhkFny
Eq9JrZYsxOadxpaDUNDgqvclO3jDIUYeXvHq3nOaRtofaWErzDlUczfq9IT5CWy6iDz3sOrpn7So
laPwRMNxPKF/KrEAsyJ6Vj8dHFKf/EAis0jH3QxPaBPiRFtB/a/4rHB0hKTNYVBDd+k8A15ngWio
wfxm3wsArdLu53IPnQP3/G/XBDx95O+DKv6DxZYfNETQlH3qBvbQ5rNnW/yUZknKeBLvYMVRukiu
msFTAwpiE+u5j44E0ogdX27cJIehEszeXzohNOkr4bfGTIVDSGbtvdNNiGGm3osIn0C/n3QQPtql
kjIm0khqLMDhhIiKovGjc99O7U2JCjxWa9/pu6KeeE5FNMKvxEBpsRYlGY+xCqHAAJ5ypcfT8xkU
13Nv4QsfYtbcIsKBuEAiXgJQ6AXUZL6WgmfstKGkh+/hRUxABje9SsySiRF/qG8F8DKlevWRpm5s
VN4c8k1totdlM3u5IwkgKlYboFJ0S+k9JWrJ9V/X5T4uv2le6Jbf93z1jVIUtMYKRiNfl39Lyle9
a4LhsKkDBiJQ5Oo7MGoI20f7NgPGFo8l5I7yzi6eKUmq784YlnfUJvOUpnp3e82v3yXO7Y2HPPBh
KzwI+F0+6iMrYj32vCOD5hF+FOsHryjXO+rHN1yqsHP/LsaLNG5QpLUS7vxhohoXEXO3kUfzbn7P
+gbTa+td9s5a3QodTZNZlpWeuKiKm8ZxGrPQnOuBBoIVb/YEn5gh745MAliEoPho5RO2jq6G3I5e
XrIfaoEC1fQzzuD2WGUUDY9WPs8PsdCmUNQ9BT9KiGmBB928C3fhMhXq27YL0O66hLbbRs8EtzMr
+aRiJaeZH3VCTgjNsfwpND2OQtAumYpLO7Ykw+O5KAQ/wz5s8yb+oUQVQSBF3qoJAGrQXlm65YbX
ovGTHybX/jn27stZ1egHc6OUCb9AdgFb0bf39xCDl+Ay=
HR+cPn/hFY08JOCNeb6h0zkVbJkyNgI4ZLG6MS5uvQP8DfjkRRWL7jHI8YDU3jAOpEnycdPomMEf
boFY70WYd+Q9LtqVJeF4Rw9yU3umg25/2tQQeocZetQBjvQlK/CHUInfQAyKiV0FFf83fq5/GPLo
grpy0hrGixP4OYfme7WJyhLVmKa4e5fV6Dzttzyr1CZl5AZag5Qd0Xh/dMTsST/FjPNjll9WfE4Q
Pdqq6pdo16QZjxPposAH0WF09DCFSBIviIgR6P9muVlGITiUm8LidVqTzWL2MN6T+f8NIzwu+L0z
30eKpkLHrKzOCSblG/Qs9yIEGe+M9y9MyfSQ2m5LWbjoGHoQR9hmci0458mqzPGEKGMBL8haNeNl
MEqspcNLX6usthE8dV1hmGK+oLmPoYWcXc4BPViA9pMuHS6g96wK3PtgGVkffxovXqOeGTN9XrJ1
WezPBdBZ+pq0flJPhsu9WkSemhNjRDtXHzeUvPYU33e8G5QxHRwWl4s70zDCa4bRSjZdCpXxPfJq
Y4KwUkoFz65gvNKupnkr9jfyc9Tij73bMl1xT6ShuXyihVNG5FJfPGEo/K76tz5x8pZFRm2jUKBt
Y24Qz5+zsy6B8xRoDHci6LlERTA1Ktgy8eMAG6NuUiM+aQ1bwa1DBhupl49nIT+DOI7RAnjRp7rd
GSp2JJd/es83BUEekN721CCx7tOE6+BmE8xTSbbUNkhCnvtctnRtkbXUJJNuqhltCRBrIKMaW4GN
mk4B5CnEQkGl0gSU7zKqfRiWi9Lr+7mKbvB03hfTUqxwt8narEsOA6R2cul//8V+DpC+Id1tGLvz
29LDzeZOblPWPhXw1rv+eI1ndsn6OA6+m91IwXqLLi4LjE0J8Oy2HJ40NmQsqtCq5rJw90fRB0Zf
kJgFgi8P05LqMVRas1wX6cwh9aPxiDfkphIsiP/hqs6xHlYqD75JwDKLEpZkzIWiQXlaCQrVI9ju
GZSBOG1TIaOjPVoTMMbgFmqm8gnVeRgqm9BnXxs42QoQCGpx/Q1iehgO5nfJu4+Hm7Joa+Dp8BJB
CjkhERvvtlplVWyBVu3AfsC6xcfrPRuF0mnZKfUdHXDAo+3i4MSnFeE1vuUrnxjNgRlpq1n30XuD
zRjAZ5ur06/Rlw4qieKMOCJep/h05TgKyzDg2boCDTNBZ0dvu4mD48+AA4Xtcoxg3nECOSlpZ12/
zSAs3c5mwaP8ySKkvGfPglyAGlqivONRSNzZ/LFNYe+Yj0gHGwj8SgO/W73/DgwTgaEHqLpqSrzF
jwefdwu4IzoQiSNiHSjxbDcX1X28N7l5z6dHk8qA2agI/wdjf9HpGc7+yVgT6dmEnc3rIK74pJt/
VA3TOLWcs+5J/sPUuXwWdgjEraVH8G83QFu2/SRm+RVmbCXZvwigFknEy+lXBSMNlbixQoYfj0CM
nKGo5D2/AukcNTwp5PC+YK3Z0/oHAsnVEFE/kDXG+8eWMG/NVKL7Kjpb397xTp6TmGwaFJIONXAW
QDsqtHBfYa9pfSgn9BiQFziX7ifqvk29DbwJPg8KiK4SdXjtHX7DGvsvT1bPzqdK+Sn9m9jJ2F62
7/GM6hW5mqQIB518Dn5wM910hO9gYzMH0cblHHO27YwmwcOeL39BV5h+vE1i9h9qR9iixif8SQU4
auenVofOH6Ve13SoTfIuMI9ahRIox4/kJOx4hKMYYvyt73uhSMfmYjHUXyjQJWRhtjHkjB/r3Fl1
Yzojv2bRguISQmoSKcuaRPhpU8ppnRgrztDC72adtLPwwO49Fy9I8z7rxA1xu1SLtj9FetKBDOvz
u5pu+9qFE1WzKVdgxeHRnLLYzR/itRmxqLpOhEQxIXzwmsPr1ef0POuWCZEuzDYiSHzoVIT3VmUp
QRxkBtuPGQ1j6yLtzUf++ZVJTRzJB+gYgudhtWdTno1h1C7lh531vU3c4X3CosR4C8dwLPommyrS
dmLWaa69AjqMEZNAnP2v0MPbXrtLOlr7mYbRvlErGAXfDR1doRAUOWxJa3Up5GqB+Vp2qJfX345q
XsLHvR+vmAcWXRyIUomgYZ0xujD5UojHvWYlaM5fIm1ov9YKCCm4FGLkvlZ9eess+75TkdoSdgJ/
wxcifVrk