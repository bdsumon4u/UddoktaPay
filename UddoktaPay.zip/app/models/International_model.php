<?php //ICB0 74:0 81:1c74                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPuxwnO6SKpwsBZvGef2P3x/gWG9hhvrA7uNFPoC8tAVE01xylZsgpFIGC9EzYHiCZGR9MxZo
Bx3QqdMD6LgPkJc3yuxqWipxEJK9hLB5CdmPnvAZDi2Kz3GY5KD6i9JojV5a0mQedaFqEa0htzkP
UQTqapCg8d9n3usys0OGaT1JyrEkmJj52D6RQYA/14UEysxtPQOIRWruY2PZH8yo2equsk//arP8
DWRsFy44V3C27uBG7/odcsjzjx6qU/mghtdmiCTWCV92ChOme3Pf8x5pAiMmZCbQUQOXwZahypFZ
DrBE51Kv09AfC70BGdewoRoekr4h6O2x255LXOPi3kOTDssfNGz1fXm3q2MSLXnPVRbFCsfUhQJL
hZNWMm2DJDsJ/leGy5UEWGnp+ltmfd00asI9k06Co/UFxPAdcnFcwfcriZcKK2c+I4TG1O68g97J
4c8wiJhSomUY4S/a/KnaaJlHR5ZpGkNLEQglvosCBYM806S/qLF45UwcU6mRX0tc7T16Zi3xT8LE
hj2ECI6p5UGfv8lJubiFcsj5pNA02rbQt53EOTskcj+PBmfzIuMf5sl8df9w04PNu6i8AYJF0p5T
heRwRGMr5yenraZ1BJEOigHww+HZ33RbZTJN4Uf9+NeELg+pwFVwPQcGSBxu6mfCO9dxpiDMdu8Y
QlKfJKBANDJYyl7/DM+yRV0AnUlW/OKPIBW93vMelVzSi8vjBxJym46MS7LFhTLTNkqfdkd13Jid
lwDuanb0jxIEWtpfM0oDHLkyta/CqtSTb9WxpSu0mI1GsIkY5AC77Ab2DjjrwkHfxs6uZ//3FjsI
at5KrCIgDcGl9+cPrbAw5BSka+Mtu3eLX9loRuMkXxcLmzPxQYUEeZYuUG4wKYlfOCyfMLsV098t
+1kXFaIxcr5e+z2IPxKVRXKChafNNr8sH6qiMLNLQcWS9JK620UadF3W3LBPFebvDyVJ/bUboOcR
aXlCYtQj3xPIPlprewI+UC8Sf7nVSdkeJ6LjMlyGvKKOiprm/nXO3V0LoK3n+qCIjZfX6U1YRD8i
hiKPpWr7RhaNJfy66PhNSjFfy7EAknErRwmJvNQu0KWMhByVcXaW9nrOTt30yCAfxFaMebWRj09A
+/yYoSP6Q8SLG0IFjjmbxSrSMeuEnR+1aSmlmunyKFB2YYfHzp/W04IcNZXWCLH1cj5ezrluwjQn
N8NVPITph767BWtlx676HL6LY78dDABXk6FgeJOwEiX76apyJ/yxX7qkVAf2WC7iRkFOJBM4rmXx
vR5If7RdjmjGP87UiridZDdQDLAlJ6hSI3fDch8BBGwUhoaQjgAkO521SiUglXL4KnRmD2utwQKz
SRG9A8tM97F/cw5hFwwdHc3n6cLw1DX+9sOW5mPtPiuQ4QQCcoWjfhwvhNkxQdi4c5RjxvCcw9XB
3kgmDlEqtVsUeI9qsEdbNGfeI2XAe5OXmGVZYA7U9SjKKd1r5w3CfrJjwKlldzVWW0OFAhhaAOOa
6eHfpi5StWDVGRsccA13fJ+QjQheREkZjFT/y0BBGdgmuqKlcs6DJ5JEVyCnrX1EAXx7E942jVTp
32Jb0CK1c9q45RWUVfQrYlkHYs9KN3Hs42j3anJUOtxgyHNMr/INeUymtDf3wBGT/sp7x4404jzS
TSU07nuEVahRZpJXMLTKjw54ZEPFG9uBKiavRUHZGO4QubR0HV+TBfj3HeNwVwIDp5V0sF5h56YS
loW1MJPha92uefz1tV9cJQ8AqvZwoyLraOSvMvweNMzIS1gxDfGfOvvz61+OCOsaVHNj7D/6mj1y
VkBHFvRCoeJxpEVPiyo7WMEKBINWFvXRq/pZwpycbvppx+VTMbv8nCk9inOBdHI5dyHC/ETfqxNM
DcvPRbhcQE339QiQmCUI7kjQ3Z6ySVKP3wQgnk+Tvu7UH5pknls/2s2rOkwB0fpil+SnX6KiJCBy
V9ObZ1isd2fflohbNOnVhUVn7+ZdtPQ1vuP4SVps14FfgGocDjTOM2UlqPkVJx2V9KDug5Zl8xoE
bH1/W4BPKQzzDA8egq0Qi7c86lnvMh/ekGkmzBj3r1NwO/EP2wGB5pcNuYvd3U6GYjTjFrqGOJbM
uvrzfY2TitLPTdrPenZ5PSdKwoSKU2Cay8jgLMQIQqEW9n7RrrZDjjZZ1Pc8IJMIaixdwnKrgCMZ
4KRFlgv7kZltCyLlK4mcRZe1T9uv5TYOoB5kUB3dvUWjuGxGn0AIH8UL3HTmNPPjgizKgBm9J6O4
9O2Zvl+y5k3yChY8g5CSGaV/HmTTFRgqjyDPatTpeJQm93++NCgF+CNuamGS8nk+AEDsOw7Qwx3h
YOlMAxf1MvsLkPB1T7XZzu12UuExcl2LZcqufIbJBmQb3it3ogAI0XD5EL//xwByQNgLcfzhREfP
4vrTm/XTOraJNbF9r7bbCGDLS4dbXGYIdGEVJmV1VqXj8/oz0MTKfcyrHibvYyUjVYHnADkUUNfz
hRImhAuGSdiguPff+FWT8H2qabdXpZ4w0mHCrj3Od7P1IcUOGW4VC2fQ18wRiUHSwtka3jWpaHSg
1T+3ITZMkxvACURKBEjnmc10tsA5XpF3BHFHl+mCNqJxYAb0tcTe6zq815gpZqa/uGoubShCwtIU
/PLAWd5WSi3ZWp86UbubrGOOzows85FBy9Bq1xpKWWpiZHcoEG5dI0CMel38pQi+vgxtVwMdTZI1
KAvwWBTCdARliz63aG8WFLNI/l0vlGOTWPikeMVRynehga7m39DgWjJ+LvyKDDKghYJShPDFpLjk
RkE9qZcq0IsW+lg1YNEaANDmRsrIJRWCYh/xW/+M99SSg/x+kvs/8ZPh4LwTdLP2gMixzNdoP4vi
rn0YnEtoYXfN2q5rHxnfjzqSm3rVgVhtvr2IgqP6NmGalTt4KbpwxlkRhl79TlZYWlNzwvOO3tDl
qKOMLTjSBpYjabBNU8lbPjXWJufD4xrlKYXMLH6Is5EnBh6mfOP3LfptxafadOolufNFtRVutZb4
cH9eIavO4NgtRstj+DPKiMAUPF+zz3sNHNq4nzOJQrVvN/ty8DqVjlviUE1pCKPl2La0FzWw4J9C
Le/CU8OtA9LmAWTw1lM6eFsxVxfn3BYIxXIKXeulQcoOfHHl5ZMpywcSmAG1lDBXlUyQpSv7dX7J
nbCNogd0CikH5ygfjJRmE8/YgVhQV1Wq7fDqjPRXM0B7TGpy4ELZ+6xXqLFOBMvtvWK0PiQy634s
miAk99gWxc1ccoGJiC1fjUKoVOOfXAj0N9X9O6vinRlox/7s0izRylv3fX0X+bRdFtATHfG7aBoS
DTHLNroxTt8lba3/m7kE7cmTjUN+miDa6hUYLfGBE9OD0VwjI/blc1Q7GqrmxVWXhkB8MOQFTooP
Ro2oifnwfts8QWZDks9/7hjQWAyEHyPx+39bOK7KqqmfwP9VbEYs0DU1HJXWGfJM9cJE4DnxEQ6Q
0F2a9jGfOnC1ONxNT7qcpzWWRou4+ALsWIJi8bYVXhkTLCTbHoMWczERN020E4UDMfztW+GZuRl6
yBcxpyJDbWpLzYJKvW+IirEPCvGjjjya8W9pscDSueXir7gfiWf3qA3UgoKfFslc8/nn+YA0u3Fy
vf6WCNYIQd+X8PmJkUTli+/sRNRDhAahOITMQd0hx2xu1OEv5qXkapkkId3y0DwCb/MTOsHJM+Ls
BYuUkgrzezx1AIIf+EpMWFD/fZzIOoEuMRO0oVSPuvdOmjeztPnkee10dqg7WGm31ofQ6ZG5wIlk
37RzkVfYjdNQBq1i9alvG1ftHSZBt7OkJESceISq1HtxnHX2y4vvzYrtWr4IpypNzvxadSzDvAzo
mLrxpePV9TSID1FtHGuONDt799D1ZirPpu6yvSQPBDf0giQCrU/8QRfhjLWjyWwvRB6O+YZFpoB2
M0HGOncTeRDTvw8==
HR+cP/9Gmt0zkpT7J+TMKzE9VJjtWF/63WJQ2STP5znCPPbRIb7u7jbIScW67eKH3VqZrUXCayET
/NrblIX6PYhSHTqRcIVCQnj+8rQjGTySIcOQ7EC9Hq2NzVBv4UqHan/uBAz37fIgY2s7stI+nmPR
UsGNkZcsTIo/zee6dTz5E2zjPwIX+W74ABmiSqf/wtuAUbmwpg0qcvqYSaFwiU85XDNOMub1H0zu
yU+WCtu0sSV1UfKPi3ieTjiFYRz4DdMRiRiKW5+VEEmnZNT4jMT/Ks44MSIuf50o7JtkTM7OwaHD
4HyIovoFxYsmkDPjRJi8MiRyFmRdFsfQxfSO/qelbHpH898dmRQF82hH4SbHYQanRe0D2Z0Ishwg
vce4EVEio2tG7GApKZPFjpe1bBYRduKJtmhQ9MKmTmFOyMwEDPdpmhD/+x3/m1zgIUPMUHoMS4TQ
xR9B/UbJfoQvOZqvZd1YN1dq036q87AbUoTSBRM4VfWtxwPZgjPLjB5VN6cVeY6y8xRBPbQXv2Zn
1tnAVjJQDijIfl7DiNBCR5sqWbgyfJFu2jlpudH/6cxyGLZFV9SVrrG8CpldRJMT2VfUi23ejpeL
vMU5vzmMadE9irFgaxh4w2q2ewAcl9VNMsTm7ICLrtYxDA5npHagIx868cKvIcpR60h71whfEoG3
6mv7XCnhPIWr8VIZ9I0wBVRF+fq3AIbrhnbAU/tlPrhkwVH+BWyxVu/8ysk0md4IFygM9BWgUGeP
bCa9koGR0wQ19tykPGrFZO0Jyk8k8GZ79IdqqfqItnVme+tr/O6fwLLeGUmnDXE8xmYRYzD+bKdi
WB+gC8rn8YV496utV4k6132/ufpk6cIZvslPNOps8hd4EMvaXdXvki7lr8Pwr4VlROzjrE1nvIpG
lQzZgwRFbe2R11iaqmzXw+HKj7aOjwl2Z4R7Hls66s52DHfziYRZnGEj8mOM9n7de30P1ZQ8Cldo
ZHJkvqPh6DWOjiIxvMBszmXvXNEYCh0G4oVqvrn8VtuzSV/6ALpA9OAgXygzVYQItsUHkKMCBShC
nhnsXig7+4f9JAgBHA301BxRRUA9sEjynlq0Jc+Y/6Dc+UhU2uYY6hTNh/qig29Hk2MeQz24KF88
h3SA2X/0PSyIBFaxs/eTC5K/M+eNGem0T3Tczn/ASuE6CdJ8e1sDFIl4ULABAWFliDPza4XgHtCF
2ihYJo2CEE0gd4LSe8TkncKJc281XIUgnEzHj45cdwaE5RLWL5mw8z4gD/oaEZ1rqfxbwnUV7pbk
VifwEk0G8KtJJ3ZrvMeo3jmxNlZ5aBiMDH1xoiFAJmDmBabAPTst4boBvFLhDuKcDEK81ApxfwWC
ebE3vCK0/+XjPoUgsH4/Fmq+vG5WPsck0VAf19H9pt4aAZyZePYHnN2iYRct8DJZg9bzsW1mmNYh
yNlNCusXU5GhfvCXOSvKxcqeg4k3atau9yB9a77NFvp0//1cFMFg2mwVlUDdUq39xFYH2VezAvud
Mgkbvvc2y424Y2mNBbiuKfYzhNuVJn18Gi6n00qiY+mPJsCJou0hwK/zFbfmlJPoxE0j3PyRvwAJ
BLjnBzzFOTx3bx+AUa1xSVPRymH5W2YFcKo0Dx0WoXswftSErRg8cOUlhoh+NsnX0+Svf4whO4be
dgTjnccHvudcTIZBrDpt2P7Q7+fcSZUXOQNXtWfDroYgJb1zKPIhjNSYOrGeSQ2VJj2KwthBSCsp
18pIcwrTYsq5N/9gV5CmCgl3FsvFUtZJ1Yit6Qqs+CC6GIQ9+xuDlbhU7zFoIvGSLBGsqywj0xQ7
ApR2D3shdsPbrKPEyelC5M3VcIHPnMpTRZgS99+rae3m32bl6gInQwb+o6qOCIEGjnU1dsffTqjt
jPwgoGjfU5Yt8f0dkvuno7ctszNII5A4Uj/aFo9VRyBSrZdZIfEX5jKSXyg2qwCoEe/yTFesoIN4
Im9SJNMKK+JKaRfMkM5id1ra951W2CMxW73ICkjlYN+tEsCCIL19m2KD6YZBeNjVPcsIXXgDwv8X
V07Ph51jXYnNCKkNx6STQTRhTHel0pGd0UCip7RBJIkEPv7b17UxBwN0+qoLl2gBBGKsdjPRQqL8
a7Dz/WfLwFqQR+7M/D2h5gvlvha5mtaUfDfYhCEHksLmdonoRXdzRz3phgiPrbHx1UCeRQcPTv6l
cU0jQo/LgEmoJFoRfQJS4vhdhL7YIyHaoe3jspBbYyoVFvpMaRPp0kmM2pNXoRxNesYXkI+qWtPD
6sEEm4+iutr3kwUw8KMoAdLAWuNM10Iru6bTq0/S7OKJP3CDV6oUWff/ct3loi5MQ43wUC1RIMEa
C+Jni+X1DuHgbWMZbMBiLBS/Z3S1IGX+VT4nKPY4UneEhPcJBMLkqikcA7fVo5zl/yzzTQgkd20Q
E6PHVhyiHkOZL5Udwntjr5xMpbmN+xA1n9b3X1bKSeSFOLGDwuR2PjHbgGXLOTJSeEsJ5vhj9vyV
MeJwamGBDWfjTko67hp7T2I4TY4LFO/s5Tq7YvdCyqbGbl7oaF/onlvsfClPQ1edleGLmxboDaY5
GuEiIBmAIEuubJX6rM0YnX38kY4YnRc/ORj99zTJESKUnfMDwQoSYq/Ckp0Czwedtm9WWFJ4BuHS
84f/ryVLHUYxnmI8PKnPb/8L7esAa/HCyuexHg/X0Q0lJgyFisFJ/U9ebrTpVfc3q9KRiehU6Kir
dDFtHniOffikytHMqqXxcJccA3eKXZabtl/kJ62z841+jVZsqyvQRy+Q6oeuRLfWDuukkHuOpxFi
4AnRfik10eV6fl9++wjP8DKbjm1Wp9LTeLSjbNrYG0ZMvgTqHkewxmLrZmAAA1WHUOd6EathzxaT
RqbV7dvx7DgO5J2VqSoKUXmq3f0EUhFYhPsjZShtVAzes6F6DiB5LNBHOy2wIhZox9DRsgutIIOM
vbuGNdHCFrISHCr2r+Z7Pt6mAEaCRIhwSLFXUSjIJNS9A9DkFsuSnDqCep5QI4VRFclfErSIuxqp
5Ia6di4fNIuPFPVCRRvQq0CvUCqYK+DwjLFTsWHs/LEONIKp594/y7LO1bZOkypMmvxtpJcVIYVe
DXxjZ6HKDQIBPvx+DV6m60WTkFWbWE6uDlimrxqbmDwMdqML+yfdMipfoWe18vS0jvMIQoxVRFsX
ueJFyKfbqn2CzORNb6GfngiIcq6LUotmTVbMAUzWOYp35nEAU1StzAcmEwgrd9ozpNxVdE5cPAZc
+S8lyfasp58DA1TgNlNmBUep1wc9NxtlEWk4HB83mHtrC2XPpMJ6ZyCaVulCLKZXpA07v8gC+s46
VKwTCOtKEhCi4QuGLjE5vLKxDQdpNtUOOh++ClBHrgO6yWA1vLdGjx8RU4wqSiVFztAZDFuKKhSV
IOSXcUbtggg/Uu2vICv425CGWlGk0MkERcaD5GDz+/YkJJE9+5SGodk5KwHiHsZQXRJjyLDOJEHa
HHF5derE2n7lTGlHZYjZrTO+EEemcfZX1+Xl4zlRiTSc7Qz1xBTjc0LyXKYEVVpN6GRqsN9CIYix
1FR9k0j2NGVYxOkAbEN5pHAIjkIoVawfIdoZZCww5nQg+W76fQkGPep/9p8jAKcChjklEle3JUkM
z18QOfld6ZVa13A8wHVHAE30NQBAVAF4RhERaAi0pPUDGjuJc6o1+1eTtN9w9giNtbQgeWI8ZtCq
j+zHJCdfclr/56NtcPSVm5t1MA0u5qQRMdSRxW34dqLLB9iTRfAVk9j9efsaQUKqTRhKCYppZ6a6
23GKefqViEJC0DlEJ7S10dljXFfpB0HtWMmeffyBXIu=