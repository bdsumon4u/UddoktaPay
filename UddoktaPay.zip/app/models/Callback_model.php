<?php //ICB0 74:0 81:1976                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxVF7oIScEGBBWMA1+ybblC11K7muBJs8AZFyg75JNVayIWLfWtM2WItCxhQWWv+EOdHl7gw
AswiPmKRvGL77atCVA7G3luPz+qvVvnXFPpC1yANJvFPyzcGd3h9QX38XRWc/6vHouRq2ckckyxL
iPcDYSaGapvRJhPtORqQquhtVZAwcbbk2oQQa+xK/QINZthGAJ+gQYnqq341Eeqcg0oki/0bYX0z
wi+WSx7WdIEmSo886xKYs1Un5HwJ+A6oYkt+dUItrdnIJNXixNwUXAidS5Z787RiHagZdEl+alql
PhrDVkZo+D4TsNWZrRb7gvKkqIYUCIkw28NDL/wc6IjGDTUQeex7g5Uuvt1uKhYfWkc+zuqO2xE0
gziWG6qPc4GBJot4WYQ12aF/OENzE6unolR/GOeqECX6B63cuf5PwGFZ19TCl4XRk/VSwrQg8jyU
s8xYvJIN3CNsiI8GAtO9VM5oz5M0ZojNuxWqBEgEW75MSCtPCiQKDzEbPOLfpQAMIzO5zxdVXdoW
XrlWYvZp4cTU/rPLqzmZwfOUyCtSwkQMU4fvR2eZmKQFlOs+FWznndFS0HiGGyIhNobPmeoH1isX
55AVn3wFqCI5kcxXfkCAsJQmgHFfyO7jm5qwG5G7dgnUlb5G87GG25szI7KHvcVwV16Q2IwNMaxm
g+tM5s1CqZjMrCPwEXoLSitKaWOKlOBCCsH4LevgNJT1LEHOfmhl8kAgUs8kdc71B4wB/BV3xZdU
ALI3g33L0hJ/nw/gmGwD6ixHz87w/mIWzxNBsHl7f9Y8sPVxy/VRumbUBD3U9okS/8fbe6sOC1nA
tMEdgehb0xVRYhJ3Yz2emKaNOOSdYJv+pPRkFxuVMGTtpqdlqcihff3mftKaS9VIstTXNiEFYeZ0
yRF/wKeGoEdX3bYBZ2dKhVUm910lZte3AGetwXk9KuctC9hJGgmUu3Qe6T/lFUN3rOXI4PcLTFTm
wv4jTYbxyLN8DiNpZlfV3h5IFPVnKzgXX74jOtiiCmmTsIS4XTulSyAyXjwJGHegkmoeEdciFRJT
2vkim8Le/6AOI+hjF/ou1pOikXRw2HNEKpC8CrDGZ/yXcbbzntvN1HtSh0rKm9cUEQ9vK7EGE7AS
LsEUt2pPgIs2t0t99BZwkVNusEeiA6oSMgwanEMwGfEmGPofb94da6EZYqgmmZz96UJ6/t36DHwy
uHrfnCRl516ume7qSI65gVujHzRZU9YKORxZPmyeYR1RIwA+dUpI/zqSO2L0rFJfYIRAJ5WdCGhU
EEILn4BLejL8nfO/d7IEgq80ON3f4KjPsFPA+xjmG2rR7nOgqPMeYIPLGKMIw6d8PV2mQYTWs/uB
uGNXB/AmviO94o4Rb6zUt1Nq9Itliwd52dxJN6M9h5xhMCDfuiSmggvh7g4qsT4B3eiDBuww4kD7
NhWZSovbO4kd1Y9mJt/APbU4rhKwzhnzY/7mdlaktMN0L3GRHoDndMoSr0ScjGa55zTCsSXp+m9S
iSn5vh0FLgK6viNUSNAqn5bS1jmVz3tt75tFuZMeFJgEYYAwZ35GJ6w8DtF7ARgpHR8if8KwHhsP
25hsKTV1l9MFs2LTyw3z//QaXpRYnASa4M6396eVkaqHSH1lCnIv9wkDDFIlWXdzWBSUdyG3wk12
7lGt2hMbrRZgwo0IjqZTSiyZoC0kp6geVk4uclJIZE1ascemQIUlKsozpfAJw76mSe9qJ/zSYepp
aLqiQvA19XmRS2CRfZFU2cU3U1UPSzLCs0SDq9/gAF9JUniLH3NXjuyYK/MHSE8a80grhhg2WfFd
Ek5e/CZuYyu/2E0G2U8S4Ru/DtjKfjcanIXffKJfEz49t3WGvQSjiuEjTKng/jZDiEGSE2AGf+3e
YrWTW8mkdH6KBJ3WZfkZ8emKKnLkB1hzPI+3/QPE8VCJgrYwkqV0IGNeX3N+LvZ4cuEZgJ9bmTlK
zoyKZ9DtGKQmnMZlutydxy1Ahu4+dhFzL9TBI9xF/rvVvlwW3BRtBxcY5vYZ/d4hkZebaa1q65et
Jxk9WXmkAfNgh+5emk2RNG8UevrvOXOisqDC7ZEXSPpTpF352sY7KQ/I0L8AWe4LKU+ipNYvMSZW
3TDgcM1kMcddZNd+BQdklYrLENnwQYHR3QCMeOKfnapyIz5rlUulzUuvXYSPTd6JTXbCC0jiLc7u
w0WhhF+7IZ67X6W6EBnklPMV1PC/iiYXfyHhx3UNJdCZE4jD7KV3txyGzlmIc4zxPmrVzqTQItry
4WAeT9b7v3UYrqy+u/YNyivWSKyLmn843hQohVNVRQTNdoSIF+KgRJPxU1hMRXvSfaJGlBY/RSYe
ppgtUZQ/D+DOnB0rOKuN6az4gBDHtR6kllM/wRMJ61RfHpsw7Lm/sBucg8RXkzkoeqOIQ4igNA5b
8jDQAZWtHTzE17H2ZzqXroJKBbvRjrMrPfuIK7om4WbaD/vxtEM3jNeaejPm4kBNXTuAe0HaGHuA
fxzbJ0Pa1H1D5tygG2JNHhvgzTrlnVxL0HFRtpeYbcOeYj8Qedlw/krTxd5qXE0ZCukkx6XkTwfy
Oa9AAHSBVqAMFZFnS07JSbww8hInaKALaT/sehHO5MgRt/SXBb+cAUSphTV8EYNclDptb/eC7RTG
CFXl5hJXfTesXZlPPa+bl+Ji71SePiVbT3lxsSd5mxtiPNMqOKA/FP+1+B/wEYPBhuw5ouaC31BU
1XdDOpSSdhR5OvxIR2LpfGW4YBP270kmw8X1S7L1eO5Q3h4YJDPNuW5HxZIRnoAV7OpklcWNBRhk
VrLdSPbY/rAvA8PJk5DBIt+sMv5n7pVONTrkmlZ/RxkmNyC5JVoLQ12zqvGaD0i7JUld6rqeb0cB
zq2tAbOS5CGo+JT1Km39upCwrRUk2EQJZdDjLYeHCUd6yV+W7msQZwDUU2z5CzgGY4FtazBTWOou
LFqIHeTlT6JRKT5JkiZvlJqumj/qam0guc+VUC3y/RHc26y/ovLzSsD/fWB3ZnaIoH9QSMwRgkES
CfStAfQYvOZpUckYIKlrfg1PajrbJ3aG0WFNbiSgB7+8fNnBta/KIdA1+07b4+D68I/ZWTtf5UT4
iQXeRJsoTRgVk8XCr4wulT8T8ZspOlBb+80ufxqRg7n9qVww+TWvo0FPQk6smvlHDa9f6cAUiQO3
fU6eXLNi1FeTkhWvpi4==
HR+cPtNudLVdGMQOYKq8T0HmOJaSCbB8jyFiVOBFd9ubOk695HfBOsGGAMnsxAIcqNl+YTM1NBPD
rrjNdGkLCgGlP8eruI/mTk078FyWss920vMEbqpxR4d70oQnVi6D1++6reDRlXdQsjkKwvdQQkJC
VXTt1DbtkZGX8pvQUjumAogwVXU47mlqDQ+clJVzmw0+Ms2Y5hzbdfXkKp0lwA/hlrakz1PRFMf3
mrAVWD8JmQvx64ABTY0gUn+NZFIu7P7N0C36HDTL1YF/Mz9omwHhUlsQrybyugsU8K7fPmiYJIO2
Ud9+Hxv9LZgBQ71WhCBHTTDdzZeTujVaUIeR1KoJV1SxVO4Eu65fdca+Hp5c22UCFGMUeyACYi5b
BDA50abzIPXBFJ7iXYrmlyVvH/ilNKK7WXUct+c7oiFn2KCLCfPPr/D0rxckXTfnjOGmSt+p2CRL
LUYgloixcyFM3NK7rKzmog1bPqEE2rIthovigU8ZKBvBVqPWqJRMFoCZl8KoYDgpJxJLTFwpdSDQ
BXQtjZVOkVtXzJ4fScoa20ASzV0s/3V5ZVq1BQLKom546v3ToX+g38R4ie2O0agVLj7B2ouErXJU
2oINVhu8+U4mp/Pe85NTra4csMk5BuSUrnrygKrgPkmV2WBq03V7ttek40eb7tGFws+SvIcTtJ4H
6r2HEYDhERuaoHTE6vdGKEad+CGVKKsksHp9llNpu0iRirlTLpZP0QQi4l4rhDu5S2GI8Wmr7x3d
LKnRUYFwtjdh2gDIDgZ6204x2GpLGWplzutoR3cpEBPIUOp49l+KMnlJCx4LuongXsyCYWc6gDY3
AXwJE1rpU4+MNpb5XEjAIpLA5fa4k+ZTuaEQ0biXwDn0RK/dhIoRYtI0DizFGZitpK5+Xd65FGny
0NB/TCoQ3pXsRE8t9uywl4N5oqPsrNrIt8zhjAdZ4v8s20yI03xKOmL3WYhOid/3Pf9FxGaMSw8n
XyV7PYmjKTsvgqjxNSXfv4vINHzKE05oYWdKTBacd2wy+yTV9l+FghjGhXpEn0dLnqdFhCq/KXJ9
dGvjJBqlIHytI1cVAJ9DAzSiLT2bzmK2L3scE0I5dm56iMfavC0PPQG06uD5ZxC+trTtKRNJODAx
iTt9kcwvmu7apCru8JeqgmOeAdCQeA50lRZlSAVGbaNx0dV27nv1qlvS+//BHkoDW5IMsxjb8ibw
xg9cEtfVe68Iu8XHJvw2CrguiOeIi14mwvBI/39Vbqlx8GRRQcnLWdTtIEg8UWqrzboalikdAIBy
OiKC1acJ2H6LVaGvLM7bQXe9t1tXMfU7SKZOdUbks/KDNg2UqYIXJYxi9eg7zZPVeRXgDnRpWT8f
DPQWFhb7Yn9gQpHO1lho3KNV09tgVARQ6YQ+vqyaANwSwSQ7jskcmHHSXIYjaA+7TVAGwuKzIzAI
7RHVPP0VzmPJ+DQhNc889aFphxg0BMsBZ0+CkknLwqZ99n3srtT4jE0cWeEkLpjNnwC1DnU5i6DH
vmy7Yf9wawaK05qhvGB3RK/NZcLdmPLVGLUwtB8kh5w148bdXoVXMQVvaSoCzyeT8pZDazs3da31
4JJKmEnZ1vNUhXwIZOdzn0/uWXJhwTKDJEBiYFehNIYwXsIqiXhLW3XtqnO1wgBd5l8IhELJXwxj
kGBhxCMNEtNQ3eUH82mJszghQsok1OHAnmJZqRxRlDsZJI0Xw9gKg6SHjwNDgNZIPWVrgDfkdhQo
e6674JFQJowxCLQm42aNbHghUzKfVKvh87BpWyE+WDCmo47JB4G3NzAiirUK1ve2PsbUA8vAkfIy
YNKu+aRoG8D0bdYlw2rhaTfnbwyUsFrfQC3TBBlPolCWY257uNLWsco+/jqIirmEAYwxqElUgVe6
qqTrm/5zVBb2ZoIIZq5KSahlusyLwfinnAoeZ9gJBegafUKEdRjRG+NymM7u7ZQRgWpwl7hei+8q
iI0FPK9fcNCoJlS2Tmhh8G9/DsTo6c3FtnhUldmPd1mRVogUGdCRUbq/sDqG00Crq95U0mkJcHKI
5YYLILXfvDR38avjOD1IT91jPQTG2jsPkBu2kuhNpoGZ5DKjOs9VGxk0J4wIbftYnIvEKBYMhp4Z
Af2uK9GsKqrudQF7YM1B5fDULo0+XHbCiB1Zb2MwPMae3Cysq1ttqOVQw7er8HLo7IHUPFiQ43uj
tL8VAE3Ujj2F/9jgTOt+iNVeWUg0Wcci0ztwljukG1fqUBsEySSwTxXeXnI01ONjubwSCzFBaXHN
wu2a12YZWpaVqyjSEV1S3OLSK5T8aDbT6VJupeyKTsYLHeYChhTQbG4TvhJgirlEv8jhcAJsO4BC
Bz8YVMsntuK42yVZrfndbjSV2wsShCEnUJfqzh5o01wxKBhsoaccMInkXKd/jG4F38bHHY4mbG0e
mHyx3nDU0XsReJwTXEEOdK4J+fmPuLSnap6qgbDndFilIh6gM8TLBZ4FU/snSde1CBh9w8/55bLt
KOA8TZg7pJ+HUmfr1riRDRAOvLcDMa/GzWmLWe0iznlCjl4wMXI8Eja6SBoMAl7j/k3Yact1INyM
S3Za+PDMqPFtWpP8wQkpVFBNSthDHZShdnlphXJHyjRiEEPiohQWB4Rft6RZVlvWGHee/36+P919
wirijmz1KWISoLlNtVAvYlP0GYVrxUJwmxIx5hM2K14veW4+MHr0ypz0pKb8wNqdFzOPyTLKfJUh
bJXnS5xFOr1W0CswrGhGmC5rRREmssy5bj69M0/QYp9yWBDX9ei85sH0N0Z6OXAiDhadMehUDrNR
6xFlKmnt6ZA6EWHEiulCqXP/epzvbb2T5jX8G/YLA//YQI92Pwy1/UoONo71PyKpTEXCxPG8HvOH
IelMXMw2eN7N9fCKUibbzloshVVbMRrlEQmEr8bB6xDkx3dLlcfgIL+76nPrY7+80Dtc5H0ifAJw
s+TXVDSAMmN42sAQBo+qab45NC78oU0A0LvRVcwKVlCfZB9mQxo6Lh6uObHC8NCksv8WP0QdreAm
RWCQVKgwPvcW6FDrpQeRyje5Us6p+jobzW==