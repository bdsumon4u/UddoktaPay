<?php //ICB0 74:0 81:16f5                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqxBMRlpdwAy/GFCc456+Ds+dft/dp8aRiAH45RhY7S2SglrfIMBvyX9mHa7Y2du+7zb8kNV
6l+9UNTRAfsonvKFBEWnJItdOvxmZoVRwSgrOIe63JRcQYQ1l7jP2gfq31o9lahV00E1CrkZIyeM
22h5Ixrt88lpkE8kZsEyHF2eTD9zebszmenpNsfGw2WQIgE8zpcuEhnBH77upqHj85WHLHYAIMUj
7f0a0eWzrbLvAXnegCHww5GFDm46cIut9U5nTS17wAIHRv02RYubulmwzldVRiintsj+hSKDs0He
JJC527aBx0XimhvlchKencrAhXG4cM6ekWXSJmTVHxh7MxCki2wqJyrqFsJPYhsrp4yZoOauPUaa
E2nD2NfcbJ/53UWYWPr94Slo7a4FQHFDjddoYcaUDV91MbvGktIHMPb+gkQNOraqdtMSJ6uGhG69
B8X+iNqE1kozWvt1LOwtJNPiSZTFFtueLd7KlrplCFG6yvq3BEE2bMpAE9BWEg07doImXKt7BBZs
OQ05sKMmNRDHw6lXL/RmxraRMKry+VI2Qf9ujUACQXSjTq6DFqTlWwNUOOzAXZEFtqs3617qWf+j
jxQPo1nu4eTli18qqJAotID6KB3pZQKi9oQ4X0nG7XM80yYudEjHAh+ibwnTlIEVbI7DvivxmiBM
ldP4bZtxsZ9hrwvGS0JI/PuoYrJhXKODtNZzh9GH7Ey4PTConfk7KhnV1L8Ax+H3SZyrj1mpId9L
lzQDeB4Gb2r9nUxOjgj4roZXTDfD7HjKwjVYLpr33QIvUp/FFO6dA40wzNNsojQyLOr3zlMclz8D
s42IRbb4mlVJZzvw8AFw0OUDlkXW2b+YRLeBqfO48Z5Dk3yl10sG83yTsQD/NqmKBhiCwwYXLxT9
H77gAYyXGeAqgHz/wpFdioIPjrGXwhZQfE+lWFv4E8S0ru/jWuoGsPr7702t+BaY1jUxifjdb7iO
AFLottIOcJsadzIWc5h9wPygLLiGC/ygK2+wqOh/DHCRTFEWGVYdMsYOXW83eqPg56SITqWIHDRg
xFilpRULfxE4GbyMBoEEBI5bMHQyzzq/o6lLjExTwhOLrtg3dDNdhl7/LZ8pv+keyiEuaMUlGh5J
kRHDqAKxjWpCwJxgmVVPQF/F6Pa/NLhv0rUpoL/j19iUyssHAvbcbAzA0ZWcYiShbCK9IOJeXq0r
IlM2QUdVQrEH0igQ0e+OqJsotOxXTgdwgovNRWy2/k36Q+iMHfZJWjXeYaM1xfPmAX+w8zAEC8wl
fXad+5+Jvj9U72INMhvE/uZtVeNbIvMQQ6dVA6S/eZ1OIoQOvHJNkbYvL+BlYmXumOfXKyku7T7z
lgl1nAoBUNKXPFGJ9cO/jPnA9x86zCHCmBvZJhdMYtiBgY3QQx4HWawM6uMj4uQGQEhsjQGephVE
E5vAoHW5vUd4Rcc6QCJZPt5Gt1HUjWa/ZPXYdWb+6vY6yLGTwJFIM8znqn3+7EBAwOC/SfTo7ZiW
kG7+N7fOTz1W2AYhZzB+XU+kkit/CA9+fu4mqJxSuMuabbZiToqH2yUUWjdVm2REgRwMTSYEZV6K
6o+KlB0e7/AxMorxzkilmP0+uPFQZbNd8gQGr8dEuNn5qwlArWtfQ9sZmWjZ4j0N/GB7QqDxrQn3
/o10oN6obUEsT3y8t8BrgxdWgZwJsNITNhyESPwOUmOIaiTl6FTItKhGMb8xVtuIZ7rItVTVlxMq
aethxLV/78+HPHqtwDXyTMG4jgb0m51iT6/P0dB+Is55hUVKR6B2H2qf0z7eGLrdwrOhkJFES3ym
shrjeyLDG8x82YEZrlJPX7r5WthFAqVPzf8DmjeuOyvqhFFmUsUbD1PJjgxYWUXDRuUnTqUpTvMW
MMVO+17ckrG6yxYJRcn+yY0fJF6of28CynOMzQ3BiLqIQT9SxQNnshsIkj99T/8txXE398lvqWEH
eCEihTmrmzQs/GHha8YS/MatZepFcZwC1nrsED/IgF6AUQQvbsZ058KjQxhJzN+xbTV/gbFuLpgI
HyJIA0yjVPDz5Sno2cW8LgaXU0GJN/gwehB61IkOFeKkK4cM0WA5Jcm/cYqwlQAXEcqi22OwmUCj
SFYn7MtwfSXsXxtKrBBjdEdi1z/6TssMHofy9/q/DISGSxyoRwNai4eOXV4ta+4nt8ODa99RI+ve
mbBGlctfT+OAr7KlIfmOAhJeuMxTVzjz+x5G1HkEGOwUENYfApiGx6unqMf+QCKahgZFuw7T/08Y
Bgu2vfueKf4+kwC69GEQ4vlLEnmkJR2liNCTzRC2T/DCRNvW1d/ayek8k0ew4YBkcmnH43W4YNDi
5JvIS7RopZFELsYHVJWSccNPjQ2OVhO2bP2NGgviDaBjWa9SgqIc2Oaz6vZcD0DO09YKMreQEaUR
hBvN3RljH+qUh/eSVbAosTjcHL2SrCDeKDVAvW15kjRDourqa0PpEF372jVJqS0BD+opboX/exdh
CvgpAIfl5siJZwL1cGNYh+qhWvsSjQSIrrgyyvREVjq3hqhRVPgY4fs/Pt8KFfQWiM1GRwO==
HR+cPm4vonxd731HYO9UFJsuhlkuy2PZLXz6VVSlQaLzslWicGpy1DK8aeTm2Fc64G0oIMQ5Gnt4
7qCX8WBzkTFXyxfodzfNTjeOvHBZJ/qvJW3gaCtatSx0BHmFBB30xdoR/l5KqxwkzTneqYipCFGW
eK4fnKgDt4ges2HaV6jYXk8ekdBrkFiTREbt6xk+pW8vHIO+V4Lvm3WpLw+6JslnYS/ZTwwyAGSw
8PnWFPnXeMSurXF8uqPMZbqDmTUvH2r8Lc4kGyoESPQjWInxHXcO+PDMiiNvrZPA3h1ygaynh1SC
tJ5FMpgMlA0phC04SZkHDi5Mwkzx3l5QNlANQD6e9K3Q2i/Z5Fh8Di/px9E8JEt/dcZFV4WVKsIa
t+DKfSUxo8dnbK99DC9D4qFWD6phBAmN7uDTz/ZNqsnCiUsPkyowVPh9k4wAQN29xS4KSmzFaMo5
DJLRzU6QuV1LodH7VACBRLrMQ05MO0sV0fIipfYXWP+vP81bdzzmbLKf+7CNkal+qptM2Afh+lXO
ueTM/Mc3kp2L0b5xYr8IaUiKrDRX42qwjd7PenOmqIOgTqAOPQDWRPoLWUTbZESoRo+LQ+sQqvqC
LJ9bHXSoUTZBo8YN0oqOQ8Mtn8gj952BofTxR0qvZC8ePtvQPCytqXGvdOzTJt9NsgxpjcnBM/GS
r6Hv/zguu63t5kQF75n8BHyjmcgqCrhFSmFruWgilNLnfdMlzfYYCNbv6aOi0cnMqsfi2tzIJ1ea
bMFhkjASFiUXhnx6vZA4l3X414NmGJKqoMGcnkFsEw8kxHS26mJIyml9n3wUvSKqjPvm68GtQ+O8
/k0OG8ydxaIMb41Crc01J+ZxYOGjObiE7RGHUVzfGbl3eQUl6X76rW5DU/+dNwGItq+iFGIi2U0F
uAhojZFY5wlp9hZ9LQ7vfq5LfgaWxw1smgCNNbGPoM/L3c1fVChHfaelHgprVAQWWB9l6Tm/e3Ih
Z22Wj7Qp1QMd0XnXtUzwR75QRjyepwPiqB6VJnYW874p+yPTIRmG61bjMZ/LlOvbiHFhpNtSNexr
jwRc/GZq3ombXYVJ/bhIFYw7giozU1UvRoqLaSSHooUbKnURgpS1UUjdD8YkM9xRaWp37NYYvMjG
EVF76Z62+vQ33vlGtVjJmAh1kyIeSFBBgEIeoBXSewoslS2nz8h0W2VXLhS65hYoNv9DYeVTpFPH
sAwXbPCVYv05+irgK3/3nngZam3nVnKMvfAJCjDn+nkM1l0iAhIBmtKbEMxf2VMnPd+RonKmH5dB
A3dJMN0jeHqczyaUMrYvIVUP+QLZNpHze7s6BeaFJs2AK5IAC3YCigFBKie9c+qOvSCNBiA86uEg
GVgzj8vO133vK9s41cP5v4Rgd9JjWbdj1eEfX9FPGua43/FHAdH9C7bTrkF2aFUDGb0kKF7eeZQ4
AJ1O9P/IHBYNYwiakhRy+ZCLCDJTbAnuW4WUvQKPUmBvLwY1XA5Pe9h7xobvAPaTmncu/ZYuJPBp
mcYr8w3dpHMbd0qq6acPlvPLEjgu3Ck1kYJEX8wjKOGhZP3VQNK9TXZkqyefL+Ef0D96HSlXTBea
i/sIcYNZTP3iuXfcx+kxBDhQYSgCSG2QcT8nV5InUNnZJSoPH8U847M1N7VVrmICYqiLx318Ym0U
vXjHSL15WAl0b+YFMVRhuLHKIuVX8LYGC71ltHbiBKociDRRB4rkcye83VUySq9YqpAl+KpAE/+8
UqiOQfTRK7n9zFyvBZVsgIj/vOAZ2/PE0ysdYsuzZiA7MXzaB5dBi4R3iGBMb8KkzU2zF/5V1l6d
BIxZ284DEJkm0rsgmB4E+kQ2lodoH3um0YArSI1apUytDoazUJWkW32Du2n/u5AC7nMV5P4VD3tM
tmyEGifygAlYHOrkRYpAm9KA/5h9ka62Rs8pzKlCkfgKVLTOBnPplWguv8hSRE4H0WGoz8XENcPS
deMTT0T9yzxLc7dL7e4aLm8+JSErmUew46DyPwxgKeYwj1N4ZYpRDvjNgdPZTYebjwMb/A0mgOFn
VS5Y1MN8r38Zr1jr5+VpYFpqhXhO+rV/1dG8xys3EPpb9+LHXG+v3UNklG8IGF29G0ISRGvgHKaO
lYFdShlUlW89zKOPYG0Zx/VTlCLbZGcXnhTbTCEyQ+g48n/x74LbPi4MLem57A8RJUfjBZjPY9Jr
dtDQlVSxnbLmmvKp9gTUidQnm+5IiTwtsVOF7sDlcn4V5n3z2rdnV8AM14Bui5U40wOtFlY1QXjB
jgEuc9JE6p+MDz7QzHqYc73ewPDSQzxg97hmOmi834b9CG7nsagMSxsECmxiBPY3zsg3v0kM71C8
gfflsSRYXxDpEiPidrJK0YvJHSBRj5yc9m54BQ2CIILTV9s6vosAclLUz0/r1jqNWI7Z8nI7A6hM
v9GqSfg4YZ3I8xv2k8XHjwJn4+U4