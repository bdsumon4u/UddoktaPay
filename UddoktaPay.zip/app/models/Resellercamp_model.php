<?php //ICB0 74:0 81:15f6                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxOAM6sbsQ12nyNDJaf/Iy4HuDN+9ngRC+MFAAgpeep7lUKJTSgh3lmfgOvBc8jo4L5tbkNQ
X7le5zhiolB8oxQhH7VGQLmeQwA2XH3Z6cje9+BjpjYzobJ6SrMYyhA1D61lxcem7A0HQbvMyU+T
RVwPEQrr8eIKqQQlxgS8Lu7+uQd35lIm3C9y1wQuI9l7LGP4OFSnn1YBALeCW5kIiK2LmWmmIsfL
4X6ZFwglhqL+yYNHJ+DBmJBkZYrmEr1Qk+HzCYzC+KI0EgzqDb6U6VMYrpWbwx9zWYyq+Q2O5myK
PP5AACgkemPKVMbshjvNnAKWPhgOjhdyV0zPFuIxXhoE30u7rnLRDHiJorQ+QdKJ3a0VFehvS7KV
BW57lpxVBLF57kt02hanmW31MvPms0kpQyxtlLpVw2vue9dbSuk6iEb3tDzCury/1QS/vQLaC8/S
8p0Xql/2T3x5shs5EzClxI7n2MaL+OW0xsUNzFG8MQpPobzUrSJ301Jyu72HBDI7N/+5I11fd8IM
EhVE7e0dlhIRhntSLOpxv4ddGmj9WXp9mxz2n1EeI+CUeIAJuKiUJuOZeZYNPvlwKpeLAHXsvdro
zBpiIcbIa+TOCsSktAgcIadfny/Yd73zMh71yAODiulEV6JtgVR8ucHZT3aCUieZ7yxARL82uHda
9NkP6XSA/Ts1zimMqO7pjPU51vz4vSu/ZG4EszVP51L879Ba20qcXcTmuSQRPdN3yC3C1GbP6P00
cbrSW0TSsnVvpTo6HsLj/knRUANmdkw6nM3Idzi2dXOCuVRfsR4IukCiCsDasrYX72ejdJtlBZ3o
Zr80+IMk3jr5OHlxWh+FK24T4/PjIe2czPwEuiMaiaYnXzmA1/pwldAm+LHarP0khYtdBRfH63GD
FdIF61/lKp+7iHXKKlxQzDRGTcQthIj0ssS268fOV0Kw5fVJJok4HFVwndP2eXqWk7hC7p137NWX
Qna+t+bMRdVaiiwSp33ytjxjwhivAm5zbwH/CgbkmYPx3W0lKmBFBPxGHaG5+5YG2y65du+7NhTC
h4sGEltK4Jf1viTMbeQ+RvqFaMu3XBq9LOKb2GrDj0Y7nC+L3smBvtQZ3OJHfUhifqCxZnVWxEOj
ytIU7wpiZgQV8VKoMWSb9cM5xEDxPTA/9Zz/43tA0RRN9NhUkwOknIxMn9/cAdJ6RqF/szxdSj07
BROr5+n/QSm7OBHw+77g7MKOAbiAorcOXhyld8rJ0M2R014cBuoiGmacHHN+kEO4R2jnov/Xfmn9
j6sb/lFmEQdrpYYN9qjbe9aZM5xFwdwLLFqvz+YXlJ9t+JTHSUMwkOa4qvYDXOTY33aJGM+kI6eE
D0XaXRkdBE9wRNEcr/rP/oXLfNzvWetVtHX8LFXlbB+oOCYH4PlhNkPZdb74hahRqCTG4hFmOiDp
q35J2xPKd2MtlTfnu2nFDsaT55dACIWBhanRxu7WSZ3JCrm4844Faodl7Kw4nh835Nqg5YgJX8RV
FbWvBJRlgxiNEJqaiVFwvu1vy5SzpBcO/pektYtOyE8Bg+n1xWBF04EcK6FpfsuC20LyQyaajPu+
85vY55hq2WrfRW6LtSYymUMx42cdW0y3z26gmYwtaKu27HDOjikVEe/KBhWh+7Lq1n6QbdgYfzdd
XWJHOOHHvS4BHWUWGV66BQVDh7+mh3V9sSid9p3Jte09FJ0Ihzqo8S4gIHWk3AeLwJLDyhusji5V
dWlzYZKExTfVWeLBiV62SE3g3RW4mhlVc+E5FSVJC+8CfvXJDpaa7T4DbdqzMzvwyXZRYQ8ABts+
kcPEo2P8xBLsWEN9fdLF0a4GJh+0QXOgkKUq5prGbARd+0PQMBkN3rEMCkTFQdtYJwpRNBULLS0t
SnKDidHGA6Ojkt9AvvDsSTg+hNk4hd9zXoBp2RSk3frMaKG1E5RZewiphKqzObPSuyGnqLMW0l/y
UzmE03SYidmdTh0eleS+84SaPRPdiVFO2jTXjNXku2oCAJwPhlgrHB4kFNOtKeqfFZ3eWFyEuVTY
FRwWnNK/Jiaq5ysI2nbRbq9y+A2m2h7H5epidGtT0t19mHShkPxRwwNht1tXLzgAW+zRGa+drFRj
NaBIkEHH57AHKTJwrAKK5znAKtksalv7LVNmIDSlhw+EEQT8XETxgO3qh9u8+cr6YGcgVdRKPXCi
N9ZX3jd7g3C0b9BmdnFirbRk4Z6v16CoPDxdLxILSKzlU/c9ZfQDpLP19cnCwN4cMMU5tcmY/tHX
qxaLVrj0UO9oTNX1t6/iaB56DR7ZOSdY8Noj/c6gMTlD3G===
HR+cPxeaOz//C/1N4V6UzlpguUkpaMKU/J4gPVc4sAskH06mBN1BLjr3zMbHDVtZeyBd0WcrNTZD
GH5JvHXhd9QCwgI8rKMQtdewLBbVFe9onBMh61jlkmQmoNFwyWNXfCBjmI90RDbb1W6cV1UHmzYl
PA8CwLiJXPepfcPcN+ZinI38DR5ruJljYqlSahDpSk1+3HlgC27NLBWclG334I5LrWQRlohaOZIC
G+lErT2x7Pe8KFLyzK2pA0NS0H/Bv8RqCMrcO4Dh+7mm1vivmXAkJmv/Cl9QlARdrf/zb0KWNJwg
IGUL1oGRB1Qx8PGjTaTsRs5gTjiUlYLwrl6NTV/MhBCXrdXAwQnbUMZeUVyXXrbVjVmY8H2ABwGD
JLAl2k0vsXF1R/QmNEG7H5XszioZnLl9awdBoC2RhOR5PDjJcrG4Uwr1vqUWUSYWk6hpAzW50Gkx
AunSM6cHvhcceuDwpBzL9xlYZSHaii/YmDXOvk0FpM4ozGz+L0tMyA3TwO6xQLnhPV3PPoK8bkev
V8OJgvhnDHz23P8LKoycm0nqtnM2ZZXN8oIJvnGXio+dECN2jO/UisZXcHDjbBtJ+FBGecr/Dsq9
SkebbueU108fvsJYECdg8HwbfAfJXYAPd2Hqvmi06Gz0Hmv0pCZMH6/XKG6N6NPyCdERboDV2aKW
/yvSUZcJ2dCdtuDhzvwEOvluQh1PR2lGa0fcrFNXvrh9cBI5NQTAx3idwWgKz7fC+4Vpb2M5wbN5
B24TkexkhAV/oegFjbeBet725Fr3jAbgmykP+90r2VzF9mD9WIfqZiLodOIGQ39n+XHQ3AnCwtDK
dfr8TApbf6cMbh5/PnbDEpcPN0IaAJWr03rByV7ww+52RS7jq/+vwVa6bRBH/bJEmL09pS9ze07B
Dp2/dab0hQBpuA8mBr1qxiYxy2rC9+vtX9Dgwdh+KFKuAUGvxDsOYUOTJhrOzg4wzAQ6a0n26Vaa
LM11O2ZX5H2z4QG97Fz90ya2LSMzBXMBr6SIz1x/WEBvuQBVGs74DcFRGQg0ZTDoKfAXIIDzp8bc
oH2wEVrWc0T1/9aTIZ5Mizdwv9NljvmY9Qnk9uFz26XJW7TfrM/gh3rSyifKGVhHA4psDGgzNBRX
xjYBDmZhVZbWh17d0heiCFUtmj+IuDJZy9sHg5lZ61/wHyvRmDhRbveLx/iP/HsPo1n4Ni4KYJBG
kYymDnOsCjgPZSMRfz5Grte54+Vt6NQ81lgdWkOvVaM4Ki6aS/tAxqmDcVNorkp39eTlu1IrPUI+
YPdWlVgG6iu2l17oy2BR0dSYoPPP6x2CkjSO8DVJ7LelkHgEYWBPuOUs6qmOriHICDqV83xU8Vji
DGMSGe5r+fKKAq5mldjdy5cfreNDGaouftOejodqKca0O4h6IEQ3Pl6DbZi8JBp/2PqnfhqdwNGN
NKoqNYNXDiQKIMIrhjamPy/P18ipBBTFMY2GoX2aiYtJOZlnN7TgZ4TghwTLSm7RMAvac7pCQosX
vgWdhznc6QCpcvRAIZ07KY3x7dImRWEWutTPUpFQp+zxIGR0ARJBJakzBNiQCCPK5cQraWpP4dq0
We7igpl6tVBnCb27dwYksNNyqkbdbD40MDb89DjVRTrglkE4UjOL1p+DuaKW7JlELAMQm4fsqBwP
2TuDI3JYHjXVlSExJI26EMqzqS85NRzsTqTfBZAYgewbBgPb/vNuf+Ce1W/LEE2xuiCjIRDAcFDZ
8xOQUWFVPCxjFe7ajLZ/qwVyo5SaGf7LsdMV7r/4a1+uc0FihdY/GHqZDP3P8NsMKDJ5J7ouEkrD
gCmpIEYSxVfrIV5/P87yL5d1B+SS573S4Tffj0gd6S+JzX3GkF+KHCOIDOHEqQrCJGE9+va/jjZ4
RKc29gkGX5L3Iuw2GpYdf4o36bY9xF1ADwMmAFtQ7bBwAUdCb9xk5YeSfDE3JphZsAOeJkoEOxud
ExOxYBUZWZDxdfdkMuIVYtEy1wjxP9dspXDkZDMt8VSFLTdoj0jYQDnIOkWFusqKQN3FI7/EzbCM
ri9JLD0jiqrZ4fCdWmdZ7M0DIVJEDeeIDnlkhSrHgp5lFp5KqyEU6O/yS/bjQCqC6ATPi+wpFJDp
u6JQ404X5cPjaoCMBM39w5AbwxrcfTPr4Z+nGAOYi5g3Ur8AMf/ltau3eDNAvfh+sfNpl2d3eJ8=