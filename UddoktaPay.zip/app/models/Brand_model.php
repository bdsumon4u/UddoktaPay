<?php //ICB0 74:0 81:15c1                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsoR4NAnIUf5ErI4KTkS4fXvetUzzz2TsiW4ctqFtftASdGfNMGcgQTfzGYaKd5sFduiikzL
g2ID2DZ3baa5kFXF36CEs2uhYW6/XuAFo5bHTEojN0F8BSsiShGgoiBQ7FGI9GbfsQdASmPl8776
QyazrzKPPpJvnlIxw1LA9YwU3bjnR65fJ6SO1XEFek8P/2gpXNBkhLArRMu7AuNL8h75BqOPGF+Y
5fprgq785W9p4Vy+io6pywROtI3kbbLqEFSYY6/KXDYTOF6BtUZ6fp1pebp9P3/+7WJqgZhG8w6e
MI/xRdwGWhSgdtvpyIou9Rqx2f6WY1a0kGXO/rqq5dDCfg3OvtfbGEOJIzzl/iEVUKVukFwbHclx
ycYJWwWWyaOoPnopaVX0XLToMVAoauoI2apD9dExmYI5Xi56NurP9rLakPftC1077pbJtY+phY3r
BFqQok15lMw0gAHwd3yv5atC+nVtoBqgN7waqMA05boZAqoxhq420A5DgMnh0ZssjRHTFWocPP7c
LpLb8BksEqPaXiRpyOFEtzWAEvNXeegALgZDmU0kTxfaYz8CgXAlrz7B2KukTiRdlaVBp2IYgF7O
7y+u32vcJrTxtW+SJN1lqXE3JCArD9PhBVlGNxkicuXGsRMUU0560a1zWvOJSwEZXbVB45TpzM30
UN6eIWUEs29Qwqud0DHxCF4osiXg8FYtWKkqfuLPqz778OHCwoFpHedTvMV9uqZa44ukTFC3stV8
hfRDmAJo02nuOKeP1RtZCy36pnXuX+Co+fujQtBh8MwenZ0d+KMxJlar4vDGCTrlsm+HlINXqp1v
WWiLk/HdWhMvrPKmgyZFoijRc+X+SROCnQqbIa/bDy/NSojB6CLUajVqBTgvZ81UK3LnNsjjxAhH
XJPwqNL0Wi/sjx17J9kBK2gUaV2fW1CXFbx+zG3Rn3l8hI5YzeDdVNn2R/YbStyFXphvjXq2o7O3
v8/u5mtOEcyLZ3JvDgBX8Tmx0G9Ji5LcTuhgjr+9BFz3Jg2DxviNIiSF1+RXvLRO1bQmJE9DPZGh
E9DcH0W9m7tSjrUePCWKsSX4hZ4wIBgtfRPSLk2XKEGvCj9iTAMK4PKMaRRgEab7WIoMNGH4ZkGr
dKNJmbwsoAJ172CZAuPTMCRvNVB5UZ8PTUSvBk00EiPH/01sIkZ9hufDVpupuUY+ZcA7MrxXZqw0
DY0X1HwAyT903tWkmIngPmmdCK+8A+A0wIdr9pB4Jh7ZDsUUqb1ozhOOEVMlEZ5KWM6/jjywjCJh
ojMz/PT+Km1hKGm3QuTCy0hbj/UeU/adRpui33fEOfDhhfHg/37lHT8GuBOt22xGC/02xw40IXCs
OPS+/pagYO6CH9lDuJfI4g08uIgG6rPN92pup/aJwaTRceVSrGN5Sh3uqcHdPzvTbBP2/HIuqs23
Uran6KuhoKnu9TLwyYKoQRNaayKmRkdWxbkJ7oUqckmHvdYuvtbX3y1RT+SxvzsM/HHmFywYv2jv
yMwzPe6C2+MvVgEqLPIffW/W+PWhue0FPxcyf1ZZFaSitKUd0mFcKPXpy1EbepMlbDMYSHzWaJ6Z
iR9jbL9IDHPV+bG6nYR4uzVexlnQDcvmg3xT/zQXs5rgXrHwnfUfZJACbtAyicXBzBSClQvANWN+
ieVXAwho/agLYt3n2hnEqKBoqJBXLjpFfi8RqZFpd3OEU8VUghaG9v39hK8r2JUMaXLbDyJQsvLE
L20YBFAVmI42h7d+xxRWJVS0mo3UW/5k1Vit+jBl0QOkIxOqAdOlyFxbhjwxLNN7Nbqu5w+0dThi
E69naa+zLhROaeXRlu7FIy0EhGUnlXmdn4+7eB8YzfjnH97nyuQLWm6Al5znjFZpa/sZV+9+2gfn
2qndG8+9/DMJvpZ3cDhvaqk6AsI1A7I8TDqqRZLjmtkLGUyoj9D7DqwsfYfc7tLbV0NkEXZdc5ba
0x6ygASWIlX10GdkWgwYg/mJaHGKcswJhHAhphz2m2HROwCKneKK+c+xqSEGOAc7PtZ/DuQtPZy7
q+Hv9/hsPlZbH3VOMwwuE1zIvBIgEwivXHb4EGLxHYKW9Lvdk2JX+lKrZ/T6wS+PJtlHRjhE4CAv
Iq4UxCXKcVNIX0KcNBEz4j+L1W+chW6B8W1JkEwzVTjTyN5ASfknyLBI71kW1V2v/E0OKhvct4ma
Lif7YJH7kMcIfC2bnM1q9dUkBEp8gn/esn8E3vAHmMvaEts+8zTgRh5l7XNtkROgjLhRWla==
HR+cPtZHi4ZI9mblt6ibQ/6O1hK1mziSvqWv7V0j6e/yYPfiGa5qBji5NPwCUKun1JCDiivaZnN3
ZrNDqXENmJdkG33WdBMiwMPAm5jCiPa0s9ZYqbZ8v++EUMgsQXGztwj/XNFAcuWPUufatbkLbByV
XG17FZC1roDn8l7piykSR4qdG0hjE+Ch0ZW4+bHjapsHDIfVU0pScYG/P7dFIuut8LTUm+5PpIfk
nCkuQqwfyhB9PokgGfeCg7CUGncYNZ2Ct3q8rHwNpXjKilY6TF5uxGVB3eZcQFIkHAGwxEvPUswp
dGjBg1WwU0WLdtyLDGrmgf/SXr537+RAoVfQxfSSM8Wug2JNygPtIDIWAa3f5X7YRv4jUldmhwHq
V1Mmwp322Ne2C87XiJbpXduwRelxXhuE1ywpB4J4EIlsOQ9M3GziE/3lyVyNQIVBYL/aV2/7/2Nv
HdK0B2sSnH97DzqOS5UjOOfhmpe2WMZHY47TzyiP96N3chhe4dafFakNa/LusqJNfb3FS5bhzmIp
sRmUkvFmuUv+llQunPp2cWrIiBzm2SIIUbil8dSmlFmUcD6NB8qNNe8f/QbURymc73DRWjeZm30u
iW0srOnSHxpAHIVqkkfEAqoRnn0kz51a3uQQEEblNrIy8dq+TYhX3OIRSDOgrIsOpoGfsy5cWN6B
XDZu1gEeiZHwmpB/7fat2YOYUoWZbt1imuGf+u/BwBNXmvuhR8ZnRCiWQYHc/kJiOLtb2ISCqtm8
SRV6CITp06+tEGpg9ePcrQzDpqU3tqfNlwOkVtwJQebYTMBT3maFTkhqD7aadgAlfCUXAhcDO+q/
G1FmSHvYr0J4ggDyLUnIgTyDvsLkyWvxx88XYjmLj5bEDQvYcO+DQa60nFijUq1+aL2HRgBILygm
ZSLyVNP3h3Nk1x+aylTqJJ6feJhnPNikTkJohRh9UenEE25NsFArtreWj8wcnVA+b9AQ+r5PjHIp
S8SGaqLVhNjmsivwdu5aFg49zQjN571LN5DQv2vai9quJCOiIlS+PT8b/GsVbFljUfB/j0/4uY43
YgLFPilGOGMztWSrBGnFuTS2wJAJKOatZGuV93Bl/ukAQeBixG1yh+DbmpvvTLtQkNpNnaK8pGct
AKd7YCrjwnYRiWneZ8AUADYA/4khbfJy9gKq8KfGi5qbcHytOrZL/2fSFkUQedoy8pc/xmRZ7Riw
j4zzCcfDBuBEcI9zU7HzNVuc+7Rzk8QmlwGAM2wS6XxCYZgcMohttfYpa70vA+zzbBx54qQDjMKH
A8kvhKCnr1xK1ZMSJ0+qvoaJNgY1I7A5CJuM8uqeTNqD1xM7ci47VSG/gW2jk0drj9uPPnK+SUG3
lBx664X/yeknAp2xC4Ghm2Xb5hZ8APgVzPcqKoe2st9klyve3AZA6yw5pMJeT7c0eVZre2CkMk9h
vaaZBukRxIiUnCGT2E8TCP1bj7M94SK2oPrfV7n4mcY5D7RjPI91ShSMUjWzf7rwqXRc8O5GRqQw
GdTb+ln5cFIUCtla9Ss/2EicLpE0dUtbheq3GITdQISH4nwgVI64mssk198ZBxWYl/tF57tARejH
iRRaMJVB49BUQU+1wrYC0Nx2xPV8tc3uDAxkJdpdFmvfJmAWadBr0h7ibUn1CZI7euaEBOJoMM7k
jB14A043TvRCnX6fxvt7Bd5BnFZB2c9VH0Qve2eAvrZTpOu20Jrhd2DzrEhyPp07JbV/zZNTSy3R
+c963TGM2oJrTqW4pjUIZj70KaM/BEKkrZ86VEmnvy++IyK4O1Kj0Wx0zQstcdQtYJX5ddn4Y1pZ
s9XomuQCjpHbo/0Vn2q9L5COyemUh5OKWxtZteJd1vNzucPiVEMvUBteLHwU3ujltys6xUw4m/lc
28DHv3vL9ZSJNnsOfKU2FNcp/N9hU3K9e6t+WFUyqqpNhPOZf1MlNkyH3fGin9RqDaMu121xpA31
ynGxVxjbcIm5ryA2d3E83Ok5qusZfOhxPydR+IGq/VbATWvDtB44fFm0MFz7w7vjg9gUiXwPQ3YB
q9uLtk1uk41O9gDb7xAjiViixLVXGpg6k30iqfqTUVCo2lIKk5D9iNAhKhghbOFuL5NVKvwE3DZc
oGZp5nNnaCEtIJgVHOtAb85BZWNC3TVAioQauPG=