<?php //ICB0 74:0 81:1702                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPnT9L8uC7QsXle71hQlEkiHlIN+77TXoFS4kioYVTu93AwYh8ag2Rw6+RgRlgtDQdXwgKQye
3TiKjyFJlIaW//tY4/yZ5KgbXhgWMAST2OM18u3vsnxh9FkLnIVBSGy4agHdRC8VQrkhGDY9qpxi
swP3rhiUr8niXEJ+jaQKBgkLRAeQStLBYvxwcIdvjFv0SokcVUkvDb3ma5oHdHFcpXlL9S7GhJ1K
EZfcuRq4uyp1m7A+srlxD/KugssnWgZ351qhvZ/41EAzm8H2/2Mv5DkgSOQQYFWfSrt7u6F9Fr6W
/Qizhbvr//nLL1bxl+ZSJgMm8IYgn7c3kGWZ/ueE0HwDFIgfjQjSFLOknMqJtI8FyatjS57sQnpG
5EV2ltMDaa1iwv3lAnDCMQwyATKdnm2miMq/sDtctBoO8NU+LS5Vm2H2tm3xX59BkG+nnS5VTwNl
S+q1c2FaRlql8JDAq+hBj2uTWgoyTxcLzzdCWh263mYkkmvAAGSm3lQheOj3QqUwNytSCcUp/bLe
/CGcSirwv3Xcshq8ofUTBmjYjbiPA7wx7EnYqF20KJSsYRV5O2L4/OqMtmB70bvZ3f8Jg2hBkESQ
CYnl4NHFL1FtnOAfjtefQsVJ9Z0Ovdw3kvuBnB+dIkUka09MqlAzMXD4qfKYTgQsE09823EpuGSM
Dxd3i6PPjjnjIZsGlDNK2ZuXyvVS6OS+7+Yj8Jjh3R75xXr+xUB79iGDLzhUNaMbpwc5Ti8QCVOB
wNp/16H9vJZEjKUBb+y8rfAgRL/sGuTS/zfvtjjVsJS7B+zp/taFLVlOMy4YJlSAUCouuPnbmSY2
/ej9VLcecTWHxWvv7k22XkxXlE2iyWzkIbvB3t4uyskxVA9MSy4RCVVWHFwWi0Z9DzYwxvSaOTQD
Cz5ySbPug88SVvp5tyMNnCHHfVOSZV+kZI4FH9SvCQWi6yHk2KzCaPRzSTmb1N3HsCPyEhbvGkEU
rFBYnwF7ib4EnQkGohojbpWN0q9A64RIZWF3E94aBY9pqY3Z1pMGmbaAwYfkjR4lNS3ujJwTxL98
jiv95gAPloURZabpt6nseGPY4bzWK6ACdk0p+nIwCIIVYb60yhXhf4QtHPSXh5jyOMCZXbD8joph
ru0PJuiZ1ZMPD1oWL1Qnd5S+3lwQYSI9+HvJ5CKeraIQsIYvT/BwT/U1AL3h+7q65d0BT8rGFH9N
JuEcNIvFUsvIeS6eoUlEjPClpBTrTU439MkoX7bG5q2MrHfwYybYgIVImUjs8yj6+kl1E3OBNMOO
VI4IYA2O+Qni4j72utDvMgf30Otwz49uXa8RsVk80FanQDaPOR69ixwS8yxA8+BtiCIGPjZDPdpg
aXx+ZeDH/xjY+QGRgIts7Incu/NZ2YRZuB2Qi5AMjN537K+XXX8D2VXIYv3sbGQm/rhbVfUJoPNL
Msm5NCIien4eYGNcKWE+vbb9ASCegshoJnblKcLc4DtgLsqdHWFxurFvAZijygQCKNFT5Uz0+vxj
ndckGEC61mHFoWFLVZxMNQ9iEvb1V79EDHlfx3qDcEsCnsORsG5NZgqWJG0UZdXfgBP9jTdTNXc0
qPpGOIw9UjyRe7W3h7b0cPv1aQkNUZvNQ/5hlEnKDThll8GjIT/wGxdHjwLbLq0JHCluAl7e2WLe
Oz0aFGUAqDgVFhBd7gx4khE9ghg/7CqYYr02sUmnQfn/fW3a5zrYGjiQJ0YXuJrX3CJhwaUz18fM
MFDwA1dk8f4/NTF1qgxBcH+xZbDZg3CMjkIPswgY1dCxBZKL0HzAPJdlQqkSBqfNUcN9HklS77H4
rSxBHzJY53DZxpWc5Cy3XljZ+Z0uoNfMDzlN+7JqXQ5nXGKdJ+F1G94k9bu1KpV5iPk82ZKVoprQ
vrRcMEhGWvXPOPnRD3/lraPhjS2w/fTcnMaF41cmVqq6pYHs3rU+wtUJowlX8Km9OcggML8Coz41
orCYgMPKqRP9u1Reph6WCUvGayZiSvbNmkDI/L/Q44kxT3S5WEOb6dAyQBC0PDwhlKiG1djXu83V
GxdNE1qeVjj4N+BnV3aARGVmrem8sFQLZmqzer5eLo/0ndzE0WNz2ehbIG+OSXewAh46b6hItDnD
GI3ohTKGZfWXugnaScYDxxbihXtYiRhHNA2kV533UtikVoQVrkyn8DzQCtAoH1zsyxSBiA2HdYy0
EEm3CbIgmvVA4gXabci7Slt0494mcWbQebWfM+F51nYfEjGL/ihzpg0g0kI0LisTON1xnah7/vbd
/g25s7JjmW0bb4+x4n/Dg0gqM97an1kuqIuWBWyCMaaupR5MnHcQT1zmfPTQZOgTeILOeKxyILkG
+gMt0WtPr69bdq1T7EBNR+Zk+3a3BZ4vfrJdTchE1HqRiI8Rd7GEMQ5JSU982OKbhX4lJvwP9wng
Td2RV1Fk+K+xeuCEwqaI1lIMn0iL+yxI7zsVhYs6gGRQuIEa5kJHrk0zwjadFWSlZJY9lAVx51pS
I4xw7Jtd7LL3nBq/SDSK/ObiunSVmBxmTsP2WyM/StyXLnBrUii9TywyaoSj3E7Ur8BjlkeFLpQt
tgDHGG9o=
HR+cPyLc4qPuiUTfSjs6POuqUgdjs2dYhBPMHjiZMLHHcwkX33L3SMO+IaaP0aVj+Yu4+OOD/jWm
Aa9kDtEfaLQmgxK4eekF4ngU67D0lxluAi6tLV1jegBR3nhJJc+YGAYU9MLWIp2arLr4wRRS/nop
Q2fHYLdoBvLQutlwVQ/z8DE5+6Yx50cK85BOx6ydLWQMWulnBM4PzfMKfettqnb1212T9Aquclyu
25ZlpJ9Jps/raPfSzSUiZjxgNKZKV2E3sKiRNJxlXS3e9TfDdn3y7D8gvoiBJFW6Iy1kk5lU99pI
OtD8dsJ+9voWl7nqJdXtmL9uGuGhhsfQyfSt/uLw9hwCcjUq4q2Zn2v0LFZRVF3iyCiTkfQzq9kv
86oWtBRzqSpg+NgiqqkIrxdeqnSquNNBR62PLh1L32sWW8LUgR0kGk0GUOgY6uXLvSPE8KKFAW0S
mE9K4L9ceWDaisG+3KK8MI+4lW2aGy1+J9m3AjjyW6P67jYih91qzkiinu6BGllxIHsCQWGAuF2d
tahw1cqVj/SPkmeV+Go0PtXqzXiT1Wmcqdrb+XYCJZDvfSZJv5TUQUOgXQgXt+TwQv7UoqmmImou
dwKc9rMJLwIXAp6MXBgu+RMrI/2o+MxLmor62m0MJ0dx0gSJAgiMR3Irn/BDmAofkryam0ck8KV/
mwQNNo0Tn5Idsu+NTqn11mb8oMuD1wX9yjrk7hPnqWw/vCqZOlCgHbryPPfBO+QScuUZ/jR+y7Gh
xyHlmqPvJkxcwLpRlqNjpRZbxsErVsRb7k959TeCwD6xIidcM3upYMebQEcRK10XY9z4fTt827hE
r9dO8MD8bIvrRipfGY8Z4mr+mqyTzNtedlcVgvs2FvZby5IgYjDOXJQ1e5IgOJFVMIAPMlgYq0PY
36WD1f4Uaa2pRcOs6s/uwFFRi9ERHUu7tO00TXRfiLv7KeTha3xzB7NL0q9w2TYTO200oOnKRGOv
l3GPaQy+dWF35kkwLUQr8oXAUyN1VMLvYWDlU0Cw7QYOdamNls9j+TeWVc2quIHkUaL/45Y2anof
q8oCC7E1zxjnvzjmwCJdym3oCZ3pmz2rC0qCOF/0337VP27wfQnXpSyb+zxsVRWMbMmoN9rO8VIG
LQxVwthRKPVHTxfZ1aDJKH4crAVzz/7qxSw6EVPiQHQblbiznv1jqul3hPDA6P4wWUeqRaoleLAg
9KWgtmOJMfUo/6HWx2aOZZknGAKfas1YORmucq0SZc32oeOiFGNkIX9dpl0dDXLP+Uj8pvjcBoXU
450CzpElq58lZF1CBRDeXwiI4i+5wQlbHvbgbKCKKAJ29Ro4yqTgg8wd3f8rXWjnWLp7+YsxAc3i
zs6WYScFJdXU/mg6X/iMOnwntDZAq4P0u8Bo/93mLUeAjSeU9mDv6TOzSzuQf0MjR/z7g1FvTDAN
R0tj17OurWGGDCJSd4/vm4pGqiZ5FS/5qOl5KDkTzkqOTwi+Yuv6qaqRslTieHoiQLdxN43sgcOB
ZMbpYnXX1j4g6Fmzm4eLzfBIohQ76up7aJXnERfjw4c3XZb9yhAfjzbLAkV3OX6/2JeifNhzHFm7
cSaxqKdGjTufVyC6/gAK/LO0ITqEztUlAxK0H86+Z8tYfdgRYi2dMLqPAIsiK4ZtKxJNGN9+oAs2
DLpPB3M5J1iPuQ/tnx69gb38lQ8wHY/F7C4hLn/mGPsgMzbsNMt4dviYZmx8xyqMjHA2U1wLOksv
5SYdveW+DGHmzb6pLlI7jHhlaeTguYRVt77yVUSWEJA28UWMPzOngLw9E0hvzoxAvPQH4kPj5Em5
/HTEC5y6fSZU+C6FifkMFqDNHKTWBg54kw51NJHSBp0bxysW3EOPZSrAvHXYsy1hdYqiwEDgBv2a
H12HpWaxNGG5wrnBtE/wZal5/DGIc4YBYG4PsekIHodKTKDpCFKwTOnjqTAmcoNL8qtKKzBxhTym
qLHJ6H/xCOqG2ZhWM6qFE4uiaTbj7ky/AmrvURQWLWZg10PQtFdo9s5Wom9ToULJPdF1LRWtrh/O
7B/fkl00bIBY0Bj1J0ZHoBULaq2aAepIN7SgcPtBT5b/9KyvgqGcM48WoH3dgHHpY4zL5eyBqa1Z
6vRoKVrs4w54k5d2Pds4/pIIora3+sgfrD3syFuBK6F5hbyuUXHd89hUP/RW9GsI3spPxX6e4AM5
LSeH7XS9eqVWa7CAukdRl//b6QAPGSURTFsiNnl7xvopDNxlkiR9TBeV7yXsiNVH5IC/EpUd9yt9
2DIKylsug9zMVt8baJqZ6TSEkMuVZjf8kRqPFrOWSYEdWS2hfsvXTQouNQdVMXaeov58tYiBVq3A
Lw4WTJEG1xem5DQ/l1ev9ht3G8VWRjej9esKmqYkVD1h0mAWFRsO0u0X15U+lw4cAoR9+DZK0ygq
rFMNn+vKniaPO+GcvxZ4Q5BAfXpXKdq5s0W0rddLq99mDr+XhI2u30==