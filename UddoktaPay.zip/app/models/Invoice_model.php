<?php //ICB0 74:0 81:16c9                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/kkZTv7E7OHQMOO/P/++RZiv1HC7GhiCzi9Ak6wTh8d2SXAZiMIm4WshEOqQjcaMf5t3RyN
XkUdLyW96v/knaC4Ux56sYkgtiSv/XqB2huYc6oz7psexc0JqwptmbOk6xmv//6oPaQvui8poHLG
0l7t8INc6MqOZAnvA6R7mKZvGLC8s1Kd2wU+Z+PZhCQC4Jdhr6GVAGBoMXLEqO32cO/9a9bYU7o5
x8sLAGpR8wHj+6YBSJHq4aRb6bA/Hd0vf/nmiyHguXzmLcWDj5yGLwBnZ3vngX7h88zRmfPfbNqz
gupxPVj3rxVnEenquAzEB4pMqA/0zgaelWXaJyvGHz9U2Id37xaHLx2HQcOMgo9NFt1eAn9YzYBc
EGo9YmCihPH56slCL+iZo2EwVN+R1jJ64Xui9xFs7gj25/I4cB+32rHM9gkkUFzt/+c4NYcll3yh
9fbqyFFDGwPK5Y1ldZ6rVht73e/oBuPuEOs2R21Q68ggVSmiUsZBomxH5FZ14Ny6AlihfslJmBRl
oQKa9HDBFoORbK2gn+Mpiyc6UEpgy8I+e33s0WnXXlH5oYupE3yvRA9wsU3WghSk3d2zr/nAHE0f
2yMEGP19VLFHospXFoUUIa0XOmCCjDUo+OjEU/SKcT+zEAO5A4yGdk+TBZKKNCuZV8DLVlTp5jFR
w2h/8wDC9yz6WQXkk7Bdeiuf18e5TAppyR+NuQ4JjQL7O/jYP02DKh6qYiozYy8gFuV1c/Os1G5b
W6eHoybwqFY1NlQ6JYYvfPD9wrbZCAfh2uVBqsGrGmpV8zF1afEIuC/Lfhb1TLc1iTLpYF7fVb6U
2YS2BQ4oWmMDV+i4tAnvFWOhHIpgqrNRdgg4+TXlLnYnbz1TcrEhmIfjIn8+4EOBfYkT//In4gFY
dM3eL2+zdkX6KKDLj7DqVNz/9chO27/bKq7Ug5n62Flwtei9u+TqkNjTQ4vehbf4OSOapFHysdlF
XvSm1NCChGLCj0Luc4SW09JNCWxLCTINWVEdDKoCFoOGp1Wr+aThd1CRZ6oU1LSmaMkaHURhGnat
SSRk9FhXvoTWEUOQlf+hHWmRRk5+xT7kTlLqCQU6SZahHxvwyFKp0t+ZquCqzDNdVw56gqVYKfcb
dKsnJPaOrlm1x/kbPqbdyxzU0fbWS0fabEDzfGoqWFjxaCCjDQNWYe5AVEAM4kuZDQt8yFYhffL7
K41aR86p8atf58qsZoYBAaV+OsA0Wb23jVI4eVXIGYG+ZLak8EeFZh5t4VqPoFyB4oigCKKo8w2o
Vs+qT7R/XVTLeXQSZYSa8fnk6vpnBV/uD54E9UG94el8rzN5b6oS7pWrmu9f0DaTqmk4o7uQNREv
kw049Z3YwSm65T3EyDLfVQ1td59Z9Ric/qka/A5E3lta/45nqRrPfsaJAK7KVNj7xEGqSfrphspR
jrNCsTCk9PGrSi0wwv10fECuuGZYabuRHYHYvflsBDY/QktmKu7a5xDsBWbDTEUPfHM3Rtgc/KJt
7fiAFcKcUOVXMRyCt6Ai495mhPD+7+GIJCBjEQD3u78otaYDQ538VKXEKLjGWmxKtbBhkKUz8LUD
VSP8FG+1lNwwKCZYky+ouPHfyT/ge4TusckldvZCwz/LYkde19cs8uv2xWxurrSYABBW97QZ+Mzq
kPP6bIVpntf13WdO2S0E2HBSwqrkZtgU5ss2dEJhAukaz7HdEjld2XPMXhka9wQMieLZrGPrgFfr
X3Yq47EA6eHTbkEeJ4ouy06BQdvStRPuRj0lM0QsMh+x1pYhPMoq32Njx/RHPuxrs+jtr/j3MNMX
wUF9feG8YKA/6ogOuGmIwJq/UqQuWs31ycou4VfEV0dOoVa6VJCsBzQhJG2Kmmo8Fd60pQ6QySqt
XevPEkgYGipUHhS9eWESdXCQLQ0hdL24NzFmIneLRpxhnN5IbbFURbxiXvzKBWjP0BimgxXaDCsm
SmPskNEPV2iOLi9e6IYUlxzv8+OEPfrHQ8YGTE9VW4YVYzWxDNecWsK7ejZFSXOJaWHbzRX9W3zg
y39TfBgxVVFE22Z329In6gDotMXBSOeilFLWPLqHe3xYOMdoaBTxurs7DgXMKWodSm92hapd7fB/
GVrHDR0DjQffR+Ccw+1CBZJ/7qzM2ejWTSXodDwDcCmJIi8jvaadlXZwuWVoLuAUThSBwBmbZcTB
zaHWrsxHRehfiyMzZkVng2dTtY/nqHAJzvc1Y6sLCsCNvmYtSLPKFjmFgRGv/73Y6gmpe1vdAB0m
gwouxnvhraMWcmJnrpKD6Bff4/8GJfarUGHFQhHLNAbjTb7DAMGKsnBu/QKRUry+p9PeLh9oTnLo
H1nLYXao6LtRO3yYdowSDjDC3NfTeBYmOqJSB9i2EiYtcow1QFiH7Xsl/Ec/iesA+NLd7xJTytgv
Qcr7uwMCCDyfFZjKpkOcYjuS8qf7x4R3w4DwHfm0y0g4UVrOUkFybgQ5Y25Kv5qo6tGSEUdv825C
0b/6nbWDywRs98tiftTgf9KgED8==
HR+cPthXRhKsD5Exk5hxbX4+H8R9maN+S5Hrox3FY4I45IvCTc0K+DIB0Y1U77s+fx2wNy+y16b8
0YGzt6Y95pJrv6MeMXT5oC6aUzHj6O8Bm5pghuAGJATTVVmggZh8WeQX+zWYm3G6rgtGkNZKXLV+
qGp3bdgJ+tAFn0k4sFrW2eoqOCHhoBWF77EWuNeoACSaq1scXCIh5WD1UguFnuQjYYwZuSKvDGSr
IoQVY1XsLk/97t4j6+IDE42N/pVS8j8tjJl5vvrqZG6He41+aatFV/auD07tMAl7sgrds4S8Q5ME
XM975O2fk9XN1NE3yi7ToPhPiIj0MbxkbsKWdgdB1rVX3XNqLtUev/oLWAAgVJI14o9l2JSqY3HT
5xo5541w+UfC0j3v4qkjDS9dyB1GZhPMcQpvs2XMB0dvypThJNcruW3DRO1u6c7Gq1H/evT++jZh
hqbCfGxg71rF8kZqcbwMFTvxvjUGcFAUczdgh8BKXmTeOtH5vbQYuHtm7iSJhjFMN6gdWpW4evyX
JQtMhmdg207Y/9ZJTho0qLHZJgkJC2EaCb2Yk/xX8//6vSTTvF6GihwCsnENYLRtnHRXL8aZAwUc
J8H0ky5R4S0XzAJD3360JslM1frOMAUEogfwrF63nUrPLmzu4lLSr6Skes3RwmPbqHrUjCx1oluT
PLL4Ra7rgXR0p3CievcR3PTp2Fnify0RbYfyeYWCQlLqgDyWS1Hd5jzG6jSGOYoxumNb/It3cZap
+f/h5wQIrNsFRDIAAOvBQ0zrYFhpjT7rp81UgLhtCng8friDjYORFZQOpzrVazeOu9kUI3iaovcK
57n1wB088lVINFj/YHrIY5TWU/1eHlNtgl9xi+rhHskjozRJsCfK4+te5L+HdPN4gWrJStM2TeY/
HcDZPd900y2PTNVv/eWExoOukb1l/+iV6FkR1NopGDVavxvxtayR5dTAKv0lu9z2cL+GaqNX/XwZ
5HRblz0nfhh1Bf7uiRQAI76I9kIokcjc4G3XszTQ7I0XL9Yc/ynixmr3Tua0/rNJqWpHqpv2jFAj
hbue5XxN7ghinZQKsWdNSb4MbNoUQYOBIu7+CzAXLgnWJAyQ3AEM0jaAn2EHYu+6LcA0+fk4EIXY
9Fn9jPhoKCs9IkBUxdA9qDh909d5vuJSZvlldVQv0Ao5wmCF/EUW3JaB6M3ygc9L+7nohNAiBBuK
/ksBzSMG8ZJGH3qorMRU8zje9bSHo2u20rWvrGVdmXOUJM309F8OutHOfnJ80zPs1DYhT2nr4Hap
9SEFlKcirJAfbdlfNuiE/waYXMWjpadLE4i7fv54PBGdXKNmVOMCYlWUa2RrYGT+MknTr/pG50VE
HGZXTwWaqUTyP2NxYZAdUJQJK6/za0BueP5LFf1LxEIU6FpGZKPS0NBKJIMIgqtKc04pigsCC1ht
0dRXl3kKpfoLfvRse5+LUjmlLPzJs/+Q4A622JHBUqhDWeUKefCSYSMcQYYa1wH1WAaWfzJURaU/
nNugx1gjVjFJjb4HI/HIHSVBdN/96ijQk0ksIVJANRjR0EoXbr33wg1ntWB2i6uZATHobeHcQvz2
d2ElC2YXrpT/wzs0Um7H9ztaRF38Y19fQKOjZoIWOepbMfypf0W+oel35y6W0HqeWoNY9zLPZE2Q
935W7oL1sdBQQu2z8BOiToZMb3EXUAU7Q4xh4e5IBJisX1RNkOFSv+bxstsFSHyCEVyhgXHpBV/E
K6ke8nc2azROAVXbxVjCLZqUqSFNOpZ3luOx+QirNlbCfhgFDPrGUjjYU9WDyYWtrWeuz5mnNTHR
RMQYe+P8W/BVQiR0UKT/YFmuMJ/vkonzk1//oGDleBDSTZVGNa0dh9YHvGDrisQ8TWMvRi3ad8cY
lx9GExDGUhBJ1r73Iz1tAsD0P+ZN196FpuDzNgEo46Fam1zg2GYAGvMxZRTcEpwEBb90OhAy5ULo
1Oe1WWTnmHO8zqhd3KPofPkptkF6szNpq6g5LErBnJvtoTzggZeobtq/Dj2UF/FYMBNWb8NB3dd/
pmFPPnsutXZutsHzD2tDc6Y6wxSNtLHjLauBAoXe+lLm7Vmitqk3y0E2pW1JKpxGxNQ7NvQ7Ll5I
IdX35Sp8jyPpDVDo2ocm+WNz0Ve51tnVtHrievqYq2YK52Of8TXVgYCUiH6+3Cf/7wdiGSQoSpCW
yo/iJzmHzzIF+y30kFGe9tEdn9L2adHxdQASAzRhx+cWoNOeol9b3YoTFa+MAY5nBWoZHgGsf5Ld
wmqS+g6xLTzDHX7v3FV/KRy9IWGnlHaB3upPW5LEUxWfSDY9m7R1yYq9S2S3lxEfknZxXcZQin1q
bhTNHezRqXLAF+23uSQ2g183ldW=