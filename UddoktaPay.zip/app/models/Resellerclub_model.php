<?php //ICB0 74:0 81:15e6                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy2JLR8pDgw5lLp0aKaRQJOaWeFUv4JInfRFEQSsau8kYX1wKun68fc9ZHvKSXNm1UAtO+wn
lmwiAPVk+fK8WqIdjzl+WQP/2g1aflkham4XAyRdqaQ0ybOEXWxwfvcgjdfODLFDz9gdj77WnGUK
Gml4vHAkU2s65w44BrL1EXJen/FnaRE6XP0tf7LGj8ByEkaw9Xrwi+aasf1TwGBcyE+0976hybfi
VHWXTTY00Khdw1yZgfTLGdZCJf8zSgFi/zwieZ5mnqvjT5Q7EPpAeHVOEEHxkUU9QavNp5ROLJJM
bqd2BTSIB7DC8dQcsEhf/FDEgphuyQY+257/JLKruxadrUnsZ/TXHTlEO9Dt3hVqcRzaKkLvYTx5
J8W+xUZXwSu0rTj8//nIFtMHFpOsaqwTBT9FgEnEAjHVT2XgMDQp1dYEyjTPep15TP5NjesS63iH
BbxMI826teeay7PC0kS76tNf8p+Uo/ulLRKfQSMQDvCwsSzMtvfgrWycdu31VJ8ZNGI9nk00lkZX
7atqg/SP4+b+BNRicMWggT8OObvsg1JwjN5AqgcyEpA1k16n9Jy2iJuuJ90zLHOuy/pc2W3y9ZRc
kBF+1TnnFy7abNFYOxnu0HR07uvCu9Wa9UhsnptTxPLHYbwgG931VmLelCrXTVuEwuOPnk2vG/+7
QtdeVo60AsFYJeCFTtwqrus3ipzmZeis3tRXPtxCGEeQGwwQDeaz08drewZXR7WHlgJ4WVQup4Vp
CWTEeOT+k2bsrIpzZFxcOdpL+NqFvsR9eBkpCNn2a25bzVqZKEI6cSVywKzyXQxztgNZXVkD3rRk
NRjAJA6OZkviR6v57ng7uFiBdLtD0Bikubf7+s0ZPPaiGAkd42CST+VlAnj1nAPTY2wdEzq+B4BG
dPlf7Pdb3xaZMtHdOjFBf0XMeg2V655HASpEoDzWnxYWb8H+NGJbqYQqs4FTP/bgDZ6NbZzju8Au
C9t6WeyBrTmdfup52k2ZeVvgD8Y/2wLM6da6//KHZwiNB4Tbpij+wD/Efids3Fau+V/eghKDC+lT
CQAT2fIiB1fBRidHrs8YtIEZ7ayJWgUdcfAMDhuzM5AthRovyeZFWVwp1QUejul+41THXVCoDzgU
4AdxiEqs00i4kICb9k+0IkF8575PY79vYWwIqgHRHVz2HVf6DffQnYFMWHbHMaCGc8/8Ce/TDDPh
Ug83YyC9Z8eeUwpedTfO7Zgr/4Y6/vizHX/kqWwtazncX88PUnVXGGkVWMxsL2fyIpiEzZI5vsW4
WTBTNpdYxSa9RJ4VBlHVE8IwiTCqB1u6WgRTWaoi+4TH8iiaxAHIRwkzbGns2/+CsSPhMCs9f4cy
DJIz0xSOyV1UdlwZUek9qE4lkK2ql/TAVWAKSRj3SO/yOj8p7KtEMrU+8sW+jJZ4wMvJxGTWLIst
PpZ6TIlxa2HrrT2w2W6ngdR4vCzdBBN1mSaM910Fa/E7l8NOj3XSbaW24oVwB0qrbwi/shPEbapL
uuWrvGnVLJGjaw4znF+Mf84XO98psqOoHkL0m3DNhLLpadmUjQ/fDTfrMc2Az5cnrtZndbMUnjRj
MMZ1nwlYpT25bSYdqOrdoMw9XJv2LKszo80IuIFOHCv4lGld2LsN6+TjLcMzgKJW35Si2IyQEnaJ
y7EYqp+sYScUAV4dzX9Bw2NJ7RR3d4N1B5CODua3ILUNpHZMR2gMPykkkHLYha/rP8IyjKsFrs+M
SNEu6neA7h4dp09Tzy+h3rKBYswnHAER/AaTsiVo3eQqvy+O1pU02MpH8xLoKGVgbTHZC+cVnpt/
DAxgq+g9W6OPf96J1E5X/euAtQ8drBMswGGiTOfJ8JZGJeO/J8txA2RZLkbdU9T/8AxtbwfpJ0ue
f89dLRVLyek9DN7LdJ0GhmkkU+ZLYNvyvLbEmJCPZv+jIZW1mdswsU6k7RmKIi0cbNIRzn+eLrs0
kk8Cmq2nwnSmk4NHe1N9SqoAfpwpV8qoPyqNdkhEONbbVBmoNrPhrLgDgiWVEMrbQCme3cu02jK+
6OR7EFDEZG4qJqrAfcsIYcyNmfNaNbWD3q8T/NiYQCTRYW6m+wJkyY9PmqPJzoKR3XR1Tl59jgha
36ENS2GlpE8Yt+I7Bxcy8DjsBZhRleMX+oBZN18UoHcKENTV5NcN4rBZ7rA1cs9yBFC8Nt7CzWet
WI49ruv4bEJcXykp8xlDutgCicH5Sf/q3EXAsUFeKdKSGvugyrEaLiF/hzqcaJYxdDLnU1Uy8IpW
4yMH9X5rc1ACIMvetG2UBx6fM+FljW===
HR+cPqgxBcDzdPDK3m6xG7OMXaK9c6mjmBAjuxJFA8jI/pdMxN6cyHX77uTHMP/ukjeXmMPVqKBe
RaUWoit/XmWREu/nrMTbbLbfkAuekOoUqh4m7lLq0AdCZkwSFtymLHRGbCO7bWL3ao0XDz6E8ZXC
FfkhCuGu0Z4tkIKDWOxjqy5UwVLldYWdCEqJ4JCdb/SXzmr12KG8MiJaKg6Iv2sGqJkVVXHIEgk3
+4lgnRuNDtTqR20oWdXiibc8EVFsPjJy8EtkBkAgUIAmTqwJz0q+jTm07eMdKi+5y5UrhnDRSwiW
l3rIJcMCnfHSts/a4EEnMIikyEObmbRkbqx/Om+qCbcBbQlnwwQrK9OIrS++IYEVyGDG6YrYNkjQ
jOosqk5kWrpg31gE98C+EuKo926aa/i+H0MAJ9ifIqCu56v1CQAG88/167dUaOr1ONj46dEvalIm
MYkZyfM+YnvihnXEFuTO10J6gGSFnEJBmuPxYy9oo+M9KDjuaCdpZrrzDWeeQ6YL7eIjpu7UGOkU
wDPQmBhT2rH3WSdNltduNVpSuvp5gTl7f7x9RaUIp3hjaABWMOm3S2XD7ruu19WKDCGIPyMPj0Os
EM+FpDXChto3vP9g5TzMbFKCYinVXwhurynbjeuAtERKwKhguGp4KP930gqBAZEwyLnrx4a6PbkJ
09MnJaDl63XjR8x7IHMSAXByuO8PQMsZU/v/MQWQFKttKHu0hUiXep0s9LzEgiJZJYNm1IMGWMy6
66vwH4/AVTocFa/v3ljJpyiY1YetUEvKg/3D2AbywDAeXcT8LBQo7R7P0OJzgY2J2iEctQ3SKF+6
ajLur/r34TVDgHFp995xhztwq6N3JsZuthyhQqJz8OSCtLhiksjve5ppshH07c/08SW3nFJUg6fl
VZznW6VEauYO3KvowEq0G1ycOHEY1VO5RmsU27MZGWPVouHq09Fhb8qYUWNKYg8g0ri2duZeX4Ma
ijSjqSRWxsiFenKinYBquTTZhbGB7EfRRN/tzs8GHwih/zjdkPZK73yJ3rlEB8t9/7PGbfePgBTA
M3S4QCJkXh/yG66Tv95Is/uNe1vODFx6LseJyognyfMzcoFeMGCM8m8UJ4gMczvR+i3B85HCl9IQ
gD5IrX+c3ldVzVhaSNasA2yR4Fc9Q2gJ8ucw82yP4q/TvClizgkxMFzpf4AZ+A1WxiqKjbPACpYi
AS4gk8t3ubSzBIE4nLRICh9Y6Hb1MQ3fbOtM9cXJM3fKThlYLMLZpPaLcQIdIVf8xd9pIexd/A45
vhlsUjMg+R1hAJJoU3kN6LBv/Z2wJ4WmFg42V7V05xK8uGaXMfdH5Fm+dKKtIU2CPPL2H40lSDXN
Q2G0j0UQ9KZnU/HCvQda43QoPhZeK+cNYye15a2NQBPaa22Ar36ue6/SRIVhvF0pZ5xsnVm1mAG/
NygpoknTsdvnAcntQL99qaLU2rOm7GYY7FsIfuaBfFoD0Nz67lGWJcQiMNJiN0veyevRO+b3a3IN
T6qhe5DjCy02mBDcuHuHgpKDzccCcOexImOZArsDeh9Qc4prkoP2NroXB0fcxOVy6MJ7xSR8NJjp
Bm6iJ55+28l2uUj9mBNkWR5IBwXwEpbtXyItM025zsvA1FrobiMzgK8xCpM05xzNtvopy6FqAfnv
++PZZ58wfwGG+1CZ8BuVCAKbRK856QV3jFwSTLUTa1cQZJK/J9/URCQBMiHFIWUm547smRlE4qwU
IeHGSl5r/ie0h9FkdcIsJgDZU0L0mxf6TVHjfEaeR/VkKZdDiOGsDVk0Mjp38PfwH1I0yZSSXXrV
cAYmXRIBJyDQktPbRADZMzqpRKNb6wi/T8DVsq8JE7p24Hgng2B43yiwQ9VwSabwwfMMWbsrC1pC
k68RB18jFQjUtC7ShS9DYhI1oPqCCuW4BCwCecjDsDIWaK03hHGb4muAgLDnTH6H3VjLYv3xP+rm
++OYeJZ+d6PlNhFf903pp6xqEXGZH4XnyvZ+7PgCHD9a31U2P1oMtF9VeubydxIY8BYB060Hjs4e
5+1iZXKBhIo5Vx4u/YSdOczjpDcL3+o76WelO5OTpulDQCKqyrrmL+/IepWWa5kHFjm7sd7Q4cRw
7S4pwY75wwnsIZhxuoTQPM624aiPd/KXoG/DZK87ads6gJI0h3amlSl/QO8W6k2+nD6NQzDtx4np
h76kX+i=