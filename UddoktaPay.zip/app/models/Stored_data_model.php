<?php //ICB0 74:0 81:340a                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvJCy//D3NN8CxyPPX/em0mJRSrtWZGB5vhFS5Dk3dotJqvumz4F0JEA6zqxd2Xe3f4PqL83
T2HQwmlp5ng7STyTgbBrwErv/IKcdvrHE1CfMEXWqIL0JqmncNicNjPQhpCkRx5j9yyqgucBVIph
rcR9PlUC4uflHCIOpaIHgyY4Muweh1J2HZiWQhY8ZHYIO2F0l858nJraCeQlZM8LRL4FsYZlqcoT
WJD079PgM7d9y70Oum3o36fCVhYtRVtuWRPWyXpHONr/YByVQQw00t/2QHPmhFRfDcoc6MWH6uo+
0ixgHOwk5frj7ssF07gerOlETP2nkNnz3oig8flMW2igRSgbog7xEIiYB1oOGCGWFUQORjYpSXlI
AssfsjbMrUDlqH+3Yq1E5SJO7JBPcf+H3gj3gYU1UJ+AKAeaiOvGJ3ExdpGhxyj8QdWfiQsvMipI
dUQOyUpOzuqJzrKgPEjutSq1WH23/hhwzhlbXGEk6gxfk0UChXP35h3QCRk+RLjNHatCAvQejXFn
AzCYfqv3YORXSxhbkv1mRqFnd7kZ2XhvJtyrCic94KCnQpYZFccAlBP17tkSxsKuuvORHaO9v+c1
OBCcyvSxnKHm810HKXO+RjtiCtYbiaaZAxp6FaWXw8cel74n3RMfn8EFxHCjDMVVX6yhwhb48Bjv
ncja/u6ZVIA86/zEvzcaatglnlE1uOQOVCGWlGvn/emOApUkYiUKHbV4bnhJLp68rxoFAJ8zmlPV
8QzKiNc22YMUnBG+JVR8mbcsxQy+PxZ9tFi3shPuw/wqD6kaj93nfuU5AxCDzA8RPOYOo75vvkkL
benUNyOOSdKw+tFU4RWBcfMF/rBNCfRO8lC/pHjXp6wsNrMFKVlueFCeoxBO7MTVqS+BYSmwpN9E
jKM7tqxjYWagimlLD/8KLr5oGbOYh+E5AfkKbjK6Ym0RQhCcls6HtWvG57zTRFu2N9n1Irzfubbk
HwVq3LlRJkHBnBopp61GacoWIz04kqbaLmkLgBI8EIhyh6MRvK42xP+PqhwCMbrrvbN/ILRaORiq
8pqszxf/tou9J/VBpB3MfoPGqOWowz4PSRX3SIf6GRC+bKfSU212D+GSMGXM5DwLbWW9qJSwU4+8
5r8m0sdljXZtXMAGr6IETddIgy+Yv2ARydEKMFGve4Z3QS/pWrEYlwIv5g7mV440afdsjpr4M70i
WZIUL/3ZsKMUnXbiOxYJuqhf+en3/oRnWcWkukMneN01Y3u6Rv8I5TTF3bX1TiTJlW29aamNDm2F
SunV+RbrQVNi/e8QqRsYO7wV0COfqdBmKQ504IETQoQercklkUWvYqJRWa0GTmCXB8BwFX60GI6V
ZwslWFCHPP1Qwhb4y0J/xci9lORXZS6wYeDmCZ4GxGDrSFyz9hVyfWCm31dyiL3NZ937D3vAKI46
cyPUhtnW+hv9PTbMwZNq2ZKkPGU8Wh9IkvdGULfg6Q+u6uqfNE81hFtUEtpEc7KFPvjvhZRloPz4
sr8+CK73lXToumP32rw0J3Fmyl9r2NgVajrEq6RTFijl1U/XNTNF2e0JIFcr4RHMBhRqMMm3fncS
QxwcQM3yiqxx85QOZeGE/sRC818TjanwWJUftgjEli3o3RCw33ZhxACIp47vcIiNCwOhpeMGTbRg
7Pus63q/s0u5gW9PYLzFb62RWyWXfPaAPltf9EQeAyH/nmHKQFwdQOj5GrGX5bhHgG0hxKl7f28c
hoEx6WioVRMlum3IPTikxtHs0AFeCujIo1IPbpebbtFUH6V1CxHJHtT4lXODZJVUI9kGep2XbnnM
bkJBHd3c1oQ9Y33xcmM3uMzt/Gly358/rBehZjzpdVp2tm8u89PiyYQ6vkU6K/onfu3NUxMgFySG
6UL0obdh06ECyfnBktUnlWFYr+PjYCk1Eydg+aGd0WbvlAGv0MdBx812h1Hb4X4/i8cYa6t8MWps
fMFv6NOGaFNDuDATZrM0ysP3hDT+OacFDXiIZIcUG7yAtpGWt4oAEKpfVHv8cn996izVtoWJI0eO
8Fdwihl1vBZw2302TolqfP9bYTjB14g8nzLEGk0cdsYHSYn1hPpz6gHqGD4w6WGasabxxBjzDJsR
KbSwVk7HFY+c5FSpgRVr+mD8TZhQj1FPn5jUeOknbB7cEMYXsOxCKWAfgP8k93jLxgl7IJD9Jc2q
f5EXo1Ik9SUlA/mIhyyXe7UMMHQFUfJCgBiIVH/OTs/oSLU8sFwsf6N3oCZ+ZqrtQ4u1Y8xH2ZfN
vENVgN7F1FVrOZNGhID9HDA1ErUC5JF0DPXXWts4kJ7H7riT8RvZNFEBjmj4O9JrJcoHtYTR7OCl
odi3GSZkr4cPWXl+1sBQDeD3DW2r6Yel3pgLkyNM/TG0b4oxHuWZQCCdWcNxbCvVcYj37+ZAyZAc
f0qUaGxyMco2dYBMG/+8g9EeZ2jArx8GDkwEx6aD88YqctQ2N/8CDjMZqgBUFlbYW5SuQaqQ7HWh
ImkIexhEHQUctXfnw+4Et9mUeLcbKnpHXdaWHJhIx5aWnINfx36Sr5vYw9uf3m14QyWzVOOwXASa
8Q/YvQpenGfUdBhucTxHtzDrsYKLuw92DdfX7B4XJOmhRbW5uN57l7+/lgv6n2hzLhZzXAm+hwAo
xgwsjVPoKpX451EKY9gM2dKgCkkVJuEuoH4hoduwxBN2+5nHmTUhOKB18VuLaATsg6sy+wcII8YD
dvS1dZcAM1SaanvR01Ada9NjeB0XbjTYgtC5M+SV3wQXgVlqDjpUryrR/y0BOmIb3OCMbABv1JCl
wIBAydRFPAfhV+ioxAVEkAysXur0vq+llS1incb+8zCHmokwaggOqNnsEgJJHoC20CE/uUcmVDmu
/I++jT9pLfljFvaxoc7s/moZP5297Iq8S8+YT5lfnbZ589aHRX9JrctwWvVnBAWEYpxY5022GcV+
O30Aa+OtHrsZucxP1xp4MQBRT00LIn1sAqeScBuadygTyaoJyDsNAYEwt97eEqNUnmFnHJD4IXuL
jLj7sAdwHwkYm6ugl3eiK60Ja6SY+sti57ClNhHnriZ/bt9IBQkwPMTgEz1OBJG8YhJzVvHbabVq
rfcjBbS9aNFx+zHGNbvo9o8GA6pAxUJ40ETQoPpKYwWJE2TS0Fli0nJ4GUxQ353w6tvJISO/2nNf
FycsDbCUDzsZt+if2wp8Cs0ljh+2bfoDWX1joic00RSJz24J+UEkkz+Bo5ouBsTjDhF96yN71M8I
XfxfTxN6SVc+Ej/B/ONkdYClZDoTc+aCsHScpoU7anK6b6ORanujcFOLjiqWadQY1DtdFjI6TTgK
8dJHyAyh5o2OlxXwYrv7ojK+fNOqHkzHzJ/WU11lKqFLLYRw0XYzqko7aMN1C7xhXBBZL0zMxogD
zaAfkM3Hs8FD40qV6Bp+chJtDBkbFY3Ca4dl+eNAHxArQAQ3eL6HK9KmRxhN4q5/ALS0RLynT8g5
8VQ96/vVeCEbdmGIvfOJG0cXoF+dUKVD4me6CDqG6jHNs/e+ptwxk1JbXzguNbUNhpsq7QKTEfEr
IJXAGq0YcGLA/ED4rPnqMIEbPboYFblBapFptxc36kNB9gwsH55ocl9B4+Gu2VDc0ENggJe60y3K
oeau1eGsE9NpFeNeAVIig6AEEyH02U1s3cJBHrr/C8xldAn9sIUzf8RxeEe+KaoSty+iSEVsIeVm
CugQ1VMBO6KbypOYMm22uBxcwGfOT7QpgkyIsGh9w4ppX0/Z6ISrCkF5YzQSwOGX4y09O3QVFVOS
q16HnEVfcgLbfN2X+ml1kzwCx79ajJSG3fdeBD8BDmNa622P6SmAa2Oky7cqqAUFfQdZEKAQES0r
LFKtt2D41OIhhiTpWXYEc/rO6C9SKpwyGDpAYqpmnn6Xr7x52fgySlBgI3rFe3gyybdfA+QdtTBP
0ZThvONVm3+VV6o7dh7w1CTjQnWiijJEKsaoZxFuyxZa1KZLBehkCosy9P9+jXVJtbmv2dLrKVdB
Oq+zvJ5escQ73TMww0PmQkLPmzFbp5CZPDV0W9ek0OM8dpXp6RQkZDcSiPvD9T/Ppyk3dHZQhigd
dIXJyeu1occLFGa4uwsJi8EpCe6+ON13RiLgHj20uYfISDwsHC3t845um+ma2p/b1I0pxPdGgdGB
rWElRBcG1r9JItEKjMwW/NFcR9U6ldYEST14iu7eKXKvuJvsa6j3WrkJdUY6T3ywqzsy74iaIKT+
sJNHNz+yonUohRKTV7jd0jRueVGbYcxVnXtkoB5FB7cDO61Mw0MLXL/uYV8rsba7cCHtzK7VH9xi
v7gKGWvZnvA1o8khPxNJ7hof8NjzVqTRW+/9wdYdgQasNH5CxR4mmqgezqh+1GOlEzhTCiRwxUyQ
emv088wTU58k7cvZzpgnJhEyKPgJGazm5AmDhprzR/lOGlPfW2DFYDdZ1P/arhc/4PdIaW6LSByw
lsc9Ia6ILpVTkXXCrX/0TV/vmFZqXBOcaOPCQiGTl5XW9YC5dPtnED0HRFcBCmCeFaNnp7U2tIjH
+E2puec6M36H/8fmpuRIPAEYjygUeThbbLHx/pudYAGME7hzSdYTxSatIIGpeib6ZhN+yjfCQ31R
1l9PwSFRtMmRtHQ2Cj8gMqVjUSIHS3qboUWatTQF3yDu9FbNWXH6QzWP8i+2LJ/ps9WTi3cJYuij
fcEqkN/0ekbkMTc1XCgP2jQPnUyJHtQMDC9Khc6iY1avhatUbHs6Hq1Kc2I5t3Ak/Ft0DP3w83Xi
4wnaUq3AaJ+DX74hDuN67tgsQR4jPMW0sd3cc9CG7i7DhFUfqS+gj74kvdMnS/nfrtVbKBBLIevO
C8777E6K29R9A/XPn6nCUCPS8DFl8it43lJqe/kfeJFpcsLTgWjuxkyjmHTlfmHg9tdgAUzRyfZT
Rpi7nHtG7dA6UPeXY3R9guSG1XMgNwXk2UUJ5meK0pgI+Aripj2/1w3W/VmJ/gEjz5q/+mMEXqke
44xbVJ7vyEtmSgwbbdPUYu5fDs9YWa7liH4OJVCCFq94fPECMIVFjA0EV4bCVbmWdITpVMKvSfeL
FcUbMj/P1T8w+SZluyhDN3zxoWMVgO2WXyUH+/XEZIQMRZ/4HtgPJpqwDA+jSs/CZHBdgBKEZ2dS
hFrRa++EW4xPy/pRUU/TjSeHMd4BQdD8UjEUJSYHBPQS/35ag8SLhXVZ/MPEfCnLbxBsn0htZOo5
fbAtl4MiKbmBzUwl3rKWnjDb0T+Th7gbAcBv13jgzgaOZWCTpyz7ncDphadyofyTNiECKZb1ubpM
nXkfbEcpkN3EXevwiFBUszjdSvZ7BrRMGiy9CHCt5CQrtXym+QFRuwt85YJLIULyU1uqf5Adp8JM
SdixyWtyXzwF4JZe0SBSmDz1+CXhJAgmdzLpVRRobg/JvqsWrqWlWnGspto9epCQo0yDs8RiFznJ
UR2iVPBHV21IRVRyKlfDN6WskYm1mTfevKCp2PNlZ4eFsGPB4qrQH2Ev4eETsmRG8VYjei4bt1fP
0q235uDrLkzx5aN37SdN3sOVIlzhKY9CXWCAjOzImBwPXvBuUacrzPyi+uPPk/hxBdo4yHBAAVhf
0jwuv9MtNNLnt8SapSWJURkSfLiG73uFfFxZKDOPTik03nM4UQIK4tytEshEa6o8DMxZV33QH+He
K95zkX6U1NySRvYDyhMmpGaxTGa0n8zPBQzMVMZub+pUpGtcRRh23DJgEYlPL0GA0jTeJAeCra9/
VlNUpdF9urNSvOVGnB0vXyoIsZT2BphGsAVkTBvjdr+ugn9NMxjBvztzQAnONdfc24jAicVzIwA2
3seoBrVltMhia3XYJo4aDqyrXngQ140sz58gy4evklcxP1bNs+gosW7K47lwqHiTvcoFihICBMsk
WAz66DAxg9pm/3XVmHHE9SzmH0fw2DVQRPp9edCApFmM3lbHFMFaQTg3gp5T2w3RCQv3PyBGRhQ+
4setTWhh6zPX6kFELumEPyCOkPGQ1CLYITK1jWKrrifcxc1xNbpYcNhYrNSl9zo6Eoi8eVcTOeJe
XyOEJsNae/QlKBE2QEv4a6KnRPRFaGu+5/jEJXagVyIzALaUKBkU5ESf7eQiDeE6ns7OM1jQL2Z+
OO9DHX0n3yMCH59M31D8ehdj00DQothUIHDC75k9xjJtRY+fhuChmJYN61HSMUYpcFQQdLPJ60S6
uPNEKM8B0N+VTgJH8xW30mG0xd2h8Xl/ZCf5uwR2W9h9oHd27R9QcZZocK7IZal5SLVNXJ7oJIBm
7rTIJzD8Izv7/8gdYvNIFKZDThtRfMER6AdcqfNzwcJGDjDT0gsxwsuDOAjFFPv6pM/dpqtDrPrV
/7aCrGiR5avExRWcKvXj9MGhwWpGV7Yb+Yj18rzkUZ9L1VyV40bwOTPaQ9Dt9t2IRa2PZ881twll
VCpnH+97BBskngyHYzRPepx+ACbRYX3Hsc802zfF1dfjJHhqrVjhG4SGGHO+T0O/SIQ8ThZBoiB8
UZ7W39PMjCrRgLM1IBnWaytSdQN2BP8GPiWOx8ouCH/z+DBG/CzGC0QWCR3Ijnyz6qnO5Il9Hu7h
+8TJ6FGE/AHj6eBAqb05BGuRnqYP+J9km2BhmjVxCAYUkJLlkfsQbOjrqqqmXzjADXp+V62eXcPu
OAhp63CWEG8xIo9W7QV14GsLWp904duQ14v9EZs/+PzlyN3Af5OmA90mM6vxr+EvWLdJGvLWBAQp
myck6LNsgL03BGyqdV4TwFTehm7U9XtOWYAZJa11K58OloxeuKJoeWpEysJ3MNKJRqIk05xyZoYL
jneSvgGRlmJXgLbsiXty14uOdraJA1eBybF4P9sPAWv21HaEOsnHvxDly+SQv8m0bFEGacvY2XE6
ivLOXeASrza8aq6ku2/8Hw3Be00SL36pJwa4/pSD/Y7qSbPJm8XONLpmvDGZnuxLLQ4fEJeCAitL
+M5Oglg9ohB+3Lkigq1Cdmqdi5a93NF7lEtwa4fel8+AfNs+aNGiE++M5r0cWKu0nTWlopkQeUeg
huTqVz7CRWbGq4Lz4kdTk2nzTsDozXJroTh6bVje9qwL/zjyU5PgrxMfP2u1hiS1nffRehji0kry
9JE6JVbo3SIWVj3FYM949CkixlZ3Yl6/0oTUWrIRMUesMzgJMqAhKM5cJLWfo76YBKkT1L+L3V2K
G1IIR1x0LvTviIVm4qs/stkLVzi41lCbbuOIk0I+RJ7yx23QLL3HMEI6rXY81tsh46b2v/6kJqd/
hzXM0EWRdxJdPIaBed6VQVYduPG25avYu3/nSPVRPp21kreSYOXe2L1ZIYrT67PvPYkftnqeb1gC
TbkZjC0jCEbwOM2ucMMhapvLPzoxzttGibUZuWPB94ld1Up7pl8CUW1Nhg9bGF1MUsmIIPTJlYjV
gyMONdHAZtlxaI/ZDvD3C8M7LjMTIXZNDCh/nOm8fab2attmzVis28qet3WASwTFi0DfqmZl63Np
HSsb2k89xfNAWUaFHSjKimPyMyekednQoEcixvOkOGyoW/wmopGk988I/x1//e+QwbbYi4esoIk6
xPD2fzHDcWkwhmq1lbJy8nJ+Mlz9W/wBRw0WBa0zlQpe41Q0Vu6CPM9efkmQUTMa3AUi8GagYTJx
lLb3n2JapiLc/iB5hT9OjuLuZ2lyBOvyR4+Gq7kRvdR7EutiZkWilW7yKfhX6G7rjPZ7yaCObtuW
gETpVx6iH+ktUAoMFpsetzYoMrJCEYzrPX/xnP/VBlzJ7D1poaxkL1l6lg8V7I6/9CJKbqbyWDW+
ancDTe0Q1dPiPMIsMFowStr18d0Q0NL1OBOcda+ju734xpSXS2pj7gLSMMnFCqGOkq1ptjwjz0ke
nEKqfEGD5mIc543z/TvcOvFmTWFdtU/2EQ7fuLBDXBGUhnZGlAZBQeBxxyWz3CAyQfDC+3bNHULD
exWeRQn5KKS+9G3/oaivnjZhioXbPUuKe8Mlz8CnZeP41PMex8Cs8fBJ29bZ12+yWhhFDCL0NTRh
xT18RpyZ9Os4tsuTFZA3184j+eiHGP5RcwmxMdM0jf3qhwUumClTRCem3yIenYsTuf0qVQwuCZk8
c2EHBa7M6OgupS7uNJfTu0OoAsfgRSYVexa3B0uD87hqdD9+uUwt82M/TCllKo63c6kU8LjH1hSU
a1j8lqx5duejEmDgcQmahUDXBUt0MpUE3X2xr7OAGnAjHtH7GvVB00XCZcHrqp7c0jQdBC9dqhlS
/HyqVSkFtMwIvxbEpZeeTdyxEgO+xRUkRHbWnAkxjwxAKYbXTmkOeqhR6gL33KPYxVKQOKkNiX3k
AY9DYU6/09lRx4rTOEKSvIWmEALO7R+V2ysSllc0xOijKZioZs6qr4RetA+WQ7xRrN9sbhL4hT0U
ch83HupjFIPvfcuoHTO6qyFhPebE7fqk1GH1h6SFMdWZdYUSHe9hKkWbGFiSAV0H6mzK/sOaWeQG
Hb1zUdHHs+IaM/dPHr2EE8aIdNxXmmOzqTq7Hf4LvYTS/O0aMYjWH7nBpiKBD1OHFjOat/nw9tN9
00+fJuBOTu4qTDm4JPNUgp7DK5HznnjsyliJOIppQtVrUUW1gU7vdrpZviUpxMRojBPXKU5G4b1R
3ovSg5XbweAJ2KSkr99T9wPMHjZUdPWqh+W0u7rKwYfKmVvPlnbvS87NqfCbLzQJlzdEbfuP4/Ty
2FjNBezhEmzbgqeKFHrela7x/oX7i91U9uc5EhTUASDfIW+x+ipWjow5enOhQoO8utc9pkl0AbV7
Xipxmp9ksgHhM+IQvctOwzpxbuywSH84rHryDy8Nbc3r7Fbl0i20oVpzS844z1EyyFQiiAwAuAXq
eYjgXM36mypQ00/j6ma9X2ksBpg5d5fruCva8eDvfs9dYOfqQm23PFx9PzvoDxMto8MvnoWk7BKQ
0P8WHN8awkxzYeX0qmraiUvju5ULPk9lD9mz+z0Jc2da6yb+aU3uuX50/o8ilYGWCj1WjGpsd/BT
KeDWFQFr4XiEPrfIp8iJ1g1SCurDlmuJ5joVHuTE4LeYUtGdRk5aypbCmAwIulF6FounkZVt8lZr
PObMPEcYYM4VcFqhcLnmXDIoQuNA85yaoT9McZk0lwvSI8Zn4HgXhLe5ihwAkKlQU693hN4IHEAE
aAHGiSoYlE/+1EmdWDbtEUPBDQDEwXfFUvWR1wHiTNH1PDG0zsI2zzMk8gP/qKraIvIYhZAQaEE8
Ek9MOAb1PVporNKwLwBI6GAYYHVg67hkzMllxotPpKR2OiAa0Oe+mioIW6BuYAtA6ZIgzeHNdO+t
AqitDKOQe+xkesYFFM//5RUwfkzJO9ZeeWJYxxvcuc6POiln7occLj1akbTVXqAnfrC40qPWbf46
2i/UvDLNIZjhGhAXrW2sAgTIzxHKTlKAVxt+W/9CLlnLdaJBCnqsz21XVcouCEU50Sg/Np2pKpcY
rRhsNbNCs5YpIOcQLt/WrySdHOET2YFfAVD8fAoVppH0+gcymAT87LeIRj1/4o2Gw1zZB/7W+OdJ
LKR05/hVQSyjPTxSn7Tc/dAwlRHZHgl2J+kj4CJF6gTDkqqJXhcFGV1OEKKqgOpN4TD01T34JfGr
uFDOEuKJxYh9SwFP8JYqbIT1OTApLFwIJx7mP1Vxd0sMKTpRNhKzAufGU9uvSv1TfRiHtKe2urK0
YBcpSks1pa9gkTAXh7pdXkU+HkOqeAc2AyWdMI6VyLG7I0fOcyzbqqrDB3b4+edqrWqu9b4pA6p5
09anU2/Rw//Jy96MAR0hHcPAUib1yQaCmvuCjtgRX9xz7pacopB5QnWHb1Bstte00LzvcDY8hWDL
Nhw09ixa6WZ1hBtCZrwmQR09kqEafXWqjtUUqWivNAno1WDA=
HR+cPuXlreu1+YgXgwX3hMAQVlXwNMqf3xbYkwZFZUbdEMIslKGImRZ9X5FYoQVcFkd5ndXgdKCY
Xq7rivI90OBSxa/DXJK4oYQ2mWOBOIapACKavyI2dWTdgwm4+/catSpjjdX+TJHLCq05QxogROfW
tbV5Y1x85d4iJ5yc3TVuG57DJ5PCzpgNvHqw7Ps2rpzgMKinH87yKXffBOu+GRTL6wR/hMCLxARQ
pUo1GO//PBmjGUfpvW3rCw7RIdmVv8iCCFhtaKo/4jKVdF5ZrNmayUQD8XOqkM7pAnIlBNQEwXtz
JFZqYNDTxJLxjtN712MWevkInAhAKbUKXb0mNy+zGb5mRlWSXSo1cib95iV9lRVDCoAXo/nijVPh
pBEtq0CS4+pWVotcIw+Vo/gMa75opWn5byomPodmE2b0AFF/LzrcxuqHIEETgteJNE0eHbBWTD8j
eG+e2pgcPJG4U99ydFt0C10vuDB2YS6ZJDRCquZMg4vdjsvKktOaw+fZnmZmNdQ5gZdslEQTcqV2
UvHE4+vM9sLHO/gVyPD/mFPk/xU1sk0dlwBnYXL+7DSHeLxRm8wqbqj2En+HmDw4xiTUUgLhblB1
FOScZ8hHcAZHDCsNiTQPAf8RnDsk86ghaa46KfFf2RvxlFeet+YU6G98H5YhLzx18f7tgDs/awg5
KFyD8ROt28okxhA6YayS6zX75hh8yu5LGT74O4b8fg6DusQ4N8HwO1Xmbk+p8fBbd8gIRC8Bz7jx
BcGwdSZEwGSA1eAKYt7fySqlax05UDPD/X3gWCj5PyIJZRt4pqMrayshw9kKMlJ8v8Ciske4m8Vy
zwpWX4lwQ43ctYzEwegxUe9LfD8eo8BzjLhJYfpg85yRAV3bZAlQ6gMHuQQz7PNNf5odNr9YAz4q
hypdO0RSjhym1e27KRMYdhttUKI09lmP9ZXPWa81dpuYCffBYwNbbxwcAUGXxMGRQ3ieh2mxbTW9
t9TKc5TACqt8y/JWiLQFNieE3HVc8boOW7UkfJz1C+c1kxLGG+1ISZPiGELtB8wJiV9juCdQanFL
dxDr5xRgUrtIjMtAbRXOCFl8BS/GfKEFnu6KLyjaNkXTGdGCf/pdAkW1sHFDUhaBvNJsztY2jaQr
cM8ZdEsM9TWc2KsB1k48Y/s3mfXhXTsy3jIkD8uIostqDntaNEMz1Ytly0wKf5bMHYvhiXtZrLTv
l7gNz11bfujS9UVE3mQZ6fcD8lomv08BabK/oTmwSxvBgL91Fm8SgAfAo1+wA7G4VB65HkgM/d5f
OCIn5WvkOsalxPd6rm/0YIQCoE3Y+l09kKRjGUxD/feV1ZrJpGMwjWPV0JCCdzAWLmYhQZUFgCY4
q6BxNmJ/HSrZag40R0jEMuy/1Wzd53JmGdx7HHMPpXBIQ+rDC8BQbjilpZsrLaHzY95Sswf0tDjf
woFbrxej4FscX2dwk5VVEToJGuy0uOX5Qp5+mXODm6emgVt47oPikBBOH2gtL9YXO/LlGVB015pa
pLWJ078RMbhJ19fwpG3oMNmXvSIKUsJ5fHuud06qsoxnWC9MViVrrC1+Uuw66naMnerFE4RcGm2D
kIXrFJl4zhGoS5MDAe5sD30qx/3zDH+WVuYyO4y3Oz0k/z2zoafjGXOcjV+cnb6AAJ6+WN5HjiyX
dEkUFYc8XJM7MLPHVC6aEheqt20u8J7lWSgfWheaavZVM0H5IrckcAai0XklZ8jmIQFGVnPmZ59Z
njZS/WF+TiJLsugn+TEG1V9qcpZv1o33mRs9RZgN+epzM1Dlt6BZuzliL0001QpeGnv4uTz3jCt/
IXNRvBJOrDwGc6b4sl+JfQ6PrmdNKi3ar78+2H1EOsUzFJMiPKegtVAL2By3WXXK/fMY9KwSZp6i
JO0dqJLgX666jPCs2wEydgTZzU3hx3A9xr438zJFaR8uP2bhfbB70JaCLN9NaPIlxQFYC9b4lcSU
otz5ityXlP+MquzIfiYcrasfbc07X1WsaforXuIcM9G2ZI7+/9ySPUg4a14+14dTj2x/L1jFWDTW
lFh5m500OvT/5Jkqz/PChtQgpGGh/xvgjb2RnF4ZMHmYxp5f6Yi/1LQuVGkeXgNGxRorcPpnhj0w
Csi29FH+xVvbjC+HYw2b0L8uHwbBQyXGSxmnnhpg7+Izf1aKt+FaLKOC7pv41h2iyiwmrDVqUcGz
GhYdI64D+oS05k9YT8CFDaLyVzqtzRkTj+uLGpPNkpPK5EswTb88++VhklfBImJHD26LhaWUG3rV
TbcPZam8bJx+ZTeEqgom3A48hU0mDu0slkXY+vlPzahjBlpao4tubtt2lPoGWuxbUSgVyqcc9rPa
fNYqIQ3Cuuan9l246v9ATHBd0gooBkaJLXHAtoa64OCOMes6By/Eu/P/mCeNpBO3UpSxVHNasjM6
42IDq9JXSTUMMOQIHzsEi37igxcfmPEeEVdtNr71qCY+2DMJ8EQYe/Rf2WCNYvC/rIG8zm+N7XyN
o01BFdQhKLp208/LIOjveQQu/eTVYtYVXG1GTMAXrLs+pQ2CQ3cNSZAO1oRi9G4Vu54q4Hw0XHO6
p69KjpukAbmeKmD7oJKRzMts+Kp1RWpSjKLbQ0Df0aAicJAHcOpuYZSNwt8x1QPPF+U05WGur182
57NoKtWQhkEXB3AdD3Ps5K7Nj8oDojbzeZKiyOeNtOMcOmAgUwnQGQR2d5JBhVhj9k4LKmU4VnS1
VPTXRn+Ltd8ld0nh34uXVf/CcxL0TPLlcOez4sAlH653PsqC9TaQDsAb8FXcnV7OPXoTSjMGnpVT
gU3Kllbu2yb8rlvk9H+6XSOG/KTuwAagoGhKPuPHc+HZw6Q2/VqecfePpmZzvPzOw/aTeYko0EgL
e+Ly+s0lINW0//pNQdtXoxyUI8nS8hJ90cpSD9EJIRhw+SIULJZSYWfhq1kbj+ckZM14QDvkMKhk
mLllOfJIx6gjIXlo671IdDtRR4A+Nu/VBpCdx6j3XFCWRxMLcMycGBnhU+PfS1oG7lJN8CgMg+BB
ij+4f/XVibI+wTPQj1Iu4XPtt4mZfrBl7QcOXHX922xb0mT8deYOYQL577EdMUq9MguEu767uoQX
jqiRgDpstY9SJj/B3Eyh3y4TRjO+mVAwFiT1qBHrmuk+K+//5w5qRQqGlg5DEvbp9yli5fTJA6Ew
VfGU+zJPDRISNEAV/PdJ1YGciQDv1zyootku0i9CoHDHtxkp8hBLMOv2MVTR+gkqvBQHlo2JGTUL
GANFEy8nSYPkrR4puo2vhD/wx5+tqGXbSAsp5NOGDE2GLrMXMJOZj0tmUB9v4h6+xkV6pZUGMeMr
jgd3BDuDDIMenfLpwuWRIjIxUAFWMkLqvD7120b+h7zri4MG1i8qqt9yQKM7zewYTrcR2HZPoqC2
ojDZsIKIPF3l0rjUQZIavVgZeE2tvmw7pg1pdH+pCmnruZPBpHBqwaD5nTxEHGQ6GYLUaLMSyBSE
xg0gyvNUjfAY20duoGLZ2MpvkwYMd8rxMFjxELeMLGSBZ3WVAJ9f9sa2Z++/l/tj16ZCuGCgx4L9
w7GijmTHPOlZPlWB0kWcbgbPANUHRl1fSD9U63ZWD5rGibjW9/JFFxyT+9Bmgb2ACFP+NDCoy1/k
/P2eNrRZSxZ2D626fW5uoBQb8XYqfR7MKclEYuqpq0ezIZImbSnWw33WB7MTSRsAaf6zpZissIGS
TDxJ3rCnCLl980W2Lx6g3ojz1PCtP3RmMsdoZS7GwVYztHOKtFCGdgugW8jT6aW4vq/ddITRgYmP
OALDwPE56CLpa5bPa1VsLGuw3lUfSIXyQdpHNBkRVW5lOUVgGQDwK5cVVFYLhNVfoBgn6U4FGZF8
Z9awwsyGaIqn1oLVpdYdqWEHM3dEWBMIT3BGyV6P6fH9jezjZVjnjDVZ3wXR0AtGisLz1R19WdMq
rp5OCoXhgRBgtVcQimssUIxXN0tvHUy/+42vzRhlPCaqY4bi+96W6TJEynFITs65gSzl+MoVgqYk
AJY1R3CvAXDLcUdE0W7QwDGv+flBqdG1yZq7tZb7tbRvSP9jByuw5q/8YOl2flLBFVejxNUbwD3F
D5RjwoopO0pDWcq7MQ3h3dGBzsW26EGAcNTxysLm3N9PyWRTYxePIh3Lg/ZaYjyt4h+Wf3zgf9K7
Kv+XURfLpgX4FObhHrYvkW9e0+yY304Gd++vDz5303v0Qg3czBmQiNRaLo7WfIIzS16qxlEPU9s0
/TZvnf0Or6/UMPI8FjSCZRxZOAf76yMy8cjaX+8wa0AyKEkKVCw0/35nGkAkTmvo+aUxkb/EwSbj
69Zac4BBLp2Evgr8iZQrauEtctvtLQWS22HLxUfm5fvwVmUFtCG4424WHRTBOjsUX001/mYaoKO9
A448CsQANH+oTqXibu2+zTzxWUevG18XNvtftRkmkh/B1dMa5v1/YSp8kJrANiieYmYFvfOu6rK+
VVPhuvhqUHgTEzVL3nJQ5qdqeWcrKUOTlfuH9v5+BvqZV7p/fr4Ya+gSTnckIVrbKlO4r3zxy7j5
v7xxv57En6L8Q7NVcuxbofS1JM+XtWlkeKpqAmxX8UUWseZGIxIH9Ng7fuwFaDcVAT0XX0VzTEE5
2iXAyskRrP+Kb8f1SdeFA9JGDnIf04MHp+n5Bk8DE+2OB9XpO/jUU7ijz4YruFeR1bETPtZ4kkcy
bAh4z368hz9phM0XtReIrlf+q0ZYaGrH458iIzW3cAfLNRqIQqbvhsVwb4MlePI1Dz9U8sYAEDWY
WmLUlf/wCPc40O8/QBz7FzZRmwcVt3kE/EE3oUL599KE9NlfuOsbzHOxKTyip/bv2WoexXuwOT7J
Slv7KYquApawd2D8b70+86OM7g2vup2l0p7AcYu4WmuwsajoHrgAZH+0KySltlkseRP2J+bVUSB2
JcJZRaU6CfgBE14O51gIiTqZwZjHSrlhYIymqzgj7bWskgKWaSn+h8QSv8E56asWY9X547mIYWli
a2sOyo0PZb0dGlw2DiZf/maZ3yHsKYK6BWVzq0f9jEBZgk63wwM44Ytefr6SMezYV46xnsq+vj8j
Dn/uVwGaLfnXfqabUa1UlGRxv33ygVSJHUPn3TII5aBKtGv9DCWXSRwdjBUZux2QFll5y3KUvMuo
fnPpqWjzAmJrmaQphYM9GsqeEQXNXf2pfzwuQr3LD4nt37QV/DOtj2Wf2tPJGD12NayOxdvCYG0m
ysBGnfv0KkNOUN4QbwXCQd64MwqAWVeW6ameLoG0EjilG0bqAKxbmsCeWqnIDnCa51EP0Zx6LN4Q
vrwFIZgQ6zDwdlf6V+5JwYIrLsHPBXQcDc7yHzDIk/ZQfq3wnzVXxqipXGrdHj/5E8CIEK6czPB1
WO1nJrlDie7nZWcvC0Bugg2H12CoXBWgjvT7gxXVI5NImQmpSm6O9Y8RLs6jQ3crgcyTtegMi3BO
MqvsNZxxJoPzefEZ5sdXQOuHlg0TiMaZPkfeAQYDmRVcebG8sbz+EuHDjB61MtO0uwSZIijZXKRy
hMuCVbKISPg1qfb1Z6+8km4IXXl1cga7mk2JzjQlnRj3uHxoWGO1nn42f9UvkH0gJtriEEmKvsd0
4tibbC/Evd+HwjkbilWEIqoL3CR9Q/vMiXDkLfXbWDGFSkzVm4aYEkNKOHfrCy44AiLl2kRkGf1x
Umoww18mKsjDsFWGVbEZRaweoGXbGGyxJVTIAg3IIRIMLI03TPiaufvQ8l2deYuEYKyMrOErf7OF
bwTmn+BCAZwc7ayG8y41XMErdg74ZnD1D5yKVfJpHaEBI9R4ynKrk18M9TJZ/0lr+rk3AOk5CjqB
K0TA0fTqfJ7plRs1IaOZm5veYxggpz5romK/xisBoNAPOIfkR0zwsE94r5Cf2TEn/iY63Nl/YnFf
mYtL/3FOuP6wgvN+aUcHhxqz1a8Hy1QfofHQeq6Fg4eEMbX2qk9eRuJ3nC7Fj86pqOMaSqEQtt0/
CRXWto0QxJSXp5tW8WBsUn3yrHYNbKKfdw0iA9lCj5mXa/UlOipZkzseWSX/nKbkhI13wcCAJXxp
VdkfedAekMN4nBkwgQRJilcNutvXyhAop+4SeljYuESxJh6we4rRXE2KobQczSOJZnoqUQ4UiZjG
tvrJpS1Ndi+3nug5MO6SyQlV8AJZ/GIoHs1S0E4iULZrkJeapzTNw8z9ALTk+Z07J4eQkOAr30Ko
wYZa1qCk7NxTa5kpRVUrS5XKX2/S8W86MGFxD4YP9JsZy0pdjv4EvBDUw/tLJPTRGtc4gO3TpA9q
i3MZZqgFQLFFiRFlSUg4rVhDKnXWaq7tn6wworeKfdDXzMLEJ2yoQ7nRQMjkupzRPTr/nANNfyKQ
sDgzknVBS8ENkXiiWj68vQhDvZhNrjdExuCSAHSYks2HIngXUa2P1tv0ILreWr9alnIvmDZaH/a7
Gjcjvj1Ck2ktc/pcLYscZopFQ/fNBi3AFfsxRJF9avbMKs6IsINTIZLoMM8Tdt0KNZ4zISLKEjq6
cTzzky6RuyhTeLaG2NodSv9+dh8CfNQD+HyZ8KnixGaHgoHaaSwm5/xV5vHqCa4CB7dSOR+6E+3q
1Q2bl4m9/ysQj4U1LIsOJsqL96yDkv5ICxbzakZvA54mcgYmeYWGO23cW61eLxBZd/BFuEojA7Bd
Haw1XC/NPo/w0tpCJTIM3Gp0/GS2A2Sqyac5QFMmCUwU3nhUs8/N9AcKhwV1b+fmuBCl6vEH6mij
z79vRILUs8MFAhqS1sUuk1nzgwjrI7/Bw9ub0GWWV/e4Luh7WihQCP4jgaNVzo/CVipL/dCRfU11
LWHVb0FM0j/CeJQX4RwvhP35sSEh9YEGL7F+oo7SOyMPpuJrdUjzKvUwIzod+WKSoKwEI5wYBe2M
qUIwVF7QOlVL/bVmlUvMXWVYSOBFhnBhLgbsiJq72F5Zn6D4Qw+33peoGuzhOmH9LiDtr0Vds8E/
RoY7EgEYoPa/3xoR5xCNNvuwl/qLY0B0lACI9Vse4xKeML6zBKT81kx8SFmvrmk3Q001W82i4n68
dqDDsgaprmCdYermOwInivDoSnZO0EoB9tMXwBIGq7U25j7HJUhC8QfqfWIJ8mwD8MG/ukmnu2ls
P9pu4xy+54lNZShEH1g4oGpFfNz0hP5uk6eGNVWa35Tfxg7jgQ5kBMfd49IQDS92JI681yEd9djq
jEihQz6g0vfESo6jlFGmDUf2vyvmQ5NL0Bd/UI0p3HawwNv3LOKcFnZVG2VfiZt3Y/jFpH680nYJ
Nfm09yBpaIOjaAd+0FiKbdzT7n12BwmgKLborwxlOU8YQ04idvnjxaeDB3wXT3b/1AQZFP676Fhl
Gpgy1NjatGCqLCKQ2YTU3QDBZprgRt3Eios/P/6vdnXmo7EmUKqsZB5QfMr5Vv2F4NdBmboh9P44
kLQoNlsMkjYxTMiuJx+Aj5xZsRNU6hQyPSNe0x2DYzZELrKbCKNFZjaj9ipBdwzCO/lFQJ3UrEco
1elmU1Yx/PqizrqiXcjq5GEuIJsVrxx526JVh9s2oqgsgRyml8SveNltRO/znZabXcyqllhSihPI
QbHvc7dj7fTyQ/3CyYlBGsDyyWdkAg6d9TPfxDCco4ra7nSCNfXVpXcSfooCDBY0pdvl/msqIcW6
Vbcoi1lMxmwJeEQKlLu+ai8Q+t7++E+N+i7TEcvOdvfv+fhlkC0ztIMtN/92p7fWwqdFY2kxfr7b
+JcHXGtIoDVTvHl6kqQaDWggZOqM4fxkG/iNHUzcHCG500xQttIdURNdrYI3zrv5lx2lvNmfcLWz
njMIMzPNXaCWCtqVzt6819sV5wMjNAQzbK6GwRznAAdz/kXm/S6sx+IaiKtDHJlT/PalXaK+m/9G
vPnDloxt+8C1Og9ZskKiEhlXUq6GWVkblGt7v7zOC0DqcFsf6BUvNbOUUL+XdBOBxnslP61M0Ui1
zdrTkJ6bFc5U/ohDsVNeXFHE4pHzd77/XIN+APJipDwNTgDcgvcTgB+1HivnzyCN19FYSnGAsSa7
u8n1JnGvJV9UgE7l0KwjqkTB/uLqrnQH92oYvQAIUi/yBg7zZy7Flk3SdwfPZ2ui2iM+WOox01T6
92Qpe82DZyM8ilde5NHyqz2qtIy1kSqBtJYB8v/dNt29r8X1z4yT6zx183yduanIOJeAa060Yc29
v0fATZffr0zbgNn4Pes1aj/xVl5bDseikh0t4btVT4eZY0Ji3JfE1Ymh3537TH+nXoakEnE5D9bX
oAXv3+jAfjdGvQtTAXm+OTtRVh7kXTPj0LXXuOlbqMIcyhUe0wW2xDUgqk8CvW83b55+OFy+Agjm
3zH2mwq4wRxMH7j5He9XbJqbm+P+PQ8QQ5DvWX49/FVcku6g/lKtjRiK+HvLS5cmPaE8pbGXjMLi
jnVNcQdoDeT8qR+zNMY+f8gJyLLqeDOQVOcwXdrfEcmhthk8C9jUgnbxDISMaB1A1CPshgrv3omj
y+5oOosMo/kS/Fm03nOzQ1gs+COQHyOAJq3XIe2GcOYlLxHXCb1o6LdhTVJoreS5Q3VQ1LPyRdI7
vxLrzDUcMywSPswMQHgJFiPUB3s3Qze5cSWH/S6EIcrCEZcG2tKcLfnWptDPPvrMOCazTZI80KXN
fMsbxueu1iDJ+LaazhclcpRyhfhYYuPD/w07uZtAu0E9Kd2xQ/zS17D/aEFi7+D/bmkan1UwTgTW
KbJRvD0PHJFTiCnW7mTG2ruF04wZukWMqdaAAm65CAxTSMh8IhIX6o43BYy9YxtTPiCr/pCu4lAE
Kk2LS/9RGjWNp7sVXd66P8PlQt9kyCYVypIUMgjpI2bzLcT767ltJ43FYocMotGg5olr1aFHWTxW
Un1StTFO5pL1nrr0odhcnHr7tuD/q+vh1U8d4v7l9DgoG/m6a8F2K/QmL7wGafty36PMoiD97odR
e6RUozAd4huvyjJQSnClgqtyiixhUGVMKkrLjkplkuw/RbRkPaPvKl1044BOinz/wXcH/LTfgEmq
Ch3hmY6nRE9Ej+fnXEfjkfmikrdRpCzBS3AgnY1DuztidzNngHiKw5GEiWHzA4mtgIHaN616H5Gl
RoHu9wO/yBigg3HYYUuhO/FTKse44JLB5PrPRRg+YSkFTcxZGQ5f2An0FNDbbm0EbKApppJLbYFS
PpN3vj7Z/D1xUE+ZsaYnQFNW6vnnMmLs9G5q1WMRcgf65fzwwR1nrmBXKUl9K0l/4B91jZ5W4PLI
1q29KsenRewiEqdkN/Xu02XkrvCGor4kgyDM4hTj5h+BuCQ7c+lbIUbKbdRJhbDs+gVC5aWhh6lI
myUcYX/le4VUwSM/iqJ9imUyJlBtdFWjbcte7LUvQFX070/khteinEFGVu23GuTi83GtPFipQvV6
/Hg8nZNY8kEb2IsDuAobq42mmAoogBSJfAoxiMb2i34ladUzDG/HZHBhdGJZffiXPnKjfD9egPx9
HrEZi8VRN0==