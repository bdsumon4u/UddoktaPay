<?php //ICB0 74:0 81:2cca                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsjR/tdEZXx4uI23Qkrn+RzkORMLcKEFsjLxMsXOT+nJ5gZfRZgU3pTR4pqOwmtAGLf5bsW6
cxuRmwOOn6EHuTMycCi7sJOPjjwq3cHGkkWNx1gW2hKpJpvWwZHjx8uZodJZlsNrjQnux277Q9Hg
MChKGJd4J6JNyqfTe6wDo/tfsduFsV2w7wEJnDA23K9EtoLdSWp0wI7+fYritG4iI0otqMrltWSN
NzXjeObGz9FH96pk2RPcgVAeCPBSk7HbLo9nf/XLpIC2US5iAQZJ6tWBG5KGY/2zh6QcDjAWMSlA
/fKYBRRQvwNM02lCU2klE0IAw3g3QnHHh83+E5Tv13akJ4MEgPakXIjL7xU0Uwm1wJ4VOK5llv1v
li66ToyvVtBneLcUIWqJsGye2aj5qYA40VBV5txNLE72WhKOou2ND2eCpAKT2LQYKtywKMtiJvX+
FmcOVmOev+IGXKujDZi5D4r/XWJ5TFi6AkaoFz6vNTh2cI4P5Sd3d/LlHBKu9ORvGr8wu3HlEoQ+
nnhNDVm4e6J9PF4dUak+2SBmCw9JwR/1ggucrqVPyyc3dToIyfz0ZdND3W284NqgPSEM0JgpPhhw
6YNpknKPwLc5785wx3Fvyuf2WxibAuSYP4rYnb+sOj5S+Wn/h9eer0jDnkyE3aYSGV2kevyFbGoH
2zabvX8ZBKDp//+BU3A11dJxdMYd4QIAT5fpRIOcUZ2vkwsO3I37TRVoC4gUU0b3ViF/Gybzdtlf
MPSXA+SoKZ+imCBBk2FAl6FSOzrb9H40sstOH4QIp9Sf/W2DQz9bTwKOLmwHP4q3m2fw6MYgA7LI
eG70DlJdGDfiZ8mHR1ykU7t8h4kRBqlDiBjjoxTv7M91QhV8ob4E2AeD5KjZ4t4QR55JtpMz2gvs
LUljiMO3oGzN8p7tu8itl9aWUreLbjyfK5QM/c39OfFpQ2AosPy7GR96zeJiupbzP0odNgARhLrA
eqkalgeTrgCzC4iY2nYiM4m1HDomm8gPirjRV77kqKL5MUYRYq4DIEm5y14DgDSPIiAYye4/Gl49
BbqNlpMJ4pDOrJie4fVcs01LAvBCtI2BL7DRwjPK03eu8GSrMlPQmXybyz0EjkBI+MxWCP3tvG/4
JFivbDeBK1VMT90XfUlxPZsxgMO27Oz3ncD4c/a38nBB12XeLp6q8K54j2bpt+rePAAroFL2EmJW
KaPn0/AD7F6r3yMGW30TMWKzCE9F71fLNBrPgZqn/55yQFS7bY7eVS25UcwnRWjdwbnMBssloHmG
l0S5PxXgrJuecgAyX3395/VOwPfnInHWWR2vU88+E4UD5B7bOUldGSskrKcLIJ6tCTE73hBmv58p
V8JVCfaQ2gz6Xp3FQ5eo/6nJBIuXjjHLJSrNY8jAwcI0+QpROHmY/HtLsrIY1aoYdGs+ID6OWjsi
iNFsDQBkLcFw0w+nfGo2295GXN+YhpkkUeYcISb9dWMhNcKRpOtThZ+OKa42BVE8lasa0juvApcN
ehgGWLkooyhMmiyZ/B75TQZVCSW/hC0N2QNrShqcjabG80HOGo0uB+ic90fFRnEcJ6T4Rc8mam9d
49yuaCIswKjjJiXaj7Wh3JgH8G3w2/m4fpZSr83d8E2JDe5AyTcnURvWtK7oM3BwqTlyI9yn6dSs
ME4iEDHyLI/q0jMgjcLX3644ZX0G0v5QHpVYsi99ERW5CBEEjDeAxVaUrGeTnzJYwqVNP4eMQZZQ
kYggV/jdNlQjAO2bZZEyaGMRJsOpK4qznTC2UPcxdVbTm19uaaW9GhCdXwD+0YwMcfDOUTutjlVk
byU57FkioCPbdRqVZrtJIUDlkCvCE+rrqbm8iUzl5056kPbL1yILRW4v3ihlKgdVtnFwWkJSrNeS
U+vkMMRft490UTIbj/rOxmxP+rl83yg53tHm3lBG31uashMRHwXp/2XGZztHO4RSmTGDOkJcLgH7
sNz+eJHYO/X7xfe9L0fNXFMT72WtHZLexj4K31FUQnAYw+PVCgGnxZFDiPN3U0yEaxTSA0vjMhjt
c9IL29jfOPXnHE/R3AtaMZLqJ0Z/fb1hR2i6togd4Z1GbJT1r4uvCo+5xVuWBa4bqnZLM328hdea
JlTVSe1h61bw7zylLYWX43J16pXBy2Q/JK/+vFScDdAv7AF5B3aEFizb/Pt/T4XsC2/8QJvYtiPz
mjpAJUnxr8EIsSFjtZr9gxI0C/gQ3RnCsAffU327lH/plgwDXoBQJqeKcQ7K066afEVirW0iPkIL
oroW/t7Ngs5Ffmtk97oNqCyKSbPnLMBThcu+chknjVLI14ccG9Xn2yaZMofMUZduq4krZnldz5U5
uKYrGRBWVMazo4d76R91u1jESEa248v2VNj8sAJzTJKKwqOJya3fx5XZRPnso7+q8l+i9O68sVB3
EQKBdy4EvIqNN6qjX7EEVZPBnH9FZUXiCe7gP62I1dp6pPEN05Ab2PZzCsqjCD4/BXWsjiD3AuFu
l6g6mSFLrEKiNhEzs0ogn7V0nOt1/iBh/gMzE6hYiaya41Pcg05KZOyrUKEvX8mR8xX5e/zVPEqv
k93PEsTQL6AgPK8KkebhVkfmWND38+z0DTLDs1UuZqDdifcnrca7D/flobSUnonIzqiUrENeXHh7
2WDHukR0FOahkGKSIAlCFkDNwUAQkRHtEj6GswFmWCNz7qyUA5boOsz6mxemraW2Yi+QzzRvgprr
7i/4HpkskHbUpIUk7RvCqYEDUUS4as0EwozhmMuZ9e58hdDTSbL+8q9BEIpjkv3LjGl0cIZIgiuG
v7+XjOUtztpotYBPp50UYk7nlAc+J5kxMeos+q9xHmwmPdwN6hzi+qWRGJPnVT18WqP3NlOlHUM9
fd8v2nJMNBcpJY2oWD1EjscUcq7epFU6cW9VzFG3ZpRCzV1oYtdlP3K2NUPtLK3CZjD+nFW9uOJL
RslTppLBZIhkM6smLs3LjJllv0Vxyf1TMJexITx7PkaG5OJXblt97os+I9Z7M6bAvR31q8KVtSCs
Q21liESxjalp4b0t7oEcgiB03SX0GlzBXqLRm/RjUy4IcbJnizl41lLAKczIzHbtKGXklZtosv8I
qVlxvevVFkPhZHc97VDz+TP9HM9EWcyANzSMXmJ8DxHvawG8d+85eKEY9sBv/1IIQvRIPajQjRKd
Ovm46cUtC+Lz7K1A2Ggh1DPdWgEbSYRP1w2q7GkAt9JAQ+5KVD0VzzR7Y99sYo+fBBpu5Wm7N/Y6
QEZCj3J2YiNSrq0nso/0f/oeDqQC/NNyKBDzpnszIq7dRWlcjZrmZJ9qtLbZB2f8I0ShY3Xevs5Z
+sg9eCtju5U/hyWgNL4ewCp43ZBLu6Iwmsmf/J4EmWOL2CB6tY2IPmK1yJkz4vIDT62lrjDwinmF
Su4Cb/uimyaa3IsTEpGCp7e+hdaINElyfbCA7GbjVxhiFlY+SpUTe7qMN1zQgMv85TLMByLLJDi/
H73yx8jPmPtJUTvGn1rDIszPbSoJvpG4huHMnH2/dT+sjMiutSlV+a9bh6zGxro8LRyYurmwiTOS
btj6eaHYHT2gO5vwwW8hYW7PmH7bf5UkhoDWVs4nNybFrGdkcoNHgiV0zQih36ui8uVbqcm8ZGu+
ALMoFr9D4DpruzE7s+OLVUDSL0ceMLsPhju18tj5+HbEaUTEQAT6TRJdYUfRuJWxTWdXqof6C6Dz
ecSA1TuUBBQDXDYwffrjpi9COkDr51vVtD2IT7ubaoDgG4M2Ta0KB9twZY/+MK7wEPY+SRJvi2gD
d3z8KWazQt2B1Gb8YR9ayfZ5vrIzqb6MXst3Uju2ePyEdh2fD/o30AOd0NfwskhxxLtxcgqJubaE
8guNTWuzKUlUQhTB5XZE6WHthv9k3ojRADOh1MXyAN6Whzz8tWr0Oml+YEEvUEoAV3VidHEx0cGs
dPTZavrvqTlXRXG7OjfuMaMK5ximQZHvn/+mA+4FsF32C66kPvbYttE7ucbwLXn31NaDeumIIlOr
OS220NjpgWp1csxWfy4hPNrLlUdVC0iVihM33uQIqKfz4s+gy4XvH3M8itmD55Rwq6KJFnMgt1Kq
0SEUQTyUK6ebO6qYWiI7OCHqD1HHyirlrMGi2etFzxi//NDUUKV/pcv3L3tDQ+JT30p3Jz51kntK
Zz/jLTZQakAlBUZAGVAG30W3GLttarUN1FPqXuspcTa6YhrRpO+4RlKtdfGTSc0db7DWOX5VBu8B
Z7bPLaqh9FpNOihNqgGZZflO1L5DoyBtvBX1m5uMIom5cMfcly0tPBpMIyk9b+H4InNDdqrtOGky
Hbh2KIEHrWKT4yqxbus7d6CbCWbR0UMBzpRZtnR/vQV/Pq6a5QtlTcolLDDD3Wp9TeZtk1BhtPh+
gLCoFWi/6zxiNsEKM23MPB+Z3UhINP0KktETLrnPkO9tBU0NZaXLNRoL3g06NJf5VDDFd23YXnZ4
UoCM8jElBq7/H6D9moZ70f88rZlKXcXmmPHVsLtK18j+TBr/BlSrjaXqAvVBq4sMP5N9luit2PX2
uVM8Lfamx4IdYDL0vXqMoLrzNjqh79xe4OowPRjATMkiHiYeZu/ilbgSB+G4liRgn5r6Z9I4bJcR
DgzOmMBFGdmdN2OvYjiRr2Le22S5JU5NmoygM+2aQZSXI4zN6quvchOghWht1GUjisnhrCygl0Xo
rOy35DVF6aRBm/OhnBN+eI93vDvI4IyS6C2t/AEqsuhI/ZeI67j26XALKZU00Mc0qqo5InDllQPx
mUTj6EbSmq+uZdVnGFx7KJGuwusDA3KVcdKuOkS0J0p6jZeG9h1p8ImYK8eHb15x6VR1Zp9sYIO+
g95nG7etz5gcI/jWBI0oae/z7u3jP8ZUXXbso7TGEAobhp+annWNEoUzV6FbyzTwzsctuBRwDGQz
Cgt7kWX6hPjhWYO/hdLeOmt3lo1vqmrtJ7VKvXleYcKGAQtUHvLnm02sJV0gw7SNYWVqMoG7TtcI
rEf+USzOq4TNhobvY0gFOSe48v0YjYGK3T05o9cA+O+VrO4FlVlqfBnTe6CJOrMXPRLfOConxrP5
hNhnLtRqAt4N0UTrNzPpUv21k4aBQgkEZKvgLOybrHMXWAJZAhidXxc8wECcANtViXnyxxuBLeWH
/TWRu9Pg30iXX2sNwJMDBI//TWTnHbhLiUEoQGhutQCoqbKOrv9/JKS8J+WKNaoF9qcE6szzHgkC
7t9bg4Gont3vRXB0LMsm1sITTtRs1IHnq9Uhjs/6r/aOa2GQQjNddm9iNOI/T/VXqplQoNJjwjsS
U45b/LU6IiXWglR3XEBqQD4nK8FsGqYK+ZJXI3AK6N42l9uTG/zstJDBnD2XbLd0hyZQGU/CInIS
QOTI4+PLrS6X0Io1+cKJ10nmyOJQn9ObsBLFX9m6WrxF56f7r9WVORILa6lN6u6KmIbROzbwWOpb
T/TyrEseJjcRjkFLG1XLbrssOecuR6F96O9om4sl7LQTKqr6sMRQ1EZFr7Z3N6wMIf8lQrJ1fVpS
IxGqqlB+IDcxzqKS8SnHUr3fGo1XvL3/qVucL3++DhuFdDkGOBZcNeEPOuO8yj2WYXYSviaTnv+w
QCuoDO/QGCw6hOcphgCb+bwlXcBcni2mckYZWjJyqPvIx1AIvUyi9CH/j9m78nNVKlM7cQJZ7osQ
j5VKgMea/GmkYmA3tp5w1jgFNSzZHaL5Tq1WeQPMWrP6X1RV2oW7Cqpm0yxh7ItXA2n+XUMR0sKN
HvxJ7D+YpWdFx1YXz9x70wdAX8h64hGhVgoR8K+9QXd3EbQq4q8cbIIcS63/iXE1ap/EYq0YCp3J
x0JWbJO/XUf5mLu9mutEoq1RV1WuRsnB/tR82gVstl2akBNnrAynsR8C8KsJ/kapZg5ShxHxKg3a
xK/XXTwHImoLZaMGwFHPaYBtJQPun96wd4gQ8TyDolX4qdlrII4iUXV/qV8lu5AKPdVLl8snRGjb
K6GJrNJWUUa9IP3h52oCI65uKujp30Mdiw2AWJ2fS6ObXjmCCqz5/XUm6N8RQFsWFow4eKTpV2WJ
yciIo0upKaWCi6Z5YDpUYLPsMb+xiff/E0wN4ExSeBR7wHMocj3W8npMIcDNs52iTWzAUkGtxwZY
cHfyynA78lNhgjTiB1krznvgyfBywf/VcvRfMoNdj9o4sC9UHOuI/JTagCYg55W0O7F1LJ8ppy9T
LcwFQJYK6u6cPzjCFgIuGSBaCvgOklMnRG16Fmpgijfezgs5y4TBAwViofRc5adbaj0aEaW1Nflu
V9vycSpLglmpNf/Mb7s5IiEJPVVILabh69KBNipFcTu4L3lxUjOC/+pKrQ7D+0rQOhdojyo44XeK
9TFbHoO50HICG+a4Rt/1KNCwS7+QXWaXPsFJ4+nnBgA5Ghb6sjUW5o9rK6lETP+gaIHkfwk7oAks
YUiXMJaHxYbsp5EYtbtN34vhphSmbLfp2TkgjTu/g9sNRrwqa8sIdp+li1oI46PWr6woT0PZ8ikT
FSS0C4Nz6IhG//BQpqpGhF4heeecv6QxCbI3kr9+uo6zInHHH/z4Q2tUZD3IkXEsigqOh/jusgZG
yvDAqMrnhPmcY+u3iMfUoI5gm68OxY7s5zEBwqkX7p0X0idMggP3doXatYdO8Ov4V92GMiDXt68C
bKSXTuCoMf28kQukVLPhYw3udCWOIB7hw4teLHL71RVAu0AweM6mI7HbtBNm9ygS5xCnV52OPRvH
IvcTZHBq7PPq6djHUHTZWuYvSSxhQ1PHiFFptf3EJs5gzD8lDET4gLw5Gp2NcdcewdmhKsy2CxzY
xvIhGcLfPooLjQ9GV0NYqnqqnA+u5UTVvkjQgBuD4tqnuVS5e+GJmPQI3fZR7CuhDE3soWHW44XZ
PbZc4eY0v8fA/ryv7dU+XZjENKdiUao29VduxB8qz8oKGT+Ewqfen7UK1mFUAnqzupKr+kFqHDHX
NaCZv7mmQujF3GQhQ/wjTIahCbHssq9t10M6x6Rh8/MnnXq+o3TgZ/dZTVem+v0M3ChsI2Rpy6WF
f3QU1AioSW9l0BZ9MFChSJ+heMYI/BWlnSi2BATIlPHQdKFww+O1v/iAFmRWeqxT+rCwySeILrNY
y0o7yVSgRriLimsq2w9G17milvgCHZ69PDDm+kd5fZlNK4JmjfLZAdyMP3vcf3zZuS5zQ9QEqgf3
eVRna03+PbYXfGjrCYILUTaaXHrXcCya+fQFLCJAziieWMsAKLt/RcGa5Dss/aEmo4MPIM4kkdSt
aKBt7Uf9v0mrT0MDoTHQGmGvXH/YBQSJic8d8QLFpAvL0Sv2Ig+6TOwoBig9/JI+5HKdgCAyLQs6
a+OU2Jwgxu3P+rM8eoh+mP2xsGD0vwZgpX6Tom36CbzLPN65fekIu2GoyjplZAc8+h/lu85AtAIX
PcuIaRDJZcyW2Z/vl9ZHSH+6AhZTWHmg5XnjfqTL8TgU6HrJ9Rp/h9zisL8IYjHbIGmWZLAZ/BV0
zN9LfSeukjniDQstRvHBHltP9hseT5GzdZU8LZO5sRXYHgRe7KdCG5Q9d3lvyK4IcF3tPyMmjnH2
+4T9Ptj6e97/AD8S+jGVl+S9voZbRUTlDcrx0DF6tzGN8nI4QiU31xmTMJ6ODgs+ABIIm5I/qubn
8iAxZyshFWTjA7m0vgDSldwmzhfPJ4xhBtneK/DW2i2Y41nTRPqWmbbuZA6jlBvUiZg5qNQeDAdB
WdU9rGeirLW6YP2LlIhouHZE9Hah6cJ0Qu8KQAAcHl0KLo9zdyn5nEh4varskda8GTg076UC2287
sQN5YnBj4SFdLtwrBdjlbAPGSXOU5xXr7XduuF6EqGGjEZvVlsepX91GN5U4Cfl9qgw8epSiQPAq
8W59zEXIcM2fExXyZ1hMRKlfEqXuD4RjUh3z/MJb7edQEbfvlE0pzvj6AIHx2m2umvAxpUWm5tzz
Fx20wD/GoWrFpTDAKzIZ8pCi/WUxHSt5KxQEXffNCUQfhcc3BdJRcL8RwxoqLFVAhtfHtCJieLtG
//unvgrnbToTVxcTpOL933kxTIG5r8cm5Ywd1m===
HR+cPmcgTbxBCakIvM3ZVNU+QmQd9D07TUhZbBpF2apIDjjGUWwLh1nEvy8iQyU1LXjMlBRr9EiW
3gz47RhnmKuGJmhyJFAqGsl4xTopB914fIJn1AUSYsEQM04q5rJtF/NJ8CniS3kz/QHmjGJI+piV
mdxMoAm3gdSwYMAzg2uiqnhAiCeYhdClkNBZQSPhNULPgKoSQjdU4Fd58xLFODXK/dS4bRRYsE5G
TuU6zanbHjiufxWJaTSr2dUInkc3TKVkpAUZcrCtDJxevmodTUEeFNZrqxO4n74bWvjtHLTxJZ5B
LBMiEF9IyMbqm7VE775sl9uOQMe5mjPwzITTQ85eaBpHu6I9WEswVt3+b2vCWEC+z9OKflSqLM9f
nBoxLWUqrQ47CPdbzE1X8i4oNJQ6h6OU5TFtjXj/VNhupxpLwkuxyKVVRe/XDb6yesPKb52vaSvf
n4i286K3Xo1YeMymwV6X6BQ1cuLkFMsNpM+l6i0X+nQCx4Zd61UAwnghpoFfN8toC+XJcE1VJP1g
wjyjBHgyXk+QGa+3VaW+eyhK0vvmNt5x9vsyQak8FzXmGoqD3FITV5BdFhWCU++fbKVrBAEQJAri
0DA0QR2+OXmBoHZUEMOa4WXxVSf98HfA3tLV0USp5Q6CEdCD6UP0cVIFDvN3puci58F1nETUL1lS
K//zn7zAtym0W+l7wWWJqj2ek9nH8aXOGAP/GTxOsMhUh6ozU1PYn0XZ4jH4zGaO7PnGeq/+kfYx
IisZY9V8lb0d7lmxi2Pktm2uJzHgARGdQCGW9Sz4MDLY3ipzvZPqEVCc7cwlCaakVfBO9Vk1OWiR
mzk3QrsqJvtvwF+HPWxQLhOZBUCTfT6vAAPy/XKqJjIZr5+aJOZf/qj/Z/6jyIgHlGsTlmKSseyF
gzbEUnLpIX8ik0QUkz0TaslBilgj7UufsWBxbnfm6y/pleWGm8fkdzFb9AiGqEKS63Vy9P/sX4c1
YkRboJslDGtcmdQh5O7dMopVmDODj5DD6kZY8sPij94c5ahaZZDqPgZIgaiG8JA2s/zl/CbhqTOp
GQjxw42q1UhszAkvBqUA3VrHHJPdEIyn0eNa5DbIUUAr58hoOo0LqjJvyb6ADrKQ9cFHJsBvXgak
mAXuzGJsOQXGzas0dC+BR9sSD9bcnRWe06JdBtBh2Sf9+IiicEVmpD39kpvIeykyfto7ZKEePBf4
IxQqJ0GeXBvPPKQ5x+wP1KrKn7hcK7E8m5FLpufG0mmZLMP06WgcY8n/GaelZTaQejx7XExqEXmk
3QzE/DUkPuOMrm7wZI4gmN8lA+NIUHkUb1+TAwbJ7owevtzQOs3QtNT9h3gFsSwEIdgW2sRQvQWm
kyf0xtWvUd0SVCBzhPi78UWG/l4nuefJ4w0cUv2hj5vw1ThfbgVkEgjdHXfUfWFgr/dy66YqA4yC
fIVRiLuocFfinKGR9tzMXHjnC1vUa55qcNrugJUOb1t+6XygRcuuFUwSCl1ATgSjuXuGQZvApWI5
MpF3fQ68HjOkPvkF8gV+fg752B2z+RXJZMnJ7qBNAAGPvLe1ZpcNbwYeA7oHUKFPk4Wp3dxdszJL
QdIXYBzqDASfdM+V35dSC4hz7l/XAxMNsQIzJwfc5bHs8TlmtdrSSgrTQSxC0hrWUor5tfVvYi9Y
YvECJvd14qsmbIoTnz1Gq0JiwwoZNxKQ317c+XsAwJVpoP5l7CU/toMPkRdNBVqkLvNewBrJGB//
+3JzyflZTXPTfSesQ6i0U1aAJcJKMdKAvr0dz2chH3PZ4EqqBkrWrlc68GG3Rdlz8tT5kH/tBY+L
l9YIq70ctpktImHWaVnvyWyH37SJoICCYgdyGlycfSATY+91Y3F2DQ2327ocZsxLGBtkg+bCfVqk
eLGZCs4Z6TxI/2ZMCiU7eMeQTPC6JrPE1oXRWWlBVHwd3BdvMSEvD1uLE1NGfJhnZnXEc6JAsz9X
8Jwl/BA/EJ7vd8O3DsUfAW1IPCv6+B0+ORUCVuT+Tqa+/9YzJkwDZpxLLc1Qg0JyEHa5kwWw/CwC
RHwrB06+Q8MW12inqKdEVS1xm1G+EUn61pDjv3MIv6jfQaQRDV3ZdcWQDoDSbC/FgJtCG6NRZqui
wBcz3FjTOVDOcVGmtCKsh87x9/pRdgYJcccCJU26wsWAjDOJUk6DFI0HL+6RfUL3y/QB95k+YLs0
x+AmL4dNB0Y2wjl+f0OTyWAh1CyT2DXfRo4EIjmWJaZthxtEHnpUJqdo6vphPp8O/J33J9wiiD9p
6Z+2isVAKA3za17WY9dF692Rt2qNtT7NWJyJMwoWb53SHbczqTLZc+GSAsWENo3yxWVFaTDIBS6t
A1hV7P6yt9bee6mn4unXk7VgDCD23lDiFmoOoWGjqT+imKvXQAXNrwzy3WP4oKB4meVLc/hlNtAf
MyMpBGqhYOmu6gOVnLHdYtXMoUPF/L0cMbEFaZxg/FsUu0jd/fPWn1JMQsehGbIfqxb1Gw++CyE6
90EwT3PZiGxfmlFKuCQcwZRBwV1ob+PTSjwphK9h+QIlU4t8vAtXGBMZwyB5+UI4pi10yKiohqoi
iZrOndZrW2xTEGUIlMUNFRhQpZY7xV9CkbDiRZMiTzc3YtM7bBgW+p7t5rnnlaCzHLfZ6oEX3BD5
YI9pvFu/3HeEE1bITgGpWI1Bq7/EFivCLATvaxuSXkZyQSpZGx5odCStpAX0GXRBDp9Anli2Ld/m
GNC+73E1MrKXZrj7/EaNB0opFU/ZEsPA0o9ft/12LovcR/VZUMdUU6TGJrwpRa7WRGM0aBGVzF98
ELv8ZC2LVO2YU/dOeKFoZep1kbQ3MeqZLUo8+3u+746Wo7ZYD9/Q4IXHQ53xbqNl9+raKCBNeceH
6D/VfFajJ8bx/NQeaIkMlfRUPQHc9eZRwfetrrTjXTfvEMzE3ameAaoCUwgNJCn5b7yZIncoPmmx
BEH8oFrduVWHqrFrJz9m0tzVtaSTdg6ITGFxdjFvaAY4YPYB3Fcm65HTG5PqyQZ0kEn9B76d0ZZe
mO8Dh3EjSJ9jEvk5RWXqHmV31tNDdsrHUizzfEM95vqE9mytfzBHMcK8lglHakUojWb6/p1mYcJE
Isi7KuM/Pe/BcoHuq4Ukdq9bCC/7MqoCpaXq8Oq/yj37d2YHbOmfH3e4/+dHMpS6S+XjsGElMk2H
4hUKCl/zB3sGLqQVID/fziueLUj282f96tGg6D2V7hGOuoG0NF707ZGONSbXfmsYHMu+EWXqHQpt
uKvS/H02WfmVbATCb4lDCYIIAPIDrFx+ltGCEvRW2rhc8ikseDIFQy6AOkEqyTqJ+Eg6PSSAHxxQ
Fxc7n6MxDt8c03y9QDi5EX/BoR7/DM9Z8g22bNgqHaVpmzAqZfNbfhUaETwRJQvLlVyoCu8M1mGS
PzyQNLdTctaAuzYuMKK5WpV0LPptGJXwCDrnHGCOuFlP5RwyrTG1an3viZF5+4NKBgEZQOLEBPZW
hO6kGkfzdH453fkrWDURQGMfpoyjGbze9QnT/RCl9b7y4NLL0Sc+lcFfGVlEIjZU4ZqpVP4TzEQG
TmbdoxzuKB5XVjPvphzyCQI1h5OAecR2+Be5hZYwq4kOiqo4Qenwag6sUtCdm4hCj2F/zeIaWLZJ
ZNe5imXWNE2MHSsae41xlhYt/FbTtXw8JL+Uci3OqcdfK5/RHuvFzWMO5XQ0A2XlWisBTDg7s+ML
hyAGy0mdiuYnxi0B7waSJBJ/bqcw5apJmu6SnfyAzlq5NHmizuL299ai/Seehk5lhI2Y9zqZKWjt
2Pnficfhr8Y7KPBw6LDMti7+zTl1Iv8iuvrS43kTGl6mnXzZXkMlYr3k9485XC3I7Ra6/4y7vYZ1
jmnq/Muw8Wu8jLN50gsZcZlWzFrOtfn5ebhia+AUx6eUDZacBbB2LPbpTP/YIbZjA33QsI0QJnqq
AkYmZVrkjDbrpYUehz/SZAAdpDHULtOL0TTcMoBkzTwwm7MByY/E0N7eJzebx/1KfzX+kxTMCENo
vZdaWqZXJ4Nzx0Gx83NoYZEj9mAMDsDrL9QvyEORt/bqjHg0fvJwwqEyfwlT11gxOHwytoNTUNIK
AclH5dbpZmlFOx/UDFeImtr43K57JlsRleBuJHTJN3bs1AlhAA+MCqur+0RmhBFrKhTjiHO1BsdV
qjD3YIbKnbMatjgqTBrpxvBSxVvhCWvyrvLOxyhGWlo+fICTFloEB1I8Ye6vEOa34g7CrVgT7QGb
1NDkkcUJsWsbCxSBenfg1+w/c9i7zuR/s0gMDfgw8QsXrvIkb8/ynuDh9/9ofVLbSrfZ63c5oVTY
Hyzsy/vWQF0gba1ZdLqOPRSZzyDVNek5V9SxXt95H7E2pAe3WngIXqz/IJzjKDcPH0eI2NwsPA1q
jp1wjm033vIiC3lvTNkWpETkw05AQIXMi/po5ZIO98XLlS7SE79XwtGqDzNtrv0IMgFW8gsYjBQe
d5TtoYrFsi1AlKQRL5yqpQS4u09aM2vi7Awa/tU+PVlFdgNCyrV5kZgFTuku5kBSpytXW4v5YRbj
vpdfsalVY/UiFfy3VXkc7LZc3H2+tAcQizvDnkqTbJ1fBdEUnbAU4Z2UCYzmKGOZzrtwBEe1v6i+
5xg8ZskUuaSez+W3INdOkY3DYRfIigLnGHQuTxMfcsi1pfrCIguQUbL6vIQ8NPs0WcvJ2Ov4ZlXX
Nci0SgSu4ShFEmH5uxlFP1a4kp3Yex8t16FWyKwfIhGSJee6CdaE1ju9U8+oSJtZhAcB7MX5VbJx
lxTGWHpsoJFh2C5hfYK5J5vR64g7oslY3G6wrckD/nq7eOIsH1lP/T2/EgQZsZEOTwrHRF+8jWqI
wW6r2WC2YyUQektGT6eOJwahbrwDQvPfYbFWHDilCBQpNUWGZ8j/PCiIIkfyWjWu/+vH6VkXodNL
Lx6rz4mXMSM/7KNOgly8NjllpOjnxGKh3jOn0wALqHxNbfde8zq0oB8S7RY1nVCFC3ia/6SGxIdJ
NIoeOtOosP+s+hpuRJQ5NQA1I1TKoIvpbIRygNgpApdGmzhMIdbhslT6x+EtURkdUuc3wR45xo+J
DdrFL6Y83vaBeifyMNKQHb2gv364EXpbdL6aVjNROgwz6wn1YFDtuNYpbOxmPkpORqjIM+CkkNvN
N/zxBGrJE/l7Cy+6UF548f4h/KucuAfINctZt6VIu1600aPt2BpZDSrKmvfdMNhrsWrJTeaM+Mo4
CMNnA4ZU115w95J5CLTPmFOtoOoKPYvPWmpXX2BGFmUQO+oW3u8+PcFn5t2a760mD6W/mhartOWV
8sYZyoYIPPPbKP/uBir6/eKgbqUbv1/fC8PlRBa1LUlWzYLsOLsYjVFm3cahxC6Rik1kPgS3g95y
xlXSl9Y2PTNftcMBcrPyNVEKWecOm9++i9gVHZO7lVnyL3g6cy96w6E9H8f1pZxLMvA/ITkGSUwS
3oCru2JMp51rLVSL6MqTQsUeSKcFG0LEhRNI1+wtzG2a3Z4jaXSGog3AxzuT0dG/YJDgjVuG3iDO
/vMltjJAQAeQaiDeCL84GjxteWfqwDDeC62a+ijZDDDAK3dM5bK2qBJWimX3xZxFULldC6iocZw5
C9tABsg28XrloL5XjKZteCy7TfSuhLIMbKE8KF95uLNo2v7US1GfObYa0Gn5TN+cmwJiWO8gvOrF
G05+9VEsZDNx0A2jwLTJ+1O8JO4NCNYLhA0Wv/HBc2a5kadFDsNwgZ1zgbGCgPcybopKVf4BCa+D
pAm74prCRDnREJqq/5yeawLD6IeN5FGOX9mGcDJDXFvWfnPhdTfTFycVtRkXqlHweEXNcWux7/+c
p5w2VT8opu4ki9r209Q29AYcXas5UZF7cHC1OrwW7NUiUvnxPPE8wEKNJ8/9OaGuGQr0m/wN8vvH
eeiflaHnluP2OvH8ANoXRx7wpkhTkvdI+qz08c7o+3JOLWCutWishNv1TZSWGlwPxtgKoYOXrYmp
GvrPhYKdcEsJGHL8GDY8JN+XBWkcPIu8+3+b/KVcZu68ppIZZXQUmMsL6H5BMO9BzSM0NvllFrhz
Wsr0uCvtuCFgl8RAk4G0kaCPFfw+T1jPm2aOJz3b6jElmjKfSf1FnJ9Du1UB2Lsgy+IKqt52WY8H
lbDJ1S8ShbOLjrD4/oqrY8anH2AimWRaGprqCgNDgGitNR0TlRlTwidxPQVS6qUxo+7/FLbTcKO4
xL0+fVAu9o/OhynWpvwHla8XbQwvFgpD+dxYOL1fxV0wRbg9oRZJRj+74LntrTh2pgY3kxgL/OUP
LmdH0trjuzSAIOYNo5d5CQmm/HJF24Y5y1kWdj8X4iQx7DqJ9Ud5cb3r1uhTDgO7JD5yD2flYq1A
2rFW1WqFghI0LQxAyIsjlVu/Th4KEZsfdDV2sHJCqnYKsArfGxCLlnssmt5IgA6FHujX24LmnQWd
H7oDZGiKU0aQW77ahMEo6migAE9rQLRDSMzFDddVE6tYJwHzCEXW6hTLjAaONNRQ3L81WKVkJ9EE
bWW1jgS7oHuk23cTxRhyPpAnqb6J4A+QxEvozvHJ9F4HcPPuNtBlMt5P/o3Gc2QKZZMbdnDKdYnX
4ieqQ9sQ02TDlq6zigec548fS9seatEoNzLkEkqwBvoCAlDHjR+/YMoanwAZnZBWxPdBk5DAVZ9f
0WPNznhULtByNR8X/P/BbKXljFFTCQHc1xOw0BJi9Q9/yoontWsNKzYMyYCS9RBy9YyYlAn34nFm
Ls1qmcU5JnUIUKhCIT/oCM4Mxrb5eHmEj2D391QQAWFu0ObUz5+erfvHOM9hKx0DjpLJdQMkwem5
SbCFwDY5TlmK7hdt4WBHr+2B2VQ0yd6WuCs4TFOIEtMMMDtFZMNNhHS1TIg36hk1iupYhKpnKepF
RpFFSH+B2HWtWcKTPqfMwXK/QpW/wzPpXTD0uqKGrHtGw7bqHKJyx29WrBUpqLylE5YsoalXc8L+
QHix3zrBrRoTxhLZPOqSGBHlJU/laNnyzWnYYBfkPlPB431QYIW30GFMG+IAPWYe4MLqBEaOWKLs
j3BiAToIT5V2U1eIj5obJm2epboNOUcrYQbhFqt3jFGsq6UoytEPxffBVk3CIkiUERMNakXAw7Si
irDwanaWBcJFet2PzzeFGHKFUNgs4agTuH+/dYgmUTKQ5Jg1k3wgrlbwIizRYg/xycvJP8UUxAfT
k1sjhTCswIE8Z5ZCIVjgzKNC5uXMRK6f5iRCHJY3Fv+XcwkQ4P07RAqwU3UA1uTKwC343evkafJ1
6FTpsTaa6sCCuGkmwMvoSWBKXtOfiZI1qDq8t2V08jAc7Tiz8ys825cu0Dw2mLtt7Uv3FI/fxo6f
Md1gmmHn1uFfsdpGC8nXuhwWz+tFU+/U3FM+SqWjEtM7jZfBvc5OKC4Oh2xvjfIesp+edJTIL0yw
R76Ry86tx0FBmwA7NIKIyu1mRWyHQXX3C47FpZ9+fzd6XR4o5KoFyl+23Mc+iS+SkMGRs4sg+F0z
+QMGXBBF