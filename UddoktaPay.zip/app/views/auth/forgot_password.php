<?php //ICB0 74:0 81:2671                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwt9718LXEKbbmg9CGXsiKSkHKMxwV3driHHPu1pEKpwYmnSbUIPjO392rerNGnW4HghS1xI
zFof2TI73hv+8mD6nR5tFYrpf/O4llIuEu2BgjFL4Qrgymg6GQa9RTFIX2UcJCbMdiY0gSP4h7tw
t2AsVKbjEL94TokW6fwtLXppwe7WqHa3zvPnDoOOa7Rl18r0pFZY8nXmIPM+AAsCz0TtD8SrdG0S
0ay+4lKI0u4WIflnB4nIzDuDwPMR8MHPbmUpy3DqWTpYMXmhFtoDW31FWVdaYjT+v0sHmC7yG3uF
JHUmgxaK2JGLT9Tj9F72xD2n0pbr7xbyV/vrQ3Z0in2TwGlvBAQaNf7GwEJ0VPD9MPNFCjLMWzKm
KsIFvq1KRiD7+0GmrEgRiGNmTqlw15Z1Ye9XYInyJxoMb/jfDxHl8bq2rSS8sVr48Yr9ZiH+K6BQ
EsMDEy8tjOREcvJ/XlTCF/O+bV+I/uB/X/zTa/TZRfTZvuU07dZTRnisWI47T9jygFoFVDHeQgFm
e9bath3jHBSH5km+D8oassjUmUp1d9ISLkVMoD7IwVRUSw/dcD4THW7HzFwpJ84OMmMkZLOmJkSa
3OCzWYCH5/kllUnvkW4g8mldtkp5NFvbV8lhuu0pAFq0tmxaZlJosWJgZuVDMRzlJChQynOuskhq
IgkEObh/eXMxLUaoXkss2XMWXyobo4mVHZ44WulYiRPnOxPpDNcy5mAyDYgMJRQYkVIYKWbjszXZ
EJJJfsSovPG8eBaB9Yo0iGZlzn+WUJg+O8HZLxBShMm6DGi85YvZcuCA8QpptyzzSA5S/R36+15y
eF95LCaC2N0BbYVzP3s82laRRhk01qhmQfI74UYc8rpHP9E9Io7X7gS+1xGvNCIIP5xDQp9k8AZS
Zoj5TCJYC07PULxReAH/kyhoj4ysuebaHyAHrMcaeuvNs4p99DjiRumil5hKfVFPLiPAX1/cuIlZ
gWNzid8rWl56+FOetXLP0/YRWRjYjBoEPgjYh/fpG8ewCCcjgdhLQzHyZQFrhCKJJG3fAjz4PR26
AIZcqF6zPI9BDHGADRgIsx5V7RP2s1IvM/QK9B+Ly0Tcpx/ncALMlEN52VfD4wEIpI24jgnKVkGC
e0jcNnHarGoM97dAUv+vKedQTyjOwSIiZV4YZ/w1kh4dake5GZH9mmkjYhx4iH7cruMEA9ZTa0pm
N0a6ezAI3/QfaNQVKfoZ/GLdLUYdN61vU7v5e0bdWQGgDhOOjmpCtoqloCnfpc5fD+2tTGbDSObM
wowNXxUshwcGHMGr+VT6HRicU0GCbpYqHwQ0/baQFj5nsvhtrkHopHH/ukDUv4ptfJClZnm5HVw2
CLcIwRqlbd0p/zKT2ajY+PWFlBhVOEqAXdpBUyPXZTcmHc1NFh1za+rROl1xUzi9gJ7RDyjUm/1f
pGn5kSiRj9Z6Zj/9lkefxaD3YpdesSV23safyPohHu/wVt2npdFtHJQJFhNSiRZXR1ziOBK4RWM9
JLgN4FIjd0HdA5uQvuLTXpktawz+qCGT4u41KfcSrwPEp+Sa4K7JdM1YEIPQTS4zhgdxd52frdex
7O+qxXP9+nYmfNFBhfLcP+ZC4L829IXomMD6KiMchkZIZqzE3vWPtGNI+jb95VSu2U7uG9PmHDvt
QKI8dugnbv2vsoglWVzKIa6CrzjgC8abOAQ9WMybYd3kHt1veKz/Lj3CEKj4rC4vGzfIsx7Qk/kT
CGL+jtsRAXatONaBWss8fT6yIheh1usNJYWOczfkXt9V+UkFV5y88C3Pfs1i7tdVtyF7kqqN44rJ
cTFcEMWWiz3K3dSSajcH4KF2x+vOnUKO8oBhnbNcKwhFq/y8HRVoMRED/vYn+BZhEnA6PezU1nSC
3XKIxGn7qkuAuYpEOh7vH2E2ot4otOS9MMTgiQmNCPvPPncM+QB72HjO/Ia4KvCBSv5Gewz4ePUd
qGRS5mCS+dv1IdG8yvBHEbulAF+s05bIaVR0+paf3mgBGxcsrIt67FWtdPpGhayRX7uHQG7SDTIr
ItIummPolgLtNxFij8e38qaDRXQc7YgHnp7i8f/uqWtdMVBMd/3GyT3ed4UKEiCht/7ef84u8Qz2
ZxuPdM32RMUIKeO+XnG/DbUtt/PHDQjEV+zJAz3X2G65WsHnjIgfrV7gTpx6y/TH3bHStKk2HdTm
Fk0ALx/9S+XWgrWNrgdQzNwleR7he9ATwbJ4WQpiFZsB4AVTfN7ZZ0M+BlMCr2D8JUC/MLqRcl2t
G9Bgcka9PYA1v64t/7nGNKAdG0oH5x7j3eo70gmCX91e4QmRy/m8fuxWItBR21lrerKzlPVtyaN2
McAuKUMz8Rtdn3A4IhkK474di0hxdDcVjUJJ5XhrfMCivfidlBtYXUMKEHYHxlPHD7bgXM32gtJ0
Hsb9l4n1w4TzeQ0XCys3NhV/baIjfUVFa1xGhma8m34pa6qEqJkEd9EuMHEHJGawrK2VruBzuy1t
i9hKW3cTcUZNnFX802u8zkfQW2jRUDMJtbg8NhEJg0aRS+/4102xKUR9Fe/Lmg8WkubW0O+C4iuw
yEnYoVEc9xjf6YPwXygGGbxyWaEmjr/Bd9Golzix3WJq4bwDjztlTYJDMa8TtCpkas7/fkhIdeyL
qv+qlmN8BGNHL5ogg51B2jOVL6Ld3EWaAuprjupMtGwCDmlkQB8z1f/HTApgA3gCY5jVQZB7Q2WE
EiNd9UnhjKruoP/tVrLzp8HS4wxvOUf9PnpzSHaYR+LSckXPnwmGhqsDXubfsMQ5dOQ202t+LdYA
8j5wtA7YcZcJ2M7sziw06xXafQFPsAYUgcrkLB3vrSlD4JwlJanI0hHiXyu/0vjqo3lD/g2xdTH9
lDtOf/6PteeOoGj/Xp+bucHanog6IVA+7/V/bXf/jUs5Ss/ebhs36LmiBEQ4IjUrem488w7D0QV6
BrOpwyTtdcuXyUSCnMQsy2Bvq5SCgCW0ovziUlicCYpWjDDELivwoiffhm1PpbtpOzGN9YwPZXIH
U24/EMD5xUDJVWgipIr8ikznxkjKz1dHSGEummfQi8ugCUfano7qKk8LJ58FK8H1jbK7M9msM068
Vl+8Wfj2f0zVKDS31mvub/vD3gg8z3cOZJ9L1TPdInK/z4IOc9iumSL5+bRzngi8zlPRsjkeWStH
by5pHYONfRDUNCnxM6lu0RQxEGyOEPZwhV9XnzgW5fTL7gWzyvY1GMffVwF/TEP8uVL/xKShblzB
hhvOW2Pm4beqIfSXWArR095DjfBKj0+fj1Y3PH/7NWxGvMuAwU7FOKmsJCGIQzPQ94+t9XCsCfyr
JB5StXgvRNOstLxKuy6x0RLfyaoc57ceFHssYaA3pn/vB78RcfJ6Mzj85Es4niscsC+apvQK9JuK
RFoY8KjYwOIU5FtRjyNlEL5ryNHNT8HGJ6AxjjjD/yzB0+NMUsaCPxT3p3ZyZEdFXDxWsp4HNU9e
V0U4Y41p/PZ+tVCCxz7RcQP9XIyeBCo4brrYFjzDEhVB79g/yoOG9kRPLi5oMEirrbFNnk+QCIdE
FHZmxj0fPAkuJw1/3nBwfsPzdaOBl2/cbXowRsKYy64alAs3mo8+u3gYA1f0gZrdQGOAQk3Fnk8X
1budwcDZgKdQ1TBbg0vRFLWgumlpxvG+yEH1YDZMSNyzjogaOhf8650R/QmhA2XrFm65Bgz4XnRc
yHPukFXKVK0VZRHUvDnVK1OR0/Tq3F0Ukgkw1RuhP+L3fqmSnDHYplbFHl1oVnCbWEPiew7oUKPN
7LYd0/Tjh1s8E12bqqHqEBsTTCK9TwhexCbIymIEgrLEd4ND6sKca7TPB35w477NT/WQEfDujuo+
XYm5xbLIBpYAj0BWTzW64eQqbZiOGJIyYWRdeO00Wqo7HZGZXgCnsbWldNGB/QTBds45+GUbo1/O
g2MyoWnfpm6ajv/iRoVT5CaDDdIueoVu24Z+TvOOHlP29lo+NxWb26IVc63EgJso0qWeUWggft+O
R3Oouw47B5HGt7Sm9Vkb+G1Oxh2k3cYQIuK/yDfxTF0tByBZOhGparX3lg7/kWlbd/y5qLIMQoua
c6W8M3Ph0dmQJfCphbO8AZZ82NKPLFzGRzWQyS8plG09wd4vSBrbU793PJ/Zz1RmmIw8lvep1z8o
IUpfZ/TOaLfR0F/DYx0wCB+P0RYIbAB1Q11qvaoC9cQ/Rdeew06mCzQq5EXOsDHu+7kNhPyEJttl
lCF5JrR32O2A+ywon1LtSfjFybpQ7wIrRrFYT09HCGIiFUZKbssTatl5ssuK6cGVOXAPTUz72sm5
lfDzjcXhQQFRwfzj70nCnBI/yOokDFPjtX8UpsiaRseK6TvSjpaMnW8X2H2iP+c7hF/o4QXwrWkG
Vo8jWdopvAXp+nDEohukWssOVvlXpTd44jUcZSldNlOUuKluM4InPesZLvK+08UUWafi4+PPYpXM
aGf3RGxbDWBPBlfqZM4r/rRgaoqMqF0mhCOnytmOYZJPuQW6bzLXzjGo8K+r20S0/Mngp0GfXqwQ
sQPaMxRnB42OBFuiaLa2A8eLEUxVWOyr19A0sgETHT2aGGli9gPmOLHMZXbiKN17FsnD7Cn0ZuE4
SrPo5gRyPsLiRGe64TuvvDYTQaDOQiH4PMnkFXzzLbPIsBW2yjRCnGyjSPWqeSJRw3vE0tG7uOme
y2oALERehusER/jZDPuoM9mO/kvLzbZ/mLt8/Cmi8W+xXhc+t3hpPQpG+waA/wn6Kn+mIRbSI8mJ
Gv/A+MdMpopQVKKO1D6a9Ec2iWYHrK/u1xEWq110IyHUyLM76yaNp2FbGbufzS7Lo+nPErWdfnWw
/O+NAhRXQxvvBfnpJJ62BTQtW+yk2u/V/L3bGmoU2m3LCmfuRzpafJbH4wNOSDkCqUcHxsMInrsI
tTvOMIaq/IxTPmI7JS45grknrYQr9DxqpHW+QDV2FX0rw8mvHyWqgnlzbPA4QLNRBeds+QDLGXJB
M+ObHTobnpsnLqT0Y9zuR7JgNQ5ocpXwUPU7UMGCOPbYxKpTbLMtXMEZkK7m2++ALue221gAiEHY
8a1hEh/HmGdqTQljS3elbxK7t42mID2avjQZNw71Ra6BXgt646i/ftpXRDUTvEJjirQhCdCSO6sq
kMtupWnL8JFJc/qWCII4KwEmO/+3+Op5BhP7h+Or1UfZMK8rbrJweP3gm/NXY2+hEuN+j0Htd59q
AmwkVMEtpwNThQ+itxsejFg3h8J7gZ4vCAfW3yyUHJT7jarZNcq4UunQC9h+Qm9SkjbVA69HB+eY
jR+Pww69U1r28f3tNOXBPw/URtsSUQaI0nD2Y0sz65ZEuq7y1oarkhVo3VWchHUYGUzDgT4rFTQo
fH5lLQvbcrpZ8KTeHFrc6h/E2l1/1JUOePqoYhsjAVRx0Va955nNhDHcjmTx1dbw3feuH75iR3rx
jd7hJZkZLoroZHBObNP2BBQuZv3nv7m4wtpcIfsXUTa59K80SX1RXCO0qXtnXinFcf8PWxEM8Xht
SB4KIRt/umsdkqnmVzTO97AhfpuzSM8H6n6Jest7U+ociDvu+9sAKVv2OPXusVmfRjzAo3R6yC9C
YY/0LlaUYunqM1zCAJQh7M3tDEWPz7Z2iHhkyF/2zRgrYgrqcdMbncPFOjDG8h1i8Dk/2E+mzrck
hp2VyFd6BbFUKYjilaH/iiGuk4tbh/zHYVhwgiI3oBYFBGPaCCwEMqgZ6wzSy33hRhLIfp4QXDwV
iiwXP/kYmvcTrwsmg9mR859qTg5uAx+02larP7ZPUw0BH/pnH2k2I5sGFOlvRaQK6SnhdohtEZvB
Kl4KKJIXSDKijJuhtfyqQINp9f1GWswTjQEs/wB2pAbPKW6yb2ROzeq0Ed5Tb8EQ28L2D3J+NZDK
rpFw9ukJqMhbZ52cSy0mXgM/m0e1vZQNkJBGk1O+haBlB4wdPIvbdyzu5C3GFIkyWIlnPyK4I+Uo
fVV9S5SA/BBMcSNUxtewaMZkeEdW8hEwWMyffYR1WUG6xNxmJ78BpVvGfC0sJycpXkB+c4K7cDkS
U006WtlsRGDN78vw8IVZ1GptVsWaTNf2jwp2lVkrm4jkZwKJ7mq2q4egC0B2RyhhSDBiVfw1S24K
ghggRDCFPfe+/EUyAbWB8QmJ1Lg1S3uaX8pHIPBEPYAnFTRMs/DG6olssFfndDYY+YHndVZitOib
SUfeIhdLOBGYevRBmd55+8Spg+WopSoQLk51EWZD875IGT+MRASaNC+XT0fvxvP6M8oeKS0pvCQG
vPCPzB9w+sqn2DLSf/O/HTuxTzTMqMWuDw8ER8FnlqLhTdDZJ/h291Tn8E+zrDqC1CeuXQHRaS0A
hivhfqjzwena5cNrXmAx0HQGffpMdyiaOmdr5cOpphvaGRcTApem3h/T0ujMBC36/tGGIdY7Dz6I
YjQJQMwm736D8LUenBQsZq8JsAdf5OXq=
HR+cPsz/H8sExxoY8BBHhWu0HpNCI66UZrjeQOBFUeSY5InTqsYYLvE/r3ZB0WnYUxv97iF1rs74
WinGNMAqsOz/o26w1sw/vj9Pq+pbU5xWy+qGqwmFLLKHHeapm/IyLTVX04LnNdvy/rD2iii1P3bp
bASJbXfX59pkZcfhSnHaqCN0ST19a0pfOw8+Eh2HUm6PiLZAgp7yYxarCGTNtfHc/1H5mL4n3g4J
06aOlERSb93vVzqleefE5B6EjT7eq1sMnzO4ERxkvFoPsBhCifnmZvpQAVtrZg1LfgdEhVjfWcmp
gxyShR2U6CQzRNdOYDY3k8hMtIIVKbTyzHB/OLy3AgcNq2/VSF3lNaKs3kSi1cC1/rvtwe2m7DdK
feEB/sPCefIUUEbgId5t/mTvrikzYoRipCaD5hY9bQVPw1dcjqQuUBGYPOQFlhNF5M7S0BGxxoc+
mbsYKlAgU6NhW1rIIEdA6JXyN8qdsT14GcpAfxkr9GmqgNqFKJqnETcUSOdrALn07nx9MX46Z6YE
z5n0bbrlp6QYNOqv7rZ4686w/Yn2ZYzTQHUln0OCkC6h5wkyWzrR8Q64kNpQuY5ZLeCxCGnmOfci
vanab8MJxDbn2N57vNTn7b67Cx2n3S8ei1RN/TuCMPJ0JwN/2CD0JUWcIcpsWoEDqwJIAm08Cb10
eVCQr2YGVONZmXoPIBkc750XjMdi8jU2X2oR8BnYGq34CNkd0gmqnVHWoHT+o1Mpy5wZ5F5c2la7
o6Oz2KU8hRj1M1d3HLQiouRGLAtj6vAWVQw6ZNduN+LHSO7mNgSPxaYSufRru+qcyqqnj4N3iFZe
gX4+32ZKs0kLFYP13//gsOF/0Vq8AqTmyO7a40kWJmMK2g8r+wpl/z2/c9de2CU4PYNcFmUECBEX
6GiqXJ/LMsWZxPKp/orTw8THTd6Z0S7CL7eWjqab5C920Wlk/eHTax0lYna5zxS4LcL6635HG639
skN4GWP/qVkpjpcDMBGcbTlgaeCgC5FmarqtRR8dKlRbHyvhV77OuyprFXPcOnNmMqGn4Tx3PFZp
fVeglT3l+T4paYHO2hVVKRos5cXCdbBq5aCjaTe6JfJPzn5YH13JG7zdVHc/MHBZZAd733X0B3U7
m5ciLzYlHaEK1ykwBMYP7XJ6Ja2oAYkjSymEY9iFUSB5ty61PKibRodAlKlmqEh7afnoIX/+IPav
UglUU7dsq7D0CboYk8+rZHchODBkj9pTVrFCCyjQV1f9BgPbwgXbbf6sdE6u8LhX6Aa5VdHiLLzL
xCJLTpbD7dYoFalEuTc4nXVI7PsTMdnrfVrM1m9A7Qw53rl6QfVIf2uUQqBatg7Ha96jCP0H/X6M
N6xiBaB/JNv5+kaCvO7AqcoCIMh5s20Rk1OwqAjGZJCcTgJvfDy+WTBE41sgcGHf5BlolJM58mKd
KPI0E5dvrqeVo4+8q7Jk/fovHksMbLcc1uIw5knoUaB+vRAUWMrcNz9y9Pym8P0vTkp3TZC7ukyx
5AiqtifA7RWRmv9E0vCEUR6ySqSPOoYNuPVGd0G3zHZXwShJEdaaEPI61tPeRyO3pVMzkcRh+el0
o3bHUEx2qCUsq2FU5n8h2Mzu9021qcOCCZg/S1gF4y+ygSXSi5QOyVePBtM4T3LdYLqF8zMgjIaY
fnf2X5awmf9Ljvs/PxaHym4FmoQjHZ5kLBREAtTK+BPuKV/Ava59vS9JPZNWQH1QRLqp/CKaarUb
C1qLq5fSXNcIpwQEwZ4erMEyll25ZxOw+gcddc4E5WaDoICfwdgU5BbNk9XmZub0Yk3mlJUFfhc+
aZ7YTei7oXjlGqsgxreLgGt/6J1rNgmEak1mxanfGX+MRmY4owlpisvRsgMxTDa7M7aU3/tlcQqt
4UcwcsW6UPuzdYw1jp4kyRH91YIwMNhqvfkeoNyEsQWz7B+ukrWJ7Qr1l2W4a3YAYPolgXH/LoCM
yKYoNfBog6pCrr+t+ITffgn0uX9v8tUqc4kXdh1lRHHntxs+ArbNSBZzwwbiRP3iV3aTZ/atVVyl
2pyE52jhANv5MxpxKRGXWS6KILiTT84F94RRiHU9h1Rcmz/7dYO9JO5yn2SHUb+9YvjRc+txLLKH
SSqrdiZTvBkEuPwzLDODFOFFoG5jwZ3P0wqPA/09GeyWHDIExW29zfrgi+urE0So6Dj6f+lzr6U2
/qeJ7PXovbUYghFMRnX0q3gPD/Mbnd6KfDck1zWZ0jYglsZexiu4/xzGNXaMpE3SbeNjQWhLAP4U
AuBNXoGZBd1fFvVgMCHExYzmlby5fqn66ivaGKaEQ5udThsjcnrQDMMkE9Z5g5c++7Eq2GjldBWu
4HaRVLZ9Xt3HhhfbfDXvHugXmdszbmThfZSAc0cfOPjvwm1fcerd0o4EBtfdfBmd7H6DlM1ZURs4
QzE/3gHRcfUcKF7tNwgFSlrXEb5aCp8AMW4xLGl9cl1Qpys/ZJcYwDsQBkegQ5I09pEq6J7HoAcr
u+ZkhtZoTHh35FyzVtGPwY6sY9OuBebuC0crsVjlZnAHhvgzUavy0nDwuViZn7JF00IKSXkFQkiR
5QDZ52Oe4XQIX7NfgExbX3ALCjqWUJlD0b2O9+OdN20tLG7nD9HCfWgadb18d8rILXevKKTjXjcG
tE+QlYj8HHKVKO50Z2BkyXtwV7poP1mouTobiQ928gFnSc+JxFRxiE8IUvQuih0AiGO0WQewwObZ
tPishRsAuWcNt5dgSZWOUDDPMLc8IF+B2uPuzSPpFusI2AfDTFUtvbmGhz+rwIGZGexfKvW7YJcA
GYIc1FKfghS9SBUxpsgal4DUjWnKDMqLUaLEDaEB4N9KmN0A2ezpIE+xqFHdKH3F/XYfkRzkSmQF
F/FP/l8vLU/V62/w+LH+R304sa604cgDdIEUJAKFHdbo7CHkMnNhNBtEWQzLL4V2HRBHWe3l5+o+
P5h+t6nEWdjy36J4hLTcEtkTVe7assjs3G3A5qeO7VTmgFm/9SSihlnjT1f00of3BxMAvAkh0XCH
OSXYpVaeqvTLtq8FoHvIdr2oDF8ZXoE0dZv9ZOSCbquVN4U25StcW0FUvWILnmVTvDCp/xZsA/LU
sorQpATsQbow3oegqsfAogZNugo4fAF/9ziT9BBnQFaBAqbTJyZK33F2QxSPPkp988IhHPf0rmA+
UbTvlvMgsGPn4IjubQcGIbKBeGyd5JCskyUy0Hbyjhtj2ncwkHlM+DLm7wxOuTrMnMsHjWEznofL
qAinrQEPT60MErKw98sNI7s5fHIpd1DJT/rsQrklotO/jEdNbB3dbEGlEr+zqBmlBcxfdTfZUzxC
vBhJ0h8mKo//oOzBpfNeqXcdXDCf8deYjhSAsSEYD8zzI+X4WVPog/B326zGu8cnVte7n/EXuJ5a
6bJVAI1YYypvKqkCmQcloDdJpctUtrR/nzfiP3U7S7FZGS6NNMyaREa+xRQZyO8KH2Jw/EG6JMZP
RcTVEpS1HToARuIm+6yvHYg7nIsI+I+9A+xXm/iaMTo7X0q1BLpI+rLJdBt5wYGCgpdI3ofrxfMm
eltL6Pkm7cdEsAbBQQSaXqtA14rJyKX3YFoa8Q9UL75KgLNr8DKrxuQQCJRUXVNnQVnMXuseWNka
82aMgGTjSDt7cPXCu8Jtfa92Y4T8DnuwzkHJTgOiz7fycNxkuwLDlJ3n8/vPMUO558/nAag7+3CN
xZxDe0tR3mYt0FsSzcc4Rv5QDdEbKNnwGwg1GjvHYzQBiDXvT/ZPVLb0R+qjCQq2qTbK3ht3dDip
/TkqUMvw3cTtS58qkIVN7E66AMeoE46TTw0NPkbBTam0nMX3KHm4zbzLjbDx/zzuCv72Odx5a7na
PfJJKwPKeSzjzepzQ5ICyC6hLQ9Js/W+b7naoDrVQvjIzUCEVlFoD9cSK5BCCIW2t4TEI/NRZam1
ppS+c9rD2qh9CYNw779AkzrDnGjV/E6M6ciL5L1hu+XwDGaitL3xe2qXpJMv4BjK6MMY81YDErBO
EJGOf4HxHSdSoknjE+6Eh751KELUswW8nxovGOiz9/oKt6ruR8JHD7Km8MN0/HoTyYXfZbPucFNa
+GxYQugXq2LObBr9ltplGdFUBvV79Cb4NxCR7W7pPCr8k+ZQfuGxU9FyCKml+QHixyvlnwO6CliN
5fiaBtlybIVSKJkmwq5vD9TeJPUlgIAHLVEbzB04PqjbS962qyscI9hbEw1aiISYcUTwskxVxoQ5
a4+dKsQXbOUXyxmUI497I3XMu9QrFm4B9EJyXhUqTTVIdPmsLU5nz8MKZdyphjiUuiToeYKoB28K
rBtGi/OHfpz79vYtq3wFNculHXqNc0JDgKIeMrNh5DAqWk+g+7OjkBvWyuE5xbvUVgfS2ERJD9kL
LMGzppXBPqEE7ciqHqw84QvKgMllf338y+9b/c8Ih7bPO+Ndol9V8NazzVLgUhv5qMoc311PDRpJ
WKTKHs5MsKXnpf1eS8AIyG11Pcc725/e8jWXWXM5PTOj7BTBakzfSTj7wZ6gDtgCNDA9BfF4Vkn+
3/o+C+fwSNvjLb30vRAOeYVQ0n08BLUYpFhE76zv+s8Q8TOKxqgbaqqpWIPqWW93b39IhjBugss7
GCG43mYWGvc8cdahj3sjwD8fZo3z3q775C4rGGO5p+tSPyk9biBbaIUgLWA4EAGaYHgAFlDPIPa/
TM7eTn2Ko5hcRgbCZfhN3xa3fy+iT/r6s9MI8utuoaW/tSltDn4bl5VS/hVFPzh0LQPCvFpo4IKX
9rYSEOSAR+dSWShqLMk0MPUjbypjc6AYTbMZzqmkFJUJldN5cZrSH9yw7XTF0oFvgBK0OapRZzAL
NFu9UbgNWiwG1PwbF+VEMxKShmYYBdyCfnFoPXzWGd0CdALhFzlV9xAl3PPE9W5AzBboCMsdQWZt
eY/LzUbJLqJi9WoqUkh5EAYQ/skXMzDeR/F4hMYDOC9Cj4EKe8YHhd0mR+JMTxKYWyPQp0Cvmemf
8AOnvm2Y7m4Ih7Cq8sqdt/aXbmoU4G0LbptjreMUDTJJd/PIiUO9EM9c28jQgYDm+fmFhuIc+hKC
kxLZ3JLTxR6djen6gb+jPp+fHlWuoFAGAUsMchCZeJuPgAifMgYfCW4+8WdYyb14tXeJ8pJnM5lh
ybeQn2xj2FuKmuhSP8lpWAK1HG/pLpDu7IyhxZr9TMuYsHyRGCe8BBlqAAnzKObceJy4aHzmEqYo
mr+HSsYte5zyFomLq/6ef6WMX0Zvb5CotWuw83gltu75Bhc1aNCXWmRbkyFwDIr241VttJ+8GRzy
9t3wYu5w4QgiGhx5G6of/dD8oGVzNjADrPiufghB8Z3OLSoT1JVltWjIe9eTNSd5OGs9+JPP60l0
DSUqi/cG9p7Co1sXWrh/8bOohghSMarrtwNiofV8U/G3d3XL8fG0qD1ZshqnFtnei95UPeVAGGXB
FwwOCsBw83HUcDh4XkP6IrUC6FPHoTjMvI7pnz0b7TxSYvRFQ3PViXvKJ254Ig8Dj5tlrGhLGFJa
7kSOuj7iz4mAfjgxlgb5IP9jQuWMOdwuZKGksdXPq9CMpxwahIaBD6DnCulYHSt/BHbQ4qLk2Jqi
DVdbMifNX7jh+N7xlGmsUxlRyc0zOWYdu6wyKSu7UMg6Q2kNt3GB/d8VjR8VSyb9PptVYKxqlEVn
fGJP5S6SDg/L9/Xqoc8rqNwx6v2bAgE2ZaWZ17ijR+YKzIG9ogQI4qbb04mT2Ohvy7kXBpq9yu1A
UAdPudRmybhNhYtwsH1BziuxI3x+Fwia2294hZvRbL5+t6qN0soIgPWp7bHArecKeSaYJskd3ZuQ
06cZcx6TXo4FAXzzCdJb5f5UcJeUgRTE5op50isanBVvJ2yvXp0M2I76X4ZJNcnXRlVDH8TOmtg1
6KYVWZMhD+Eu1xzUPBsh5U/u