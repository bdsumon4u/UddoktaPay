<?php //ICB0 74:0 81:2669                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtamqoHmhoSBUlD61oWxqo9u7LjlKh9E493FeNnNgwSQfAJoebc3YMegxMHc0vXvixsDtYkC
noBTa3z7pQgdEjjQ75M7GiU72H7Ro4Gvkh96gWmH59mjG0DIeZfdTOO0wD3NjRpatsvBFo4rOX3A
HslYwWl63PmeC6JoltlQepBHPggYoiQk/EhmYz56Syp+lPMgmxtQLcTVNPmwyGbseSXMLFV/iegX
BimHtAS32BLXZgRr5ujcJolZ6iFg5wZdNeQXZH03GlwfY2gE3afjpTjrY0W+bqlNtPkOGzR40T6t
wnI95bEijtJBKNGgLD1tAWdq2L7bOQXky5J/rdkLKH2XpeRivJcyyYaUnL3kI/vWr10rSd5WBdrm
oFPYxo9oYTuAFG1Ca3ae+ZX55fLYe3tFUbYA1MZeUBI++nomxQ2FhUUTMnMsS0Kr3cjCPM1flmZF
hv5A3bqHHEqHhVYGSczyQ/fDnsVXHWlICa9c63zKJMQAbJ3aE7dTgr1UgUI61h3FGE4S4wKZen5d
P2L86azUQowTkzpmyai8tQwVAJfXrgDkfsYbwGbSXsGT6WPA5b0+8OJ6VZDui2ujwPCI8DvnbQwC
1XKiwWUTL0u0+xVqtfIJb+7i7OjzqDpgCfslsv22b2WohaM8DpPQOor4ngKrFoLNZjWHcmrV0//7
gro/InbA6oI7V279H8BHQE4xEUAzy0I6rNN/DCMV6WsB9suJM7IjvLYXW4rL2oM+BvY0FQzN4Ohq
28FQzdfb09kpQKk2wAv32NrPys47tmwKrFCO2qBmGzckfxbundRJcS5ElqqmIQVN5Zr1xmKHLIrC
6Ep19PdBNaKUUI+wzlHqSWfDltcBOUlCvA0lRMOIcKBYGshtSp/dxTnSQKDMqZKEkvqk3Zlb250n
IldU3eip1boqozxNhT0l3VU1eFz/60/8aTxR0FLJCLRYwCzwpOGHE5TuQo65huSQHwo+4iDbmJzT
gIeAOjTpgy4Mm9v/+kXKCPdWbizOBnWfjQPa/m7l5lDd4OHNzKyHgQnrlD22JI+GEOrnxpRCFVRm
yKDp+T/ebvllwUkX/asuyXbT0bT0TbmrYc9G4FrHxCnH6u6+0uPDk9jvlbPUOAbQVCuWORZUWvb6
eLN4e0AO+sNAgWhzMbMQ9jEham6icMBFYyBF/b4NZkSg3UHieRDLz1SCVTI9yyGC9otYgmiPGHLe
ybQQMRMjoeZG0oM8LjGFjTwXLKkFURw8IyV7JuXMyTjNdg2XevGZqpZD2UI3euMLb79WBlSd6S2M
Eus9GZWz9wFibqOoyFW0h7ujsT/NQeI51CaYpZIwEwerSlgqqDnBAk+QX9GtuiFcXY9XEmhlYa3/
Ipqw/rLRiXuaougfVgHkdaYyN+iAI/x+Px25xc6pVLjhQK06gqul+D0E7Mhyw26rKw3l2QCScpW4
6o2FxcOwIKwEtAWAvNId0AXdAd3LRbd7/OJy1+I8JEvyebjbYb6SLFhHhBpUMbkEOoPUsd6jWQl0
dGX+J9PTzgfHylULysU4hxv7a/TsUt8lkxZ5pz/rBTBi+7Y7+wEsKDIxlWZR0qiPx/eKkHGcKulB
lL3PMtSkwesZOSS2G5d95Mlc40M4EgxsLiW6W2NkUgxtH1UVljz07ImnPrlFmYkgOmxIMR1I6ofr
COlwljIcN41vVhlaifoZviGLENummptE92BOO276Lu/cNEe0c7CiC0FLMVGjRMX4NAZzFMc3xOox
9SJf/TU0QKJTrqlo0Qy+bJlyZ8Z7YfzgRFUI9AoZKTTiyf/0HS0xkNpWPs+dQTGqd9o7/kIwJYHJ
uahmdOs+SYwU6OhCJehbVSGaIhvRaqFUzyOrvnIFibjuXzTCQYDiPGCkv0r2J1TKZcudy2zxdJkF
2ZH0OR0KwjDIyrbGeSw4SFg5BC62ZavLwdQ6yqnuuCYiy90hZJyFhMzX9o31QNmhFYZ8PahqWiTW
LLtYMl5Io2nmUcDYnQob6H/uSKnRZL8LAMrwhYy3hdhd74HE6iuVw1VePTuiBXyLWVIgJrTgG5Bi
RA5U/rnjXUelbMLtdCYGwranyt6ftgvwOeOIQ6Jh9mrNSuj66jTmRB28XZ9hhcvJW/BSsawFvxS3
KD9DyQTbdmpxYifkZrMy9dh63Vei6TgPCaUZXb1ckbEfND51BWZTpJXRepaet8ymzzGEWZsP+59u
llaYqvqKf4JTw0VN3BcuITsZPsD1f4QBq7uRlNt45sMSGgBB7XwsR3lCcspxLfi74wbLCVkC3LVE
XjDibL3KZ/ZPZ9WpBom3Npi+n/BEZM8arFl1qDfmaiJnkP0EXRodLftrcvI4SfF3EszDrWQbiqVp
2hZl/luLqfjbnYC1W2sihSb5mPoqQdjHMEK5BMjlkWH55eOYrxL7p8GlfkxT1ItITuy/9KEBISkG
l7iP1xtSW7FqAzJ/JcFPdkJl3Q2FKhA5KYnoWrXd9elZzHOtAoT1HYMXbcPOXFyYkUOJrLV31WCc
hVGUm+2nnpR2VM2sDkdXf8N8QsXxc/FUWd9FkushxGRNLMPtUGRSFoVLuGpt/S9hyaeFyL5IjAJ+
ETxqn2QMAy8ByZLFTExpvOR3P3jYf3QYUuP965cnLfsDAUsAKk7bjOiJerph+p9DOmGnSVBiW4ID
Hd8pGEAZFUh5bARS4QoPYpu/0vkRo1P3CbYQ4zY/dYZW2PZZTcHuR4LzwBnAcUI4+7Mvbm9dNgEM
2I1nkSkvOl/1ulwVJsl4KUYVrKlls2El4wwtwAegkA5k0Pnsrce8Ph/Msl2iUDX82RpQb6OfEqsA
XB/b7+01FJ2bnxKSjH4AcX68c/7M11QjU2w+lCxR4vUv27u9//fNJyxyEXnIVrNwD7Qt6+AbxPVV
pdGwSwetyDZyqYFaU04WaiA1adCSD8oySNKEYtTEE7bApl/YPVNaJEK8ei86p+QkUYxLvCovLs2z
iFv4j3GT+BbeFVUMRkNc3mwRladEnJYr3b1XSrauF/RPgoDirIq8vnx/yjgeCvmANYD+0W2mzQ2/
51hfo0nSd3PEhUUURboB89yDlgxKr1jO0EpDMU9a2OCq13Kd/qf2aHE0WGOptB4Br1lnxs97T/A7
FefAY66OOuFe5zJH/2L0GrDQfEzJ387vBJNcW5ev9XA1bB5dIwHRxsTr96Y2ROdSoH27aHTy+Pmo
vLNMUBfT/NxYOfpB+nNW+PbmkZA0VwS6P5cjdfsRG/sYENxX/SvtsOw5Gv0XozKVwj8//U2dbLxN
+GASK2hZq5DYk7btP24eNzXaApLekRFjlMHLeKvpykEWR5Ahgwmqla/aJYgBZPe1WI269tLEnRMb
wmLmgfGSG/G0xQpiq5lSPaMgalffyJT28/geVBoFRqML/3iBAx/1g9yTW8tEh/cnlYWUpGgihCVb
3o/kkB3VBKx/skI2edDYG6xlnMktTNEl8wWZ9qvoqoa0KGZumzIcKViWTqWCHk3wwrBPKzodNPLu
qdaWNOugIrzSyOrxI8qdIE2Q+2H91HhUbuH5ozj4SXi5nPIFM6bR+PNmsm7jm21yPSbpndHDTWOz
z58JwTWwYBaf2KQduXpqxnzeIh2nwuC66+FrxjVahvPr8erbf/sD8mI/sBTNvHMMrZkiCB+JptWc
kDrBXa7K7qHZ7TUGzOb77f9W30+FJy2rlONRBtfpx2WYuuNSE9gtzy/c364Brw2+UIXjUN3wmHsl
yQ6IgXTSUV++znOG1pY3ajzh0RM9RhmAvo96B+DSascazkiXAl+jbv+71flxCFpt+OE1oYZBT5TH
Cu00cVL0NQWmxA51zvUQGmfHORfPd3hGnCpNhI6/6Dax5cgwKzVwsIDBAwjks0OfdLQjprSoGAN2
8Og0z4tPCJO24+HH4aXUDPJQrqngH1kQyIDLZu0N0x2uBUNRZ/g+RCww9wcAGj2pWVZoQuyRYOJt
O+uNRhuMzfYNjy4V5f2OaMbD4n5IIQPXBucqnQOlrPo01/kzJqbdc1irmB2NtKfxpzx5gFVwgERU
dkKEQZLQW3j6mU6pYrNrIUqoQJ9Yeef+CPGIgZxFITDHZLaAHifpGtPAXnyMwyYcX7HvBsSaYJZl
n2xKGuImOjLu/o9qMmSsrRSL+NeDToTX7YYDA1kt+/reJXoLIcFZ9OiB1z9rX/YVMbyJFupjrzxF
fxz9mt7YUsPBOi9etM6qMuBoJobW5oQspVoZUW6iDUHaAFqYkRfPi5hMhHXsvtQws5zDI+fRyG0u
k0tNH+GtSC5hq6lxJHepbLXl39Wp9HND5UbuqYoFkRy0Ntb1Fp0vXfP0H3VSDkMctvz6xmm1kQiS
l/BXIAdFZ7AGNn8z7yuNJj6bxbE8InE+NCNTeGtgjVK/s+t2NtNOj7JlxQ+Dhdz/bsvVH/oOFwhP
bb+etvUVteyxCjuM1YnfhtBkj2oiB4PNlAcP4HAOld+uKwPik0glOOIWPYqS7uGP7nvnW5KneBIm
AqT4Wa32zPXTyydSlTaV6NNWy1ri2wEoaoa+WgPoprfv50p5Z1mWbeQXXTP9ax5OG8npuRSTnkfq
pR5Kv4ci4eVuSPct31lOKudrq+dCHtsBjpyi8Rb8vs4D1Ly8Ne8+57Ue1nkoOn6Sf0DikyX13xVK
wHmAHO0PWXpg6N2zMuawTyUCW9MVCJ6mdxEpWDahmCCXkag3cBm9H7TjlOhDSK/LOBje2YVVAGE5
jsAPOaAXioVyM++xyKhY3qDXlgJS9GNJ2vm1KAeXDZ81fmUa4EtIP+2xIyURGRt9wn4om47Bx5+1
mOC6uITpIm/Ewh5KDrqpiO24NY1iQi/Ntxt/CB+/PWw04N4h/afdLDec8BIn7vYetHc2NAF6DKFh
rjpdtTOs+2SsUyYqfsy+9vQ0Juy958O0Sb9A7Olk6BYSUXqbYMQIePi4INFzoeFjsnoNkI413O4L
QvsozYiGWZGxyBK3gH+Ka6AB5/4lkIGaSBcgNQOYnBhAknAaJM5QlTIxQ2CbTl83mgGLdzM73CxN
SPoipEusH2zMoSEvoCH2QLOLIdqpJWjTADHiSV7CPvNx/z0WwbmVwcAVobnfsrMXOW2T7wyrpM8J
m1oGW/SFjSSg4ssqDpOxk2OoyzozzPkOqJV3CNuAz4zq6p8uCvzwYVzEHUTLYyDH0KbW6g142hR7
SzI/DNyOM4mTiBNmKV1sNaUWYl53W9uEv6nhwEps4VBF9tgyHgSOdWaaXvfluhX4B4Ko5F6tlCPP
pKGsifw7J5tueNpNduAgB7eIG252QHSTgShsXhHkgBdXfwqDJfLHYCeBmtdBACFbXU+OKPqVcnMJ
jub5L0qQ3HME8DouJSlXeFHGq7pclHV182L7lAzRBffue6RjfU/I/uM2dId0eFghCrLezBTUHIwI
KijDNkpco26mO4xzUvPNMClHbTpj7GmIy5DRriZQOQQb4iw6dc6vnhNcBsdqJ3hR9OycfJKPpVD+
LsDAI/gZg6YJVEhmB1Rn0KoqpEmeeZYsStUT9Plcip1ljxqCw9W5ZhTQaIAL4GyMai57OQz6qFcG
A3AletTAL5+ALPcRBIqwtwZ/1M/PSUDoyMicltMW4WYZjWPYe14WCMpOb6Sho0s+++9294rPWqWc
qUbqc6ygS3uKeRL/210U1seJvhwLk5De1L6Gz3G/jLlz1m6TjU6Ik3s+MKtz1LgzQolcqMb7f9bF
PZxcP8iY0CBc4jBmEfVqSM4dIcUFpyjHSATfjsurVqnjtVQme2IsM9MBa8nosT1OxB+jI/PXLLgL
d3SchyGVQNw+8hsny8TxRBYT9Vxzdx7JS45OwDZqINjNNW95cSi5m0npnrIdAOv/te4JEjBsap/v
IslliG/5rMefg1J1k0LWL5l/3S7v9mUr6odUjoC7ohSFh467qQiRkxmAS+m6XPdy2vcI4D+RzSUD
0SrWORtx2P3bznEQLnrfXX/HGep8kNjlQ2PWoEYrhzHZE7SrBSj/NlhWWtomTsMx0zD5tOlqOvF/
pNHWvN2FVoon0pFPs6YeueN3Oe7uz4koqFnZHAQbV2VkwsQohmWAdmriPVV4Yeju5TfF796EzEjb
PlutQAYP57GvK0BcjjDtVzUHUfWVnIV4vSx8Q3U1/yZAJHVhoVoeeDtwVy+TFZ4IlYsRLpQ4eufi
4XulTM+ZwhXXxt1jDE3U//zFjQ8200pUThZjZBoAZHWZ4eEzfNedxYDR1y3/NgbVaZk6IOFH1RXs
Z1O/7P+QOjbZUIjlY3tsYKH28ig6QSo1xQh1T8pnON+hD5dN6DQYuUMeXr6IdbE8VMpYzrzy+VtP
SY5k+JhBIihTitoiz+XtRjXLDwJa+SWJE7yPyVT5DVcgDfKD8wFSIauc2m3gy1yNLEJWDcwp11gM
tK3v+7CNlhvFxcO1eGvQaMwlRTqMWv79vsloObzEk7r1cMbnxrdmSV26plFQVbMDW1cyKQEhiJrZ
JoGv4jGG1/sd0WT5exiGHy8==
HR+cPv6GybiZCCUSJLvdUC0IzeRcGFY9wUT2CF05c+XG6YgtoUzZrQJn94GI3g4MLeYYU0jzd/W8
XhWRg1cbAdpg3VqIqEuz3X3GJE0SFO81ICPkPelMProgB3GruBL4xvocclRueObvyD6nh+L2sFaJ
gPd1o7YYvCNCj6YWheHFjaxbpgjbazbyjbn4GbiC9eECWAbnXfNHLzCDAotQwLYGByOftILfdhbq
7Xi7Oq9q86akjDVMqIm9o3+JzU0VyqMytE5O/FakdRIGudSBK+VngKJFHuazG0JVNxdykS8EYLX7
IQpAOcMyHK9ycrvvJ7/ZfqCZsb5vxy9MUlL7+RJpAjQG+Hg+DPhQbthTCGrbmXK0a/9uQZiiYaWU
4iGJvDXYyACrK4jZSCqukunfvXe1dgCLxXxpyNdO1799fFdh1bLanzxprFhNPLRI/tpt9UhUL+2P
GVrfpI2hlqVfwW7uZdXeVS5B5nmiB4RCIgMOPzqHKWuoNM/2cjx2aEQj40J3qod7fIRU0tYSEdng
NRrWCL9ziTc8zIOhenUJ4F1TzT3D75ejMwytCiS3LtSiStBhW5aK8jRv3LqHI/N0wWPgrt4+/pQs
MmaPlJ0OsH+Pv9BT0btIQgcV25JmxWXLwwLvNh/Q/vn2J1SEnm5+YV8/1AXzMQG9j8U2CWNK7Odz
42//fDzjfuB/pcXdd0HD8tmdht1dhPRiHP6WEk6HDCoLVIL7bIOibXuhv3O5shKhLF0LyPZW7OxE
iQUa3AsQOW1y5MGYzhKQQc8Qg7UNFHgk6+i+/SrKvgJ5JYtEtqlGq4PJHE/te0GzRBm9Iy0Q4E11
/v3C4+Z2hoLoGAZBxyZON50LXkIkqd75BiQWH3bgiS906akOungnSibBhlutr35B+scfMUhV370l
tXixSCiMZqqhGBN6wiToQ1RPZD7wKeW3h8WmATD/edkgSzSjEiiBtGF+843DfV7VrqlgaSnHYLuf
5OkmJWitBKYkI17vW9aBNEUW6hPPhuIIHLC+m//b7FydUYSbtW6GTgLszoyp2FO/VSX7ytYjs+hS
jBgMdTqj5yUxVkhKoby6vYsxDrQ2TnFmz4maDYVHeR794rPvtys2mAf9qlIiMdbkboUngjoHJRij
v6dUeGzlX7s3oi4Awzqr9tbwST8muiHaKrA+8il2+NyXGosKQtA8Pr6RZz/ypnfP2X7HbLiZwchc
ZwlXukWSRJi2lwXX15hwqlEXspWdsZl2sDpb4m66u9476fpFSAdB6Fj22q9/Mbkj3f0uHGpEsQt/
pFxhBQAIntvzPS3GMcEDod5W31rYEguMV27QzAOOXNPO/AXrXaPCQTD98axsgJ3jVTTAZEkegky+
gSXRby8f3x7kQQOXisY3eXV2KnbkE2efr43G1ufRa1u/vBEEmQuQNg7s1x0e/rOX0enL1q5X4NjI
G/I/4puESUzY5zHCd20JiXW5YltfkYr3QQ/+Rch3cdFrftgnXc5fQqoseQaUX9vrRPpwnuCo8HbI
GWw6zqOMt8u1vohmC3GkG90UP4Hc8ebaCq6tJKAKvwMXZS8wnA+fZxoRTXfXwHUZZ8+QlHx6DSEr
M5OAqKKkePR6SWfVpAK/tZ3whG4wWVjYh+O1eOfqtNPGp98UzI3///lN/C+gKBtj73SnfO2tIYCh
ojwAZtxX1qX1DV9YsV0/mJrn6mLbhZ4WV+EHXPgKLGLTliEHCoF/cyULgG3+ssFHMcS70EMQt7oe
t63nuq45dWKoVwy5tvoIDgEPQk0Q0nzkE+qMRAPAJFY0wBn7XOnX9Gs8scR8wFPTDISi6x3dhzQi
V3Q7Cv8gYa2hmMUGpRRuj2Gl+7lWTIs3SPxx6V1G+I/IygQ0o3NQmrMVA1uD8XmTio1TXrsFwUeZ
GMT+u/oPEy02EYV+0k71EMt0Kw9/kV3ZgzmpDsj+MjydjFcwNNKiGwiFco3dKUr+QUQs1L1WUheH
PG7lOmGkgMjb/qWMngbzOQKomfllAiomk9m5vt1eE0xJMTXTG1RDMRPB2iYckiJI9j+RpRIMJkq6
6xGUln8oMChARWQImNkqoIcE+5bH5YgpMAAvzuvOtyAhEoIGn4nwmCIBc4qwZqQ0VWgmOg8eV1Qv
YZs4EC4BAg0+1gd26+apZOPERbjwvqiYLuJTl0xXnTmRgMRiBVTKwHHn/SYacMme3Z3HB6t0QruY
zqcpdW+mYDfhbpNYU5Ibm96IFRfEc2q2FZJKe0PO6PazAFuVFQo9mkGIlBXN0PzTqWMrqVeY5qlv
ab015b0D7gdO1OO+bQoVwjnenyV1G0ulEMkwgENmRm6rwGlSb+LaiwPLtU4tPEyYqZJTo2LXVszC
lnWMEVO6VgMENrRxz4SPOEvURGvGQ17x889GM+APudV88p4lei8ILaWxLKRJN2HR/yLIz0MSXey8
5TvtXOsRrKI/rJPczczrKbPB+gAd6HmzgaBX0WSdx14o6FJ6se+bTacOV4gPEUK4QN+5LTx89VM/
dbvvuZgaiH1urJr2lFNfxWBZ9cN7PS3uoflPoyv0XAKTQgL2WooUSIJ5uRanngyjnMDc0hBsWx2a
vo0VlMM7JznoHYfB0kzVA0iaWJUITzYTCuXzQoBdyIpDVwo+ny/TkX7KuMtiGGOPlzP3q/aHPt4F
iVuM7NwYCc1lxXBGftgfzouhU8WTgMD8CkryFVCA+g76DL+tKVa6o2kYEowshdQeV4IzhlexUWgU
GOQM+PLElbCehTSMsQ6dLoUsQ7//6cbl6IiNz+e/ldAZFUZrsBT5hq9O8x3OV/1xHa88iR9XL7Di
xXy0XHKNfTrNYVmYcYhK9d4Q4zK6QhU2cDIZ70TmGZJxWu+Q32CBNkFUCjrcUGlUTeHoe2Mrn1Lc
cTt+3/MzYph4Qiv6JRgtVTYCT2PZvzL84nXuuw1XPmalH8XfGJa3Id/71m3NrDwLbt/UxC9DuRbl
vtLr/sxpMJBCBE/DENXB5+D81tQGrc6RB73YGYePWqijZONYdPMNWw0z3NyhCQ9h3ZzZUHVRL55u
0WEDbXz5VaCQ0EfGfBPRhnYEXcyDnR72syEC4Nmz7yorI/BDhhGmDcF4Fd9E3hA26ZLrnK8Avtts
5rHmUQZYlneitKwOJjksZBxaiS6wFwJeQJYQ2q8MB8dTUGTrcj/KA758UJMp9PekN0SIV81RXC2E
d8uomRbUL7eQTKxmKHWfY5Pbck9sTjfkN6trynX22mybHvUAbH1Dd/xv2F//WASWsqJekk5QRLuc
M/DQ6X1XZI2BxreeN4Wwpo47SJT8Qwn5xvlZG1vWk+YVu+MhVx79zY53LYJIlBHhjOwldlwlbMTJ
Xh17/LYyz0IWTGGKxtbw/fTVg5TvwKZ4Olf94yYlt08JN7kR4vTMpc129FBJtSUwNjriaKEzMQXm
CigrmW64B54mA0yjr4Mev1lQAAingYauPz5RP1kQeDvNAYP1qpLOxhx2xxnMzmoMp4TF1txrsFQh
2Hp/7Zl11UPXoViro0zxjNtGDltuKHrrqPSKCrWspqXLSezzUS9WQUSf9Htxlk2vdNJTnc4276a2
OCRHSzOKbXcsmoyWY3ARvIKOXpblMB58A+Ev5bJiVluxSgi/JluKFuSpXPG5WG27B6CCw4jjBxnm
MFRZInVbzp2rLFMdbA5Ry57E/b5jogeqcw1oK8EwL9N3dEMntMLs5NJfpSCZHKQtZmVwtNqzn+xa
MZvYAIHO3iI6Bgr1CpDmP7X/s3tiWOsQCULSQa+4qanFvENDgJ5g7TMPmpRq4fXnNyRReMZxADZZ
LI4odZdl7l2fisw6wHA7I+sk27M4tNnWGUV2jUhKf/CT27GLYQQYufgQn5/8M2Y7zglzC/qEklca
dwoDEqyqyyqEpVtH/oYlYTeQ9PWzvJQEoMjs52DmUOzIWvEtpZfXIot9VUJXBMZIOVqchKcMARAg
inH4aFtsJTqXqv8eO7wSY3CMiHQz2dakZ/Z7AZweB9Hhw2drz6oDc3SVBtRkKR65TIhtCRsoxn3z
5X6gQFLNRISaMo7aUbLg82Kco92ZDTN8wvFWqHYhQS3A/o+95sPd3S3a2IjIpH92yLeNtmGVAwrc
JzZcxDFC9A3GapCv8qDADfMPo08FBpdiFmsCajnRWyZdsjRf25HiltIL/mUGEKLoMG2GmG4VTg60
Ff8VQnOaUyWTM5AdBNSi0zBKkU9pgT5JFYW23JJ8Q982a285oto2A/V3RZU9C/icc43ZewRHKVW6
H69B+jdBhFY8wrTmYhLbzXumiuvjbwKAVQC/OrsWvxakj2pHDhwQrHxSMbe7QfMVqg2E1/GMEwm5
mA32ObQyZAye2x3CETtKROxzwIcvexkOLzer2bWFHkH5PJZtjjCmdB83Q+6ObpbokArzfVUidGm1
e8sOnzM7hRFD8PVVEJaY1B4Gs52+R6cr9eU7vF3i2nV4Nb2meUvqNywTegg6L1S8p+/tSvJU2htR
6KJKAn347wF2J20/tzyTH/3KGFbBKZSkVAYTqAa2DyvZUKXDcKuJQJ/JJ3NcbNThbTVNiLoGkkRE
V7jJRpPjX54Q/o6+b4UPFJS5fb/cXVu3fbvDIz1odQiuJT8K4wL6S5NxBamn3FuBOoyu9FohLvry
XAy/hlif/ItueZHDpVekAHCGBuEc7HiIeHSzNwS8wYXWECGnYXFz83hYaha9MQq8McTJsIi5cEnK
8CwV1Ochd2aq6HG3OZ3z6XPdgTWbTmjjCHpvfaIISzPxb7nbI2Zqspa69xvrQkUMx/MN1tCXvr/C
Qgfj1e0UlOKYtEZ7/8BkOsepjEtic7FQkQPnK5X8v3fvsNnIap4u3gjMlx0j6L1Eu7lBPciXM1+L
Mxh/qTitsw0orLVqYuKM2ALrjcWzoKbyMXI881VZY+9TNdVdbMat6zA4+koQ+Hk09ujxtUAhoiz5
HPAW/xEqqZdGCC6xSwvOBjXl/aPwNizLtAzKzBVWgoGt7ImkQ3rD3xFurqra0IVi645pnou/s2zs
/AhU3V0xZOwrHj/XcygTJXj+KbTxkegWZ4x/AbO3Jmm8Tashb5YE9tCuM1MAmPuS5GaKu0ZUyN/A
XChR19VNWmEhhdeLHsXNakVp4FuCxXsY2W/n5COAr1/+pIMyEkWUGWJbhBGYC4onNYJNQCRm2TdQ
o4aXQA7JCmdVQFtp2OmkLfZYVvfohMtqiAH2QLJm0rYgkSoANiUi6h8bjKcuc8dherhtOfckka65
sIJ5TXAN4caCzY6eRMQ3iubjXzBQMYj4wnox6EBAgfgdQbY3qzr3J79cK4XRLFmaLXYF2KpLcud6
0kWEn7IeWvvDLivzkRfBwbAuKiWEoc/5ZVjs1V6F293auGubGDKsIGsyFviRjLe8FHyqX/Z+JkDy
zxzdXquRKxFXWUtm1YNy8px+fYj2tdoyaLU16zKNxacYBFqYLDTiZQ4xJuMWH1AkHRM3k9h5iIZ3
63vco4WIAi9m1DOTy295k1WzXb7frmAXEZjK/E3/A4OeYLrJaz+wTQ/tBgpIhgeUR/Xv5J5wrwbN
DN6Z2EMnuSLPKZGwbX1HGNvdJG36UL7/4bNjUrE2CY9endzuuEj3q836KNV0vikMkCIRM8UK1ItD
k06ysQ/QA+ShluUKTBXlrZPX1wVg0uhglxNyrVmYtbfaGugP/pgi5Os0rv4tD2LBFIlsy0rkKAP/
4AsGEOkxWMPXop86Ol19gC6JwEvmY4W+yAF17SpgSc53vbl+l00qXfs9bH6q9+WzUX0jCPB4sjTn
nAb9IWMnz11Tw9Ijkc5L+gXZbYd6EJaIJczQXOBEMmKIkorIE6KbXunoOc8QmgbZgvI6pBv2KcwC
O0tZtmVqJES2XL2i2y2sZ7KK+Wb5XrWMp4Wu24i+ul6XW3OFnkSbsZ+DKGY8irieRu6xyWH9K34Y
LihBj2UVe3awjUbWfcUt9O8R8M9UZ6y0UxQxEHnNHJ3L2w5DKqT1SlfPWQRyooUzqu+spZzcxXNm
z0IGpfe+cyjYzMAYXCu1oSIV+fWtuur9GIOKmVV8/1RGfT91dskMLd2b7EdITwc2I/hSv+wtaMCX
CAuHGM7VMtCntduRgnPML6q=