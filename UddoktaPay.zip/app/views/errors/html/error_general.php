<?php //ICB0 74:0 81:1825                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyu4MezJmRwWNStFh3D7xVkTzE56iSfeSh7FwRMfVUGazF5yV7p1S7kyT2a8ek9yKQRJ8EkY
EIKIzKNsz14P0xqYtmP1f9yTKAWqeBXDVGzGr6Ms+tvHHRpwG8fEs7ijCVSTvW15siyHHaLAmfoz
nTVbfOLWW/7oqcHUW8tWLE4JagiMItBrijbdv7hn3N9fiVR3rsOVsLOIc+SIsi24VBCIYfVwrzFa
orhRYrY2qz2gJ3MSG9MfVXdpGcwYt0VupC8/hhXvWI5pfVBIzYl3l/kqjMUKmJVizwrlzGR6Cydy
JhbDEhCq57y+vO2JZCYIPxED9KUXoQc1/bOPIY7jgWGQ48kOkfx/NlDsg+cKLHNhrXoB/9P6V6jk
efcfgfSTeycm4318kr5ZpzYnlBWN6V9N1G+RvHeIzSSCiVvYoPoC2iqBcTiQdwRrnIcdfA9z3fWa
Hbg4Kr6JjU82GS0AtVO9q5+cIY0bQ696jtNggycYx2PWJ0MPwkHkLwC7HTkEb5w7WvpaAtaqr+Sb
51NUJcM2GTCR75bp25IMJgDBjO4tZvKGZerMtLSRoIT8oS7xzGPAlYc4sFarIAF4DCUuGNNvXFua
NHSt+E2+xV7R1JxWHS9rar/SM5yGxvcbP0oblenIJhAcfn44N0FqVn1hXP2meXj4L62a/mGRksbt
Ks8WOF/6VJEfME2+JPfL4E05W4JjimGZ+oaLAalsMTeAPA1f4jKgQ4d8GCurw0nXXSr/QFgx/H4I
Xew7mDcHx7JyIQ03994oLqnSMcCrTrMMETdhPGm4E58E/dlj94Zq7NjEa8vMyF/PxTp+R/3Jd0PM
b7hQ7rFd0jzWVIuzcY3Wlj339wrrMqNKFjWUHxgMlir4zcgrRN/V9o695XKgH1Vp9sYt/cMMtgeE
bqit7BHx40Ybpwizj8A+9noLsXYGeBSQ9LoOQes64Ui1za6BRg+v7AKtMYdMwwZHwoYNEC91Ib1Q
LYA6B9PwAZ7uMQyszjOp77Y9q4RR1i1frhUBLuKZrjTg7NYETY1u8Wc4jX5Yzfk2BT8fwUNbMqvh
bOJjEib+YajmuLUhZj6RbSBx2EQAyvkjts1O9EJvO1t+ItT6/Axf31FBZeLQERX4etnsOsI3vlVH
ph4XL2cT/SpYy01hQ8sg6tfSVwXEijtDDyNXX1KWVG9zZh5TuyUrOhsYqyFz2KbklqhsUtxaZeAZ
WXKMaaA9FeXf3G77+cSjJXOjkQv753qDaRDmV2tJBtnnXFYOoBy2VSWlUU6JLR50w5DqpJgXf6e4
lywB5bVdD8mJyZkQ1dtP5FZ8Qm8cw2zCSQA5usNv4JXf7xreiDVeoSgwmnUMHS674s+jd3wg+By2
d+i1we9UEa3/5wrj49txzbHns419GjfeYgMpLb3VgFPVwn/rsqIRNfjpfSCd69oAarsfaOXmLbLd
PkLngcIPbH5hTIJweHYIe09thmDXO+vko0j1zUVB3hpVLDya4F2Jfk2jq0zm9PgJUr7Q7j9R/aUH
sMH0taosqXoiTzYokeS2BocbylTxDPCw7iCEwa4h6gKGfMHHZgXNHRQgkZbkAQJzT2hHxT0006GH
TatFznLqRDb+r6ojdN2uY4vBRA2JHrVfukZRgtrP+hoDmbIFvgCz5abDTXgf427pPd+rV8AVPq4R
ksvCmlxMnc8nQNHrPi68BNpSQ/AQSJEW3BA5YGosrKb3TWxGB/zGw3Ng3dy2+XCZkKLpM77xDMDu
vxmfTMRqwffLWvO4uRxrNXOiUYEt5gvj0zhd+PywjRNtbc7VkycwZAUL2n7EpLwKYx4vpShO1aj9
sml7JBhb2/JpJtKxOLO0Ng4CecdLoq+oQ0yn9HQ8Ex1w4hudkR2o/++MTzTllHqMEgLD35NPkanP
xznWcFicjpD+xlCERRjkRL9a5xOkXcjitgkblLPHrWLhc065mLi8XL5PXb08AqvlPlqKyhihV7MW
6xOpELhhK/jYfDv3bdMkfOiN8der8uycN42PBXRuGUXfb7MP8/1rhC8nOVG564qF0nnUtMlDeqaV
7lJPzz2QkkXk87wSa/WhZGdEbY9Tp5IjHnAT5ElkZrD7X4XdZJETuU/KZXLutdQaeCHgcGAh0IMz
rja3NkgGzZq4jUsC+DDBLUJGXEBf+0FUaAq/YVC46XsVDUc1v1KnCx8JHMb7ygHpwu1iA+GIefRV
Cs7xzpxEKkB/FROLIYrcZlnC3ljz26/p2zglMstQKMVgZWghM4U407tEKTwTcARVIKAtHRrsBZxi
3l+6A5va1VvG0TidOzwC+QSHQnmYVREX4ZYp7vbFyG3qP6c7XTO3DUALL6mw4/1fpPe22inBqLMq
BgaIN5+SkPqweM1yP8Mphx6CEauiqkUrddErj3UHY3cLTEX4qb2ObqQsZ5HDd25mPk+jI6VM371G
dXBOcCgPG0AM2k3Q6Bk8pK7LCQSxbM9dok1aPe2jBCo2iMWb5BQ8nct/UY7caw+K4G+i2x9dgfs2
9rQvZIhtmz7YQnJR3zCwSSjlLckKr59KaZHLUvH8IKRuOUBQKxJkRjx1OexrK8/aqNMvn5lV1JNP
eKI+Wo5WO5KQLTTxb6jnffX//m2A1v249J9ya8suYqEOY3PzQCK+C5Lus7NkxCfGeDZuzQ+6+mD8
EKKbsmd00/YENszlcFSd1u0/xUXbA+qbDsanElfzP0vvV+wH0iDJ3t6qZfhPt4uTkBZjLStPHflW
6rCl1hIyXUff/w/3pn2UC14BKmz9KhOu+AiDSk5Kh+GS+v3x93+eK2SVla52xEt477n4Shsiiwwh
o5X57rW48ggkRjzzgkS7OxwTuaF70zl0FJ9qRR+LjSsbwWdyVkF9LqOBMWIsnRBr70===
HR+cPqWVgBmmvn2pkgizdyyhjkMnS7LDDnKQoUz+W3ELPxABabyrjKNbW0jggZ5kIfoDVBjKHeUl
nErjr5vT9OHJAtgFXGwKUXBRUwj/AS990afPXHf6gbMcQcjyTPiDP43lUSsTycuI8zESJ/8KD3Lp
nlp7I4GciA+lFVzyTqTDk/hbh5luJuaTvkoE9ThtrNE9iN6b3gyacrb8oqYrgVqq51uMQdJKITTg
bEJXuncjMLbeWVRhh+cefWrYKZlTvM6dQRBTeQIjv+jmKqzrCogd3LR6OytcGQS1NzE1t1CidgfM
jbkz1tDEO8boCTyHTfjw9stbBlOLk9X2sttr7FyPfcpHln+zmzFg1BfgkeKTZJgDTL+hoo439TFJ
e3tTzsM6xh7lVA/W0eZQ21xeOZS77c0nyYhqwUr5FWExJ9vWCN+hD1sa6H51hWMry+k5WJ5IJ2lp
kyIvqrZ7l7qa1BxhaLYb+3MdhXar3cCvkR769NUfoVf2VY5s9sfdkgRC+ITDgMpTXbxwAsiT7o8q
78eflj4UwEoE/psAzDNh0noR7PBgv4i1aS/UMexUMl3CYEZBNV1VlVtEgKU04B0PVvPfriDB3C6U
Z7z+zAcPfr5fbObW7UKhh0GQR0VOjNDWrdi8X7U4L+cNM7/9shajTrss/8E+1CreOeyoXcGoqRmb
WjAhRABgZ12HheyIUWErgFPosZaBgDZWO+D0lE7HkJ5Rmg2icZZ11yar1Wg63kFL/VMSGxqWNCOF
HDgub01877FgLT1WQumXCidTyiQPafAqxWaYwF33koo/lz2Oc80OwGF2deWElHH+x4itT209SWxR
xiu3mVUCoGEjKkq9EC1E3VA55azyeZwl+70wehHbTE93cqPo1U2o5RhTbt4bMxKkcf+woNK1xIEg
K5hIPPVAIHrGUEzzeCxyc0VAq3Xd6BegoyCGctliWfJZ3FlAxJ+e3iEKi44JWmgQvK+Mm+fRtivs
3Rl7sSjxk7U9VCtgQK7EzDe8lr8MDvscdcIme7lk2q7/Lis4+FzNMMxH+RHx/GPSsl23gihxKdm2
RXELsalrImDetgePrNHFmDtPUliBQDcNGVLwel69kyeRvYqqUzBJqNfC2f2iLnEFaJOBzSbOgHk+
hhYLmyL2MJIliih9UfK2WrwrSibTpIRLEleGnKswGnBmN1mWFIZ0+K9y79nxAKTmLPNtOiz9PD/d
2fQhZhG1sUc7FRff6UZ/gfFg6a4lud0TULM6CrwRi0oGudv0RzqBg8/VZ8vb/hizkiLU9VuFeEB6
Px55pvczq/IjOpHNfM16uX8G8VTDYXRgeeft3cFN9JGYbztHqRvlHdBjjzARDfcnNyQSuncmlZES
BZ0zDl7IP8FxaovPNyPIY2NsNQV5QwAJqZKCT8tzR6VO3NM6leX4jm53sPDxTaPuna8PRQPmbLkc
lpk5H60/lLO/m7iQiJ8IUnDPSK+oOJS5Et5TZn08rlarjNjbVRJzTucSMQgdvCHDtmf+MxJTnf20
ocW8ZA+HhLwXdgO1fl3UTF7CxndRWNr/tPzdb7XOArB65J+srkwmR8innMWDrhCa32Yx/EbeXHdF
KAthjS9u6sqGR+w16lBJoO/7EjfybYcxSsFvQFffPYmgANKgdrvmNjSLP0c0/kyEJAWAJtduTcc8
m6K/X81/PQKGJrRsTcnmU+y/bg093HnrJamLL1uRlMY7nkiuiiZSUw1cm3AKRttirbF5aQdE645s
NnsKc6YbjGfZDYWozz30I9r1LLc3mkI4pgVfyQ0lFUNS7zl2FN24EiLLnK6HDQJraqilqz3hqmGr
RNJgiOJmqnUSDaMi8RMTDf4qdH4TMvSAeYu3HCYBiCW6mycxDUSn0zQ279rAJJjm3rPYYsQiR9AV
3ev6nUuhO/YjzO/hS9IE3xoWaIHZR4O9MGrNqkNRNQf7ScrE95zYOyHbJs+Om4iV5yizatUXfjsr
PBixS1bIDjonDNdyZlvA9cU276vBg8j5TYnoC5EKO7dri/GVQ9TKn1xuCaZJY8fumVmpvl7fSjAW
lbmOvHy56pDF9cX/oJjByDkiZdZ15xejj7vPgsSQMLQ7x+KjmTj+AEgiB4Fi92nfQWTQy8VEOjLe
8T/O32NxKGaaiy8v3SBm1IipWj+f6zCJ2hBBhzqU66bwcuWGdrQw4Bienp7lDgmxGUadsAriZOUH
hEqvreIKKfGDl1q6QkooL2tGTfv4ILj5IgcOPZ3+7aakTvXT0S/sEosSWyRAdAmvV3kPEm2FXT5N
WNxCNdXUKX+BvJJ5w8TGkGtvMjoQsdbGkhbnPkoOv5FHznhIh0tLIK0cOG5//VSI44EQOwxRcNm8
fXTPobVKdcOEOqyjHRPvDIsAXiUatPXhfP1UOG6TWJCt4PMK1tSaJ3GWHUG1bQOIQUjcSOWY19AG
IJP5YcVGKQs2bKQOZKRrt/MGUsfqbVjrRguhHrtU/g3oQU5u23fe/e5umRFs55i9K5gvBfnwc/Mr
mU5aY/oO9f3NQi1w8f3w4C2d/wRzbTOC/sXyKf61iLOQbikpSSbmDeDMVRTuEI1PSIVILu36np89
8iwQCpsKDqvluwj4/GTTJN5iaGD4NW5Wyl4MpfYlk1KEnr/ZJC21GtzTf5M/0wuMueeqQcD0xpEA
UOaNAUkFtCgvVQ7GXkE6c3ROZytLZVhhRygsvedBbeJjUEWBfRT6GJO5UMyAEQ6wUnTLM8LHPP2D
jb2/oukQWW==