<?php //ICB0 74:0 81:1f9e                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP/65p8hmNpMj+aDPgLs4/nlNnRiIiWuB2D9C3aCmfshuQbvKwcH5j2FVKFW1M1gonWlRjGLV
ADjdY2Im1k0t7ZYa/7sP8SaR+3xd1YfmorkQbVa6ZG7JMIkKJufQoiLxpKRG5APS3wQ2n5nY0NQN
vtyND6iYBLi2qt4sc2JvkLTGkwah0sKF+p7ONBaLx6Two6zMQkMgyrN20vyvd0Wo/sRidzDXuxoo
SLwZvNNEI12J+/0Kg/NloPXV7SdxtabU7QYTu579XtMmWZOCTtOPC2/pxPWHEcA+U8r3NzSmFLVC
0fKAipAE7hEwn0fosEuqotzv1RewOD7/V/ut/w1OaF+9l2fHzBUqVXUkx7cYPE6IGDdiHGrhp0Z/
oGl/CS6LhJXkw8gqZC2edJYg7FdzPTRcgoqLVqyj4nRsl2ZZb9LWoqhCYYQC3vv8ZIPCnCKhBpLC
EtKbnvBxtV789VXhbs6QuVqUMJd/KUVWIX1Js5jqHgd6aA3hpXc/41AOCn9I5p/hmBtJ6INhodvL
0KTYn2Ac+CQqX6LLhLwc+pYbuh0GEXP/za0Z8pONGmT4ecz6mLiMFRRJvCX8HQs/+wwkulOgcPVy
AxXWpTACoaT0zLwNj8DTnW50pdWveDNCq66c9eoehVSe46NGal0IINxbzC8q2vuIOknJlvKSV1t/
PwjmZhhp4cAOAtQfRXTx4jK+8IaOGAa5L+d9yHmYrWNjtNfD1zFH7Vv7DTRIuCHiIZyPWrb3eaS9
sbHuO5M4k+qvmwDCbGAcnEfUKIYl0+y5gBDdKEVdDFUv4uqTZAp5c1xTh6R20YBOIQp1qQcF5XOq
xCU5CU5zT7TW7UoOYGBCkJ59S5yrZgs5bmpe24/3iyhpuQMRaClKkrBwaeWnrfxsZ+UfNs8GQFvX
+xl7CXgKPYP7jUIwz8yKCjfqw2WocrOgaYA/eurfG45y4CQHfTYYQHeHPPhipTrlFR2bs62nZoz7
HG7SRPObYpdqxeWdUYzbpK3RiAcjth2hjP7IS//46E2KBpUVS0vck+U4pAXTyq4bHx/P/sjC1OY+
JYtzK691+pztX/U23cZllqs95bMqgP7f5F/LMAGmj+8dmPVPnRHMn+2tCYS8c4hT3IA/j1+CsI4j
Qb0IN0yes89JeCjbO8+Eu0Q0wltTIf9qSWy5+ddLm7z0Id2uZLLhfhLShNnn9ykfdGRX7jtJHiLv
v6eqfu4PWJbQS05Fh9ljJx9S4hk1T2q3hdcpXNm6WOAQ4AMCaRRJ4ATFhjXsEXkhjLWBQE8MxywF
Wi/Q7TqGMIwWXH+QtRsKz5BrDD5xXDDXel9TeIyzmhmiv9oZfdAVBD22LeLQ2K7+9WXZpoBv4OuV
Ned2hA26wue4bUkcEbpaK2M9jTTrYCQ+l4cu+nzGIzf7b+AZZMEqQqIDVZjd59PJyOPdOd9R9cNb
XjVeRCFeLqtqYuh3uTFSbVC+9e5VEoobZY6vsCEzTslVvAW7rNwVL5QWIqNmPxl6KZD6QQ/5dJkJ
tRacMdWw4OsBj4oa6v/6n417haidQddIgwv2b19s44edauMtsw89G9TVXhLBuSonWXxkfan1PWTK
eoiHPvA00/HwCmDpk5wIGlu1pERzOoG5mEGzANKMPp/YAT8w8PkEaCA5LhiTIsVyfbhWHu3Os0qR
LIXEXoMggC7TCsye+ODiv0Csulv6xmUw9EdlGMuj7muGkSiKr4t4vaNliKWL/aNKnex6DmRXHq8M
/qANz3NaoG41HSGzyi0MJK3xoc/zvKwz4X/+UmzqYyoL2N/7WUWju1nvVEjUhSqc/dFM/Bukgewv
g/4ZX4peeLeupR2EOGjw6C7dduVqLsqIvFOXLIsjfYcRfnsCLEYD+0ZhoQ+YmixYQLG6RisIdhty
hs2Zf7xPmbOGFgMQ/XCk7GzVxdxaxR+gjKmLJUP3RpgXNzZv0WcBh67tM2b2jRFl3d+1TGXhxxxn
zh37M2NA5Ba0Z/pWaiwUyZuws+t0PyASQ0yupI4RhOJ30RH6AuKSOZY7dkiWJfUiwNjxlzMLS8ra
HqVdTrbGbKOm0ePx02+Vq8UrPryGkenzJk6ay7zM9lIuFzs4zfKzdwwuWtXMgwAv/r1EujJ/OY81
DmN8s83U9C/kiIHwCEE7HO4YM27eFPImFHlywWnjFs7cA2ndKCPLNhVy/XuCgq3EQdYK+oXM0H2Z
DASkUAn/iDnlqUYQT/jYwRse9+fa09vmxTxXABLtxSioxVHdlcW7hHD+N2hAB/0TMc9ji5xlvPhC
WKoNeIp7dfyDaVWDW4/RpdnrpTz4ZvQJLQBshsb5Px47O/UPQ1rG2BD5gH1qcfC2QdSvMOVuOj4N
blh2P6620wwla5ukh6Tj3LNniUQWJJ8Pkez/YgpnnGVg8oNCzhoK/cKvwVXx/xqSZI5ahdpEX30I
FSQCh1caOAbf0T5M/xcX6zslEoQ9ML47SlGKM14uonKroj2YIO61BTcoUzgGDm16/vY0AzbO25K4
Z2FFUFy5izzyhwFRCO1LZUlzy16IAZ6KReeivuAXuK/0iqvn9sh1lHyhbNITqJTZpyu807oiiW1Y
no2INZYyyGLpNwM3lpCz+K3VLJw8n+2T2/AT+8kjISqanVCeG6BKOOXW9E7P0bQcfsIMtWuMLpcy
gdy0pkCIoXSaZpAYu66tpPr+bGj6v7idVt/xyyWWvvTmlWIJpXC0MEWFZdqj8C8cQZVxnRq+xvRG
nRMYtqiw0upCqRtLgPtKhKTDz4N4uG6N3IVVc4OuQbiE9PjHingGC6CUrzUK8iTxR3foCO74+p81
mxaWQD5APaKdcQvtpatvNd2/GUML79d94QiNzNvQD8rfAWlPIcI7qGcnXH/77MJZFnUtvEFwjCAr
Jqq1erFzKBN9DzMUy9OZfcYmJx2Wppq+KsEHzKs/DFqI+6OfnQj4A66evhLGpNjci99QhAwgzuxQ
HF7pPBd1KLVArkFNRpNDmkjugCraWtcrZVyoAAuFiG0FSbfNs/QKu/GHtFItHsonYhXZvBsPcpql
AG9iFnzdb7GtCNBfsysWPqDe1tfflhZW7Wx68zUGay5CZBjH4nUnDymX76gyp7PT9unPyjXtb2XB
CBiVplgSZGBiy5AvQxXUAgy/gK0H89gMIWS1m4hxhX7Tlsjc2ynUoqdJsx/xcrx8WPUJ/lsfquT8
tIPJDi6zpoOEhJZNTBPCs9IKsKqfDYWsle/cN4L9xh3qO/cT3rE+8myNsYHtWmvw92RQV4Vl8gHC
V9PoHWR/kz8wujWOxBGxM/DgAOVvPNB9Q26eMc3kG2NWrkasrEJJr18eHudaPGM5m8MPCpyBtATQ
6PcLogEwpnarJN4OjlTHZaY9grlkWaAIXd/MRbGPuSU3ODZw1B67SY/PY5EN+al9qSzXack1WY3/
djShmUe7BdfnlD3X4wWtrg/C4JDNt8L1VKW3v/J8ykvJj3X5Waaqy2pUfZ9Y9i1REogIBR31TXDC
nZsuzsyWXrHo3gRBAWliNaOIveCfhrqph6DAgkXpvbvHfAP1kB5L6Mk142QW6JiHleSnaQ2PfBK5
9k/F+NadQpfM68HNEX3UjIX+xliO7JTiK4U5tuSS92qIoF2jWKGBWJVLtyHBHyJPq3B1pp6EVmKl
4ZNL0ry14eqZC8jJ45sUhfLfU/QgGLdMGk1fL55ZuAysxYndsrMGlLYlc2ZigxGq8H3azTwjYoH5
WpflofowEGtQvuZa9b2/ID3A5Cam83/iOKh5ieA3tKQ905Ir0UgipYXDa4rArdEmnBpfQMaFiWiJ
m1g9H+WI+2RgVzuLE2B52nIAdej02EkOvv9lRvCJ1m2RuBr6rlZWHz3KcvuPiE0zfphgRRi8LkET
vLTVjWxNAoEDGoL2hZLJI5fcpnrxZ+wPzsoM6Oi2PHM0BfSzlfJEpK2twIKNyQ+0/05Z6lhaC1PY
8Lk1+2HDiPQZm182Q/qu0HrClf5RsRcYfP1tScNx9f428OMPidcf2VOfSWDhf5hlJMK+0CcY+DAb
NDizoTGWlw8UVBJywNW4WC1JCwwIn4903C2gOUsWm7SMI5JE5Anc6WKSCTYXhHMYlUEEvGWw1yyc
pk2U8qHl53tnHZcGdRjLbqcWgEdJuA7ZFiZE+wK2OFz+7Zcr9/Jpl7lnSWB2qHaNVBuwEWVkyYAc
zth7eAJcol8BzDwMIUdal+AmaxeZvr4wWRJBPMwOzAB0+9bamKX8JR7HUBXk3pfns2b7SWxa1T8k
Ecbi6PnzMmdr/9UXI2od7xtSrfDWUdw0jLqVYc9AO+719OAJ20sbwrq6MPBPG/k8YRZKK1gGeQZ5
BIdQ9C7WOlKexlDV8RIeRX331DFv18wnIDycrrNpuKKcf7JKvFPFZAnlPpDeLO2b1dK/tzl6zIfM
FrlTrVbBcf8VolLoseUGW2PMROUdK5eAtO2U8VI/845GyqxLjYtIxpVrdWWluI3yAY8pJX+3yX3A
ylzkog4l3NC/xgQISkvW00Q1RxGTAli7b0lEhCmvGUX0NGUVHeJ1ZwWtkd+vHF2kiq0Cf3/RIh/a
40xj7ekTxDoNw3t4cd7zrtanfGZLBy4IzZLSUEP9TGX4flgfPcJNdDGH7nSIgPhOzDAcKVU1+NKR
xv7wxWLE8Z+Vzc5KOu7f/if4r4YMjlA1QXIvuA06PCeu3K3GvTnY1/Sx577jTfhczTu/EminAidR
Y9jYi3VXpjQBJ74Ia2tcozI/BYOMrNG5QLzNcZY4BoCNv8QrEv0AE0===
HR+cPxIkAb+vSw+GCnw/V5xRun5JjC5ogXq+kVSihOB0G5QIskiOAIB+upJ3/HULsZ1FHTeor/nG
FHiYrgxbDqUFVbB+HQHi01pBKjYwTdj7P7I04ByQRd00vHfmg17IajWsMJJYAorVeeG6DEFs8iO/
Pmk2juncJYciPRucSKI1XAYUm+r9L8CtzCaXswrVl4nf/aBW06kAfcdWXdc1Jmy9yFvXt5/8Lc4q
j4tgdBIMy94DAxXii4Io9N2zJmUu58VxQyIIyEh5oVkJZbYz67NO8qUCD3+7iL9m2goFMrOwuTwi
9pHGmnf7lqfB0c8PSrrp7GJG9m5JksgAMtxrESZzYOlozesJ8TnvNjDsdUpm0OPsJcMVBKTclCpY
DnBOOWBiX+qzd9u3k2OzHoPz+ZrAnuxq20wU3wCfdDxM9KwaHHLYM4n5Bg2dvWDougHkWr/TcjYw
U6NBI4xQkD/XYi8wU28VSsakaZcE8BBTi+lPuY9t3BzgsM1dFuMO7EaHzT7Fmix4Xk3HdMXwqFIh
3GlXkJyFE7ajEaketrSOrWKU31u0nc5cl2Tac4730utDaZYoRD6clkuntfNz4vz1Fs0POd3LWEmA
IPaM8pR6UuPORX/W+Q1z7I4WqeW4jHqwiOgWdOzta9Vbts6mF+JKLSqRJuqqtTEjALb3tPgL+wGC
7qyp/nu4h2mPNSiAaypNykItoahzlkp2zgu5766MLv+UtQXCJ730Nl4xjH704XIViY3phbosoj0M
gbY6N5z0oZyTNaRgUw5jOF7pW6O2YjrgTyO76vVtSvQVIEBug/sK4KRKv4wzcyfAwlXLi0A24YpE
of7AVCKzM/qd0m7uRT/xaiPj6rulUEpJWbK5sZ0oPgE6J7DFTo4R6yUygOQCtQNqawCktldrljqi
FzsgYHzn1ora87vTX8PywG6dLjodtBHp1CfW/NDrU8Fa41wdV50dk2D77ze4xWVZvqT/A/F9PEjk
Ayapzg7q34NWkkX5QwpPw0toARh5jmoogPhO4HcQ0KYLkqZtkLkF/VkkTG4oId6vIGY3IK/3cnAD
J2g64EKSV6KlTpH0YPc3g5qNAm/fdyU3/6pF0cL4uAvIiRf7MU/P7helzTcOyX79bPMb+Ztgn6lM
r52RLQ277R02N5g5X01lRqiD8gErZ5qPEGyLtjCrQbaBSo1d6hLHDXfq7/QOlLZLDL5ukhzEpUdc
uoeLCFbFO7bdiBg8nYPfRAjiWlE2pBVCP40rkLaYAfSzjjeHfxxQugO4H6fGS7nwB7tLsW1WODeo
AVZ3A9dAiPshpLLKwtXQI2Zybup0HrTyWwrh8gEKgHthldOsK2/Qyxg+Dgaginus1zY9ujEvfuy+
TY/LV0KnHqFiDtAFvjpySKaHBxhBRnMU07DQuNLZ+/kP8/F1AxOM0PtGDih+NGF07mT0rA35VixJ
RWaehFoqK6mc3O6l4fA1i/iPXyiHko0jGxPgaYlEOoyPbWoUcCGNkG8MgL294B17EOoX5R+bSUFn
jXMV/o4PFzpZMuzECKdvZN6lnETz1K9/U7Ss8RQb+fyjQJQ2+gXW0fxUrwcH8jd4a/T+mSrDEZX4
AGzUxsEu19KAPxmDbjvcHlL2RvUOHNb8uRd1vmkMbUUxGWjf/MKoitSQXknozPmWFOhq3wKRXecv
Ed6s/2zNhIZjxK/LCJ9tPQ4JT9itRzEYKg6LSYhH7ZqzjAKzTxO73SYLDGo6WwIR6Nde3OA7W4/n
FlHdlALpjypAlX/tpU0R4xYp8c5IKdASGDIOT18SfFs89tHnT5eBMquxS8boRH4aoEeXBujpYleg
6F8kFjf18SOV4xFZGlJXebZ9HXSzlOpil5O+EAezu5kdkriXIClkzds0XPYdsoQNvchA/gkzEaxd
Uvl6VThVeKGKw2LM5itWiAVAh29UrHxLbgZQiQ0uGY7VWfW+2aIEnqLQKR0ILXSqk8CzkRfQXthX
Qv9kQNjRXLxFB8d+wgCakRj9uXVYB1HcPBD+UKC9tQQxN3FYel/GI7kqE6YfBxn0T2xq5svmB9KC
3UMwFnm41S4Mj+5Oc68xMhtXYqb2hgTOdzrmbvfAfSnqRPgXcldxKfFwBtOk/Yw81vD9gRWYLcfb
JnE3Od/l9ESAvuOjaCT39dI2DHZ32u+mJ7d4xGrtCJc1EFG04HFEEBAa8hyhCduaqb4pwXCFizwx
LqXJNmwHB0sfWnYDNUjnE6Gb5HQhjd3njgJ1hoNvXr6GgHhGgxRHvKLML8B2ScCUmtk30T62p+l3
IQNAEfXZyn/TuEw3S2/25x8IcHkgDvB+cfUGjODtUXr4acU+lGb+5vnYOr6D+VrBV2PLbThyy/aI
P2/n4C0ZgHRF/UkfMb2SYN7Z9AD3j8+V9GoIoeHWWa3DctknGVJxWkiCYNjkQ0REbd2bzXY8Nshu
+6mKgHpg67iUmHHtGv9YkWkxn9sSK2cR8/GuztnP/9M7AsGbynVmyW9eWDtD9GKjIU7uUQOI8ZzF
ZIN+ivvv8JrYVgmxGo90CthWhqFMAqNqLeQWZQdWhusWt2oEWZSSJBnO/kyB9hS37SfBijs9kK2p
oatw4uCkCxBQh0IM0TANc0R+ZE5DeSUBFntRfZbyUfeojl8Z5iK8thF8zK3tJ/K1HlyOiBYfFsr/
qayh2hkG2v8vRYdUWgjx0wYWmcQJ8Y7M3oxxa8fjOfqEk6MfmqA36Ij3SmDaQSd8JdbKBGgxLnl/
8kghx/UO3IjfHzUkgC3pvpiScO4IWcj/lo8kqN/8x6Bt+EaDCXt1C8KizQvzeoe0zgItTkKlMSgk
UYRmm1ivboP9y+o08TzrTmyWuouK2jz589ANZzWELfkjclm7kr/GPSlU89vtIFEprWMieiWSJzo8
ry5gCAEHJvYrYtszzwRjS9N9rbPne1eRv+FlhZX9tYEcc4tuN6AIRoOkIe4tmVvsRYD+bGfQbOWk
ly6tgARitaGi/lDQcMad38lVo7fUdvrCnLf68YkVnuQcFKrcsFvDcS+r6uosu9HQRe8mSHNR3pD1
QVp8IEA0w69lXN5Uu/m48m2bUNaQTTOq/tkYMGilIvzMAzAHMXt45UD4SO8wW9Fx/KVfAdD2kI09
rKTF69q29gXPW31C7zGbGl0m+SoUZcm107Lfy2nzv+IJBC8ROCtE8Bw4FLUCyX7LCkgLBEJooj6Q
sFuwq+NXZxb16koZOmQbmPlSPA8DQRZnAFJbiBEV3t5qtoSz/c4MyQNrjEuW+Nr06bb55zWx4C10
MqoJahqY7epE+C3E9N5dyuG8TowTfoiZJv8fpzqwN+1OJH/mbcTAE7AI79JGjp1AS/cQU93tWzWa
JUrXhKZH66w+JADcHx0k63Ypp2tLrMWXi1gy+fCASnMzt9lOpJUrd8YZMHsaPi8d96cUHvpjvHoq
oKmloI9iO1Qq7YDuV/jXjk2RJZI+Z8KP4W7rywUw8oMmFJVQxKgP8RvJfFikhqK9kl2bvjcw4pkB
mUsNfKEuLZZqAGcNetfsgnX9AtosqUUDPLq/9wDUj41qdT5XJ3slxiyZby1DlQ38DzGA7fWzxbvr
mznSVOYr5WalxTBecS5oEi379AWfTfpedFdBFkHAIJVbVGPotLwHWOz5Z+PJIUFejsd8ye07e861
TZykSIyJwMVoMwXypCgLIfcnCTYoc6TDXoO98UE1C03rH8eeG5yHLZXkKdJx1Spfuf/6Voh2akw1
rTpu1esxVQmFomqKIL3fXRc7R7KSlWkHJbhIPOkrPatVeVWetOAVX6CWi2Q6OAQ5Ye/qr6lREqfR
+Z9ZJpAGBvaks32qOUzikL1BbcdxHUUm3TjRlld/ogAlqWeS3ECbBcRGVpZ1x9107wbONHDqN7s2
XnpgMsXHgaOCptGSDkW6DYWuBoJxTR3tdN+H/fnylxsLOl7dBH6asA+Gp4M0IITfsU4WIvOR+RFN
ABEPy5KE2kRHlBX4uQJFxpUczaVaMd+TcBuT11egoIV2o8EbKg3okbf/dy25lJisgQiwzfZRROkV
L6HesgD48x5XthajGKQU/zAuWHl5lhRSvk6DGn2hbXGDGdFjTb5nc1JMM1QBUoyG3iSXHtjm+rkr
zvi4e2hsTnF/iQdP/nEI+33QgGtynjiSexFBZCkFxaSkm2gT7z4A6U7eYwVCeUARAmK=