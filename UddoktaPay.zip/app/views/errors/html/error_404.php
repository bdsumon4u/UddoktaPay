<?php //ICB0 74:0 81:1852                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPy0MKRzSiwcmRj/4d5Uh9tYW2ewbxbGADUU/uhqlgfipvM2Gc75Y3CidBVjtRDD4oeHSiGfq
PfnCyj23aJ1uTg//aLm6Th1QA5FI5wdQ9K08gv5sJWEeinpTcx96wN0tbH/4oAANICIANcHaAZyt
G9iNrnYa52notyGFZCqqRFnGetCLohlmoO7W424tEgIwAiySI6DFRIFgisYQl3hZQK95KX5h9ZV1
aA/JYaYv69abVF8k/eUfUWE1lCCiYf39fVWC55ncNHx9f6vFYuXtVIz0hmWMXgKU6vMN3qP/qUL+
QRspqhZ5uvlF3Mjn+fgJtkOB5DmGWP7zVlusGDWt+GqthMJDNjHtJ+mn2B4vE25GTBMpZwfxC5Wl
H/aE6WXLXXA/KOcB3oIwhzt7VHmNhkV3hS1jn+tWyBlBr2wM09W0bm2S08q0XW0R0to5BPi0c023
00QNExy1cboKQvk6dhHjOgYB1efEzDXxy/JvxTlQ2j8CsyHykugoToEiXQlAAltBMugPOY/RhM7o
kG2AYueLtyk4byuXeQv6QTlk8bIGp7QBbMpoLUIIotWDbGhNKaExfgH7YSx+zz7CK1mEEEckm0g8
dAmvJrekeOLK8fIcI1heUos4wxoJs9clRku0+uTOJsafdKnCRSsil8Q7RXl2PypYPrpocF8aU8up
+1unwk7p0ovxYLEInJGl/pV4OjTS6/IV1eIEKE++i0mLn7lN/v/CZ/F2XX9YRUF/oOwatzWSeybw
n+HxPNvcamTEzm5MgRpEE0TogrHE6PedP6zclrDfcWUEIUcJd9MAZMKGTbLrgtoJZkpa8dlzniq2
ShL1UvsUNVlDARNzt96X/RtJ2F2E1gIoIpHxyu/saD/mORRMtJu8i5DeNMy9b7+xJduAr+GVRRSL
XI0HvqOYADxwRfOOsgOJmkPzXg4ASl0Niwi+oFRytoomTkAszbNR49xQEkacEh25cpMLy0C62PzG
e2nYoOr2SMChwA/uB7vjATOjMpDtjzqXL0IkpSNcnFUg29ULem3LwwCJFZwyuxus5QkuqjcOM3fG
/rR54pLcaVtxn7afLW0rukVD7CzFBkOtSp+q4JaXJhShjY6iN6bH4l/tRhAmJyBjr3FdKfpN2LqO
m4S0TX6trdSdMgIEKmBGGQ4AZ5TtCjKfVfMV63BqCowWxIYwmJCJBsvqaK664gFNRDeLnHyJ3kOl
cTci8T5f7gQHhz92ER9qjCIyIfhxfv7uGRGXkaipMxNJVnItzfmVMT8BqrBm2xnFyB5RkcawD3Fz
9TXQGmMUJ3e301QycgT97qV5PW3BuscZvQyXu/kMWXKit+OXh+k6mv9J5qyZMXs9Q6SUcz37xAuu
nv6avQN/ASVXtpLJxLOowVN5evWV1Fid4myRZRMbqnlAOKG50XLjvFAJSqplDoWdITtJ78ODEoH3
Ex1QQZllDqXC9dbmNByGWVQ359Xx955hT9eG3SvEv30P0Rn8Wx3XxALyTmTlileMqNUx9+eHSUbh
GSEyYSKIpiRLY4DLCMKdMOzlaEDxwsS6/sMc+R+t4K2fQc6ok+hHK7GLuGziDMwL7HNLj1DpAiet
2CglhECGFU+2YOE3001FQRkLIZP5Kv4+efigvbCAOTJf4tvYwxvfLYrSi0ykMgtxQrHjK6XCi9fi
uGfoYPvtMRMRZhvCZwfc5prVGcPKbsUAd4CqJk/CWat/XZckOWe45tNxRqQG0mDz0mJWnGDz8QK8
/zLgwBLxhIE7+yuzrtnm8WmvDGtd4+DMxwrQaJ6NjFgRLJGhY+WYMw2mzojGStEe/v+YGwa0n04a
X2GU+VTD4Cew/YqCEmRIf1pa5TN6Lh0sjoN0sHRoEqU11CsShp1gElrPWH+cRQN+Z7zOtwHY+dbx
D57qWIiVQZPyMvpg5O4Jx/UAOGWwNJL+mgBKxM6WQTL09b3ahvPgkteiPNPeNVlD4EDZOlhsyIcD
i+LSQ3OctWEHGNE4EpMnKdMkh+SdpsKQWJuCVuGe4SjhygaXon/Ot4r6yRLuqAXWhxsSyvQqmEsl
O2YsQzbLe4TyKaoLIC9Jhd+WH/LKGlStgCeBjM7/p7E8T+jZvsaL6myrB1TP04JguGxrqih0Ecva
yIWvPcdeytMFZdVt66PBhJzScizH67Vat+5DCruxOzwM/j11dwE35mMCgi7izrwnlFpSwSGtWphM
No/esjIxB85sy1Wk6gCwtEQcN8FspVaLE9OjtJtEgcBZU80uKOi5w1gN0Z81epiPnVaOmuO6Fo+W
rmzKelGYO0RZp3azmUCtbIrvz+XRMuf/6gcgtJygQrGR6vVo6+TVyNCts/sAytGASwxqpB71kpS9
APxOR6BggudV+hzizci2EcjfdmiOemIGXyZCKHSK/RjyHqw4H7v66pcK1Y5nW69C459WIrrbcqvq
OuZfJZltRc4WjFF72nFeyI2eii6bg1NVrRInDr6VjtAZ/MfUp00SyPAW9dR0hZ/Tz4JLDUlkqbvW
6IUjfXYUAASTi84C4WYRRM68IxgyC4tHqImuP0g6yiksnmWTkZDh8KHwv8jF6Fw/y4j94OrSTVFy
VmL9U4V+1n77pmI9yKB2ctWnbAJvFMeSWrX/NSkFvn3lUcLqMV1t7ahfk6tb7he2Fi1UXsMq7J5g
uQphD0pP7JuHLGWIpJ3g4IQduOyNYDcg7sDi0goheRmjIWbPv7xM/w6ZHxZKArndtMhnhjzhQHTy
ZGPKx+ePWv+yHXYI508uvXrlOJ2j23APtFus90h7m2keIHD+HAkjLj27FGaQI69GOE+tIb/aKZf1
KEgUgr72QBepv1qA59HWU8aCewq1uCy0+j03oNFpZ4lN1xFBsjVgfkLA8leX4aRkdWv56ypfteiD
mGHoNHbWsRbJ9FTbi3fbAHnBJVo3qgsak5uw=
HR+cPodUUXBM95ycs6hlCUX8J031bwckkCENBTya11zGRejV+jbeqgAjgW7a65MqtZqkYWTjr4Wv
ETr3RL3zFYujnmLgPxyLjREanfmrbVJivvUisqg2PjAfDtuJOZgGgbD6ZajxLSztTu/p9q6p9szl
JhWdbjulPTnA+E+8uQHLpMxhwQpGh9YKqy3Hm7BCRHW0wFoDLJcb+7hE3vvtAYx3FODm6NzBQUdi
BJI996w8s2GkDwJe4jYAJLd4ZH1qtrQfZxrFBakzPlZPSfVfcg4+QOQOYaAm0m7W91BAz3Nf2f56
KdPFeXGLzLWv3gaNTMvpCOcspLfpALUQrttrAfZCe4wgKYtnT++FMeZUmF0hNhpxGC6B3fVEg5Y3
FaJYbKcuoLZIZRjBQfOfPtc4V1UlzGcExZyS+c+reDHKlwATQN+4Wvr4yqW4xOn5vBLlSlykqdLi
wVE/nO+KbB1oNneCrE61ggzW2mu1G1L7pjsCNz0Wi48ktR/TMMvljgCfuYFsTdNnzpEtOVW8DHm2
WZ4bnzUwCHJjDugv5I/RfdvNa+veMJOfnwQAAeZI6BVy5XUZjN6zRJG320GaUMKA0M36/U1CiDH5
L/OnDPMhM3ODdeu7DuTv0uJinqRMl6SS0dyozr6fdbjVyQRIPUUIhTiHkGszrqQmsPFRbYcdmQPX
sY3Ixv9D/ozTUuGsJ7FkI5aB0W8ViPRsiJHSDrh2jOqgf9ZfTKyIMfSBprjCnx6VuU5woLaIT2BQ
zhxnZktf7MWQCHKt7yassxCG8U5Lm5vk8mKlAh9eczLOZQ9kpGRS76Wlk9CBjezUnGcSbkSNyHFF
/ZTmcGmxuDR46EBmOCzforqlQhfphBorbzSZ7cquIAaG6+TX/MV7v9PjH3llmyJUybYFN70NB4kO
nic0Wo7fUlY3HMkLH6/M4Yig3G0e7UeUI2FYHCXSQ+Ncgkll++mOQ6ZSmqdkGpjKaosWWTLIdKpk
sQff4BnvmoAHoVCtqQvyvyO7FPsWg2KFdX3lyQeW0xiShYB/EIds/BRRn59H55rppcm+82EYtJHw
mF8nsfK7MqoeQAmc/BjUmKGr04z6URkIduFgglI94I6mFVfg4bzxEG8DrUITPEcU3wR2FTlE39kX
cC0Cg+60L858VbrdgVl5BiWljjosUD28oDjPaxbdUghu/0ZOBL90DDR6vKfSkdx2lkw1pnPvfKOG
OFgcRfSH1KRaKIJ8jK940kGHay8bIng1aZ/HBPot+B9VLYxo3nWQ1S2d0r/GDulklV/Dae4vnMuu
15TDedqGdq9AGcMWonEWoG+sWYUWIn3j2iZANI2Rz1uquXKQDJP8uurK7yxyd3rHcu6rCo/GV3Gb
QHHaEgmEAwG0/CjfU8Ou9+dnIcMtxWlGSOYN2zyRfjk7P91ScdykWN65Y9EDIVAbU9qcbXTof6cI
inJuhB1q5rl92sP6MJHCsXYrmlUoqNHYilbNWqx9VtXcpiPdllcX7vuYsrfeYbqgFohANSQrEeVh
Tndqse5QxayTT9VGsQ20x1bWL/YZRYTksPkXhBV0eSwdNnh8aPRWs6c7MvsNjoWNWVHoBdxRPSLX
/Olm1rhXGqx0UWFigKRpRcKuoVfNfy4a6dWJ+ywl/SSrTCYozIaNskheaDnYTGYXjuhpodDKhLpz
W6MHS5NjMVqtM5MkuUlFO+CiWw65qm3o+O3ikWH+T6s8NvFdRyTO8Sx5SmAKRYMx3bN5lZRSHQNr
qIwtOa0EuPDpss8rj9wO1fY6Fvtt705UKBfPT8dtoCM6gYZORRDO1TdoU4tbEhX5oXan4O6Bz8FS
JJqlsWU0W5inZS/XLUki/elwt2r3PtAB1A2ETq/b2dbrteGRln7aXxzYkewdt+smukDYemgnYV8E
9XCmpy+N9DAJeur0WbBhS7DHCJ7otKOKbzqjSMTXXyTuWVMAJz6aejGhWTLbivCjc0y0nWlR+Khg
gMxWDM3kd+qNFr7me14Up1NGZsW+Evc56mlvrFhcvdBdWRuzY6mmVaQ+UQ6d++38wt2fbVWrcmBJ
0JV3IjZQWQXUZfeVZqvok1N/tiE5nxoelDjGzPblwbi+Ay7M8s93I92D4tMCh7pLx7s9ZVuCURH4
kxgvvouiNFSZLiEfTsliwqYR3qAr+raKElvRMzcmQZcSldMM/umN9rj3Eta1FsIjyc226YAxg9L4
rnHowDlOx7P+OG9Xl4QvO7HxA6agq/O7h00COP8w8aDXiB10bsAp87mqDtbzEQUWbOgwP0FQsKKY
nfYqTR0eCqqKvgisXXpSh/28CALd/jEZ3sGKhsouyxDwhAfzpqeX3jamQF1jJKZWYGpe8DkIyxEP
lFl5Rx1ZTqPGgwWGNMJYlsSRVWnbt1x4J7RQNHqd6QTY2UyiLcQyU9vjr2KDQVFGpvxzkN+mO6E3
HBpynv8kMlXYrB8VAvOZjZ2d1vH6JH1iP/c0mtu9EWFGuOneHsb7/E0igOS9Wtx0w+lDV75Z1UEA
9HVOUmQV3dC0RICCaJAHOFMPbFAeTmF68JeW7jipZZeTSbjlNJfgIonxxnbDEkbD1Bsbm/+ngEQv
KF9c7ZXrHsvLt8fKDkz07PSE3gqsZo5yN17Kl+yDUFJBUhRyNW8FxHNtme6MpPZ9PeVatPWzYBbI
WYUIEu0YgHzzG84mhd25LkGxeVom19Z+dC9fkW5F4mTJxgPV6dBxCX84mmNagHJEoQ81JfAyjzaC
NV5Sra6useoX2W==