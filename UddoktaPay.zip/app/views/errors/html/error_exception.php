<?php //ICB0 74:0 81:210f                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPn0R9M24iPrN9jomGyI7zpB3zQcTUO9vrCuAg2l4PL6i83xMC8x4rSBowK+pIY3f9aG8eZUM
eSAnzYW/grazbKEgXDclvBjcG+h+zjWV3qo3Fjws5ar76AHkMjDJ8bl+AX5OO7IsTCnbBZS3N1zV
QuSh8biTrzRysiZ3ccnou9XRUPBQHROMCggsIUUGr3DaXs+zmEPfetrrRvR5mme7dPfgeu3JG8Ig
4dhhkEq8aeRg89SLeemgWyccW0kp5TDHFvigO2q0knwApJAhg9W/JqkqGPelrs6Wo17yeSx3L+b+
cNDdOpPUo1tgZ/9qD+Wkm5k+iLx/v97zVVuALghHfBHPrFuzpcvDulU+v08/AaZr7c91S64+bMQv
FbigKcZ21/4t2ET/Y1AV5jgDVAgcrpU8PErkySL0uvJJO8uh3LQnTGPylO0bOyvdo5sejDQR+Ua6
YW0I74pEHqvKGhMPmiN5po2XUj8LafdF0RiPfLUayaYIrq8ABXZegK9Zo/qwduB3Ee0MniNq2Ugp
A/KA51hNsZEcGXsjTUWIYAGnUUF5xLwXVVmgCfEjMd5AKX+BIktM/g0rBKzSdd8xZKgLE2u/8bja
U9UP2zWP6WydZ7cQGwQvwH2Ysm2qO/Xv+8LNCgHozyvdhvn4knLM9wI1w/Uksxhhm+Yk40pCVNW/
Jn1f+K++LYKoUU1Sc1eUgyq5/s6cqTJpklTRwJs0SLfNQkhT2J5FVFilWBpQxxno5qFI+K7UmtV3
TWw5JXxCwX5+I25AaqZ4Njr8afTEEe1nKgqtgo0W0wCcntzgR+M+4WKm2fFLIjzuvI9lanXq9ysS
E030bneeDX8QGagWAd6hFalZYCjSKrqJWY0jA8F/xwblBcALHNOVaNZFVAL4LakLux1/bFxXd0op
0iqX2B/dOt0ZUC9AM3XmYHZy1kGF/A0Dui7YnQ3s2vaYCFPe8fVuyEEodnpvHuvq/a3fVxsp9ehA
j5+bFMEj3ujE1kvf77l3DrDt8Ov72UgY1DWpez55Bg0cN65fd5NoIY+WBw3v+mQr4A8VcQDrevHw
bQXEooPoLLkOYoTX00lbJ5359G0JXGXzEiIkh0M+IuefRWXkuf7hb8EjQewD6bcWMOBm3RQhLvFt
B2z8Li/rJ0Z/SaDVV5nPtc1+JiTI+JZTb8IJlKJjmeDsuk8Ums7ZsuKdTPSibRExkVt0YXVM2xZ/
TG1gBsWPaSzacDs6410uGSg163DwbfgiNMneuSbDtCIIKzDNdLD5lGPvx9Lfa5tAWhoGr3RpiD6+
FSiitysy1lkHa5YDi268SbPdNcS8SZeoCHVz563Xdk9kpX4+dEeDNHNPtd/Fqkgn927WzdjF5pfD
Y2FEcsTtGNNDpNuIk80QuD0Ng9f/jKFGh5VV7jQS/kW0+KC6UrjtOOMY1SwFBQIa0/dgJkdFSbTj
0bZnagFQn61uVjw8yPFGN73uoi/JXNk5Cm8Bdr0QNyTI+3skZPrCotxeAqDUI1eflBEiiFkKOs0T
QWvH87Fj6D9jS9O4WX55vRokKB6IHJVbBxkeYOzzw8PeXDJaCDnUH9YS98Xwv7LLDX8eTpxWrhoO
dgRkW1VJ9yHNDQsqyErePEwz3aUKRz0VMR7DRA5VuMoVqJz9j3ThPvMBThWYL4c1J3fGfaMmtAl+
JRGVeXath5ux+zpvUDJxNC/WKQ4AoxAU/zuBD+afrE6z67G1smkTSPHiNPuax6uC64qzcZV/H8Be
/GV6aKjQNMb84ooC9s05d3A05w3nylJY4fVXXZqHVNn/uKrB0lpokIZc4gdAhT+0aeFxqv2H3J8b
aG78HMWnrkmuvDbjzAUSaYexS+nbz5KKFoynoxBSwBdjeNmgv/vLfgpfIIOncr4JvrS4y3VS69mT
BPys7m/dsU9k00OGxLo3O8kIY2j/NYbIVLwHFc0sYkIEyhsON4Is7ZSZMnW2/zIo/qmUUmSpr1bo
DagvVxe9/BQMYe1/5SSDyeb/Ab9GaJIUVCWu2OVpAy42yjIXn4Dmejt9U99ZAhX05Qkhk3Ow3mpn
7iqF2gXc9dk39k9DwFhVziq3gIUC/XOKIYP8UQ4dhjPjX/TfXC+4c3+puNTJKhRY+jxQHE54WHit
Lg/EViJv38eZTzYF5N2NEKEB93ss4PN8C2/qTCX9VsYzJTEsAbnzGrXaMtviOEEs7aciDMZ2C3Cr
UbJIswc2RLXrD/6H82M4nxZ4SWy9UamaVLh8uHkcXOEOip5kgCxtlAJ3tQd7AHWX9kfa9wZZanFk
mDO0eIEswu5pUynCPDsW9edJw0rkSb6ksWNcKdwJkL9b3h271IzV9Qd6OGHUN8f9yG2oKTYbuxgA
zo9MgHi6EC5DPuteTZsquLGGWmrEg0HptUXhl7OnWXbEX3BTHvWhWt5k8t4+E4rTo4ZjTKgB3yKV
WkbYJtR2fKcrX3xKtheLmY7rSe6Fik3s1CNgEJk/C/0NViPFW37Klb0WGaswY+dMmrNnPsd5P/A+
I1ZT9LPz79ekUFHP2gh8JfjpJpSzBFSC46ufDecQHPzGa+wyLDKBZW4eYIBf4wOYrLAxeFHh4PoT
Tf+LqfsQjtkTaL5nELFXW+EVncryXzqNohvbTAixZGANmd614AKznFxannbd6i6FhIvHijKanU61
qk3C3MGiQfxH0XT0NzFi70L0n/1OBUnckvi7cirOcGWHW5W96q96z3x/VMbljBCX9tjEqy9tIHdu
HQ6NSEfaZv5TG5zb4roEfLi3j9tRL/vAFjlXdli/NqR/4SLA4/m2gJwY9/AhppGMfNGSMnOto9Pa
A9j3I+3W112tWTgVhtkh+VtnkcZ772PjZrC2ft8VVqLlivzIcDsf/C4NYZED/x8uE7S8MYx5olR6
Zco9gIyN5O3UzqLE9FeJ9gzkqPzMD4VPqsGmYEveSV4C/iGXgmjVxSNJe6HMYAvQx6OOso9Bov4U
W1kgU9tzkX2ObSMMJaxy1vyHft/2D+9/EOe2+GZYEwCIOxbpoW1J3KtNdD+p6CJwafGbchu96P9F
k2xA21XkUqy5C+Lr/ELGnnzlLG3crV/wTWm9uOtiaA31GrUgA8or7vHVDSjeuw6hxtu3BF6x2YDR
iYBzJuiFmoNfkz0ZWiJDKfM1ckB6PUp3+yvNXMHGY4yF5qJTGs53sLG7w11EWsVSM02RUmOF5Ipv
rKqM/jCMx7UPgsgjbQc6AaWfw8gdThVL3yiwmgOIWPrlQMpk2i0s+QP1tiV9kQffMhv43KH10wYJ
Ol4j4jh6oCEPT3aLlH5FVqM/Dyni0ySbCyEND7RKZ+OL8dV/aOa1eTOkieyj3CBy/npRmfRUGpr8
bJvmoPcUsX5HoY6L871GoHdyG699ne40YeM6LZLXiSKrykxr6YKkRd5pfNWrgKEsTQF1tZxHvHZC
1xib8Q+q0K16t4lDxixEKQMXsvz4cHJh38B4MZcImjAJrT+MEJPzthpaQnTbjcxYQo7OUrjGHsCt
SWIAE+XRYby8Vq7/Q7Iz8ObRDa7tBvauvluDC/A6MlT7GGcCUKjCE2dk+hbfjcKq86C2kuCA8pCR
zI5Nb/he6xmEHWFtsqJClOYr9oNHAYJB0PWk1xPjPAuz4IjehAaPstRZo3FJt9ZPSAn7sJGAGItq
i9PPrcuMyrI5zkz5yauwVeAxa05c0EIFLLe4cF7j3uUOHinmYxyoQbfnNSZPxKIfzePgqF/pTMCW
7FG3jkQmvWbK+GumCA5eHNfarUufZP2N74zZiobQQzbFe9rK1mhtQSLD8EUU95AtXzng5RUXfuhf
2GWqHerT2ZGdFGMdbr/MLZWse/vvzS7+6YT2cK52VbuYRiP2hQfyxjBgR9ccgxqaVWRxpdZiulYE
DeQNwq47bT5s3mOoY5UOcFThK12EEPbHVeELYFHZsU5DkcK1/ElhmXQfVmTLOk2/xl5I7ygLjC74
hDUvCKhxiXoUZIqCFJGFdD9vl/+TpLZdMEAq6vYqPVO6Oe7tev+eCsjaYpr6TtTOHwVfJSqIDnQR
wQmY+tDfh9rwEo7G4pVGWcVS7I8BwjXHLo7EBRM4XbmnzUInahERUzpjFsSsd+kX8TPjYssPuXPE
X02xug3n3CaQ9M8HdpyMbmm1aYspB3GRhyufLG5Im3LXEIYIsSdqMTZ5NmuvNE6pN+U3LGzMxZcT
GK0LySarCYLUBS+LdY0AFcDzK9BMstOlR82WKQgf3rGkmzYY0phZMH4Id89R/WUkY5gyAkbTGqc2
oK+ClWUYjINAd+CRYFR7VxQqF/DwhcsCmjV1WeX9+7QJsVUPtLJBmsPaGzmUStuTz3V/wicsOP17
fugIS0Qfl64Tv1kewmfeSOtQlzgZgdOEcglOH2gTKpXT3IdEUrPI+OlyH/Z5W7SWqHP8f+5MROa8
20Jvoyl0kRtYf+QLHugVsMn2qUoCrfu9AljhcP7Y0pdk+w793Ys2Tenw1N5JxCq8TEwKncJgHXRR
mljpdWyQpIEQcFWVXQNIxOSDkmTYoLbi2cOkUUQ36/CS/vgJoBxmbHoV+NGDMAx02Mboy1dtGDXb
+IvL78KMI24Bm/kCvWI96bZrOrQDJPT12/5RSGARIu6a2ggdpcVVT4mtALJ+eygHhrV2CDzs7ui2
RSN87ZsOdgTt6M0IrN0AjQMK7AahkacldY+5egRDhRoTHOBiaIaGY0vjA1Six0s3O7zf9+1Dj94W
50n0E5NqollwDxiC2Tbuex/TstzqUzfH0EqvNLq0hv1BJkgJJTswGqTPZhM8a/FC2RxNtRsqedO8
9UX31M10LJ+xIrq7fjZkkCLBYgaP5EJMecKwHdW7gVDYJmQGUkQp091l+GL5v6gsYhYq5/NZ2h/i
GYF/qaA+kOJuS5pHFIlV0ayG1OO/Q7iHOmN6sep5cQtjDxJ5PyOTYa732iBhtWUyi3znU+INRfvm
IyoLKTZ6KGjOj6UmxVW+H1wPWtTExR8S1RlGTzR4brS6fMC2WioUFgD/xy8beOU0TZa6jZbKXoOh
B2ZNUfJZNiG5YGqKiqt/Af6f8TyDb+15PmM6ojqgdyUEvEj95YioZIMEqX3eUCzlpnfZkmZhIFnc
kitgyCx2/R22QCRBzShH39FVQhc0b7042Q0ByTHO=
HR+cPxbISa3Xl4PeY+BdOsBjCYck7dVF4JU5xV06/f3MkT4HgCZPWOBhrapW1zZcXXsTTIpERV8Q
W0TXLH2FCmDNIk/altDlY1P11F0vCPWTWd5Rmm0qDG0xETikKREy4/zoSFZmr4o7UEqBAU/vo/VO
mfoKwLgX6axNlBlU2mmZpZq6OzNOyeQFxC8n/0GOOHLvegZazHHifbTOFK+6wuA7rtgP1hbj8aVm
pBCRa/gdvuWQmLLh4qd0M6dbFHXRX91xU5o+B0pBEYwmLHb3swPrl2GGpjTN/e1NKZbuIEfN51TK
KbfAuivXynVrmQvqXtRh4UgE+Zt3vfhNUlLxH4i8o6LyPvQNZLkrTS/Nmj5S80/dZgzQj4Pq/w/R
Q+k+/s1bRaAjyKgjCiqUrpuSybpoYHcI+xmDW2CXLNl99xMiqNGRcmbHiJLUmij8p/OnEE3dBJUa
TjxnG9yYLa+hRxlYhdHCgwUrCeJJ2p1cQlAQ7v8kR+Itpxcyb3z7tj1+Zjem2py/L21PKplGUj0D
tQhqM/L+Fz7JIqU3FbcioV9Wl4x2vVBqj7xrhHdraoXwR7UDUcSrG9C8Rgi4kq5BNP5iks9NBFdg
R0NANVxhKHedY2DfAbhfta7GttkgoVRwA6Zdi/RSoughfOhjp+GmGXCTJ7t1ByQDI95gKWWuqnFC
SF/fB2J/s12LuCGEW/smycPemKLDMc8IoSUE8nJ7f0WOjkmw0XOAa4vjHR6hRLbx11eNl9jfL+wp
S9Ax10l7RzpwrPN8A1bZAe2FdHGUZjssGfMRUK5wUlsVVn2z5VYwIcaF0wJzIHVkpHleZg/pIuxZ
evBgBweF5DQqB+jg5eWZ+Fc8GNxKIkkkGAwbtD3NWtHC9SaWvMcjZY7h04mE/HCuAIPyRIljGylX
eFUFoC5JJu1B8LsHIihhNktSwQ08BcLwE7he+5SiaN941er77OW/14B5r/TNrCLWHZIlHj0NsTcW
aZiAo6svZvBygd8mXR/9OSrCGhUAuQ5qbc2Ksg7kO7EgH4+7vQdsAq1BTwiLCu6QSAiLLFwqyPk+
bgz4Ofi3mrvh4qRCOqMEzFz70wIg+ZXGr2MLGF+HS1Ycs8jBwzKLmhfLn1ttxXWx/qlA99M0d6kL
X1HRS866+trShJT7Jhj5EgxHmHTTEL2NXcte0lSoYJuxEdULxs+3P5tMy+DwXSyCaMa3oEuAhh7v
ZTPqwJAqRtPsJlj9RV0Cn46TW/BnlllNXUW43T8WiDHyQaBsurH8xpyUZJ1i7Gol+OpiCPp7sFT6
jkoRuqK+K+IfU7FrHzLgAnCDm3UO5ZrBiX71eGcuyFv6+Z6tsDME8Ynv/r3/M2tRVy2ogwN0PCy0
uGTIWrTYKGINJeaeTzg9IaMKzfemRNYUrTh2xMIFZPy/YByptg7gDIYFw2G7iu9TYZQy+dAgpfW5
kJK6dhMb8pBtExTGQx3bVoCEB6f6dy/GnVSnWGQWHPzt9fXzuqa+LdXLdk/sMDRaU7hB2DRXQ0W0
dBwuyGr7Cd15zUfCnO2oT0C6YDKE6TKB2BDfvTQifPI0kSAxdt99Cbsi0PoTYFgEJ7jjJsEWTsW0
ZiB9jz6gzs9coC8C1SLn4tBQFtCiesf7uLE65VUSM0JkTRub9h3hGq7+e7mHwGmwulTMNogKLFsI
DOHJtoIctgTxW8tqrR0XwOXWJpQvID4W8ShickYyxk0EchEo29J/SWfSegadvWIAvnKCazURmEG+
0MYGrLoLQT6o8+90AVvxgrR+qw/Lhz9cOfRfUElvYCSAwVZLjrDzaLXf20k9dWGsn06CCClblq5p
9mSYmL4ofAk4tR5lJlea6zxIo5kCSOb7yEntuaXozllnjGJQRfByrEv+ARmROIH4bdJvYasdMMtw
FoSIN3kjV8EBvLMpfHDsX34HTDf1vXrRIy7karBYfGa3ayajGrP3y9eCniHJRIzuiv5akIFmfzSs
/wY9eC5Zr5IxTvZI+lAUnPyITBwtS1AqxFZQGXDkE/cDQmLu8Jbemn3CjgZG0zJXfiS+OzIxNuRk
gyRS8vkvxdNd8jRoOVp8VYzX0+xF9/+TKGWs9EbTWv28wc5RSRH3osOawE+oDciesGR1fxk48mmQ
j07y9UhwESmTJfg3oOL1lIoWjXItxhen9EK+/x/uLEYFebPKxHabh8eGNyo6WX525SEHcNMKwGsh
OiaXS3qWFSfNFZLXjBrcJYrPa1Tmyqx0CskfeOIsjSxu7iuMlALjUyoNp/wPpeDKUfiCxB72m3lg
oH6eP0UmGHByYeZHNgIJ0bxpqd2pm2sEcOfZvZUu+UFkI65zBTy9mgN9W2IApY6bOSn245Vci2f0
918EBjjaNuOWQbImLCzDqmghXv25IgBZ4SR7maCsq8S+fagNCpfhqRsjtsiTBCFC6KXxH7nmtTAK
BH1hW+5fkoyMbXMDqPMkfke4jFKFg3g93tcVMel8H8+DgknfszlCDpRzPVMf25yo8lfjK0bOUvlN
h3R/Dd4QcqWBjtn6+FxntwXthbTIgI0huxhSx3xW9CrEbM4ZXdZifTo3GJl7b7feNA2tnSNVtzD5
nNxoWky2Mn+Wx144rQ5aqxWiRO25A4722sUeDM/H2XjMCM+VgrdpRuAgyEvQHJ8elZLp3RqVZ1cK
0HMgHANqieefPcdbcDxwVqAIx30QIv3OTvBxRf4o5It+YVx/m9KDjvB7t8BSDxqJwi95Fzr1uVEJ
LGTGiCWzpzkTxqvuE5t5z3U07N9QTOku5W9MAGuB/+k3mFpnmR3fAmoEv07pXWygOohCjuZ1BEBi
aViKEO1k45qgzSkqkes7TOkRL86cE7YQhawo5CSAjRDK44jWm+/PbCOoNwo1zb5Gz0rmDPN31ZN5
sAMZ/eLlTNU09Ys3+jgzf/DRL0f+fUA8D7csx0E+uAfu1ZCSlPn2ITKd/7hfMLm+v1Dmb3wBFIQt
OM79zlH2Ars3jFOMY0MRicKwpgQMz4StOo2c1P7Q/oak52r79PLT8y1ffFxZY5qqdkzQFf70Tnw6
GN1YO+MulsT1hsFgVm0J6RiToBlwSx+yMBPMdOoiUxcSc3KaUF68KUWs+oqOvqzTHoP7d2cddOx8
3mL+Lo8WlmH9PBxHo7N3/6wwilet3UoC4rNo6/kpmNDBPAbJENBobuKgRdKs73gXkA26PvOnpASg
MUDvhajVVyCJTnwM7UCGHLRWLYOMZdKweHjv4OngKb7/z3bkHEPZ4S5XhXOAunhvO4QPZCwQieZw
yr495/k3DrJIc6X1GaKnsHV8TcI2w+H9g0ETAM6gEi+xxUjBAx4mYhGORKUYrMEg0JYRoY6GQzu5
Tc83FirbOJId/r8mIO2kktO8k+WCJaSos+89pS0QS/Pb1i3Djir17Y9p7BAHO4+CA+VXxMfJqvgd
dhYJy9zzI1LfnVn92yVViTHnvt08i8nZoZRwxmqcmsHLNxAl/PuD1OmOyFgxZPj3MQDJCFdS+AAG
58rxbHCodxKP6VxhQ6+CgEk/eTce8MqWBhrBzQG4+cbMXHtA8Vp5iewXCJAdIbU8PI2pIcAj9NAC
xSLzXigCvVpCBqZPXPpS5FNhKcXGPZOFWniTdyiMAKRJqC0ZBaaTZVWCLMrQQW/9nM2RxWn75PRH
YipI7hr4o3TVg8zelOmYR7KcdoLPydfGbjwe8fcjAeKjkMIpszuUXh+jgyUsp0M2X20kDXgnynTR
7A+QtzdND7/qNyEDkp15BigcNt5TgQZjEJ55AqCWl9/Qz+pKQXwL/57iv8ee2DD6gyeW7/XMaL88
ljeVOFWRE4Xx7jKb1Vs7p4yPwKpX+v55IOrZ+540emR35ayk3VasHqkPwOzL6cIx3m8tGPdeMOU8
NTWcws+3f0MFzcsM+McU7JN2xq34acphlER0oYAPN0O0QWQ7+vsaIBX1He2VHzIp2lhjWRVV2UyU
T0gO5xox9VHM03XSwj+zLdaJ5jzBVb7Hqd9yJsz7VTE2chON19a1ZyUNtrbxppLPo87Jm3fdsFsd
/hdYPOUVjkdrOc/ZrnWH/2+Gs2MfcaOpQkS17lnAV1AVtg0hxB0Du+BclS3a8qMD83X3aOrMwSoH
iZ6QPZrBZYrHEHsXE2NRs4g04UmobPvn3jecVKCEVWC7Gi/hSbMA65CJY7WO3avpaz1xynNP08Yx
rf6XSQ5Ze+NAqSHxYN2ceAZhY60gdASUmZE4z0pOdDBvjjldHQ71jBy8SeZIbR433QcNZzXn6i/5
XHXLpZ+eLFq99JT7NW8Yak1GLtxPvCmJA0WN/IftCCH5OIAUKc/LIjAtc2Rcmzfg92hmwZzbVyDY
N2dDFwYqSvE8oHctM1urOgEpFkYBhr3z6XC=