<?php //ICB0 74:0 81:1846                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrHeZbFT/N9axw4RS4wT6kqsU9F8Nt9o+zKRyTZTB7WRojOVlYuX/klrifOzCf673HZ25WlT
/8LzOpI7rj4/upgRwsoOplEWWsHW4Nof4CZqZspUHA3UHmhW5jGK0EyiJ/qZZY3ds4VAMNqsW+mL
4vWMUNI+LigSmMrr6rTizybJugRCEle8EpxrudDvKSmQDOtXVsMtRZ1evi4kp+VZQfrWP0P21cTJ
u5CqvUYuwUNyqnTHGWyjWhTOWSK7wnZqeo8txv1K//Aj0EnErwqhzz/w2tYOFMor5FGEVZhVKj+R
jMUXHzDNsQWUC0cbPNeVtmhwnuZtkThbgQY2/WuTOUpBj36gDB6zd6thItaa3q6Fw4ufTQtTZ07G
Q9YE1L+ICChT7QR/OGh0WYvT/yvIKj6kOz1xVSetf67H0GhYut6IGGPzn76kIxrenOrR8kJ3dAUk
Jb7csmTOL6vXqSF7HQoOlIKW3Q1zDS4YAPm+px5/lhItANtxXDZK0gqVWs/ikPclxxM1MsX1JDD5
qrvj76NboABenwpjM1uBvtvA22V6szQYjBebR2tKdMz/SUyo1bgVQrHE2qnm7xCB7GYziU8NleO+
yRNKUeOI1upyQRtd0vCqYqiGevtWggiLwUnlckssKWnj2bPny2TQdDfyiqhcVLaWP7brbVY3VRiN
xUOSkiBSUBJJQozrJYcT0Nad3RCkW4vLV5mjn2kiUXPU7QoFD23fF+GgbGlDbvKXjWSiRO1RMz8z
cKbBJ7CST6aEev1qkw03hqZ3hbody/h9I9Hxlny4zybXZho+VuUpkmCAOwaALcuqmvkBPL5SWryq
GPKm6o6h/N2Zi9P1qno+rw5FYSXBBxzMTaLoS+I2iyFw9Qm9c6Sb8C/mobqdyijQ6gh5uONtDg0/
eAGExXOz5xiqYekTdDLgTXAOqnLAKOmq5v3sErQfb43ZV75LrHWoyuXaJfJZ2ykSabsgRdfqcaDN
SdDFDWuojIa0nrsLbfTCz2YgOIS1qxzE+5mZRniwMWV0VZdKKoSp/oUC3s6L9YPfMBYyNgxV1vad
6mAStgkYeEjiASryp8nuUhAWbHJPjxleEkhlrNigxayXhll9tfFn6ViMnuRPCIEsWq/k8ZPH85Jw
SE7xmCSZwAt8BuWr8XzWaBK/AjhUFZtDkzPFR64SdWTa/PC14Qy7H1qsVoZD5gO4MyWpK8kiRpDn
8WYJ0l3nD2+lMf19tY8HzoBZO4FRZWlQIR25N4o7dd+KJglKB9fzAhJNre0tFPMta/JMuxQDxzXX
IpY3sAYEDGJOIkM9aJPApzxM5Vs5o+mY2WX4LePiM3zl88niDh31BX88cs0NxTvOfIhW/gOpiy7p
MEZLeXfraHDKUWd/mohXmuXLyW0dvbA9jJ7xSzpbQ3P8QxSSjVzxgGdBXP2RtEQxC1skpl8czbwI
oYoFShJGOUnoV0F6UQXeU3gKCD37yB1rXqTraHNPY0o9M9f5EF7Vc1NMtdvEnVy0/OvLmSq/SEzN
Htt3LQqkU86l3wwOJl8nc9P0b7h1GjNvBwdENTyYcnqvSC+h59W2Ng+uQ9VRObgj76MXrrtH4jB4
Bx0H/XzEPMMu9K1zi71zQzc8EyUgCesFuAGxPlHPcn86+TIXsow8BFsbI9DK5x7by3DMrTM8m0Ys
WnkIgR3y/xDS7rFeHY7BE+ZTyurmUNFYvE0w1hCd3980bhukjY1F1o5ztg3D/JWVhXlmM7B5rIWl
SiThWNOgxQ7V/P3IIaBbAiY7Aa9KcI1DIygKHhrMWba/Iecg++RcyAZK5alL/QMlwhR2qaXAFj3L
vHmoSq6XxpbB7iRJMmkX8gQttlfxJZMwy0YUiN1RXN/AAsylBgulYKJFhkZZ6moDWjD+PjVO17ZE
46i5ckrZPwL4cO0RPvmNf7XdrqdwDovWohWUvsOr/uQ9JA4m2fDGYdy1vCPLX7nI0lxGmo2NUgCV
snwTpRcOccqQ1cz6JWfEIH1ktGOA+z+mbR36m1L8XS/Q/ypm6t3aQfwYIo53PukERRdBb+uGjnkv
BwLChxq+FikY4GRKM6PCakxSdETTgm9vQR/RN+sgBmjQLfGp1R9wAQ4D6INbxuHJkbwX1czPMlb9
FrX2/YDI/+6hxkIZbkBEn5SHbiquffumGCwe7t3LRKqGck0YmzVxIRyb6Vajfh6mPiRtMSQZLUrp
Ui8EPCIMEJlRIAmzuiJ7q4l3NzlA/5L3Dq1O1QBL8SljPCnpX8G7OO2FcPLFFrGpPE1MpT5Sx3j5
QkUnjEkdYdg8glawRCfSfAu+W/3JaPr78mFiIQ63p2vFMcZif0tcSQF10s0a/J2/TcYbP2QQvd/t
gjdAivVesfJPyNsrZrcpbm6tKjMUr0VLABuSglssU/ORimAvGc+KjQ5pWNj71VPCrvzVtXw6XHLK
b80IbqweB6r+cnIbCrv34hMTHisutRk6NIepr53m17sClCslx2c0sAkKuP9kZBhb0/LiSmNfYtdE
XMBxFkkARmZoBqwsiEPAEw+DMJB7clT2EFjobQ4uJwZ2Hoe+Fc+EtXZaX89h0E2OidyqAZ+v7SO+
9bbNRfl4lZxeepFWekmqJH54i/UA3V4KwyXJrROKNL7RwD085yG+8fA+bGHmtbP1Cw6j/GcOboXQ
/fU6Mts5UzDIugIm5xAFLTQSmR+uTFJ5Jw2AdYOcoy0xBrG+nnxuODDNWxsZ07hZkIc4PUU9Arzt
AuP6FN3W7KR2ZWxaXxUmaRa3RjkDG5ik6/enphHA7bpJPLexgJ2fZT5UutOK/kp6vcAmWxhC8whq
5bgN0RvO3t6/UlEh5jn0xpvAn6PjLuA4xx+O8Vmchm8uX+PAiaPow/vLdVykv3XztHXpfXYswHmc
re0PAys5zCNvK9so9ie9RG===
HR+cPwfN/p12KR/3TLlZQc4YSeZO8870aNxy4gRF/A/OKh+8tlHyYcO1zSgAJkCUpGei8tp9k+Cc
ZQv05rZVCK/kbK3pvHQde7uW/qcQf2wUT7wAHz4ZYsRYYbk88dy7kkzyL1ZAfGSqwxPwzl1j25+/
56se92w1MsO70C4n2afsvwmNeA5R8y3/JiYHBGYSVp7ZjzK5aDOlAWh4j21hcWDsmk6jGNEDcvL7
whsA6hLBUPVmTL2C+rtPpRevI+EakfsYC+FTJ16TSw54dxBz5z2VVw/MFJ2GcdwEKGuSgynpScbQ
N97Ao4CaRjx0ItQkJx8Jq1jP1c0BmbP+zHum1ZG1ikZKF/fpbvYXv33AqN80PCOEsa6WYMP9FwfT
RKGu0f5yRiozapKTgJufIoUudW42pZrl54TEj60KZQWSjt2DANdI4N9ydgafKMWgFdQrbOgc5jEM
r4zTv0RNyQfjIaFqKidsN/oy2fCogn9Oz1VsI99ygj1eIPA52/Ku9iGDtrDlXiGuDC5go3TQtHYi
DBRHKZQLBfeZT40kX00hklaNWVHu3Th9Tqu/iOqWrpH4ihceV1YSl6ixDNU6G/yTjvw2n00MSCYH
p+ZAAHV59AVX3+/eETrVWqfiaVwfkE/OA5vPd2JmAwKoDOCQzi19YIdjaUj6b5lFcFK5oTUjIBfY
9PY06Mg0u+2kutqKfKzAu+RGWcE60LDtYt5CvEu375uKSHncDXs2LxxYDZEXce+WksuMk0pzqULd
aaPoZMSP0nH1b6oUcxEzlgbz1HYPaIephxTd2nhOT9dt8KdckVDEpU/sM1+KQDu3hLAmPPsuVaPW
NpuOw9Zhf5TeGwu+EJq9hW3G2uLmgk8VfdAwVAkhnw9Ga/lVxz/gt8K/HsRQFf0uttL4qp/rvXdY
V0HgxJjnbtfGWEO4V7L/vTsLY/P02DOqnmN4uN0LwpWPK5fXRhV0xwzhSNdlLkXoxN+1/doofL0L
NG7e+nkd1GGR17h8j765TpYuepSMzNbnBcChyekvzyWgECRGwsoiBykeYtoJp45POIJVNe+Za+SW
MhMPjMstAOgLWY2T0EjTQDbu/MTRG7r96TUO3iVP0mRCYjOdnZHceZ6PMCaBl7PsjkYakGYoGCbS
z68Exc+D249onyvrXWEDuUvULJOSYqileND/LAq5jLSuDXc6cwnE+zeV+CsbcvrEiUuf6vg6EzfD
KMpLhifO2a3KUzfPG5RuXdspxUCNrIaSWn6Mfun+7HPxzT7swgvkjDsBZbV/EXip3CJnoOCiz+g2
ivlUIwBB1r+NVY9ANOauLcD49EKf/Avrg4gtUNyxgehoCqMmMb9kGD15VEHtQBajWAItY2qHdkSc
QYmJIzMTzZB/W0WWGKIKQXOJZiHyPR828lJ6HlDf6VHAx29fiZGByPpwpO6R+CVHW1EYBW/hb2gm
mzN5Hd0N2p9jdadEHaAVvcYo/5M9TuIDk5T1n1nXKKzubc/jCpTwId0xuLjrK4S3Y8S9ULF6v8Vo
hvYddZBhTkq7BQXahsvn+1Bpty3qtlBUjbrD+xLfD4tb5f/LyeSU75SXEhyvc39EV4RLuDSmuihb
2h9qv/qva6Nz6NX1oXNWZi+OX75p77zUK68rUoSa0sZ1K2JEEMTvaIZDBchvW2UEq+wiC9SkVzQT
Up9OuW0fOhv2wWSgvXeqvoxc2i2T2j48fO9wDk2vD+Rk3+4GOV+uGQvzOCLyfv6OxJVl2UmR+O90
Br6ijRhYl438CVXz/rAF08Zb5+DKLPy9hymhcanwTaSfGZGmw8MCsaRWzecHURbzSldDl+lCutWd
Aa/RELjvyPN/P8Rm3R7+WPN9gl7zFQ8bEc1rroz9Y0w7KhxBKaqd+VYcb2gVnMsE09St2fcNtnob
M/m5WlUchhd7jW1TKeNrEvsfUk3+y17B9r3Ex3WCLfnJKY/kxWDJqt9jSCEPQk1LLFis/AheeM5l
dUj3edHGipb8HEcn7t3XLZcvfcvux5WEAZhFbx3VX6gsBK7v/vr0dWaZ3eOVASy8cxy6nK3BSMFh
JsqXFNybMNb98WtW+7lLqblbJ9WXM2shrdCiskrHDtKW0pVlKBikpt9rWM+954TcJRtwbsymcZhL
RJTMW4j+nMniz/7fWZ0ooJeUjzdKlhbAvpjm4TSJVZAnTafkd9mlmobJW+pzlOAo06rgB4qmTCGA
gEQRIBxJDGW537JogPcwKaNMgry7INxG0OrtRR7rx3To/bR3XqWjTVbvOR8YFPmGje0xIiwqwlDB
+nAjZse7jURB+3ifwSE0X8DfDar6AomYKC2q3aTF7aVl++uzb9FltLzb4/xSLjr2Uo2F7l5qYdoR
ySRAKmjpDmxmdCTWI99eh7R4vit3Jl+E6aktlmUyoa4/4ujhdrLpDSh0dMj5kD0rtKby1YSl4zYk
U074566sFnOSq+KeCRwwCFEBBWVy9zt0LLGGWBiJmyKrVuFwb7z3G5yjYcngMgFz64utOaQ+Q81n
YnygNzkBq8LsA6xfNcAfO3PuDNiBclZ8GUBGKpfx9LGxZQhSDxlhc7C1ELD0sCJZhpTs1ILWB/5T
9zo1vHBanXma88o7P+09Q0Hw7dLKgGRzSyon4bfa+y4AduvMtGCiUG+QYYXFIHK0H9az2jpIPMoP
mXPs9or3uj9ZO7NaEEHTUj7iBfwgjkiMyLN1CcFE8erltPHumCJS/ejmcaxNRiLLcOD8GP3T4TNG
fBcBabMYE7xyim==