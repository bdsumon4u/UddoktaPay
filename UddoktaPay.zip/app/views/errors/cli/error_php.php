<?php //ICB0 74:0 81:1f31                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsAbipMmFWWwEcCc5gGa1BY7QY/xQi8PuSvOVasMfmuTK+xu8+gbIwkFV8ZcIAjSGhv5sRPd
nTqt4E/y781qageUbUA0UvS3bgARwiyi8iP/q0WoBQiqjXWCHpGNLbzEyxiPdbKDAZOrYZIOt3to
zDzmVT4J3ImJe+unTtMYzYLFIQqF/06/9QjY+HY8s/Sj3Il6Z9PUp9Kd3tCnFJQZClpNnCbDLsat
qmS5pxZU5C5BVQc+mZ1of6zkv4M0KQ9gxAO+iMX0+qMMeSJe9ul4OJI+UByVDTHZXsaWCW0VZK9R
B5pCqSmKah1B1Ke6RZt0M4XKhojQ+s71gu3+AHi3iC47TiLfLDDFalHIFkD4EvEdmnmjwHsiuvc9
Lcm+VRcXP5WjRopnZpF2/X5VNk3iKW3gp6IicgWe6wa3GPbYLDlWtXnEvMLd7EDZp/8XhT4hzd5C
MwSttEBq9UECu2EaOxwDR6l3mIqbbn4ie8EKE7zZO2+HU3HR2b5hdN4+jOh/JmES03GqPBAKCBnR
k0Asue6FBub0LEHONy6zSqPill7SX1DazLsVzliemF7lN8n90Tnaec2qG6Z8c5r0MZbM+CyvV03a
KTZqHckeo6z+HSP1TDWYpwkjmNu+jYDHjDZ3icmYa59qb/MOmA0b8K1dHgKrt1CaYoagh5+cFPGH
PeB5q0TuRmrl9w2yxqpbJvH8m8ugljHsxKHmAQd9g2/lScolibkMnETUubR1SCaqV0psii0cu/K+
95a/wfEf/dC6w37YDIoeCq+hTzP3cmhUeSZ6m/2uLKm8CuJ6hSDSCsbLVYMKSqzSUdhk7L4gVIjp
LkRxgfYqCpk5R7Zt87v7w73pJDNkGTG2GSlpsEZ16ZcnlXu2QZ9j0H2h+zShPBH1N/4eWJhzPews
GKB9RduTjvfaQp41M97J0LAV24RiNB2yZETehsuEAW1R/uQYYx5BtldYn39EvOfsaNoOdEDLSMqB
j41UcUyA5wIyErptDB9BWkYJMA72HtLh176hZNkJdBd71UeMs/FDSixML/z22Q3Ug3W0sSED4phT
Cszvgk39RRp4tY6LMsSB54/hSwJkdYr3U5OGATbC/EtjN+ASHn5Yds2GvzbG2R7kCjxNtsOOH0BH
AEKStpyo0Ou3SkGL5mIHkx1p0JIlBdXdIWzphSnEZhH0WEe+rGGvCT/F/KUBH6b1VmHKfTK0wDNu
IwghC6EgtzV6MWO0DPYMDl6YVUGqYHEkdtZErqDRhn4PAbODHYF2iZKi1xpo9w7E6/iJ3uy15GIR
WU2UPOo24/IPuljThBOdx7tMNf5OcCSTUijqZzDBsRuH4WXa9UQUrZa9C24Pa4prie+P14YUcwlu
Ae044+JPiuBzGOZkpyi2zfV+EAj9JbGHsP1SCEZEtUZ0Z+IhCF9+AyJ+aJMaXx6r7zaP7iIgH1fC
PtX0i/kcvSVADAHsxbPnbeIy65rmdi/mg8h+mgLgsQwhyijDYG0aImVPMruZ9v0OqbEH8QxW24lG
/zUcVJNJKFEuytu0sC8mf7VnjyBT+zyqp/J89ipWeOqe/kpdStgQ7rR0ODZ3ZjYYZG2eqAeFgkbi
XXAWT6Jvj0ydtM9h2jC2ksZEKn3D6rSrgg+72h3n745+Di20t5ZhFQhLR3ve+1b0fUHsHb/0RIU1
LjNTIE7iyrn9Gu/MIihCGw/tXELDTYfP9Opx6p4U/clzSeAlSmYDUmcMUGrqP6//2IXee8ZxgYQM
h/eY7d0YlzMHvwlDcNgfM25iC2WEXB3hJ4BMMF3S/TluMjMiX5WQeZ2mP225DpfS60cc25KNNvc6
r6xptxQAzO6rkr2chMdBygTVThogZr73dwG8T3EPHZ1Prtaa285Loo21vLJMskgZYn+fU1+LTGnG
cGomlaXP66ZyoHMegEuLdDCRH96dowaJPJDCj7p5uR6rivfqw7Ro6noXl+3SUyBU/tb4/GcGRg+2
hYWW/xbmjZ/AqC92Xeq8buYFcFHgvHTf1En+nDUfYPLICb04axjpvTK9gLEfgGaAYU0wgcQSUHV3
uQ8UQQi/CTX67Wi+u5uq/zzEUFP4P6obgz7tSDsNbvgqUorUpbskkx6l1Yr62hmzh1yxh+MY+XAR
jRyLPwRtIdelzvGLNW70X8jmBR0j8htkm+p0VeDfwKcnmPHO9BjoAHNuIQ8mRtljtVxawjc9WjJc
k5bQMLGDa7Heg2CwbR7kvVp8TElXdz8bQO4akw4wyadojHw/1NtIlOq79hurtIeK5HHwXoDdaHN+
0jtUwg57iL2zR/lgOiI9XHXCfrVTXGzs1c8gIxZvvZ/PXI2TejsBhPPvQ4XlnRQZWxZ0wbH0Y6Q1
5/dMoDG5Pa95Se35zRi0JXhYtGCUe8P/CMsU3uHSuc1iPnOZhYgOnmm8JCYJ/tKRmE1x/xwSaYKA
KorxykGwT2YKZIlZBsOiTEi731MuY17NOdD0g6pnRPFIJzosBIYkv8g0qXMxAk1o2V/tb4VhtgB/
h0WbggjH9cuwqkLyLveeOWDoL8L0pdJaHL4c7hk1drG4suMvWAyx3B10krtCqVUP5K5ttLuIA4x/
mZxgiIr33PXlGCHsOTCScw/mJWaGputejkv88bgfDNtN+eYNY33cPrDSMHz8qUn1ZbgXKD97Tm8I
MJba9NQPTsPs0j6s6UBpTMR9X6WzG5yT1BqYrlmxTBHMOFwJ9VqrNza1jVd9u4EZYQfZk5nR163e
qvaub6zvgZ2EA3j3fKf7bjHa5ImmB2yZfRnFsAbVeUkzQBG0sqqXASZ6k+7xYPC2ikiVyB8v5/Pe
KUMFUpP82g8TwtShGQNYk84jToL1shtMmjiYds8+BkGgtkNW4PSf2Ob+pjb5egIhmxpt7ca8nu5V
/TKJZ+psKEH2gbD77+pFTTtc4vgZbbLMaeYp15Lu3jpsHBWCnFl9GWS3N0SFSYXz164OAKLLYV4j
QD8ndT+3pZrOXh5TM2TZ2VLFXpCaPHrJrqNpzlluI/Q+5sl2FhMTOXz58sPnOin2mFnzUo7A5x49
fgRxaOP+Y7QGovzvDnNHSIKO+Y2b97FK/8CYGZMMchQEmqtk8QEx7R7/eKdAxjWDuzrs3wdPdvYK
IBxoTbhDvQVDV+7ZJl7ro7iRC1vgNsyWoVInJr7hxHEKuIM/lZ4+KjVywHYC6MP6SDS0vI8BW0Mx
fxxt1yBp/oPbPgLZGhhP3n3BfH4rFg0CZMKj8djw0BG1fweD20DRCSmbwQWakQKzptMb4SAM3xG3
jiu4qORS/XAviUerj37/u8xg6+P4VYh4FvWLsEwlAEGBo8nsevPbch3NqOxmQTshdsNyHe55CxWu
awJnda4bolsEV2AjCpBU6Kk90AbmYAf0G5yf7H1j1gQdlyOPVC3bfqmNZQrJOB8zmvvlaBKW44iE
QgrBMs1R1Txk0tTm15YhQls1z1S/6dNB/0hhkpAdaK5NVzDz1UyeM4tTfIbclncdA5/Y0M/bqsy3
p7j41VbjoRVnUlzIs81Rh9lIeXpnCI4GJjaFdEHhhSPb1ZD7Cop0QDSsnnocGV66WQAIjgsEKyH8
HRdSvGeVgwNtG2LOPoV7O9Bhoz79367nKp57NHio34Ypd6Tt44lMg5OQmt5j/x2NsHL/IfE1hk/j
8bTUyohWMoKqd8AXtB3lM40tryciEvkgtmqigMVOrpwz2wda3d3rz5mFWy453dpIlzznrE9+Orf8
CdyGK28GRiefKtdUJYxAzA8wYzQrld1/nt/+oZ+AhzYGeU+GsrpAFRFe5VWdgvpDgXfGA684J8Ql
Q2YWHpVxJIF/VKXqQNwJNAiqREFgZUtxLrtzjH7kXPbD4A9jrs1t/pDThuqhY4Rluxz8kSU/99LL
u15X8ZgWzBQTFflIqf3UZ0gEgKMD5c+pqjaioa9nq739dpCgpkGu0oJGQfOr7s4ZsUzzt+vN8Keh
N50hTmZqOCoKn3rIb+e76IEEHpcBOOPvGVRly1iOMxCn3PPDdcb8EDVl56NxwP+heYE1XXjUOhC0
eYbGM+hlo4nqxo34N2N2DZueLJ7OSxuTOxi6jSKbRpIu2T7heghdx3ebGUSuD5DaTloJxiNtfaxI
LXWmj4tshDSahtI4uCwJEIdDgo7v7BHhtr9k3LeHqTAcSXkNQVz/MaZAtnmvbut0dC+n70ruC61a
ir8/LFm2R9F4+HPh5C3IItGiD1Ch64fWmrFLhbGhd7sovMRwMG5HlQOeQDoX61sXPInsbHgGbL65
73SrCHC4v/QD+Udxyk9mQq08CSHP2KQPxvD4DBy8sZTxOpq8oegxkk+N/EL6GYuSewWMmQfUh2Qs
MryKJL1GvCWSq4JdfTol71Q9D8/h5Oeey7xHoO6+Am1TgLpHk8CQkc5tJyrFwfqCys1RRqRYksPN
9I7AJz2eclpWmHhTaiPdvwtHjBL+dPHr7DukAavIBsrocrPeOj8nUbD67tvrICTtGlKPoX/48TVL
7VOaPBkYR35I1lolNB0h/f8uJMiBElfsNu2zVjsDE7bcr7gtKORFtVmPunDlSYff/1OwGs888+Tb
EOnXFh/q2BhlUAMsgSyZRWc+xjf+NM4gPjpKri4Vw8PZM4l7YaZIqkPAhZeY1qHz0CubhuoRtdQA
WF4zuLOrCeBAXW1ZLxToLeNn=
HR+cPpOTxAoMvzI36AfvZrjC/boRy+GETv7G9C6VkjjWaMdFpW8Jm0atNr84VlhpE6Fk1Hfx/iw9
Jvpl4ftj8FCDb3ae6HLk92rVMkJywrhTncE2/X1NAIZXTbAs5n5f7xjNkJJ225Vbz/ZP/fZsCSdT
W7XisIOkUgLxk37SFjue3PKeBfzzaS0rE2aPXKYGPMnlcMpL35cAyR+22q3IGDRYnB7fxocZ+BWt
UU6GrphW/l0MeqL9N48kw9bZi2/p8T+x9mcXlMZ5Nla9RYz5pknTCOm9jcY6No/yfQ0fydF1As7h
WntRllb8oPS0/AvtR75GTjEb8XRQ/dhMUlKz8guYAB/DdCxqIHhBrSgnEaQP86ifJ/3xL8jcJMGF
ndtH1jkT09e0cW2O09e0dG1vfJcFVMbJaQtuBo/+CiMsDEB7WAkxw3vbGQGD6Cl6WImOe/jcg+rP
bBKZ1h8XTo2lQV9S1zWs4uZBydDrEpTGf7GoTrZHsf0XPamQrb1J6j+5s+NizQWAzy5hr3X3cAlW
1eDhYz0vlkh/nic8ShVnRy95XNazpXTpXYn2M8T5DdtsE+SqhvVFqLZqDHFs75c7uay1U2pDLahn
XkEjm0NQOmz4RRWo9vaQFp7Z6ih9ZtwfG2eJc+v9eHQC4DbDWKfewLKeggnI1L1sV/yztnjkjNN+
zR02Nq6PRKqBBF/cIoE5xEd1sbWmgStx/Fkt89lN5VpbRu60NID/DwVuHSlRef2OG4Vw/v+dXBWt
wtf8h9/a58LRjMEmgTTN8FA0jEKqNxkY+PBThR1ow2lNxMDRxaWOoyB5BOK7kiFyK+sApaS43wxl
HmwiG28akccfDoDktxTfQ3DiYb6fyEENQd/rVTOzw3ddQ3AW7ETThXTLnNUxnCxc8E236DyGAMg1
Q3d7Vq9N3UwcXiXbEIqJB7V6AMt+ut9gYOVxigEgsVJ502+9mq2GBhQosgKhGQJ1qDtAJH8+sWwL
yCY5p9iSH8iOXDohHNsgehStJUT1tZfK3MAub2GzdyWk68FN+2Hu8Ea0HVz0q48hf5FYd5hhCeAP
hc5iUqad0RnQg/LgVsRIcFPg5zIwmqQ9Glb5TWn1GAOxmccCh6fOQCAqYXeUgTJg9drAsfKG3+TF
KUqpOGGolbTuvISeD7gwXyrOkgGBlHFBs1EWH88mC9OHBKLtJ+QeHvmDZpYoDtFEOQ5gDzt9MfHl
2kjv2uCWz/hLUYRVh7a6DmZq+YneAYUM6LL1NrN0icZAi6Ssb3wIJ5DAS5qvYUda1lcdpLzuKqog
a94R+3uHGTLMLQSHsqa/3vaPX2K6m59Op9lIDFIFtdEbpvaVJ2Fah4yknRcUj34SNCf1ekVVIKf+
8JJ/fULSjZFPds1PGtbuTSXoPskjoMpIYM0HFmZfsYbAdqqjMYyWEvIIGjuVwbZD2u3GNUApnttB
qJy5tnkXj7h48nEZgt4dxC5brrk3cVg9e/MPmmfJkZlIDqjPh0usN84gxBt/AWY2ML/PKKhrZcPL
QCqeSogZdt34JarNcP7O1hKxGsqtIqLsVMrVaVd5YVQ8IukCR7rf1AJPpnUsQlJQIfLIrCaDLXgr
4DCC6EtzWqnWFQLRK2bEUE9hRnq/hokB1sHH4Ro4oPTc5I19kpHni3Ipyc9TMoi8DsE38WpoXadA
Ib5SrkMa3r3P74jTbzoFDNllkAEiWhQunaaml4s1P/nuz4iGAhOnqQj4B8AkrG8IMGGS6CureyIe
bMkTk1qi/HIB7NXcXkU1HklJ0LlysuHpI9QfH8+N/IZzxJdSzPqCLSvO1FgEXpUq5g09XJXAB2KU
gZ13RrMoWe2H1r1oPmY4me0cPm6vwRvFqW2bdh83JaJdaGDyMywcQXvgIaKz2E6+imMyN+5IrRd3
cgB0R+BiyvZyjaL41Ab9UwGzqW9Rr/3wymDnDN2FtzDYMx4U6bxhv0Mx3ET043dNnjSnaPNC5y5c
H1mJRUW/v1b9s6NcscldR24S/V/GKD3EyL15lBIiq9Z3HmN/T/ZcR8UsDYgBXN9Lhj/fX0kEInQT
ScR4RQPTnI8G/DlIOaTXKx5FvnMXIrC27jXgfN8VaJ+fVsOkyKm+xubvh7jUsaQ8/02cw7IaBIxS
jnXQOfG8ZxFHf5XwiLWMmbE/lcIfEd1vVeUq+44dXka458YpiWzEMfqVjzyqyu1UY7x9QbLjPV5b
raCdXm8tEC6JMTyIHrcnDbv73to93guCoANv53UaJSAmG8Ze3lSG27DM2SEiw3F8dbLHZ5Pvb4nV
0NlL1IcV4J9j4KW5c85HOyooB+LPX2weY41bVfEWBMB/ODttKnLUQl5QGxCZHjFyJePumGegNMxa
vhOcKlWVaLRAJuUfzkHpo0FT9bAZgqk/LkK0bEDJDQGH45axRqN59NxO/WW4KtSe5/DOJrSt5VBt
rF77gm1fUAa2fmMRn8fRx6U8jpEV0+tdiIvnC41JQ9dlUsQql8H6EtXDLUpBRHVx7DliNd6vAkiR
b59wDecojdNDjN1kwDVhRWlMYiIeRRZbplkBm3hSfy91icq+D/fXDN1lzFZvCqjIvAjffnVnWACO
bKl9DJ5J12TUK/g09u/XbQqD6ktGJhv0csS2Hw9wv5X1uO+MVtV4UWW7EXUGZY5UBiSkVwEUAkfr
WrNPvaKadvBri3862q9XcutZXWZ1tHkXy4HTBwJFwLYsULDJRDTqFLZuUhvziOq7C6V2zd2WhW/v
XkL+nj+vDkzsBgfwsVhgliDJmtD60G+HMqr6mK4+fDC/xejcRJPdHdLyxdL1TVB2KLsngSGJLdnM
b6dtBPMG1h1uic7K2N2Kd00B/uZgovyHRwyf4h/OKY3E85cDOWQ8OBqvhULpOETMca3FC1Qqx0rD
xsMCBzj2kXIISFRo4xXLb53mU/9tgv1eZY18B88QbbJqkjz73aRs9WItoHBnxifYWRT7hNxPK2h6
sFGa1P4lvOX6lekVn9EPodVfCOXWVEo8r7qTwNxmfpy6XjYTWVtA1Bm871CF5DwD+TZT/qVIUa/j
cqJJ9uR5BJza31EpOEbMcs8zp3De77Kv7Y+Ipmb/4FpspAF88f6+1TEQ+KNO/90KqJ+THm/apqD5
/Abe0iDN0oK1yefhMKm6//CxI2865QACzT/HS5MKnB+qouRAmSIKzP44SEm4NLmJ7VCOBarVg2RL
rrNGWQxpHzNKNG85ibz6kAbtPDMzTpGJPWGIez/ddf4dLsfiVFMaVaPmyfed8wNQ/RJBe4ZTSXtC
HrUeQkdE7DIa1PbvPBQOtVbRJGJVTItJMTtcBR60ibR6d1hxGP9bMM4NSeCbxrEkTqDL4CQjncB5
GxOEIhXj7d8Ik/6WYSKpIlzYiSKhSdjpGZR6IGNfYrMs+rzLw5La/Ef3WsNRzLll08o1zRLag0Uf
aS58QAJPW8UNyVSGph4XseDBY+DR7akLfJr4/WfA49neRMAdeCIN2QYlkMd/a87OwduDh0WJB5m4
4k34nstUgHjbqdeD4N7KlHrj5aItVav7z7o9Ro2lGEyoUQjIzmPxXKYvXWwcwzfJG0wBWvC5l5hs
x97PBnuSLFoWBrMKk+wrvh6nkJ+WWZcn35mLf0e48miqX3vcZgdRlTvsv81qlkab0V1pPQgnYuio
mSFQnhGnbqh5/wn1AlomkuzhZKs/XYVR6XbouWgHYecgtyC5Bu2IuWxVPV5rg8qA3BEMUjvl/J3G
/Pmr07FCQWbSj5nZE93QvE2j80Om9buYfrsPdb640ZKGD7A9VzZnRtFvM0jx3Gn1FhhmOnPsDiKH
do7+ER0vPLCgHoNPXuAyK2TzAsGTSXJ69m2ld4+q1TPMVIf4DRodbVuUWkHJ4zZDNiGuj8v2XdsG
WNidaA5Zu8QDnm9Nw6cki483Kxhks72sLBGNNXHrQ/24cqJ7nNgBJAZbcyq/GHmBG1UF6H01ijsK
HaiJDkxfYwGkeGt/R9F5+GehWGRmC/OTbCHwpvYfKKUojduZpM+QPyOn2rhvlf/bVNnP4whpjbnL
Avy=