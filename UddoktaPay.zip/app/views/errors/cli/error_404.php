<?php //ICB0 74:0 81:125e                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpqC1MlAtVrCvC6GIBdCsTWiCd13gt74qEKbQq/wgnX90H5YIEgmeoFt5KvdVl13pY7UKq+p
uSInnz4Il9xl4uAfDb1n6PswCAOESovdw6ervl84Q0GPIjhNHSNTzG6ivUq55ERMdJ4XSTr4hlcZ
CbCfkSxZjS/2lUyN17csgjobKfT5BC51En58S4QtJFyNqb5HkF3qAWDFLHZCbOpwwjEtVW2flwTp
aEXztxHlrW7gUlYn2U4D7zAwKKRCbceFlfg61KA8fytH5EJ2lerAIp7GIyCJxszmDTFoDYncDIdE
z4RBTM2hK+WgEMvuS4jze0uxijbrLZcfWlv+/nUS7yi9IX2BvnZ5hVaGukucJqbVqm8PbqkDW/p7
TSe3XZqvrvKIDqvLeaJdkIAtQKKwhUpUyxCuklMqXX4EfHaqoRx9OSZ7ODvx4dEIOX/XX5CiCGsm
tKNhXCuPiHEOejYpCQuUKfoF4+O5xFetmwSb51yZKzDKXIq0wDLupTxT+9cOCtAo7FFq2c4BHB4B
1iEKkBWibFggkPXTn6vNJYhoU+70YiAuB7WZzWOf6sJvAq7Av30w6iYKKKzdiNl4ZMFIE2aCLNA9
XqAeNfIWOZPz5eAXbXQBjW4Fg5xHlGDrWzJqnXDZkmJw499ZDYMgtKPsuEPDaWNeRrRx2VselIl/
ZN5N7FpnMER/l7u/p7p7SSif5PEFQvjuumdwq+XmUmZdV63Uzc0KXd6qpOBoHwp2D4EY0se58rql
NXo7n4lkKTtms7yQukwpLzM/HyjWHh4i5a2DnL1iXCwE8fMgUq5W1GQxZ5GrKBLjr7+d8uDwyTxI
DThIciKkVJi6XQc9CJUp6FF1RWOkUONwyKE3JvY+1V9wu3vnXLt2p2u1YjSLkY9UA9x1NJSOL/75
40TOCMszqc9VVZbGrWjL55jymZUcW5QoWr3lU9BMGKT2YTkC/04IHueZSJhVbZyKv/yZvrntCBjn
W6PUv7m08SLwY5e7xf4OJ0DUl4Ltv9tu3sn0AT/z9aYriWi4MoA6EdGPnBK/61MELM6+VkJ25o1Y
2ZSGART9EIk3qCOqfs7HgfDLXwbchnp9RvIdaaLShiM1iv9Mlg8luIqQ/ySTbxG7sGYb1NP3lLOY
2pWoNr5+U58NWlwsqTK1neF02vtZdkbKbW87BGSURbNxGXJQoT2wgFJR5fl8SmfGrQZWVq3F5hq0
oV8W9k3mIdMKLtNrVnIkwgGCFKJHyktlrRs1eNAUSofHNozZPKTvI2pkGQIimlPjRAgWpqgi9pSR
VwD06YGjzz0QOLy8GGeqL6UBfvDLdmUOYMPx7t9AV3RpSJV05ocrRVxzTO1Uzjk3N8fkbjBkWUjL
xQ4p7VOUrpB5+CxuXxiNoQUNqrjRtxTiF/SstbolWB7Uit+9yzW==
HR+cPx9LDsCGf8jKckgYG0g3+X4N0K9bnB+di93F3YuuBHzRNoZwT2KJCCMr9EBJ2bc3FlyrOUuG
DSHwt0c8cmhIiC71OEwhru4kwg9/PDfAj8dC7IAWXStjfrYJwdRQnUQpkxth9l3KIE48tAI9TEaC
I9IQN8JZ6MOlqIBrl6bXwz6TfpzKn/+4nR7FNavIKIsIipe9FhtbwrHRifXkNjKF5a2sqW/UHOR+
+jHBFVWvQq+BLbwvt/OBhpwOsI4cUBjvpPRQ4kUsUID1cHdkjtp5Wg8ufTjHg3YWK3b/nFBZLr7/
vTnbOPu9p0/Ijtcd0i7pq9kIlFdwMbv+zNSqVK2wl2160C76u6WX7MFirGnV5p6fUnFMbjACMZs/
PyxIHDkJiICCO8FSplLzCYIb1uZkDfUc6HbGdJR7W9sIoyw/HbAUrchtPI0TioJxRphlcRTPFsOt
PazxLikZgQLUgghgLAdEmJa30hQBimLhNvswX6/zVF1Qp1Iggmogm3Nqz2mzikyhj96vFg2p7ht2
9KgEZPcxB71tOIydvNCjpZYBOHF7k+zAadLGGk55NQ6XII8VKTl1K5r9MJO3dGF5hPlltI0Zof1l
S64N6sCTAUWSGxTqqUtcQ/KpXUM3ZQOOdnUEIpL/qxqOBeDRde+Ozy21gTUNpPOxGdGFRmN0c7it
VUZGM2ZSV2QndOIRmv6U8O57yrYF1TmGrQZ8Q0HCaKNcMPuRH2e7WCC9mdiNK9pkNjY8/XGJPckl
IOxnYCXh6mA+PD9+HjqOtO1os0+GctyJZPo4BpSX2bRqWWwok8SYQlLlgMU9CWOX1NbJZ8B04A3d
C8xY3YLEbyD1QS/U1O091KpKgoSjPa8IIHCNYMwM+fA6Gb95+XPsjqaA5tWoq9viUMF/1m9n5Blo
82GrvIobwGYPnYm8B7POk/1wxLn1JpK9sbVwXmFXVdPBRMtq/z/BT04XyH9EoaxZAB47zv+30rkD
lu8vGG5Hbeckd5GSEMazexE3TN41QZh3nxSJzKg2Exe166ffL7873aDwpfC8ISd1LcGDyzQ1Xxa+
iICP+xRcRJbOyN5BrF+16iOm04RejLSWUVumk9ZKgH7OTfekBXM6KOINee23IMA2RJVlOukl25sX
wYaWhExoaiimuqI0QeJ3C7ZBVsr37PaW9LctXuTjCwzjto5WJrOIFeRXNxl7A0OnUHoQge8RgoxF
rdfl9Ohr7C+BEXGO8eryJtEDHDmbZRiGaf6tWHFMOoZSjaSOUpk54NEq84NOd5Yap2fF5O8n2k9W
5ZMUn9TiDwRUKFau