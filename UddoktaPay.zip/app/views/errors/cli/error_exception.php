<?php //ICB0 74:0 81:207d                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxMwAywL493X5ts+xG7Zl7v13V/GhZ/C5OpFURpDU/+YTZk0Y9ndN+x7SQ0ufRcXgOw/kvfg
5AWYqawp1xoA5CFAAnYgoQCbXRMR9Nd0fYTKEN+vTm5rbYZLBRaGn1UogbHxg2LJ2+6UsfQNLMVE
pTfoFze0YXkfzR2TQOFzCvjUvH9H/iv7vquNHrRdEWUfKOADXzHWd+oe44Uko8R9gV8INpVxTbmH
7EDBtBhRsgncdXVNstLGHeXZintQQr3YvI/AqApu/hyncJvkTdp+Rq1Hmebu1bmYK/MiYxIS0MaK
w9u90cKbw2woP7YmpdX4r9azDi0cqQU1/dfGEWpjiCJlbR7N3Fu7s7+xXUC46PiPSw7rCoAKeDgD
mT1nl3/jsD5qI+Dmf6CtW01kjNF3jYLsLf54k5jnG8J0flWPzsORMjop7pK2x54RBFoQ04okC1wb
BWPnBrqjCquFWQWgNKYn5148zzNE/lP86SkomZ+sefoIo8aQ1fSm4lKe2XletEEScoYg55ran6Ca
1mpnH2dDDs5XGqOxBoYlO5RTtC9duqQ+ZXL8Wx/xnaFyVEaHb8oKlk869jaP8z19Df+3cBlTEnlb
AgI48CtyuBAxftgTBra8Uev6XzVILjNEHK2KIHQ70K6AFpTAd8iXuniJWOW1A2/MwaRE0n+iRJUV
GzCSM2zBHSZwDy6oXj8lkSifuDENKxaL8sXAsnPWVhiNfJ2AZl3i1Eb9WVANWa35gbyMOxGT4+Lw
5SW8V9X2aEwawBYlqC5o7HQq5e9cRFZtRi9e/RMEMzIenbBR9LnbJGOG/WurYGEuXnyMZLLl+ntE
5oKT8240rF7c1GUeVf/BYjK6wt9y3o6ZcVGLlblOgDS7k8yiOL5mBBOhJyK5XnEmKQxDd89PzD4n
9XqfGEdNaRgFNcT0yPEEHoMUyRVb3vBqxBC/Qw8+VAxdrE+pWEAoWncXWmHtAwtcT5ajzzxLw0nm
oINMWDZUuH9eRX36VC+Uiad1mBGYO4Qm1E2xDMGXJ9fvTa3tgXA12qSqpbT3jlce2jMQO7dDz6q0
Wm69iOuLNqRg+bMOWZVfk717Tp5yaiTI8W3T3IQnCOI1V+0mprZILYH3KLFcbz4XRIpnybjzMODG
fJbM1Q9+I03qaZwjQ89ecv7Scxtg3GKk2etzuAmwlw2UlcNEUJIPvJw8bEAbiXcT4kxdbNVFFtMp
tuqpWx8BJmjNRgNdJtoEDWTNCQVubcV1YSDt7SPKIQUmcdoe8fjIs06LYYC54j1JwC1KubtgsKlb
FSRmK3fXROoO4tWC7wcej3TXs3lK4IZBDimjpzBaqwcD4uM3Lr/tjfA0ZOr+gyCDbEI8bdw04rHy
UNzeLcOwEW//qsdlGOi+uv70HAYKCA/VhrtZvU5Of2+NX5KTg7oox+U3CD8wgKHiRRLc77OeL7db
fi326aTj+vbxxCVj1vJp+Kwvj49ldJT77//Figs2QMw2q/yVCnlZjpvOuYVh7tkGhegqBgRd7HfP
IF0k7FdGndXtVqaKQhdny3VBKfODu4lm0MJQ1hnnwTJ82S6I+S6rEpsjMRRLunRfkyvHna3dLsqF
853I4UOPfZu/mE65iHEoWpgmmP9p4TuVua4nuwIDxyjt0FzWZo14JgQPcy/GB4fD+rZCzIPCzVeO
+fq55dvtLInoMlHDkXcWKAS+OD7oeIYj40go++1ZwasGJRN/5F+wLRwyQCPN7rtscTYdux0dM413
048s4VVKnIL4HXxll5nd4xoFJGPiTqmV0iH0OzCpcsSedRplgVRQQJXSZSqtOSmXWG36NRgQc6Xf
MO/tdj6vns6vpozM7FTBT9BR+ChLys7udlhj3HYHhuJK1Qe8vjhHfCwy5oQaGl+FdDrDTP1JXzyG
JkyEt81xW0sAaZJvR6xfMBmnbZvcesy566wpyTd2bnUJ2+qjTeQapbv/I5FYwht9XeCuSsou2GJ2
SOEBqfUuFShj5o2ivbL5Da23nn1DXoaDQnF4oKcSpcSX4MbarmdyVl8t6gZMptRr9P6AEi7pPhT6
CkWU3R2qB1jj/srdI1WvhIaW0dLdYfmPz1fV2TNDLFOM1aRRzOS5B7r0wfDkl33hbGLWniONdSAY
U+ZioTp0KnYnbEiMASwj0RDpTLwRijyolvf58km+toVfOZuDo9MedvHdu4xNIS0MS19KJhGIVXeF
BxVeINkWlXNJbzHmnZQ3t/rBM0WWw963ToNILIramidAWq//hy0U7x+x6P6qDDuPSchi4f1WL04k
J+dgiOdbJL0AXCFOfnhf1q+dfvfhvot18rV0l8ddmGES0vjtFStpPNa0WuoCGhgt9L0SOMXkJw97
52vmyZK3usNZaR6hdMZ8oE8l9kj5ULC1eJ8jY+HIfm9SJ4mbbcsV32SaumXHtTyVI2Q/5e7l0Y/i
9OmindsjA26/LNvicefLB9Rbv7RUV769eb9riLUzVI1XvYLaj1uJoYQx0bxp39Mi7X6jlo0I6nuD
jAuayAUswM6ObapaYP2Oj9Fr5zk7QAvQNwD4nR9eUlAbVwYoTFj/vmg8kmYF0T9sRRk44O/VqXil
c0GszbqiwY3P6u809/t+Jlqgw7yuFcgj4K9sZUzbNmGfdvJ3ORVrbIst1OKsjcURhoh4mzp003De
PT/l0Sw9KxBfh/PAC6pB5x9p8A7fWWk4+hOipSk/vwFn9BKlMG+S675DPOkXiEDmUBKgcUdjaf7L
KPtj1PdMjKlyr/cuMxlbTN2iWHyK35dgRjBsn4GzJuOxXOjqbn72AuEDQmxp0t3G62kqkp8uhZi2
dND6qgQc+uYCTivbA8D8v8cJ9cs84TxKRAmBVKWkhdcuYzc0MlSdZFgWcCAspz4FuqoSLFS/Wc/8
Nk+EmMt8K5B+Id3SVRkdxiMpniKnEmQ0+N93wJb37gD3X8Ec7C9nJsU+LTZ9FlU716smjJq+6Vdj
zHZBzsCD2wDpuiE4q7tguCFZwSb9bvMkRrd2KfupcmjeGxNLuqxS/1wmX3aredInfVgRWYZjSzQp
TfIzyTno+FDIiaxOzsQFYpQ0+SoInaGrZpVFdjF6P/+TrYpzNFThCS0JWI0vIHS+go49Mlx4GTCo
cSmEwKZXPNkbfnQZ0EZoE2ePM13/YYdncTQ+QRXsYws9gADsYguJYWrZ1QjI9Kcq1ba0b9k8cvUa
L/u6XGYPl6ArpHH44h9UUiH2ZUuq73L8f2KrghYeXY3qJsCRuQbt8PIS15MchHmufFLtXAnQneFb
O20boXeYipsXtilF+hiifxOP6N7YkNoo85Na6fs2kT37+j5M0OgDQa/FvY69cnYZNbsfTH53Zisy
MwYdRD2g3BeFOZX/qbkXe8CwExsgowg5qBiEOqWkxB6KMTT02nCRwtToNA1ZwWkFA2pT9mcIn8Gu
7OCXokBGHm8lTiSQjGwzPVveJr+oAT+XIP0L2xA40KDzzeMIZo3KHxU1n3XbfpOrH8mstxKn3bNP
Of0oKaAg03u+RIl5CEpZ+Cw1n08PLMHluj+9Q8UH9EH5t+MIdAWfj+hj+s9jtkzz8FrNHUMOgxiM
5sVRrqDDA00KNwsb8jSJBcJv+uOdxLJNFzG3Fe/znR1CXuCdRNNBrVAulSxQoqv+ERkS4KAN6zi4
sJC1BNU75e9CWYvUn2UBgohfRjXc+I99t3Vu8fzz8pk5yaYIWCc4hyta46cALfd98YxLqGBKUcTO
IR4CLXk5bCiv71NmFUoFqFWeJDm8PFGaa2awFXBOapaEQ4K1e8KBTmNYeOSfSvSNBWdHqnS0AJC0
rK4N/x0ryaR41KBOs9k8f77yrdDKzL5DmAjjWMdjtkbZfolByauIhpSGXZ9S0TwluYeikCcVCCIJ
gbkqcEsubNjdGpbM+smXbLlzUrV+YDNJrxt8inC1iaz2ZCA09mJExH1tsMddccxqYaUVyAS+iwLi
jGKgsTswMynWjRpLiA95PAAK0A/NMDm2Ke573UeR+0rISm7MOqJvw2FbDlAT42H2Q21/0g+akJbI
fPHJ0+8P7OGnQ7k7m3KYGhmAmPDinxJGlH1MzcrceH8XggEuCycHTiDNP4B00dbwvuW6rhG6xaeP
cbPYq1OJnrgawZIO/giO8mMkZfY/c8mSfIgxHO5C1LuO0uJInGMV+dmwTApt2CvdWmpeQVD0zLdl
dffDvaSH4/211VA/5C2IDcCVSCvWRIxWAzrlggy2ybUbL59vmVsT72Se/GfKzPlr8MAgorSnHbCk
HWM3u4GF3WfHtkhVKjLyIFUCP+89AqY2tLPgcYxPR4qSMVXArh0YiFbyKGpye5NMmcUz8sM7LYdk
fYba5X9T+ngW4g8uZwITQdJEZ9zKiBFtgsWikvOg9QFrZX0Phi+YNefM25wd4CRkl1URs7rFGRLX
09xZGDnCsCRLqyQhWXnUEue++gcQpzGHO4JgMmhdIU3pmV0Gs1G7nQcXSZ1IrUiUSpM3BveB0Ie0
xDu10b6W2U081UJ2X7CfXNFX0rr33U0AnWSp4KaBsy5h9p1e04g7uc8jAJq8sUNEbMdBQZT4ryGX
8Qgzg7H2Z4PSn/NHhSNa5tmNr9lmjGWLyfRVL/wIUHoV6bz8zDW7xTS/TYOKVQdElYjIj4hV9xwZ
kjQWqwWQ5XWGh2ARrseHoF3JuQVFZkCl3kk++Hyv/TSiYYYbv38S0EokNIA1ETXguNfFE6pp3vT9
iC+7/OFGDHw2yJCerNjkCzIrqGPuEi/515wdyR4562Mn5tjYz+TvhSTNwTbPkFkXRkiNTt437hAp
X/ldB8dzV1uwSfmCQmjIxYyHcIrpysFAJRiZaQpSmTKbVIpWlQLsQLVQSbXmmyHtAVkDbJtm2O1i
NpgRM7QHGTCf0HaSvO9K853rANt1ahs5cZfDlCmCPGFkCWRa7cOaeVGRFoJhBlffpctoUnyRlj7U
eyhcefP/cf8ou10vKUX5OUkRGU/gppRMYuWLUZbbbRvUmzIt=
HR+cPtEyb96AWMsc90m1iWD7SLv/gY63RQaICSGp5iNBcSJK+X8rSGnFiqo/7YkAeOCseZJUH3Ff
nRHpZZ32gvGpe65WWAcDliQFZm9AqVtrX9kFvq22QUw3w28kOEwjq5lY6Gt5PSyRNnAS+FQ4Ss7p
IIwNYUIkpiQTASbUk3ibki1uBhErAW6G50yN+lKvYCICp9UaHdn++XiWCotsuIcQf6emDuy30sCk
r7NSTr1NPA3lZ1mOkw/rdy1KxLojydFuXbFnjPIRUcuF1rg4MpwibFYhIPjIaMLHGbJNuFJPQJwc
vEyLZsdnjMicClHrHFwTbY2OaJH/qEBNVVKW5xHEreDpc1/fGGTgKDyHlehDlqZ3MsXYW02H08O0
aW2L09O0am2I09O0YW230800WW2F08y0cm2B01aCFw/9MGTJXEZ4kArdcG2I08i0aW2V09O0d02V
08u0dm2S01B0EYc5jHoU34zExffatFwkoXxsUKNTxF/wfjmpvbG9s+gCT4JZzvBkTwSu4yC4W5+3
oSIJrI8BKqF8iKtpL3bTW4wZvhxOwk2dKAuDILE8quS+/u7AYXXYHN/fde7VdhIHtuslphRhrNHs
bARta97QxEgLuFAQz6OdgDGfUCq0lTHw8UDZ5u/Q6BvJ/aXhOa4fVl8oVbRH+r1m5wW0OmEgBrda
r19LK7u2Bo3NpcKfIHgDnJrEpUl9vNCIHDTPNX2J5IdCdE3GlTlB1A5RClTKY8U0dD5RuQmI4cZw
GdpzoSPt2uNqL2ns/LMp6PKXKblbsrsWlE8296l6yUbgQD1hwCPK1VBAYdKS9eeN3iqtN6f4i+8t
fjXb0Mts9uD599Er2Zf6bTvN1ehILMYGxFNQHugBEz+c38Ww84YGIvxuMHO8O16NslHDbotzaiqL
LRfPtIzck6ce/Ahv/ugYtlwocSS2FNPQoU2QCSTcfnbFe+g/g0uibr/VnP4HMFtVA3XUcmI8mgg8
xwoUXLI+OebGVms2qmx7sPB/+zYuzK1Uy4lScPALGLWZbgQ3jbxU9EK+o7OjrTGcxpTCBIoxFM/0
KtE6O1ZP62O/T0HDwGmEhjw5L/mCOY8Shpt+uBDPTK6k5I04VjyGiLMoi1gSfeOhaFVErplpaHxW
6iAvlG43mQoTpsnKr4G+9kvC8Dy2d86/pXHhjQLeMyj2MoSXxomccX+lbcSJAXhCcLz48kNEmvfK
OPGGgeYw5uGpX5GFEh5qEsJ2TsNWMJ9QSyoBi7bFBuxeTQ2ctG/VdIAeC5XfJqDVznKRFYX5iINH
Gq8sLZehDsaQ4eqBJvP9LCahgf2wWQj8RVo3upzlYOiMaCZiVB1QwWmUMRMEO6pBhNNuZ/YMGQrF
JYvVFMNHDD7d+O8ResRJ/UCdZRjW2KPVs5RAxjEHqO1VPWjmjzHQ+4GKHnuBcHa1y9do9zgCsY2r
Gcz93ssv5Fd1hjQNM36Oriu+LOFBytLN79PlJ2Osk+DadAF8QNuzLkZgods5x+WVsyHLNs42e3vY
Y1qq/B9PCdTZFYhcDw5lAmeH4weCkzTk7KmkXmdTWBuuaUyRq85j4sQWW6f9OGTZgjHr9csr1475
+ThpT1bG9WoihjJNFYvubTe2PntW3W3Jc9wFXUnRwOhtOGutOUT1tpDhJzJz41lly5XKZCnylv2h
URKZShjlgIFqaY1Fj09D9fsD2+wdIRA8NTxP1HZU9HkDN8OvGXQzpLeSO8SaRoAhfJG1KTeAd2tB
hPEsxkFPt9TjQqWP3VUbPl6HvIIm8sNY8F+3cg9ag1r54mmhkw9WJY7VpUvTO9hnxpybDopBdnKp
vIrqXmSqovyXkw6I5zB+jAuDWUyW8UoPuKwDmZ/uZPeHDB7SE1PNm1WayTcGCA0Jx7uhlTDNc87+
nCt7pAdvtjJCu4U/6XythOzotF9DSjo0Mh4eAXeVQYwFACLqJEyxqXqT50oe7mA9uF4c3bkWJEYi
k+d64atxxyE8V156txVzgTOcdu0f784Ja2yr/8zLK/QqiPw6i+aZ6LSdNhKQoZjxR7hdb3EjGWBd
ajFBgzCNzBHvzHfQqhKgGAecwNoBi6GZ56gRwxlQE52Pof0tj1KnPAO8f3JeXoer5M/G/ImP/weH
bas8Duvp749fdsk1Zf/+HSXkq2DTrcXYdEChQaj3N79mSI1Izta0Y2swgCqiQSkUC7Uhq89q9nEA
aisWWKHUBXdBmb738rC5uKbQpqZIWUyO07pciFkcdNdzqswCKlUdXwSDPlAzw+axIiNXQhbag5LI
VLkWWHDxbLurg03utbHHG5G7DzMgR4yalk5Kv7yuWNegxnh84LiJN4KC07+dE25ABFDwBENIYdUx
VfIN4sPMfGhWRC5U1dWKBOZmnzhKvynZvmeJB995FkwoiJ9WFa/JozpCAa8wE0O3AMp6zSi4VD46
9OGo0C41dsGR141QLOxGmyMBbEQ48KI9W0oRKOjJ6X3hYD8P5jS71Cy80sv9RX3YKSkkI+TQAiJZ
SzW3jkfkhSlDsW23b72VGx5PhbARWcz91ToPu70xKqG2Rs/G73F2fgvuHRX5t+ZTHqFe0fV474cI
jyfZtHzNRsAo/F5kEBpOHJ/6VuxJRLon+jWkQddk/hElhZ2HvPDe5tJKph9x2erlJ5I9UOUfcoHv
QNlxWnfz8gQJ02ICBKnZOuQq5wiDXDD5IDBhJyvCkZKbDj/bKabW6fWLHL5pmNFWXu1MWlWxCdtI
IBqQR8q496V6zJEXQ1gEU+bvczHA1GyhLGn/jmmmLVop6IHd1Fuku9Vi8VY4tQHdxPF0K2qtsi5S
KlyUG9xJ+5hz94NJnFbWm5Pa9b00J0ok576LRkeoAvBX+Z4vabS8o/225jJx42JIfGZSODngPtfw
Blmuua8ci9OSfHJPj1JgALrY+6FCTE8svqyb+6115bVyTyjEWefDOav3vwnOMKJHKOly+nMQI2gO
OORbMBmenFzB8EcxMIE6MYckarp+osaBTqSfblxEAkDUfuJDnhsfZLSBcfjEgCHI722FeaB+Ed9O
J1lYYuxK5vNDMmAMA+//6dbJ3z1YAiSCBjXED3hYi1bgNAP/+YuaSjbB3mK9TkoIHtl4JqKefkj9
GF7KE2zUp2RAiwTu7TfPHir1c3KIUh7xGmH1zQT9/r2J7puCaX1BgJO2sg69MBTxe1RZAvyZal/c
O2MvAlMgWhTKYWHmJanv2TYxjI30XgfVnpPORn/Ep3ZjH/cJBcCGRL9MxZQKwAgMHSXsTAVYFtt7
mr8r0YT16XlxaGzupURketFPJHx5irJ6jlP10YaOR1VgD48EIcaD4iBtarsKd6bpY7jmVCyirPXb
BogzRiSqAVywQzMbdAnzLZ28Tq3HN/BDcUnl2q9G6KwJyLdTR1+2aj1bRIZs8vH15NXkyoPALOp8
jKZ1ZyhEGb/bkIr1VsqXNM8/7xsD3J+NQ0p6sSgzQxI2sROH03tAGPrrOZXAyKbjhe02v9RjufJO
OXB/Gj5UOCDhRZqAydbwbNocJiWfZfKt4EAOeEbdg7OpuVFCU1ortZgxvWsG3jlgoQi0vIjonNKl
RrZEeOCOAqrqbntjG+yz6kRiFt8EP4x/6V4xgCUcCM7VlTHYPX+Xa4MQO7RtDjyxRaDxwZPbjOir
/KastPMpRtEMvFtrVUvG+CrUZnS4g7yrPDqUJXIF/OvBq/sDIBmUwVxn3Ejjd1Taq1eUZvKtJpgY
CLu2Sj6/VC7hnIqRB1Q+390EC8buea/fdmNRsNpiFbX97/jAXNOFgtPQqLmGbkJ017WilTiPyF/Q
afiiEf/3q68B/lwTab13PgywfnK+JX68j8oMf6iHTlyhp4o3udErKBfstDR799bfHWfRDX1LNSr1
ZLtK6GwJNokaAefzQ4sSx9Tjp/U5qg+H2TqrJW0Nv+K9hldqIwdLN33y73izbkaNPWR07bs94sFB
0dnB3/EJRrgvdGI8YjTwGbyZKUq/FYFO1YmMJ5f3TTq33PkKxv+goUvjM0F/SOo5UaDvPeFTNQtk
FI6xw1voLjBq9dgPHbSLRcnfMwniBArHOR7aRRXQX3f78DvFQlHSobjilxNIEhRx6CKFVoqDOaLD
N/6ORNLmgqwamTBj7D23vs3fDvduMYFEBDb+URIRpL24B8xE6KkiOkxcn4RpRf63ebJkDUx9KmMw
IUCL81GChY26KDmB7RiiWX0VdDZtCEIimTyR80Np4rXbdaRelh2AYTe=