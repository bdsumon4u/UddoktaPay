<?php //ICB0 74:0 81:1266                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwElCr5+/xI8Pd1Yfd9qIXO5vC+wQRCjE+ilnFjHmuC58IFlMP8LB33JZA8noKjMiQZJLZXf
FdMr/7TXtQDe1xcJcYIxY34zxX760N/yPVRDrBKvOpuouV0XN3U77M+Zh53Xr35aDeh74sKYlwXL
DQYAqmSPeK2kADQJun5vCvdDfdFji9kInwAcU6vbPK225oZ/bj6ma4kxm4V4liTpVd8+Syg6oLv1
5YiGhGrvCALFDxu/mmcdIVVL5xLV1hEqBTIE3R6nbNvK9KU+0zy7bP7IlSKDx+S3TOB9rAxTf1Yg
MMfD/gvrpnoMorBWTobsaKK1VyPYUAQ/IxdyV/vK/oV03bXZOb5DIhC4iEnoIwuwXb8Q/jL6D9Q9
G95XPwsegKys7kefKmLVcja5Qysd1FFvppQoNFxImbnnCQbdVTAuYO5nTffwZvtFTS1l4BSgwcEg
QUPIqA7aJkZ8LzNCjI55bDmudXJQFiK7Kv7fFJK9fFQU3N9RqZKe0SnqojOJse/LstC283yeST20
pty/KJ6FMcF2D8cvlY7kDjpJmPh/G70KpyLpO6kLTzNKHwWBvTlHaiR1Bgj6J+YLE2ReWL7afGca
sdbh8zIgDhEleja/V7iCyeMzHR/kZ3HOtiEJpF3yWAKB7ojd5I6SnF1r4qC5RqbnfPFyvYN4K5mq
xZ1YKK7/yVWQaBuodNT8grcRRG+Pg79xkiMhy2n1Z38x2oPY9YruMdo7rC0GYm4Xd8qk5TnZQ/8s
rd9WrLS50OpaMb0SZwmI5fv/PtNLoJQPsrEPeZsYMHrqV3rIywrHDzYmJx+Go7wSXqUAaGWS0IlY
oukNi3rAqSyjFj2sgWEdR7YVgsfUnlwwHQep/AFXi4i2RZ0wrQK9QfZA6+yryNCFIS7BCOPBFUe8
rAcuUyb9MOvc5+B53gKwh/8EkgDEl0ehwNfE17zKRl4PCLLxSCTq/vW/3ncG3vlI+soU925J/aLO
xcokrp9UoDBjg7vU8RnrWSS2h13UaPdU+ArlXjlaAwkkJ/IEISgg++IT63sh78AkPwiwxwRf1kAb
8AeZ5klaC9qfu6hfG6hQIQOmbWnZ5LIhqki0FLqKOhPHZ5U3zwpN2NCN1nrASWjnERslhe4O0wmW
2U5udkVac6MNCAB7Sc7dd/hc4AkCo872k4zCM2hnxaATFzLMufbd1lv8yWjys4dNL8zAlISvRvYd
8SUycEn4g4EgcRS59TZqLzy2wRyKzxspThn4eYYxaUQSrQ8QKYLFWSFxzvJnEUOefgv71IiH+NrQ
4Rbqsb7XKnsi2mZ4Dex9klXeuplkpELzGNrX7wihHZPH1jNLTq/ANu4pOjIg9J4TSdQ5ZwnV2kjB
99hUBIr4sieo7P5ltxbx6RWBAWfO6ntRo9v/U7UNqGLdlBLbt/NdgHYKQ4G==
HR+cPxCDH0WIxBmldBBHAxmRcVVnZYy9w3gg4AlF0pf/wwMlmSKORBl6gl/seSNqezus2E788GMP
8xLBikm5MuzplAwUzi0qVgwrrQrbcOzT+onnRb3euVw8tMn7qIpA/uUEQnsMsCrtfjQz8z4r1RMV
gIO6HSG8eGLfJKJYLWTZu4N+3Ouq3glC1gLqkBETs1W6evW9mrMd1X67hlar0vHXDg7yOxK87tEX
cuGwd2TNgywQJW2h1DPEA9ciVsddOU+XXW8mj0yP/UjrRb/UASlSTblAUgwXcYfn6ALPI1SF0nLL
3uagyGb/mehIItF/yGzQpvUXjKZhQbf+zJ//DSFmJaDo0BrPkWtYNc3PFW2RCnYRsT8wcBwuYVVM
0Eu3z1ETG3PMrZMEk1po+0g58xKhU4fHfgunH/7UKVStcQoiksRZ+Z4wYZ6DTWtvGQ3S7ZTDyMaJ
8GFGHI6qiEt4v1b0mo7M+2NRKNcbo29b+kM7qZX6+9Kz1z/f6TNH0fALptctg+AL0Y+D76C8Xfq2
0n8gNDEwcLdcfH2bHlteMH6ZHEsHCjlFFtGzae973xfPU+Y6DJ66hUG9tt0aVHFSzVu/QtgG/loN
DV/7syQfPIgKVQ3Fq8XUYiVUhANbenOSKFXeteLaa1iBwLvHseu6p1MF/sX0i8BDH1go13gzJqgH
6m7vh6oTZYzxzWI+MsEiqXjNQ47O6phpQjQ9bk1n/1HN4vpgEfHsZuFhvbdDCJP49bmdhlTu7XZx
of60Hla9HMPOgxXSI61aAOzbVBI31zA3uw12b6rg4IpHs4XQO9lRunTl4FPHzTbrog//eQhNPt+0
XZldrKsGUAV7c7mimrtqDoO1EROJ1RJLbTX/wuAUqiCiFl+pVMF4lqb9w7SzSHzqi3zojCsEoASe
xzdrFiokz4cR7o57dHJXjZ75XT0rGfxf0U7PqVrQcoqMmFQtAcK/30EEaMReUBcJ2U4Eo5IlNA3I
h9RaIZZbShjoRTCZPvMHJFybEIrF4y6sf/S+Rq4DGGltYXBctop1ztYPqQsS6X1OkN7zoUqU0C0o
wjok0HJ7GTKpNHNnbWVs6Z3QH3fNnpsUz2PHhu6633GqJXpx0dkxZIfPFPtEk3uMrgESwO9Y54DK
kLU9fBXF4a7ilFmD4pGcDGZ5nolfhPaQKgstb9SoTOtiT8yIbydEEop5B/Lp2E2P0cD131tm/Nfe
+vso/ocEf9I2DVGiQCmViWwBwX8fMiHFqbBAeTkO/MUvHg8AHBCkGZiT+wfBLuOcXe0mwqU1h/rX
wzMZCsbWR0==