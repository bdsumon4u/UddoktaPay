<?php //ICB0 74:0 81:126a                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPx/plwP+K0I9S3ugXGZM4aQ/wNnJJIYgT8FFsQX453ICnTtbPJJ5oEPzL9lRNvuBtj7+NFcT
ohjuA05B6gflc5V0Wo+0YVOVlQ06Onan8kXvI10DhWEyYKVCFjAN3No4Za1mUVAFMEwlmC6tiZlC
7p3EMr4kgffKrjiM0BJsgPfz/HpSPQDJDmWTiM/bYfiYpEbVwbWeYkEnuldDtboN02g0lVb01H+C
4FuhBzoLbG4BrRIgng94tJSQ6D6/LKb8rLusodK/CCRIWEO27lIli6kUs8u6KzmAaK2HPpZvVzH0
7lT6NmxuCsv/LtIbbMr/pNSIy4pb6G1+/aF/EOU0fVwDtBcIPKQ5zmgdDr8VEdQ7Zm28cRskplaI
X+V6AvN53kCFBlrD9Jb7N2+J+ZwsxybY3m6tcsNtgYPi2EnUxLqtc00QbA4Hph5uk8VLrihhAIcw
pAiowQ0mG78v6TE2yliJb4F4J0hLvpTmuyNzJ18o2JSlB1HiQ+zK8i7HXLATr2iu5PrNmHHFyLLW
RbPUe48YvgFpjmfJcnyVI++Z4SHf0zRuXY5pyabLMpFFPi29VsTAtaUqeYZegUGTceZqjbsaHUj7
oY6e791h0MVIhpfe0g9LDh978DCG+o6aam9kZdrWQ4ziwXk9w21MyA8IWrE4c4OYRIeqdomZ04RI
GvelYQnd7O2FVTNmh+XQxqMZ1GxFWJC4w9Qhq57pbZIVIuLTbfAbo8yQqrrgrvpvYkG2wTXTRxyL
wWpdqK2b6w/kgPV3WDOKd2II8TIdDeirRq9PkMybbAhPzJFShkX2oshuYA254oJt222dRQJ+CWmY
IhLnBkHqBGe3E/x6oSWYdx1t8NyNUUN+P6hYqEqh4uEVHR2AjsJqjtaikhS+U/SEgXCSQEhzAB1d
GDs2sFzeKRcySD9vf1SarRuz5K/+55HfW0gvvwPMXxmpzCGqB4W0qNUKzCAi430zxlHad+8/pIe2
dfGg7HkqRkR9eYoFG6ePttzypUWJ3MZc+PWfqEK66VKc/w7Mtzw9xgH9YqlLtTvGw7HgvhqTrSEs
45iFEFAFWeBYI87aH3CrinOz9R9+Y82dElEZ/6KLE2eE3H+QEe0NOHRf55SCV6VEjAplhau2Zxoe
j31E8kGzDulNYVfyuDPbq6rzVzpPXXgMRfvVcjC8FSre6VGtkzS6NbpOMfH0Ifc+OtJmYgXjxZMb
So8TjXKAS0s8nuIIcjlTAzNPCro+3MsDcqnF/U64X2YcWtMlfVQ7ZUnIEN/Y8TaEJXproyrXHoD7
avLJPIO6cqxQO0QR/brMwzNfgCPG7tgdkZFpaBeko8NIFxfA2rxnvRwq0R2gNzB+ItY8TIxxXOMD
GmgNoNqbNE5NPh/4FUqeSfVG0Y1LACArTM+0s9nJ9KIpm7JAKJ/Fc1S4KwrHbdFB=
HR+cPsPjdXSep69OGj8BD4DoE+NesHHMTN7DSVMcI91jT1kGwbwYQKZtpglWMzNaSAGscvpQFJtE
OPQXKuBPEXgK7FCV2LoaAmy9bpluqccT796O/A1bblfCBgnSYXX/EzsjANeROwIBqqIUWplkrOxv
fMNNP+/R4C5ZC3vkXoP+zMONostlSVt6iMUoLWbOCnKCcLMMNnU/D4KARMxYmz1qxO3dr5XprJq5
e3qO71Hmq7KdnkE3p9Q+FkTiEae7TPrthOGeSz3tUovruFmhJ7Yt7UDEq3C4sHxl2O95DDggk8C1
TJ2eY2lBTRKlBcDoSX2G8FWlYljmkkBNUlLlIKN0DjJZ9AdHXtUAfWm8bUWpILHrL55puJ8DocSz
IjwGHAhiwrwXaI6akq3KdT5reUz0FnbpkK9OcFekvjnjv428mMIRcXZMHREFoIsrIoAJFoH1qOIz
HALB6EB6/GhUz8r3/YE5Ifx8YPPc+bKZ932FuKhWJI9YnCH0oCD0TMX941E5+iUtvG/19LMdzTL6
9kSYnNl2yIstYeUnNuCiItg1RGzzmkBRaV3Z+9cJmirSXvifuRBOcaVC1ISVGmMva7gu2J+WQCoT
rfNnPbmEjhnpyy/17k5MNA+X2pWHf3wzWdE+InakOKqeSNzsfdgvlSr2rDkcbB3LORqYu5JFVBV4
Fn1LSd8DFe14luGVZcC5cpkoklo4PzqkEwhet7ZT/zMFDo3AVdGD3lvBB//qIg/RADmMB/Q8aV/G
gYrrVbjzGUeEjcHPX1ysaVPsPBoCln68Anl/VMSARf12IgbmdYj2NnE6/4VZr2RXaEsvj+DAb67q
4p0JB2yJyp4OxvULZioHo6mFsYVpimNBrvAg0Ihr5XppWlTTUiGdKxyB/qNTbzK5VOHyAB0mw6Hf
Wev9IYXPzWpZFJzqLRrmIkL4kjkfD8Ac/MO6U7MlI1xRYe48yVAJ/a3XRprR67q180SwOZ7idqWq
QWCv3eY5bkNUNIfwSoWqoJVIR+ktV10U4ESAC8AYvVl+8M5m9SvMPL1mJkAqy5MWTH7w2pZBShiB
Hqbn5rX6mdJF8QsNWxKpLXFMHpQm9tUchrXSme6164YkzTsaC2L8XKn0eEQMpgeNu/Wm6OjUoMt9
LJ0W31vBhd4+kSKqSLoVMa+dWGLIPtmXWe9nxOuZ1jcgR74z50WHKUTX3HKQIuzDRVb40aYAkla9
jxYw6e+M+iYtrUICRWm6gNlflQjbL1ITJM3/ZsJH1Ue84Gqb++DG4nz/nK3trFw0Ssvd8NA/siHS
4jDxQ3uIqIAsXogoj6An2G==