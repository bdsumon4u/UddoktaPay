<?php //ICB0 74:0 81:362d                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrz8gn1cyoyd29y+CukAlt44tclIDhFU7iD6+DkNxGCRb/oDYrz6v3y7I1yMIUpGdUwXKdiS
QTtXFZPIAJ/9sb16D5BMfHb9tLpunkqwdhX5WpBvXwI9J6RmtvC8o3wBw+9xjuhsImIfS6DPzpPw
oXgULCn2zu7LFWFJz3ZYqafM688ayUg2Hj3MLJt/6FinGTEbX/1tfa+7qSEvGLijBnryW4EkhxQQ
pu/NmNtNmTxEL0alIo/v3o3rUM3yXI0Y9h6p8E4tp93UZpAqdIzJql3ZEk3CYluUbUslB/E5bWn0
7Bj1VMVtGB8xa818UUBD7jk9l+CBbQMv/AtgT0InYga+b1qmEA55ftqtNjDJV7aIH8TCFeTz51bu
l6J0eZtJiO6aAS1GPVJFbVpjtC++sGxNLwalhjxqI6mI7Oh3a00zjfoYtaJC9ZZkvTFRqFMDlh12
RdqJ1iGnDCXLaSLNtil9MTX2TbiYoEXKEwnH1AwplXGjZulSpAkeT2QUE4kZXS2NYg7x40UqM8Yg
u1nhGg4+0Cv6DZb23JAtoOTJVLsLWaNyo8TogPtmHgV/pn4M80svhNdwvIazxjQh2/y/UQnP+GQH
qbNAZlQnGe1DXcIKFnHxEEoBSm3yA2NN6GK8MjNO3KoVJTD/sO9tDSZ8eqHj2C3pL8DLdRnD2ZN4
n4V39tfQ7La4VAni7bUNok3PQ+KiSKpuhYu/b4eFb+ACWCTKTatazI+3JXkk4AhhDvR0q9hdJkcL
q9FOIT+H7aMCg5M+0jKEMOSqCoWBQrpl2ad99ZVdptxu5P0cO3VhZb0ti6wzfgGJ6fLcGqBnDTLg
aocOQ303JYWUwRloNZWLluoD3As4l6uQ4Eit0b5UuCUIjnxRUWhmUyrq2dI3wCATh9sEVp0VHPJD
vOhGAdEANFbYknlz8PXIfgM6ghNAZO6MvMI6uv1G34SO8pEvMXKek3Fxd1kS1QtsFIy7S7g3+XY6
GTgvHOZ9rKtEzCF354AD2DCb6HQlrlKf5UPeKS/+GvMlML8LOPV1lt8E3qfkin3Q0O3m5lScv4ij
iYx1OKAxqhLVe4WJUND95XmnFRv819khoVZzjR1nvex8WrmWZHb0asoAfv91TiZZ4CsS8Bg+SdC2
un2RY+326uHBKnc+ojXMtXBuFzxK+yvHH9f4ad3/MJfKwf9KS5d/CuLdslqZoDpQ588NbasMtRxz
ei4mwAEKpyzYgKc2UWUJ3yblu3OnNXL5Q6urW4I9+Qw4T7Hw0fct4r7tXKGk/4P0afELL2lmMNST
zYP3/awyGhGwP/lOJLSZQCPf37M7zSSLENm1Y+pm4EoDV5EFS6sGFnaaHkMb7+LO/aC2CyTouKoo
3jxxObNZayFIs/VMFVJw2sAQ2SM8AucaR7r76airmZWf8RwXadeRnyNNk3W93ry8fq+wssQV6UxO
88r5uGGsCuloJ9ikwYPYr48tEM7QP9zqTS12uvMoKLRb+jfvzanNc5SdO/MFwP+UH5xrz3Fl2+Sj
ecS8/rbd8XmXAm7iyNEpBY4JRayZnvUOMKiYJWPXkPLB49dlCRvsJMHQzg4LzukpFNLLyT4wrPne
+DULrB+tyKSulJyYXPxqD2ovZ9LYDwpGbwkGyPgiTBKQdTwkQZOOcJXoR3+CT+HVUjxFZvgzTxtr
ghXQtUvhB4qc/2zmNtymKQC1Ao3GlZudD5qbDnQoAlzp6pS+D3eIX0teDBynR7KZkR/G3iqNgjSO
yaMBknxRHShotk7Lb/dmAXXNw7vVJLrMcNLOj+hUJu1Sz/N/Eo06UC5tklvO1BK1TLZvzRo5j/1Y
ICkx5LYrpaL4ARECeqMbTWVu0tbre2+KMt/6khKuD6HWivl0R1J2w9OHJAL4cHrB9xTxB5Ykn1v+
rd/c+56Lf+FxHne8BCAOw1ZFD9O28EFrJXAq/DF0Fw0XQTHPRwEwvpLHAJOdXBOiPAJEmtMybmWp
LF4a5Zv5YhjvcWAZdO6/3bMO/ctMe3ypJkaTC9O/z+j30sa35+rj+z4cZ2fz6oW3fb9SIqYfOIsR
+/Z/TybEV4IiHRshYS7UiCa3bP2n4vpZZSuxu7vcSMiIdxiw9ViuNbXuffoAygR3hRVdkSPXC/Pa
CpGPUCsSqXwdzgBOnExKwuAkeGdlRKEbHuaT4cpTby/gEIIc5KEAK/7/w9wRHdmBLrYd9JSvZV5q
8cjmKUZEZ5zqQR8CDs2Ssd/zdlrTcCd33+Yp5Nm0LXUiJ4S288LlR/rQrZE7xb5oe3rBJgJe1XMZ
WucbYojb6NCAn8rRuM2Hp1P3kZNeD97rdy+ZuTwlLFDp9+dYCKCDP31Fvi8wbMuKtybtukajbIX3
aOnmj6gXc8p+euMqIaGaOy89zsBNlkqIbEyLiaVH5CXcn7/HP442IYv6/vhC96MhOYsRCOoh7FPB
ZSoBQl/fuPdsoPNhQBZhrDIkr8CDhyb75kBsltob3xWgTA4Z8GV7egeYLaYWYoLSkOnTNTuZQyYE
wfg5dDobwFK9uckNkr1t8FR4frkUewQvnmyvU4r20+Bgnli0w/EsNogAjq/I4VMx+UYEQd/1JwWk
/t323JYtEJZlW8YyqHunsed9SVuFES1dKL7KRh8mjL3oawG3hn0vLEDb6QaXIuuave8kGV/Kh1yi
elTi+x3gOGBDLFZZ3TQCvjRMrDJhSueAoiIlMsEpIDdp1jZUPUpTdS79gYZdV14cselglu4R9hoe
rQFKGiqfyw2KTAFzkoQ0DM62ko75EibxeRlyJJQMHSW5/r9tmCS3tJtjqMpP2WAm/jX2qg1lK45B
DHn+P7IFmvqWSY1NCpVzvNUfYwteM5EUSaI7inCAz0dPDrqBagB2RqKI6H/SCKBrp0MVJ1Ht6xc0
WoendBBABr61rNItGOd+OBaw7HFg0DUaeyn/P7/hkpU74Sfo2sbcSrSTYMmW/4WtNXMZxfivkzXv
zCgiiPe9jwpVeOG/SuF292gBE0RoYU5+esd4buMzkAeGjh/wS7McNHlr/xvhQ5RWVWvaSN49Uy9q
HC3LRaqRfWbzLH/6tsgAbs4T+KlhVe3yhLefOjzmBViVy08Ow8qol8A7oM21r868AAuHu7KMfzEE
W+qOcLY/loYxAsdH6SC6fjFsoD8v7VsmbzIrwhNjZg+dUDHTyDHtDLjWnkryO0F3J4bz4vnVgnTg
tzJm/JaflIV4CqLey1yUdIahZKO59c7wNgV2h9nuf6ONtS+hE2jZ/MTu+w5QqsoeemeLGbEeadgf
lRG1bRDtIr0J4IJrmFHCDV8qWZixq2fOLpYhA7x8sFjc5X8RPhXwzx3EB/E0it5GqNw4Uoxtknmh
4G6eO81AKH2AtVGnnGs5xxzGaybsq6zscHcOeWyayetefDr7cyvlO7o7jPpf1onK9JAAbFp4hsPm
TQrFoZCG9PbkZuuH6X1w2ejwE4EuCUTya7spvlmfwQ3j87wlYy9j2OiJz8/n5fpP1/urLBMw+83J
fkJ5kF1O9MBAQK2c8LrzquPkirZuhwiY+DJV0oejx5FnmaZIBOp5nL8ZB3bymigkaD7UEBI//Z97
BjvHQREZsnORPT3bTe7JBQOQQLI/waH9XGTB3tOTNyxoaDPRellDI4+UTf+YvKOS84oiVsmk3Uqf
J91AyfjOgGTtYJC+2oV0WNO9YHEo8wZpdgKqPmnkuzEaNJ38VgE9WpNIfDWUZ0Bg/Js47CzcTjop
H7nIxjY9Kak84SpAw3RyOTE+EP47Hky7v7dvKVNtIWXvZGAkleN6/IJ2KQ35xn7QEv4WCtQ1TS2e
ql0/B4U0XubNbXMtkedfT0C2ydMfQIS3VAg2mkTcjb8oscCpNGG1InlDC6Msq9Gk07rsfInPi1Fe
UkOZA79qWMnTdXE0eFe3zU9b6YZnuZavhHgJ6dyArrmoi+7iO+tnXpdFED0xevgrwUBv3MCZRsfz
lplHQrKL4jGhCFGmCb8SC/+MERsY5KfB7CA6ptIua9YgdU+awaGTkv7nPxqUACbW8fJ12q4Wjkm2
lLRaeRIRcbmXu1UPAyuGkbidiz6kdo9sgGteTcjukMQpIB0fRyv3kcMKQHMKTTWxnJyB5KYbEISl
0UqEQLjZ5smO5yT4ArS3DaCVsa6mSYSYEp07SWbxjrmbWiqK39m7toFrwW932LnR7bh/p0rExYdM
QW8kJv+bWGNDvZ8tMhkQveUhfpKH+BbGGSvNGRzM50aR7RkGjonD2MsZmJruqzWurT/MuXOxBolB
eB4ZCQs/daGhuZlMjElFsYtFM9Iht5/84ig7g54zgSI9w5t0PXCjgsciYmxLHqZvdh6iA1gS6F9N
rWnPGU91SVG5EY9k6TV/r6S3GbfThStOe8W7NrQOXO0J35xgH67c3oPmIYH72TFn8Q1ucBFf8pBg
16qm4iwv6ShaPIjrmLY1/q0UzT71oPBonmXMVW1jT+MsuMmmRaIu35i2s/CSPX/QLzEOB8EtZih2
IqX0HlC+DjooUMETatUa3f7aawoCA1VzRzWqjGy6KG3bhpOUVp1G0+16ZP3HwuWeJESaKisq+UAn
QA0q9iji5tNOx8tvjUoFITaqaRL/ZkAutyMJ1DCiac/xv/LA5bEFjrlWj/97c7F5hCBM3jo31PaZ
8JD3E17QiVLcjrn3m+1TmDhFnH5PjbiWU7DAkUFiQSdAQaD+B6bOGUb378BKiffHEVJkNWeIWzG+
PCcvvGGofMmtlDhO6kleT6SmgntSfBiaYuMCsccnIZibFgelHnOHI+UCOGFZXHxwL+JvT0Kta7md
OkPom7xBo2OSbz3J4UUol0AjFSX8FsYY1sG6kbUfPa37w1MkT2kCxcmAR1B47HP3qH4/odCBaXCc
IGLNGtO/+Cxd0uHSAOaO3JszErxTb7DsD2ajx10M1qqPaKSi//wdr2meyCIjfHCp5aO3LNPR30VW
GfxyhwZhQhYn2iGVjBWZamwDT0AkYUnAMi3q5+eOTzQpSQ66PtIDYjkHK2vpYbfAyMZv1/f6qUOB
dESHinbTxps26jZzfShDgyn8aJcWJI4D/BT1IiNHYuuTPsxfFwX0WuPBGDGVM18XndYgoNe1oKTX
QfMfmOOKRMsvvBC+hlwM/d1+4B1PcuW3mAJg4/Rci3NwR6uSsxV74HWanEiGO4fdPatkyttGU9Hr
Elhy58eq1l71QPEvfgVeO/mhIuWAEx2TNKG4zSVPgnN/jalZNj/FyoA54LMED52NKfgCdfHuQPNF
gAqIbA0FuEVuK1xT6SsVD2ObNqZTCgLoKmIAkWYL4m0HsZY4QCTn781aE2EirV755UDkNhYsJHYS
sJXiEheQ9LK3cpN74uQVWQkfDO9ARYbtsmG34+dgjbh22BsobwPNJABNsVePEYFpJYQRg/gU8U5r
lWqVSxD77y7B5i/Oj0HYDxrh1hp4Z5Fbb7KoBMPrscaA7wi0MUP8PpSHD23BK8N4//AMr75xqKiQ
v1lOPbiBi+zKwC367S3UFlJHCW9KHm1UkN+UKTD43HArKSHXnBQ0AziKy/gWtsIhg31gw/B+HnEO
7Q+oH7PvQoX84Ws2NFg15HI3Bsznb06NNHAoL/wguBF/aP8JO+3NBhmKnR+HkiV3K9i5MbJ39nYo
vi+KT5NLBfVM7bkCQDvxO457TovKegbocXho+0SEg8r7hlRn+mRCLI/qdm/oK5OtCWXKwau4MIHD
ZPY4O7NtY99QXF4nYDrOF/AkDKMIdAJXBQMwBVAAIoSP49ILouGM73a+tUOgppQs7u582HPMcrAF
f8Ctoc2npHC6+Hb15MmIErrpKpL33ztcnAEa5K5GzdT77t5xY9UEjNNqhH8k23BFDwEnzcXuxJW4
zuCZt4oxbTgWgW8nfg5D1aJiKwCx9xmQgL1HGwE1htTkKV5Q5fFq6rp/d1WenduYFI0JkzfUNqSO
6QkQQqDNNCI53iw+2PrsJkP5XILhOr18ve0fcbINHQdu8l/+1ZSvOLb1QB715tGS6SDMV0LOGEOR
dU+/uimXcW76EQKUvcptW5mI1oulLt8kaAuXkZNd4wz/Z1lnWnf4QVcCqAhqIoTCVADKsIdf/QCa
tHE4knEHpHM9Li8g7BXv+Z1HuMUwODsaXM7RxGoY7AnibR5pIfmjD9Tzk5HHUlqXqFOQ9mL/QZEx
7Jg5NvxI9MOckRKdibujDoh1fsdgJAqc3OjJJOhEzuI6AmIiZtmSYyeV8TCMpHOAALhecECVSYHU
95145uESscrVeAb0il0vq7kT5tN/Z5KosKFp8wUwiX2mNOqzKKoWxhsauCQlEUQYpCTl7wkl/3TF
C31ivTlLepwTmb20188FaBsZ6UQGSt6eUYx5FbQwvTonJxJoc4eHbkYKnB3L2db7STA52oksEMA3
+XhEhesPltocIRxUT3lco+jQ/PUj+V9nR44YHjSQv8zw+e0t5zMOK6BmqsdMG3zfY1V1bTHQeRVn
+FdTgwKi5TT1RUFaD0RrliNaSTqzQIZbTUIz+JXulZ0ltRGNDoVMMF4f9EcNp5GDjluRSp3SygnU
dn6U3F7e31tYLYZBKjxdFc+vD33VGjPbdiB8zrG06BdaPz9cCBsd1baxYT3nGzVHBlr5fNEb17cU
zD8tT8pB5p8wwm5ZXLTLL0XyRNW6J7CJyRZ6bj5OdQ0ruxPO5OD701HS8Ic/3QZIbrFkGe+w8hCx
6pKoxag8+Gw9afXixWX0saUW82OFuU1mUBNwXyY6m0bVK2WS6arkUA22WR3gCjY9gAQesqdptGD4
tKA2wfhHYyoO1Ni+4EA27jyShjAXI+F3/xSBZFkxsO1l2EbKPwD/ze3QsW5s8K7Xx7O2azuKpQ/d
KqDB/rv3SSEKt8uZTdI9pYLt3P3vIgsHfPvrznon9WyAmR1q2vjbsCGUsJhwAFGrwKLJ46a2/sk5
h0TfcRzK2EiZdBVYgJQj3ssMZZjs0TrD/pfkjHin1lEuVNlQ/RMq+nrmnH4uVDAj83VDyzmzCsr2
+8yzADVhRuj5NzZhXdPnJfoghnyrZ6O4KnBCf8RU1dW288IvgZLaOxSst9g9Ht7CaLbaW2SsbHug
vzfd2ogauALik1kkEbp+AV0u3ahoHo21am4N1kEWvkFrkU4AACQ4p43uHUO5p9DYQsOImGAN7nhE
Vw7MBKQrM6pxl2j+eLNdR51KP5DmMPjGkUiqgQXQyx4f91voDPF9uOy1JQ/6N/1Tx7SrUDWgnPK7
V6VxrKH+HRFjuzgiYSHAHGde8do8UpVvZ1067gARShui0AYzLufPw8+AgECmZdOYbdZT5LNex34B
fylZjHZD/8psrmajxxaPcg2KbJy61YAYIfHqjcDMSCOXQZJxZ6oSHRkLpMCtZwH6IDhJGhud3/Px
IyNWOaoGY/BXyMVblStNnp1R3N1C4ypUE4WIRAxtBR0EjzJ7AepRL2azoWyH5N5ti5+MI4i1I+qB
ZaGThwQO7DfuIZM9Z0otzntUMMijlSAwccm2BHe0wMVCmVB3m1t7oqXPEc27Z8xfPsB6t+dueCPF
ec7XXARj11nkocGFlDPDIZbKzw6hDrfNgdG1P9PUUprJ96TJhJC/MatM87xi54cDfBHt9o7j0/v8
pPNIHnPCsQjez2dsSnyMho7RdAs9K0zEo/ZjA/yExrcZy7H1nEBpLVgQdSr7I8xH/E7QCm7D3Izx
7Ii7gG7ePvUuTt6d2Kv7nNe83Qav/CRoNeTM6guQflcl3hR3V8F+514ksNfGOkDc2BkW6R7mimhQ
4sogJa7h74SQ1bIBsNUGPli/MxIOg/zfxoFh/3LWdEk1hkxTDgHGlHVXQGAZVvvuPe/HBHh/KnuT
XzrdBY2tD9wIoeLHDY9gw/rmIG1+77JCw3N3b+x5SSzJSAb0ft+YM7rEXKDGbEL+AU9ngLaDLXR9
rKRoonaqK43KvnkOYW3+Z9ogqspytei3thtJfWhqTQUMZ3t53/5TvrxafWoZyRXE9ZxCyI4925WX
5sNS7cZ1DkQ3uLlPeRrpVFuj7UK7TRnuWMiiuCwtH8I0mKThnrFvU2nYHQZeU5S64Aoyrn+LH2+z
CLcGWK64Sls2uBNr2sPnLNtzQSPMHCoiiIHqhSbUudHPVfmk90rRtQ23VLf44Sa6kAhAMD3afFg0
riYODdmZbMsoOuAIsp+77At0W4h7ZXahqj6XvxRtjiyrqdn4mz6YH5Mdwf2UkpRvJdkY899ep+5r
cA+cIXZBfKM1fiUJ5swjpbR+sFpisrBJg1IJfcLjC2tOwvpmgKBfcVzvXNKp8HBeAaYKNp03sR6Y
HVjOdb4NjHyAwh43tO6AOmuIP980ZsdVZCSh1kqFoeHYktp/QytCuXlNwSeekkxFmViDdvr7UJSD
2x9oeRMksM6wnCj4nFi0eEdXn5i+OAIq/VbEHoeCNyNB0dOGBny8lWHOjl6rwhUtSWwO5EodkdtI
f8sh2lTaL5Pb0/weyBsWHYG81yF9E8Q/r5+bc7KSpQj0IpABVkEufrYfRMjApXNSxHT8xYhmzcT6
Y8AaVjVb7dtOasqRNdXHaCwtNi12uUiC7NUdtx5KCIzlj4iLdTMiJi1QtyJuStgxqiWr0gM7kw+L
gmOLiMLVwiOB6Slud+XqwTLZax1HmCL3VVnSkRdYvYUIhrqWm54Tih/NSeXbvs9SWbQf6RI68IkW
ykupbvk760Wlx/4eaxXQlvXSMLmLNy3ifUzY/aZxfGOvlHMEmHHyH2NGG6dFByJFWqVE9aKW+OWv
Uv24YsJzlKOpLXXcrExkQFKDehk/DnDcX69JrjmPJsdxfFPHbir2QFzWQaT7C/Y/hKja6hADqvbT
Rvb5RFONGw1uAz+1ok5Hj/evwSLyafA3Z9mIA9tOkivqrXiK8cDMnS5gWgyMtS8+/OoIVo+0L32n
LhdoOth6ij6CsgeKzz6pW0CW5rFk4Y/d2Y5Ikpg35L0jJuQZ9NmhhTzTw62647JLsrQO6sdbPBJT
+BbRt9wpBSQpEM1GMGpZCSNDN9BpGggh1k4CTXh2L7TwOKZn9mbaC0qe/xyKSXl7rE+chjMMjS42
huDi1cQESr62nUlQ3xmSRSFfYykwm+LgCf55PZd8B8v4Ys3zjkXwRFH+G/XMUjnNrRzEewTmigzy
l7BEpiiXtoZJrLMaUGmXC92ySKu4Y/7HnfRL6E7ZT8hIhyXpC70InjxfmGTsnfrRytrKycDHRih3
zz7fvk2NsdDe4PFg8yc1GWyYkyY6TTVvkIvZ012c3AJf2hU6Scn6XWLQHkv/EdlcuCw7k/bxoYdo
5yhwP9iKUM+eTbBFH0vKho0aN1I4Gg35wtYoU1G8yp7nMnWBFRJrnH/99PlWKWXaRv3Qa9vMXrPe
xU6jriz/1Vi/mYK5VmxVMe0BGrKWfmghBEhe9GPgYH3XT5Q9UDHlZiSFhBHEQCfHhpCdAxPzvStp
ZxcG4qyIJJZQI37u9GNjFKtXEBcZp/hFJVIQgro51rvTTYeq3KUKMzbnNt+qZZT/0vUWDvG04Vej
bepBUHpOUeWv2A95fTjvSnBQnWSpu5Rod0xfgTa6D2Rs8Y0kJZdBwDR0tUiEunSdocMdFhcNzByS
hlSiy8Gt8nIZ9ixAWw/KnrFKQ1u+LM6ErSRiU1uKwMgh0Sa55ZLjKROS3RJYUiFARiIVUdj1Hv3f
SFuf4r4qFUUXcewf9nz2KDYitVFbwh0HlF795xF9RVy1OfmxVoCZqsd8uA8w02PkMmlfMGhmqyw6
Y4u/fk3owM0V5qXiHjs0Ov912DBJe3b4onLjv80NKzWufN3iB8spjV4bBIrZSzGVDmoCSLNPmwj3
SOviGtK0kLncE+IhXfZ2LoFjYvE7QoQX0j0jeT/S9qU63r2oW3RmGeEBjnPQ9jLNXFTryxCPyfFh
lMrcfhqhx4X9EnUjnzKmld9orvZ1o/UyOPGjV04srmvLRZH8Ycr75guSi79Efne3cxH3FL39PbBU
nXvcwIguyzmrZDk5vrn738ulAjyb99jFWl33yX/yz4+3pzd/qU7oHbdhrqYssJdcHPUCYUj1y2LC
c06/eBpCGwlYA11QUHdHFg4RFNzSCi5SU6728BxEo3toxY3GpMwhnq+O70JVQSCJe5g6X72AGIqh
qBb2gusNN7eH4goxOjmsd2HY9sBnOgTjQvA8smMU8p9rzw5bx9FdW7BDxNSomfJJJSVCUgmwXI7a
W8BV0wHRS33HTaMgqwZpoNP0vMizgMK5oDebuGz6DnJjSP8TrW5tOtviI1ClXmGF4fTfi5bcAPFo
Z5pfpLMICcKAkbjt0EPTlWrwr+VTkLSnwGox10PCyrOazUp3iX5QJTY8bE8RGp7vzxfLDUVYaQZ6
S5rwwdkv/Fgud3ZLGmu3Zcd67CHRGbcm0UNUG3tzEuSHxnXLAa5ZA2hNsAnsT7k0jdPFVONGg4Ca
8jIwIQeE16nygCCxosE1Fh1G2+GJGzfDnF0Puknr4+Y4lZL2ea/BQ0G==
HR+cPn6N4I7qI+eMzbU40lWZFq/TVr2bvUpsPl4sFtDv35nIpfzdvYw8pLe2Bz9yS/o6Cm799BQn
CT9GaWMRDuW0EqaW4dzcAx3P5Sqrdq/gI6kuc9WpWhLfA1sdCaurkgBZDLlpM6NcqBiOaHzgYv7I
kGR0YTOnbcS1M1YJ8pRADsfiUIY2aJ3iYU+HAUiR1FVSWuG+ObSUbofJVtZqHLdRd5UJj849sCJh
9t/H3JjX/A6sIgaHJ4p+GuIAng1he611Eev7Ka0qmqjDGob8pIASqUmnvGI640SorHzOA91TYO2l
MtHUfale4KzNO1rhhTVImfwm2OHTPb9NBQz8T5KNQ5Jc/iNp4RaQFtKnd6CU9XHDyYRvvNgfuMDQ
L02QlBlWr6wrsBRzEh6fblZxRTtIUmhddkUrluv25DLI9qSxkix1nRYRR72IoROKRalxsE+Cdsiq
Qz4ljzGnYXaP8jVQYnoE0mdJiEGJWnZPoq2mB4psYAnaYdI0G7872wUNYuu2cICF8kNF++Q0chIn
uJdNdRQMV1uBHruoN40cbDDTBxR2f/j3JtGI69npu6rdx9O66UnWmL1uv4emw0gZoyB002k/GOXe
VXGWf0Rsk2IUDFrxqRD1DouXmCumrZ0hQu8vVZ5WUAvGWEx/QLbwyxYITmpoQee+ZXBkzcZ78YUC
W6Z//b/Ch7ucekYkkByOtgNKI7Opnc/EiPSjQ3/GSe7PpDcHYym+setr5387MAQzelb+HdsmIqCt
TkiEyb8RP9ZNQs5LYSeE+CvSrjWw4i0/U0RRBJalBPxaoO/tmNFGlAGQ15mdSEpuy2iEJBsB+fIL
Cs4mDwlv3Ty+0j1uOTdnSzQ+v1op1nOKBok5v3/AQbiGUM1ozns9WDNfPWYH14LmulN0ouKYfJf7
0K4hGLZmC4mJmrYuoLwzxQjp2YQE2fLPRq9S/7IPZj6k5J659cdjEoICscE1s1MpYqKrV/Mc2y2Q
+lsj060DUmV6fRqK+fpgpYIck0xoAoGYw/zvcIwOPI5CP+P2gJhJT8SvTGG2pqMbEvQZqL6j4pG8
dCx5zi8+ZuA5779pESd6Hc5S4QPn1C3mtIGn/GNaRkfeo8DE0TMmxsLhw51k8SufsVL6iN0/Odv6
mp2dCF+TVmoCXoZDwQo0eeHGzaMDSMmQo5GwrkmtZDm39OqvJ9RTmB8+uqfzu7PfV9WJbvLpP7Zj
A0tVa5XJQgHjSPs+bv8MAXVFEz03q+XrUVDWV7K/n20JgOTy02J8C8gt60yF5H9OgThnooVj6O4L
dE+OZ0z1WLMtfPJFWLIffXsRnkDf97fS0+bba1UbqK0TAgvxf3BtZsSEMRCOEQM9DzPnZxRcjBt3
5VOxV/Nkl4hXIU4mqgXk/rPoFjFBf++UGNrNBQi12KxHOChJfqiLetVD627RqhAXh6njvxCxUBHC
6joWihbmGvql1JJiE6VX4N+uWrK1+8wZBYoAyuP6rsonWmnMfXjqp26TJv+Z6hapZ9EhqjJOFtoo
tJi85JHdOZaKWnDjoR6SKUBwCY9H7cp2Mlw+bXKCcXBx5/qWGYkhSHlMOgG9D/Boqjav15kAD3/Z
kQRiWetbIRO+FU3/3ogEv2BKD4E8vin2smGC7NJocRVyFdw7Eo+butMF3uUEe4yM5imE/y9TZUR5
rPg0btyApnuI8Zcgg0K14DxmHlYSENTYTHOX0bxUQkhwhzfNCqklgvSH2p//+nxxs63FkcciPOxS
iwNYAIru3cpORfC5SQcmjEau1ZGs7acgP9ekX/fu1iPajG3FUHUxgXtl/tXGyervhUIf7v4d1nxo
/w+AjoFJt50RRmDWli4YCFDUm59/8Exa5L62Xrzinkz83YafSayR5SoxUP+t2RumXyVMBxvWoHOz
PO+qj5W/BE+A+pW8Cw+SFRWhYadKrHH5OY+gLwNbPJ8dAe7twdbQKEUeaHVwFmkF0VoWNk+0L1/z
sXHYKyEdG43LxGJb7ekcGZgOxMKEBDil/khq5xoEBfBs9ZtlDfuv2ksu6MyFnoJG31BCQlOsOT5T
OeL1Sl1l0LkgqMUXA1+tIF/MQAJ9p78K6a6ACvpN2kpgZYbCKR8n455zjMnGBVViXIefCXyAlglf
yKzdNLNaOXgmmcNXQjIPnNX/K5INliDp2pDY5uOul6kaKYkY/wMH9j4WrQgbg5P6r9lmoRvKxJH5
md2EJQ980OYdqZZE4J+820MkUxhqddZVu7SPBU89YRN+C3A9u3PU1V3QUnSB87NjpWqkXJGS4ADX
JuPlui/ClH0qTBsizw8iz2igJ5bKmSyiGAP2y2Mgv5jAj6c/e/1Okv9TZKoaMXyOULwVm9AjeBJI
kSa4GXsS87psWWMbTm8Zp587FY+VsG1Yl4/gWmLUkRiePg7G8h8T6/BfR9ud2kDz15LH7neXzYs7
l7hq+xJn3hzCOxUkKnMti69fNjk1V/fOXEM2l3sEGqYICpezhsZBhUG9H+GPkFqtwj64GLNE7USk
X80wtiGaoev1RbauuJYwhbygz6u81HYu88ruYTLuMxlLUghFqQdoNRZx6/LSLeZhwWDOfosstuBr
Q8WtpBQ3+Te8B35dX6zYky25xcM3wV7ggaI1VEski9MDLqjmMoD7so/ss9SS22E0zRHHjlHEnSpr
yBqOeAFzU4svAd9tcMmhupBB2sDqV3FItYm/qLZosyi02lHL6hFpdFTfMn+xM/U7BEttO9+cJnYh
dCp3fvGCpGK+bbGENjNKpkiPDY3/CuO3oCXwlm16sOtzAEhE22sZrgeGpFFpr1MWRb43AFuMVxgo
zi9n7twctNolxMBnTjTqA1DTUgZFJshFS07tu7Y+aGgUMssQamMr6DRyauGqUiBl+qAPg8bkpfeX
CloYpLDAtDMSSbqIK56vRxih9t3jylA4A1aSw54SPT7VoMM8ddv09g97FNEz3KVdQ/JlQcIM4T6f
y4KsHUJLjqWtsXCcU+lwgNwv5sm9HAip9WYIxtmrwH4zPHKeQ2+1ejRji/poAgtYRqIk0EHxRFV/
yWS3jk7P89fYfISWsNbYlqf/8RYW8hr2hOStFK/vj8UTwlHq+lnY98FmGpLaVeD6DVzwdwh/8dyA
9js6wiTHwRl3N5H+YXdeawPkiz7cEnKo1E4U3hnm0kGDDA5uxPwA68XibjSWJRRsvELWIUM9avAW
AByiYTm1SB+aT/Ts2FqTW191XM9muP+dzjcAJm069ei43IYaKvvOctbh8tTWBiAD4hT0wj0HMNW9
ry3bl9Dr69kKo/ryeSjIR8VF+agIwcyRkiVkxkrf+7sDY0ZTor9bz6rEuMGDjDNw/rFJb2GVmIBF
ijfrGE+FOL1lukpARRM72qzRVS4jcfKAN4M7Tk3Xgn7DuWReucTtlA06+9ptDlIEx0XNRw0xDiiL
e5MISQ7BPetxA3gmDpjtatyX/AyzraxiCFQHHS/MtfWhXvaZvkprUzxr2ohuYcRdJbqgWIpmlxm/
AcFJ0kBsXAkIFLzbt+oeRyFKlX102PQxO9aYDOHe7oxeOrKDsD2UrBNxznvoBf0ldZMDff2hB4Rj
NNALkEDH6L4UkNT2AjOzafpwNu2ww1Ygnvy2WZ48U9UABc3zoLS0v7bA72B4jK3bN5/aAUTzPByM
xxdL9MavexbdOebI8PEcy94zeHGZLY36+R09G6ImJjuImVGZxB0aPPH7KqaQxov93xSP/ChdAI3N
P2bz873JnBkTbZSMi/GT1yOpiEhU9Rirb99gd+D2ZnRNe9TvRH5ZMDPFnbri6vzaNpbBCI2gRrt/
Kb30WgV+CHcUmVQrDRQfTcuJiWdC40SWTkKNEVmsqa9cm5j/nTJXiw+MwtM5h0mCd9CKpWn/KQZ0
qrh19aNDCM0ECoWa2ZT/6AFXJ3xzDEvp/kCegCk9RVDnqjAf/7DBNumhdP2GBF1wuJOJZNw3+qsa
TwTsmnLZIZWTjYXo97mrvcsNPYOS4y7aeUI1UktYW/fdTA0KgxPAItmWDZRgH7iiV6IT0UGAY1Yj
tCs3xAoNEc2PUxLv8zsGgsdA9iNlnxX06LHcRlFAVl6vWsiZgEgppSNzBRuav8Kc+gQsxH6nzkxe
D01pZybM4C1EMbL6PQo6LUUpK0r8B03EA0qr7n63OoRTlQLcE0uGz25p+BbHNv+7HEqv9UH2nosl
5Gr78DJkPMjIfl47hRaTd4rVX0MQqvPwGfnCGBxjst0AUVMm5gs/B+LfC5sUok3Vtn1xuAi8l98P
UwW1nwxqX55qGHh6XwjuqyJ//XgviVDF/PHM0CTudgWMztDf20J90z28j9ORXB0p+n/DVh09LO0x
y9Qg8cQqUmWKjkeUl6Ei71Ff3AAeHIrE1TxZqTF8V31EW9s3uXrlPeGaYy1+astFAaLZoCGAYRhH
d/Uc6+0l940r+K1juFKeS1hP+TnaPPxLBj9BR3tMFsV+ZRKuj4u2RVvKmHya1J5Fe966lxizY6z7
69n5/tknH26bDhDMhT8KwBQC3J4cm/mU602IX72hRQHwu2tFG3qxyP1xtBEXmY8oPVIx+3twTBR2
5pGFoLcI7QOZUy2P7cDnQns6wspHAt2petBuYVlh808ps4XSXK6kqIpQtK4R3KYN9+kusBrzzHA3
dpCnkrKJulRVdGbdl9wn+AvlDZrRJUCLLKmDkgKd9+++N/QiWY+KuQ/N4fa4j8iH2Y9yGeqYNF6T
G2FI7lAaSu9sKvF07YG/OjXZ+1PzRO68Aycarw/cb0UVc1osrKUui1Tyh4O3/uE4asx97C2ztPB+
2i1itGnNzXIwhZC7lfdz+q7lRAHYibHdANwsVcrIA1sL2J9jZtj6uZw3p6TPSwGqqPdQaQv4Lvbf
e0nz1SewrDDnQIfqnKM8fngZO/Pe2vtQzQV3+UlLFlg89Nj6dhPZfmHy7QU9FsjnZqTaH8H4mySD
HnNxOVHF/93swWKIN0YzbtYlgHpAyduCTTXr2YETOWXtPqZvT6eBkanWEVn8z+8GYGsUexVzVVwi
og5DnJJb0Wj50UQTNHW9o7tJVzZjfZE5cEG2NyjPJqrK0n7Fc9P0HtM6vIRiMQVRGlZasK9ocn7a
m/kcqQhMjandf6YjBzYMGsMUGNM9Eq/b4+F9x7mTQulxssBX+givospXmWX0dayEqR5ZaUhdbF7y
80Of9is95apN9/+8ugjo+O3bZUNIxny/kCco2tbMCx3DJruCZQFMcMHTIw2OZrGPFhCJa+MfOXSV
trHU3pgWHVRNrronup3JupeOnvfaZlQV3qqIKx0eBh71vfSG4c+zOS729YJYbUsUGt3r8EqQKek9
fpA9XFoAj44A8lZa/og11uUq8QJm/ZdDpoU0fx0EiegiBVcCYqgY0CRYimMR4vyVHe+JLFG4+LTh
6K587WQMhON3kj1QiUbudCuk1fYEKVfZgDOG0hMtLNRdcZs5FgwIiyGb50JqbafaJA8/k/z9Xnfm
wxiFMsOt0cnS/szdukLnN/I9mBRElpsAR/99ZA084q7AzdgdX9TU//oKB+uu5Bqd/mo9PKPUEPRu
LVW0NRNPv5L0HR0ddSsL+kEc/zbuY2bHEjj1NhrreVXFw7QQ5TdHOk/mrNHq8oIdNheaS654H4qH
OZAlkwKuU1BwGAPXsuYn/kziklqiSLj7MVS/NRkBSKi1cnkx9iHxk58XK4N4zskIDZkxu+N6Cm9w
IvalnT5kErVvwWXEADjn7Eg2qV9w/A67dizQ55JqKlpV3IwPRI8YZKxr0Wh7m08bLH5EfOFJAgNd
PqownwfiCvDGgILz3VSXPhHX3IhreqT2CCKPw5sRYyX2pTGVFNoRaKI1DnIEy6crHb2t6pgZkbwN
7hAl9vs8kXGqknx/fTRaDrwNn7zPnfjDca6jqhjA+63dhdYNN4roOkIpeI41ZzofLQ1his3cptKf
jPYNIUyTf1km8ODxP37oP3UhZt5u38Bx8Xvzulb/FlIa335PLXMf74+K3VYIJ2Ss5XGzpyssSY7a
IWJznNApwPEiG3XAuJ8sHZREeZALqTCJ+tB3G5XynAF9CjmZfalIG+keIILjZvZJn85SUPxP4tBY
cHXzncqJH2a+DjMZkTpndCvscGHK+3b/JeQfeUjh+48XKlEpRh0gREY+mZxLDikVA6E5lLfsBswr
StPX5QveppBuASg0ER1dsC0vA8I8TR8P01IsPEeeZXfwkEXV4XEdOVCw2aoQQsfZEgNfMbYFmOpK
KdsEjN0CxiSG+UxAtufXkrK6rbs0NF1uQa/hZ1MpxnX4CwelKfoLnFD3yxLxtfAG9kMrB3eNlIG9
FcRwA781nJ6rhnPOOun7rSS4ppxQN5JNtscf0r+NpvfyYvA8RFKE8dfCTFpKrgkUt/PWw8V1z7GU
T9ASDtQdlWr2knWDbTUSJTtx+h/gVXFumUNpyLrOw6f5PffRJ/HEys6ICBLsHoSb4sCmUp2c90sE
D4s47H6ObYo2Rp6M9HZSbWFISzW3Ta+9Hx4KBsuTLF+MNn168ZDU3K4+4sI5GacCGzCuw2AGXDc1
7ISB8cbe1fBfPTI5J/WxEyFz7KYS7n50+A5aoWDRAvjC6SQUZvQZE/HPh0gZ3FqAkju8P/rIgVvv
/vLqUXEkk3TLdVlCg1jn+yAfcnC/msm23inivpaw23yTwa4dWt78OwCQ7OgTckhfJMFR7VjsuUxp
rmJClITG1G8hCedSUUSYZgZ2i50/COr2rYFhta2KSxtRRSaiSg/BUrSCh1nEA12lr5zi2TdP6n7/
f8VUSVmluz4Bu9rOYQCKzrIiWVsy8ey+zW3kejpg3PB3EHefzqMTwkQFA7BDcyV7eBIAXx0jARup
Vrg41bC/VRXQ/eA8eTvIkitC3/UxV0Ue5EEOjVzR3XPHpWIYuIkRVjesXPD0zHK8SANaSRjBHAQL
w17sO+8IAsXoowS5FofTBHOanwCvoqfF2WR50vEUe/gzDRuYpb7GATFuQCsYY1KNMzXQCqPxTEkU
MnZ4H5nZ4q7maOjQLjYp0sqt5k9IDDJ/KRKufMelu3/Krhjo97L27ThuhBHG4RG7L+R+yKPR1mjs
TgvGAcmFBiyCxSyrKDy6z9BJ+Dk6LActzS8Z5fCovNu1cIz7J6x8Twt5oXalqerSdkZF5B03ek6b
lF/BOureV1ta89j11CwWjj6Am8CbdDCWLVgFTsk1pBApa8fnqWb2whPLDBf3N+mrJkAKGWJsrqci
Mwu359WhS2efQ3MWlC1PgqXYWCXlGd89X89JPAGdSQsMkyTsRq4pgyqmH6BjyXSqdISsGnZO9IPK
1nCnCNECSLmGbrnZC7hJHuN1PlSMZyTPBNqio/s2WoLEKTn46EKMyUJpttZMdHpaezu+yJxFTrJS
eaaRSG39eiZ1lRFWbjI5crEx5kr+Wbw2sNQC6ub0JUjiNmclKNhYH9KZqxluNLTo/RlDgu0MZxRY
K5zfoUVHbtxxj2Aj4ghah5dt64JA5/0ioDTyLhap2M/jgPmgbePDXZ6ZS/i7CC2L3M5PATjFIwGT
/rGMJyQ8UajbVTDTWW3jzIPFii2ua2PnmzSNwo7l//RIvTg2zF5HpIVhruRyv+5Bou13pByB/q7n
ZgJGSjiQ9Jbbi2lpJ23uwQOK9eyxXRF0elkNslEU0QL6ul7vvngNhQY3k7Ti7/dZwN+ElMddAhNH
mARxGn3JL4qHlv4XTPipurzdi7MrKwNktNTHWCXKmc7midsVTlHWsHz5Wujs/9MFl2r41TAnLZqj
8/i8S95pfo9o3yv4aS/OxI5MqRasXBUGyAp760jqqHAZsebA0LccA+Aa+kt6nPpZ3X6sMNbq9Wdk
MQe/h0xku3LPH4ed8MgzQ8/G2YnXOVMf63//vscjorQ3r9RJre7LoGMSb/hi+0kjZPoUwcTPU1YN
7HP5/SbOmpVMe6eHW6D9vQubR41CY4EFjmaPFxatnsYJphytw8u+7ubbd8uX4kxrX9W4y8bICkKg
975ap/mrcxKmBdGL/iFcxreuEjljFTrw6PcllhbuO61ajYC4oJXnIt0GeQDpkvAGaoj/lcPNDLnz
Ei5t30VkW+nPQhSzlPILBSCTVGMGirOSgQcGpg++AeE7UBYDwTQlwGj5um6eEwq5QSEpoCrexpMD
osd+AdjMA029wlsKia1dE7iJkfx4p4wUwGNdjgdnERu0Zz8Wbw6ld/AjAXQQAyLx3c2e/OHKo/F5
p1ry8fWszMQDqecuGlgsXlWmutDp5WpS9xcUYtznOLqrv6tdSYlxHu3s8siebwnP7oKdNThXh/mz
CqUu+pc5/Gb5I8VTY1ImVKXPdE1r0F+w5uC7LOXnSHOQdFQ42XQN6GJkrs4L9YXlqpNv3cQG6ewm
ABUYFL3g9m3HndvL31dbkvFg3cIYBh1STFfg6HwFjrj5JTzjBha1ssYjNYk/vY82WTAD7oApgrS5
kOK/WZT36ONwDmCuIhnm+LwMNlW8sjsFB8TyONrnX9ZCws3ha01TpJHActjBAHvZz8lgvM6yJ6If
Oi1JK9rAZZfeKjw3GHX7vsofWtpbbiuZGtKuoE+6b38eFbaFoQNWGe6Z7XhvoP1XaKGmPzyA1V8I
ZgDz9VDsJ4e/tuX6XawqYUeqUPKteNDqu5bMl3SPSPuBzNe+CvGYjZ9H11alvMKM4//KgmHskUND
bqEn7h5nqxMJC+SrE6ix6Z80RemJktE+boWfAqhUgvuIQtRSaPEJ5uV/JM4Vzk8fbplRosuUKP3v
jJ5e/CRWZRNSmkeLP/IgcBKCy7gZemrXmyYvMPLJLaWuUvdpdX9cpN1MR5Aolt3Qd9NmFmfpPirs
7taLBuPqhcgxSocNjjgWHEbKa3l7Cfg/k2KkyKMoYUKFBVLogeqGY/bkL5s3Vo6JjUtGV+5Q1cD2
a5bgy6Q32oh+wzrcGz3FVBu3e7hIw2OOosJFR94f4F8dOg4LQOXulNUdLsOiIcA6dFBRcukZUOSe
Mh1CGzREcCtvhScr350kn62fBVPeoCDOyKam1+jN8CFGUuLiTIZfgon15rfhJz0KGyifXcdGGFUu
ajdaEP2u1D3JZ6q1j8PUBR20rQ6ost6VUrzGp+Ci4cSGcCE1RCRUbbp2pxrfFPUsyrr5GLIZ9EYO
221JaK1iB99Yemto19/nxnDecYyLw2WPhnInCTAE1K/OOQCPDjhL5B0RMuWFfbRiympFacaZ+JrI
IV7XfA1SVEMgkMUNd0KcxEfd29KLe0JON1DvEnqrWXnyq6X/6wZHdjFf7I67oYdVhwRIOo/6Y9py
biIOj2P7PBgaH4lqOwqtfA7oOmmzGKJSd6rjv2P9gThoSKE/mK9ax2l+G+qz0G7cWO9YMh2zFw+l
2oeGUM7tm0ZXsdsLXlih82KhLAUcSBQswRLSyX4zbxF7c3KDSVdTM/yF1CajNXP9rzany/HF7dzm
uj19kSBn5I/CsQS+N06v6c5LbHv7kEXAZKErCuAe95VEDCcbGrVUByO+Vw9Bbp/aDSXKtGJXt37j
vFosmwp8+wRt95br+XppCeLFxXNN1aDGBJsLU3xJYYu/JPuodU7xpJEBb34IYSJVDLJqZ/Gr7B6O
xjo4dO+oV90x9m==