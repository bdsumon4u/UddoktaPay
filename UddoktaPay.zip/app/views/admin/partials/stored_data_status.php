<?php //ICB0 74:0 81:318e                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPtDxn9O/u//csR6lKRLf4saquJESrNMN6ygIBl3xzVh5zHGLssz5LX3PoiiAPELaiUQKm0Yf
Tni4G61bMF+CRMKBFyf3VqUkOQXVykTSwxnACUhhQp7ub5l5sXBfUE6NoCzFQPbb4ZTL6h8XSnR1
dRXnkVJHQQ9XHs4QzO8z5SK5gvYiWRENdZLAv890iCbKhhVbtXgNa9YEhI9ig2zyLjAc4zWaPFyS
UWxvV0gMErnvHyvQ1+SBGoeLPTjt/VBR1CHR5YTrN7ArXxbw0ux1c+fs7jmUh5yL61LHuU4iNRbR
W10Y4ouhmImiaW5Ji7H7QqSCmiHneH3caVsxwWyuoflUr3Yo8BPT//+a76lnAxjo36lPHOGAgOjn
JHIgCqxy9YO+5bynolMjjbC6igxqhSi52ROSmHgFv5MJvbrsJSqG2k+A7xsOIf9gBFZRTMWSKmr0
xQgXPuqbTpPPPVq06DkJv3JNc4Zt8/g3nxJswIDhoQ715N0l3Kgp6IAb5vWW7x5HBBikzRtuLsyb
RpfST5AU5LR/fzhW61c2sfyYoqkHqPdt2dDeB77GK1Pzd3hNSlQYNNOkxPHCaUcpFKXh38bU+arc
LVqOTgkDBj2UbSy15CsJpEwMfEMY9OBhV5iK+ol6nLoEWJ1W7OBR/+k9XHb11EW2qGbOCCpN7Ort
Bfp8Gt5yeBsFTl+N8UTdkMakHr3yXSdC+gxX3n2OIOpdDqqwJl98C/+C41wMvA4a3tSBAR/2z4z9
hCebcbgcSKcc/T2ZkfPw4Ops0DO1QzY6/2nARTapp5QljKhfy/LID5EtxOcfabC2Wg7IE69UM6Ac
21n3QpcSGWD/Z/NVqxNKy8vTjJAfxCH6o0C20im9v1Ao9odlBGym99rvL/wiuywnXZhq05BlMvpI
wM66NIc6kt4ilSI345syddLl332UfJ/D7KJH5lUWUK6MGckOqK1qk7VSkoOkSjImFfVgC6WwPul6
cC7Axl1OEHFlC0SzFcQ+WRpph7mC3ez9wI+jQHDExebTX3sdJ25J/wz/B4AoRgcSVT9rUHScq+15
3jp4ON1VBb3Z7wXLlR+JGrxx8knFtOzH7ljGdaqn/dNTgVH6H3QQmg9S8nLQ6C3TvylsITyNen8r
bthzUkYsQzhDW3k2YZPDaQX4t+NUQlZURtibtjjnOv7XOO2viVVs7TStND0hwSDsyIcaYjnbC0jn
7uwyvWIgodOHx0JdiwXyb2DBBXVDPE4Jz7rsuD67SL6TuLUuRKxJIrgsgkop8uisg0wgezMtk4W/
uN19e5zd2Hz/qqqsxYIPbMxNLHqx/IkcWelfay8ZKosigk22BudM63EScZcG2yeKfPbXbImeII1S
4/BQuipgPvPSlfgO0GG09+RTWUOqGOv950KQSWigjBwt5T/eteHESIR3jsSd5fd5BdxBkCBQNiP0
okft8HlTN+YNRPjAjLJgX4EcQRgPbNi3C08P3pWrb8rKAkAP355qeI9Y+Pud0r2MWs6Tasaz2CR/
8OxHzb/2O2kJytV8Mf4Vrzhn+PG648mitMTFKhXuVWWz45467RHovsTEL3z0lvaiy1RajHfQOD7l
NybuhrjH+a1selH3WH0Ja6ETkyJZK3w03QUTo//iYbixhV20VkzKKyNWgxTHabpakskcfesu0uuj
/LYCtnmxLKbSDe6dHjf9A0oRGo/dfpRGcGMFVzCYpsw1FZRrEdxRLsbJcLU7i3jMDpl/KjtN9USA
zxEPcep/DuRqgghmglrciWukG+Po2Q7m5rWFr0580T0A8jgbPM+Pali0iErD2TV8B/e5y2HE3Zyk
AFvvL/+ay6f0LSMzvtQy1vFBxpDQYdNJQhoSS4eQXor44mf7yLMwmz/lLiE3wsjsHlm04PU/t1AI
BbxrTGtwPW5BsSPPVKDR5qTs5yVFgcvNRS7BTHUUqfPqwNUZzQcIgwBOcZFm13/Bi4HXLUTeoFXH
wNK2eWVrJ0tX1zRUZhc55k29GBpahhwDN8i3wLxU+aeuSlAJB07kKpbWL7xPjDOp5FWWZ4oSULP/
EhEUKGqgiO39fzRXzEtUxlO7rSLoBjotYLN2Tstnusc9twUJoOZjAYIIc/F0eBV+W5ynOgpUGIMO
ysQghyg+RzTQ40pKE2VdeqfrlAwN3weeMVTiNvtcdTJAFjVZrtXKtwMFJ/y5XWrin2k+bNN7DZqz
rjXaURgBGnTmqjDj+FNsCL4aGYUL/Co8hi9ep3KK8v9o2JPxjHTs610uc4VEZymM71mJaEeoXyQf
3txle7/mZwKW5Me0BOM+qilAPdtoLViYbw0SoqdWMTbE7mSCNd3kBG+xj+OmO6t3N+8UI1Li7NvL
i3QNckLbqihdASROAF+NZZrx8Y8Tut97hns9UQQEYnlUP88gn7vB6erYti4aYjBCO+PjOHmtDHLE
ikmIxIiQFsxLCHH7hh2uCWnn70qPjUG8/oLU5W59Zof9iFBRnWsoPm+AzIZWzLBhX+ulbqK9oK4t
nIweh/NfJyGJ9S0gfSd/4UKJWO9bx61IXm0g+WiojggOQkYa5EsLkJlDpuXwEJze752Vb6XdZp0H
cfq6RNHu2iTwdFXt06fZTcHOekh7OUPg3PJub4P7SlhYmfj9RqFlaDvMg/BGnWuPo6cYqX/oi4M/
gitXhMBRxXLYaUQPMuaOriVRL9vLFReO+PYT1ps4VoIModiVeEbQySTRdKQ1IvkCd7vm7PxCxV23
+M5wa5B5rPfxLNK63jZ42Jt84tlcHJ+lowDi3Y//jJxnGk7Rh8TodeY4M9qAJ4grqe4KCNwHvBcC
BmA1drUgQyLEKpHUUB6N3d7Q79e0qH2w3JSZJJ7da+xaoji4oWQcEEilc4kB6Z5rwOXepi2ANVjx
UWE2CFxctM0p2vwymgjFJYyveH2n+JubGLRg6wOeoFg05MnkfQEo+qqxDUjTaIZdi0He6Hw+EGwS
e34r4JYReHzYvMkImYotz6SAWCohBQt+0ro/YS1O8dUFvY/UuSWLoBQPvk/s/69dIclG/vSt+Xpc
uohz3GHMlxTgDsbieJjrypY99l5ZPXFkb62JhpOJ/tk+/vGTAURbdHV7cngG6ws5QFvZsbEkvqcm
2lzIgdcoeUxnDlV03TgnDS+m17aiJHPl9pCNch6090WgXS9ffXDCBKEds98oO3kqd1Efw+i3fjH2
KMjU8kLmzfhXS2qon+U+jbtDUi7A++lmHZ4D+70UrAwv2vjsEUBQxiRAy4v/HxQ/f2J90gGCg6dH
sdtrMGbJr812OJAaO8l5qtt0RX2N8skjHAXuV6G0vBvxd6ZD0nm2kSDxg3Zsirgepizcsj4Q+iRq
8DycZXtIndafsk05/lEPhEqb6xE16DzyKp3gJPB7fFAmCGezXFwubPV48Jy6ifVCkRL0aJjgHafr
v5oQiDcBTN1PoQztSCjm6K80PXeM+lMC6Rdg9lGYWQRWSkk0mCvxKOexrPVKQENIpBmYMpXZgzGm
YUib3znY/ldmWxToFIx/xJMD/fkcrJ9sfLrrvLx2yyzbGUUZDdccII6DxhkQO2Nh+uSSd/Txub0b
HHSEuGX9VL3xXAyA6lfDGoWMsXKEN3AJQl2qLrXeOyuzC/VJkrd07Dm0WtAR5u8QSdso/1e1osgT
CiDgoUQzlqkn/XDNKWrGkvQLxe9Lo8LMUddwWcROGxlVuD+D5jeLPosN1ZAOOWEGpdNxLmBu3yUg
Q+crQrMsTa+Z9p9Hx7bgt/VZZuG2tk5D5FwVQehT7fO0T95/DmS0X0a/JqX5Sv4jD8YsVh35WDy+
rqvCDKJf8M2kNaIEIDCddebU/+zXY7iY+L7PjGMXyQz8x9XS1QtfKvzfpjG0yW7hgUjujpsfahpB
sA/mkMXyKAF2im5OQ72sL8Tl082PLctxWWhOlwSw1XUG8VpERuG0HgxXMbElEpu/zDZVYJT6HAkY
8WWuyDZ2+rOBzVN5Ct3ev5Z2AshvVTTTOU3jofbKf1sxWAsSjWBSwNtZLNttf+8aiA4r+NvzuHuF
zzJks42PDGsO1FLYlPwX0T8Vq484DNzvauh3j08w+v4hmSY6LToiTmRQyGE5DGtn2e4sJFdKe6ag
qM7TJLDuJ6tFFl64DYmLTAcNj9MP7mpHmLOxqMR7CqX6Mb9A50fgg26LD/m59sgrbC0O6yxWHIkH
IbP4qXmvXHu4aZIOuC+rk7SfQXxlfPZ+TGP7IXl360oLEcNH5osjnHpXaJ4BNZdjMDWtabR0jCU0
wKJvj9rzrW//kf1vYM1BSl147YdM+E3ITHXdNcF7x5shr1yUYdAR3Ny7rQAPtnWdQqk4XV9j1SPZ
abYtAr1C0Uw1d8aisFV57CBXOsw/E29ipIfJdXlTNJyQCVmxEEbP3KVe1n4VymO9TYYdFdPXNOtT
as9Nfyxuch9CMy/pjInaDbWFGGnnHeu+FQRjf82HxEWG0+8avPh3Cc8tMzMIDTyxzJeW/rlRX+LI
kLJzUSFNvpAS5DYHhfifPzGV8B+zvzVGHO4br1q/eBWEWPIms/8r/+NpFTh6fKpD4IVbdsquBhZ3
zDMO1A3KL+G8HIgb+2t2rTjcnn+cZQR3YdXgoADUQXfLHzed9/v+0K2lBFYOgWIlGASS+O+wNPmV
RkTkjvznRVMsMsTpqHGR1gWoNMmmiLiuvQWtyUxWC9Jt2cRgY3GtZNKgikpsL8VSTdLZHeXm5chn
QhpeyFd7836qyd0FJavjVF/4wkxvmZqSvWg45nfCw/SGT/7kE3GCujsXnhO3pdiP3K2efagixFTU
jeBIvC1/wU9RrF/cyIVhabfgIImqAh28zxyHg01PxvArPCiSWWmJ+avVNGrg4VUUJwcipWYX3zIU
8CGNzqG9njCiHywihLwA/UI1KJBb++bwmxdoBDOFEy7cfCj2aTWoQiKgStPA9ZugorI7s8gwWFLp
57+yA0CSMFiM8rwAfGWQSRtn9VyjOqq8pV3Kl0bCM6epBM8kfTf4XbCrTnpROF9WRgYnmqxiT+cR
noCkcerw9lKTuo1oxbOxij8Q29wbwNtDQKOHOO3lLe2Gpw7wyWC+8nNkMuw89ZrTij1tzQJe/kNv
tQXnK/7cyPEUfTvYRlU/HQWOqGi8tvNOqqWNS9inq1//i/SwP4QfC98u+SdZ75NJXc8oUPc17h+4
Y92CAcYa9SWUkEko4uU6a4S4q0MBbWU7gxFc4/zs8ah3K0iMgJcMXRMUALoO6O5sOKylLPo5xyf5
IlRLgnz+2HYTTvL/A5Cg+5mjharyRkrZPMnb2ms+VkEcal1EQpR95sdn3JGxXvMLpVVEKdtahZeS
Kfo1GKSdqNix8fR4+G68Z1QTa5qdPElz6rLvH19eOqcga3JMybjVV6PtauPYAOgMtTk3rYfE4Emi
Z4g30WZ9wCW4kzeWngKPks08qbxXlJ/XCgiDlglnFRVsLFcEvc30h4xzZxU+FNfTZqSPmAEgPe/+
YYpq/5Zq3mgfdpMyVY452BrfMkPLuA/j5wBOsXCpWgfKUlq8bygPyLO7Rjx2jY7MPkS0YjM8lFr9
/u9Vn4eaa4mOEqdQWK1mYxmP4EQ9E0ZNdvdWXqyIem12dkgsaFN0GpEPqCgf9rMnob/DXqyBzsuM
uAnr/DpEmAsu//a6cTQnqPOPGcFdg6ljKpfgYc4DcUc7KA2R87v3U+oo4dOWzYCp0XaAkKzdcDNw
pfMARnwMc5PZ15JvLI+pYq5py9SEKDi2UiqTGLvmfnPbXiszdWUHu4Vqkrd70wR79s7BQ+yGdarx
OCGNxvNrKkGBjSjX36TrWiAzqGytXRXBAmXu9CWhcOhLDBJHe2LM2L/9mATNOrE6VHIVRIZgSc/Z
SMSsG0ML26fKnMDo6NbWkEYzqhjHUKDRsPDHVsMTnnlcuMxw89BiRdm+6c+6Tj06UYe6T60B9aX/
N4z/fObPQ6zUU2Ga9whQ/iHlAGQ8ABdGr3LQ2kGJ/B/rVeFQayOebwnl6y7GXm5ebYuYiHHeYAx5
d0dNNBfRsgKV7sIqYRAXiiuMKQ1nSWkL6ofpHNz0JP9sSEFVRFnFPyd4BpITyZQ8r5poMsWV9R0L
ibHcacaiIc+GlR6qunPoS8L4O4TQKz6+/bYRpXOsNTn5wW3KOoCsW+as3Yd3JMX5Nwva3mgAZWHZ
gbn1qheQaUMet5d1tV5Ttwd3/EAmABQwvLF4tNxTdwhVg83ZK1dGsZZBlZP3AqB1mjKwkg5Goo5T
Tt5DJHTi9V/of0R685piXOxCGSZvQy3lBEgPFlUePWdR+CRjsVSRzjAXbpkv/xUlM3DbIan4E271
SXuhsbdmiC+HpF2eO7qCRc9I3bWbYr+jBzydINCKeTBk2EydLSSUeBawPk/BDJbZmA+huBMFKcZC
Zq3DLgVC3VHX1YDAAbEL+z1R87aQNGhhOW/14+FfiOpAllO6KpHYNQodjTIyRVD8SsJhJm5rdVar
dzgelsfyy1fdfd8VtLAUk1xjv+etcjUyrlJmb4I5HbyBDZAOhJO35Nw2hrr2YWgk7QZfluEX8PmK
hjDbT8TxZRHGY8CJUD///8jNfkn6neKByMrR6FmH/Mi11+aFC3EXBiNlg3Sg3gd4QbM1usGxgZQG
hfaqlK2tLnW0eXbCSOueDMntVWqI+5StlD282e+CFOxFwPnwRgdCDiRS7ALKGhtcDfnU9Ace6xXr
9z3bubM1EeDcyrlfoEhYsZTECsZcriZmUSs+PaqJ03Ysu2SiaI0cBc5Lpz263bvedxoPjjx442G9
Zk3Z9WbRgfa5ac1kUSyIqoqNt9xFFKt5/Rj45K2NqT9fIrnB1yUIoWuw7BBlX0MMh+q77iePRh1J
fa10dPPmFp46mDXELUwmBcLpZ8ZPR4NJqPYxrkxOTuVQeYk2sV9sV4y3ThMX232GfrHOcQpuR3g4
vQQhBRfD0y4GTWACHKLj7nA4zo+Hwx9hOMRYG54NcKOwkHvLRTOJCt+Ool4afPNCLXzDppTY7bgF
8+LgYmA5h3/J5jEQVlIXiWVdUlHz99FE7tw9swug0WCcrUzlPhcYsZYv9cvMC5a6nxTbO7YuGn1k
hxxsydRO0P0jwuM+896fkd9lvrwBTFk1dIyGr0yG5Sp+61/MBlI/mup1Ud5FMzix+CcIyTtS4Cmd
uftd+Vx7zIFaFu/PhXsPEsBavwMECk7XKTLxJRA+MTjQrkzWj5ORhzkbQt0siWslfOBoT2AZAEF/
OPuDecLxIH4cphH7g55qEL0YjBI+zo5AtmAg7/sR0rZ79AN1tAjjOS86UZeKMnoa4LG+kgtkZfa/
ze2rv7RZlJb/FWbZDWne0VXpczPUueDycrztXEMve5bFHhLlQlxzTXN3N2G3IWrl7FczOg+olzS1
aQZ0ctM6kCv21dsbI3UFihMrwdWCleLkS4+uhHX1rn0Qqo9yWZ6rKs1D1EzEvEZEj3anuvfpl04V
fnQFPEmmUF7GtUTvclB8U3ttQD8mMk8MibtElrCFyiIr8o/WaW+6iL0mtQwazKsIzlMbZdzz/tNX
nhN/4Tc45dFNpEIj2G+wzB1dQCwdLyAHmPM5usAJUH6Bv1CGIdHEQ9D3VhG4hEm3vqATqj3qycbQ
7J3NGhqxff9S0ELFLlPQ1Y18A7rtRfi/5HDcgTFuIiXShdKB1Sm+66TmCXB8bft1tYJb1SnaUzNQ
8w7/O6Z7pjKFCxAR9slKI4tbmIcD9RNLbqqhdVP1DkcyFKB7pOfkaWMSYJHfit2vfrei9iQe93gX
04wBM+ea4JMB/iU0Rc68Xnt5b/nHSHYRkuGoplSs5l7g3AkhnTjy8YMHxy7uOlg8YymVDfQjcsR+
WYDKINVqHYJXfGDkj3jkOWXFieA456tVI/OQtVO7vuLP20Z8oqM7zFUc9B82BcvIsYiSPkEG8IjI
G7+2Fvr/q8v94H/kE6p+W2hKxbg3aKrm7iDApd1SCWKWH2Wxu7HuFwDyW6JM6yYiKVuFZhcKG40/
0yXv53uvZ87XgYA7C/2Le2y14o8t7bUU6UT7xIeRgI1T3ZhxE74ZXPD7XgNXA4TzVg4T+8pNwSUz
nnPxRNHEW05llpDla143kZK8BJ56YxwzAcuoipcD6a8ZeRPKob3GC1P/9QZvbLEpk3Km4j63Kjj1
5pUFCiNP0K+UxOAz1MvCu6NoMDcYUn9BOpVpobUL00XlMCXt6+PQAwN7W1c+mrTz1Oyf1xCJSDK6
73AzrZF1zggyQDmlKvHflHHGiiEK7EustQ4zInSulQwNq9Kq/JPVLRXcnmKBLc/SGVmJKgmOo4Q3
thmKB/5QL3bDXm054r/9ZNBLem3q2Fv1XIgCOy9FUNSOjy5rMWY8jwo/QZ3JXYqv2bedTI+Ajc+D
VFFZbEfOakBw8JS+C3NbzZdeXRylnmUCyaCwZW/Nrcws7d98q49ydMxt+1kTcLbKbSDFUbvq8k3H
zyiKFQ72Pnxnt+G69FrrsfqQdU1ap7WmmkbHvl1vK5pldsNNHvbb5mR8OGplnecNacM0dT0bsqTU
pLOZGuOpU20p2AmGwVj1vNM+E8821N77zxQRKBLe7xNUXSFsxI3R4o+qOR/MBXpe8aTd+d5Dbfdz
vbS5xPW0tEnjAj6BS0H4Q1m9IH39cqPJCG6G43kt/jRSGA91aXi3CU70AD3B7J7z2ZCRpj31Po+u
E1HOn9kfy8CSO03W/XcSkqY63orDXealVrN5O+Ck72MDA9LWIJ5UrifdzwqxlRUsmx+pVwuvoOxN
ZW3xhSOonN449kWCXqLaBiluxbTFhTQ79yZxwkmopQwXjAB1E8Z2YezQ2p9cm0JxjfngKPw5ySP9
RcvTBX4MJVU8Xpvg2FQl2zH3sWd/vCpNIcXZX61/4LNTRL22UqxH0yiBtRKAXu6FwsdfeYwtA9pb
3zL3VxPc8hNUYYk46EGrFqaQgnuO2pDBt+lhWfRO1TFnTB1pYEv3NIPaUxmq8PlL5R/JYNFx2HB+
rGTJKnn9zT5UDLwhJgbEdKG3O/LwbUv76er4S8xKA7Odo5jXnDSYvc/8pUv7BEOtxH2gsl3rRI4j
0cfxNSsifYuefub5ZSby1ao0rl2db0KwHl10iXFtKeEXQMUk7pWjon0G4FQo+AnmIwomKqbuytLL
9igg7iULeSAAdBFQnHa8BaQ1KbRnf3dM0hdnPMQ5eH+N+h6wsvc56vRRwOp2oPQ0kp6l/XbOc1fn
lSJhbkrelvrHeNSn1GzT5vHu0M8dPpFxON7bDYk9ZqhFKkjaq4/J29ErH72JxHIRIcgnlVDWNTBQ
KS5tRoRWwc+l0FrkzGMgfI5TnW===
HR+cPqFDRG88cbOseWZu8IpDNGJqTky5c8TJaBFFthHD6Vtjkr2EFR03gq3gT113Ni+BGtWY3Y+x
46GfR1cmoxdUWLGwLrpJ7XkmogtdpOECh9NkkfLZ9hxCSun9fejGRKtb2bE6rkHX8vLIrtVY7yIk
1AVC61Pl3Jxrbmvyl8g3oImk9eqSPq0sZB/guymc4WsjabG8v1r+O+WSHzNCO5HtP1Z3suaaTga8
YPUC1tQVNMpiRfTSHTIh+Xecc/QuN75UL+vffbacljkH7AeV+GGvodnhHRd8Psaie0leKfSTJ6or
CrnD3JY7eKguusqMZNNmJ4NWmMhbQbfxm2iLpqrSoaZ88YTkR2N5NGPAslRUVmM6Ym5mC3s22BOQ
S8N32fA4+oEMMyQCwIk0CamEDH/ea9YMVvQEozm5smHGdHkysaODTBXiwv00IIWSyPH3azQVLaoL
qacHiQqrk+8DX4/oGPYC44WDtOMAsUPEBzWFNdYeYULl3tUMpapQBfOGYq6xtuNZwO+a65icyrkE
oK/6s0GserJ3SYYmVFzbSTQP6qdzuOcxIIV9Tx10omuKrAhifKftUi0aVJcr+tfIYqCLFJP9G3Dw
OKqSsWXsKa01D5102Yp0tBrXB7WJQiLAUaTc2YZcc4T98yACL+hiUdYf+99vTKB2KnBc4fLkalCO
wlFa/Uhkm2BuPl0BH66UTvkxBz+x2m860Wb+eOaTolJoxQO8axBPfnR5ibXiHjhOrYC5Z5+Av8+B
ysyKRH9RoB+kL5UILS0NUhvnxZ0BgZzkE2A6oLof7WAd7fjW9zjPWZVSiG4XS2vPX4IlrKxPXDKO
dUehuGua84uB4fn/W2Z4zeD0/wtf04Vmux5R+eE+VTJlYwsttDF7me8GKghWduham4oiDwV+JJvb
33WFyW2MWcXmecxAV7xSD35/gVRQrfpGCKyBv7hQ7eCYZNaIYDeAaRh6sDg8bml/Y/DvgupdmMgd
hBmtNyighJ1c/w7qLaHZANzkMgcZez9zPVRRAgYR1lulDQd8NhunWLkbpOfMQiZguaGOXYTKFeGm
Cdz7GiylDCMmEYyTv34Rm9jjybzecKFarZMzWLkETzkOPi0GMazN5N2HazWYwTOwIcQRnKotTgZ0
VbbcKOXqA+IsECp7m3hO7DV1trfZMAAhdGqEhL8La71k4RvJx/QMncEKlOLdvSXlTW3c12+jYQNK
0rkQ/NEjhkXVIoF0d/cDlgmFLtrVM74mIziT4w0UvoTfn/yawc0QPHodlouQtZboaNrge6wE9Fq6
AEgf+criYcJxl/YOR1W2/Y3ehR+Ej0fuwz8VJRbXoOCz1FFKQhqBFJGIRErWMW8Xb0Tl40g0Fsk8
/we8HV88BpRw1b72cGBdgQx/zGHN48ZnqT+8D4YcHr+Kgpf0TLb5kzAea6JHw08GBV2aWmNHEl/w
A2h73CwJuPRNMhS5L8KQNUKPsNMbDDwGKt1wpdxI7SAR/7+VJruE2g9Hc4d1nGiIOsRQX0fHf/jS
4dgDjHod9OtBIfKRJaQAC+CoGsYedHLksB56n4MxmaEixSk2QPq/19ZVxrp+q9D6h6QN5C9KQ4tb
O8hOhtHECxl3GZaIVnGElUE+kdkFGOwTt3DhL3bwvJahO7EmInMJ/pIjcEvrLJXLxcIvmwjtTqZI
PJZ0rLoXomfeDgm1ulpJKOFdMPPs41bgtaR0gA5AFHVRjVvTIK4xnVcVfv8oxhJ6wiREPKWZryCU
sGE5EE8ux6bkNDr/YN6owSvvPLuNC8oFlLDbiW1TgsXGL39pBrSKyDrsA6dXMEMmYSP9lvnsoADS
q6vt68D0NT/T0U25r1csno5MmgJQaRLhYdON5K6lgTj+AkSSbKSNwq8fREWvp5PCVINCuqDo4OnW
uv1MtzCaR9HFRTB/3GnBh9VIdw7oV72DKw1mr7MxRYgy4FiJqCgraJ+O9Wb6kceJxOiLDVcG/qb3
TRBAp5m30/BUwIGFRziPpPiLhKCKE2cOg3IQ85UcsPb11lhO6EtN9o1XkQGaJgWZHQ5ShPSdCgdk
Rwwz/SamBxG5ZYpeI/QFabXispxcxiOZcqbZ7ZM3gOLr0wPqkbHV3dMDy/PgOJ6TnQ03n+fUy1gW
9uD85b94QNvDCiiu1iNhEfpVE2WZBrxRkMcaLCbaTV+QPWeNKcdomqoi4gJkyWk5meqoI2o7xGL7
RkHO455h1e/2ogGS8d8OWiN2H8a9pquLuZKfQmGLbaKFLxv+fCJvSwM2qIcwZsXfx2KO/4uCafQt
7HEQzf3qVh58t/ucv70V/t3BQc4qsqExo2ULmtUWtlbZ7LBaEgr7hDEOr3IhLiBzTfnas6f6wKbp
7uE97zqfueyIJWiD84xDxDjvTrcDMOw4PocY/5HAWNx7w4XInaUC+T5aDFn43SNhUZxbeNHVIkIF
7XXXDKByi9nk5Z7/ns7vUEOb+6C+uZ44W6xfMnWkpdFK6SWBYEtSrpNyKPwP8LVl5pgGz4MJ30oF
ycvgnxmgNS3l0qv2pJIGTmPAijT7d8uPa88xds6wpdtEWziu4E5gAOdw1avlznOqODKCLZTcNDhp
FbU3ufI0FHV+JjJ/9EY5NVfCyujY3VjdfjPWaT5mc0emCeJVER1A2SLZMGDXKCUItAVX8/Y7Nmj7
Nj4GAzg4xV6NMVFyvQiIXWAb9t4pPXOkzCJf5oUujcyq5arAzWYXucWtUS9zDgOzj8Y4w0oscaHc
lxQnZUrwo7CELH+4BfA8RhyuzdXOq11DamD5rwEbW+2T4fehYl21L7d2CDAhgbWlyM4u+GDEGWci
mLb7JNnQFrjctTfsjYH6ugE3O8aKdtr4ihBEYsoWuMBtIRNojoNWrUIECRprRBDD5VB/lhHknrFi
g2CqJJcmkM5GRBdANBe8CvUJKMdNEzAxf39jszdHmehk0lU4vut0EWKUpfzK2QEvb8CwXTyk/2IS
haTejOtEJyOmeC9wjo4sKu51pVDoaV/rh1F0OSCiEbmUT3FasvjhmkSVa1m6o2AL7cSgdn7Q2HCC
12iQM4cxRXLu4V5EC1YOpVWubAGgenTtjrvMFn/1ZxcFw/pzI1xrCLoDnHSH8S1gpHh0tqBpCWWd
KELeZlUvCP6Gn7MG/tL2eXB5nqfAt/Zz6wuMMrSDEZfFoLwNCLQ/UaDtyQrvdXBMR/ypnENUbj/l
NkL9NP6MrsZ3QIj+cr+46lnhl13My4bej5Lh6wVosCbTTX24iPXxSyJb+y6Zr3eE6d58AaVbEq2w
QvpRbdggdWHus5WcPzf5PR/5Cmjx0X5VZOouLHpuj9aggbUw2Nmtcb0OtvM2AZb9VDGKrQvFRQ84
cD2lgizC8u8VVpjfuvcuzbQzuSMAXLsyJFf+qRNeMkzh0jz27PVARLvThbHdh6ABuAz9qU6vwrhE
6x/2tBzmBxwjPrD2v9+IL22X5TOVO226n3TdP/q80HsxZG/GksT+QxYrkVkSZ6Xfj7eCjMIxEewK
ojLCh6O+cZTTyfsA6apFkG5ZYwgd3mSeE6P/q35oGvwJ4xK24kmpsdrv5nMX4vMSLvmi6hCI6LdN
OV16kfhU6In0axE+RtP0vhf1dsmPa53O2IK9UmyQOz/fXyPHR1N04mojgZx8ctUCDsx63rCpqoWY
HBJv/oEy2AvVVOZh2ZF7+iz7p5QCDe83nVvgyDtWGqCMIbMSDp54VFOA3M1nJxZ9GLpEGA2XaUJ2
uuwcngrlc0zfFNTl33DG8K80eWyMnczeW3kJ1MtY/fopHI1KvkEc8TeqJYJ3TKUMYklXBn1O6Cib
Q38zhWLVt0Osde6hesrlWbPtjgIbezv9Kn7Pti1I2h1CcGr6/llhh8pAvPC/3339XdK3+z5vdPQp
duGmHjiIgOMIozkRZddi9ljqL2A0e13mw4rhdhihDYMGVJ9JHfUCZJ+y51b9qmZN9sfqeCwnuDlZ
jEx3JPeEtaS/mQ6e4olO9yFM0g9FROaPZDkDkZB6mpK8g4hY6hhYITxib/jGMlqVWdkw3/LF5bY9
m0EFkGmqxerfk0eTLfDGB4p+bTN/tFqn2jPn58hNsrE8WbkSFQa+MGBPGc4NvyHgfii75lD1U4+h
XnQZbXvDy6f9mEmxP9Ve9GjtXPG13i98Z4AROIycPOdD3fF4DsHh8aBd4MtV1udA7J6jRMfz2Xks
tHHwZJ7WrIY7ojRogtRE3cVa6M8d3PP0CW0QRzS7MUdYpjDLPEphoGpBMWq+V3sYYNq710sAS96n
Os8ezuk5JrandX3f3+ffNo/UMf4jAwN6JeHNSv1mAI2fPgwXomzqjJvNH/eFqNGAVN5OHfAqihsz
+g2lQxbE+2Pl/t/VgGWsAkq1Pidoqk6HtCtcty47lveTHnkl5BYGUzPKiVzGXIgUdvP6PCS2HZ4h
TeZmKog7Jr0gLYoOgOHAG37QliVVCjs0rhig4utK+4/JfL3wILiWRl8bmQ+gYpso+gGaaES97cdU
gZD4gISN32fy7xI+CSxxFMtJMSsyjkC7RgwHAeaK2Wj20iXWHPHJ6sIb4YR/zKdUHpsFxWrROQ6l
8sn3XChGoNLhHOzknPTuYg3U4OueGkhKn2M9HQb3uOhGltbL+IFZaXWNWtRdDmzqarqD2x9M1CoK
VRD2B119qXAoEzbG66njsdk58Ke1JX8+MSzZbNujRXmpobpi4edVIXA86FyWFfkO6Kkx4vTIqMoo
G406+uE+371AlP1hDUms+RmBaOvp4PLlRO24JgA/HdgljtGBHmmFnRhKFZqF6Apen9Qn2o2Vo/YN
++NZteEdqphlrwI6z4ptgVe87KgRZ93uIOuJnOYYWVLJLi+79YqrSsCrW/bynLLCdiy1mS3G5V21
GBDruIvyduD7SdZDcw6DCl+FINSdWpthgcqTjjA0RztzXe0vqlXYp3Al4uL0q0w5asbEPCzWHCQW
NV66eeZfnctfCIe++hs60FiIvKGhDubTo3DAtn15KrLz46+v/Tt21sLxsXfvivE2HJhkgWzVqhtV
n64OOaP0t0yLvyKCY4cj4/YrhQCqfp/QeDqGFMf3vaG+mmcX02iINO95UnUPdNwyC6NPUEHoao35
lY9JGNG8tRHJ9rXM7ZbN5IIkQfZlYSSpgPoVUt8Zk6lgSjSM+hJA0fH4qeNI0mh2auLJnVgGHUzk
c3FAmlw4UzjEvbDuK4aGR/Bv83HLuQFOY75Sh6IYpaLm5d08czhNKFV3FpzZg4tQvgVk4oMSxi3N
OeCnSTwhJJceUDV93YCx4kXcdZwckKXnOmaVt5Re3u6yWynlTE324qMFXVDYdEqa7c4dUHEAEbFX
8noxx24iC63kkBE87kT2eaG4BQRixGE5pagdX7eeY0o8kAKjXx0ZhTmIgant11al+cbWrmfcftFk
HbRogkDNFoNENjb72H+MbB11FeyKCxvYdKpWgR1L6CqEbJGOWwJ8OcMsQeDEOb2VoBIXv4giLZM7
ZQnPwrN+5rJJn9984+1XtJRZTzfk3SbGVcAf+vdTXGwf01p4R6FNYQsMc2AtPm9QVVGZlOPuBHAC
3GuskUdaD/Roe6b8MuASGGM74GyJ+KQBToP1wgNQWK+i6ihLL8Hlz7vzIhMW/A/qT3ibmrqfHj5n
EOUPJMwvc9I9ZdPSSfO0gfUM7LUfPRcaAMja5LbNun9Y/yfp+XjsWTQQ52BG/eM/vMzmP9yp37QS
O/d6kc4Ibg3ej36bQNWv6TXGMz//27qNbVmIlyLoMyvRt4FaEFm/ph8F3R5x5NLpYuRFQdCKQu3G
vIfebWqQe7i4YmG4VyPdwHzb/ZDoupNga6K2HGddjKUzhuU8y+28137AmzvXaksDvsbI/vxkQWkZ
/LJ6TYW7MBKUmjerhmqmcjwN8qPDxU/1+9LAZkc1u8MrV8DqSjnhmsUUU+fB+ECUbZ6YL0SO6iRl
nwBXlr5FYk97urw+fjxwiJEd316Gg/LGu5zA2lh377x3Nk1J84renSTjtyfzkJsdVYdkaUN3E2aB
ztnQNQNfH+AOKJOZQgwPJh9Mi6nItShqndJHn6AqpwvNLfu3KQCIdYoFvA+y5NKpw7NkLqc4lftR
G33NDoVlxfuF/jIjSTTg+OllRXas7pONtph4ElcOeGmmbOTIyCVXdN23t2V5FcLmVXPeT/dcjOPd
9SiDMXxCjT5sTLjui2oL82IUp8fXee3Y8b6Q8JaupdqQWQNyOLvV2GwK+NLk+e+FE6/UX9rxPUb7
Y/DrJqH8tmMGR5TQ5+Z0AxrGqfXaA0Rlgl+cQjaHeFBQEsStGrpomE+otRg7v6JBAfCwapEfl2uP
zdrI1NSKi62UfU6tPzsGD2xlRu0UIyMelUfv993seoio5iLATd7ibC7Ny5T5mbcKro7XhGubtXM5
Fjc+4mvSFPAO2agREP+ayBz+WYRZTiA5qLOfb7ZLBTSYZeSTo4mkOSURc+9xMaUtHT9yCvk2oSqS
7NkBvEMtUVxXcTLwC87EHzjg0bkHnWTUz7VzK1C2kHmW3PANbubyMiocZY0flvZUtBbQcL9fLyps
6UG2TXAjvSzwbjOo2ZO75Shuk6TqYys9rgsw9QyJf97tFWNNGtg5kYp5SXXpL8WRfPo2K547otKh
HKSHgZ//PbcQbiUWesC3CmKLKtH3ouguXdC+0uCxfuMeKPCmIONuSlEU6hnBCXCMtRivyfqcJ6Dp
+XzmkEyAqKwvpVrUwgPgCsMCNV+o/jn8kn24v/IUNaSZn6dR9omV1PSW47Dkixxt36qni+tyciWT
67KIO0FLNGcudvf/27RxuW28WLN/AyJTwoFAbYp7lz2mRp3kw09pgPUzmOLgklpZE92aMhKzUCP2
Bx7VVjSbPW8BJaY9BzpyhLV8KTFHmEOo9BSxT9DRO5ZUUAcZowZg+25f8UEsVC108kIspal0eGbm
W5Z3OfRNC0mPri1L5I2cUe91OLUVj7rPY8w+5o+dLWqMQPPhNMNBsGUwwSCwkRLLx8PHKVKGzeL2
RlUyanUQeCy/jXrpnqtPdj/h6HY18NE6EjrpeeTq3hFkaAAoi3IYmoKX1ifrxiamQrSw9/1eh/8E
Y+kSVp1GMzlkY+jqPXu8BcFc6I4E7OyRK+E1nUGvpI/0/gHc4YpL1Rx8ni2whm+EQxVx/rNd7/8p
pnYSLVaCpOhJ5LWPX929xJre3Z+LKXma+hBaHnJLBmjJC7rkFzEhAL81+a3GEtQ6Yl9iN1ZOtRx6
j4IE+KGEqgjs8Jw8im/tVcVAPVPNznfF2AMo5Y/92elpDFC6l9jFRiQNU68KxKJo5NAe/ZCnuqZm
F/LoG6n852DC/omGC+fOmtSSYkcPMuf2SmLk6/Y2Ox8kCC83utDJgZt3uyLIP9E7mZdwCG9AZVMl
XjVprA6vcFoIGWePa7UosHEQV3TMHrjc/Sxdp/z+V4XfkADMb09VcBDSTITPkoLhzcS8gpQqRK8H
0K2YBWSm1GZHPntw9hV7gcDjXhbbN1BbuxFi66XktOMCxqkJ3eOGtGmbsvkJL98EmgjQRffE3VYe
Xu/Ru2jgHDWs2e20593tzr7jFq1Ewh3/I7TI5LrsbR0noD8S1mlhI4Vtbg/zVTOWY7MxkcnRCbBP
wbFZ6eKoR4XU++n7vV8R7h4pc3RedIrDtRWOXb7fwkbEf1yJG6K5jRa0AlE5idtvQixvf2QUKcND
nqatYneRm8IXT34nItOi+zPAuag6BRp+GwtjV6AlZapQAAgP1fbgZiYL8V97SCMMRC/N1Fq0D18F
6lM1HejWYtcl6w/sOBlySSYIZakNmLDbxKtnYlEboXT+pE2XJBOLc72xAju7WzjLNN8Fbb6RkqGS
UFuH8HkO/c98k8NRxGv6uzbt7QXMFU4VN3I/EOaRuJWQUSVBhW8cmBrf/QZvulUgWWGZNyOwS9W4
7BCOlbN5o8d1DpgkBpCo0Y2NZXOdPZyQrKROMh9Ljx5MyUMAMNI6X+qxCH/WiU9lhhsBOntgKEhD
vm3iEONA8UiHnzGpAYzLmEANTA+Uiet1pApGd6nowqiC6Eqstl8r36/0VO2cvi5NQFabqmfp2ibD
iajO2ugu2i+O6FdmO/js7ricrvMOFGDKLHtVErnuRXp5NgPhCfzHqst88gVYiQ2u+0vfjzCkTsC6
YJKvo/L+n/mdVlTtlI5WTCkzOBn7vYC6vz084QY8QEN/NbaOjStzpKGp+fX9MazewU/W9MWvWkO4
JNDsCRvKHc/Fa1Y3tcr7Cb42iZlJLsYByI+rzNzNrcz1TgtTUrvm4nBI5RNukAh7330QO9t+tpOf
2qiDrF45KyAOHmtckuu41i1Pw22Db/QSU5aNHi4aGYwDmPI6RM/m4OAkjmK7Utpgv9ZePrsuvcqu
SOxSEhLwlwsgoHLr42548qYOIGTO/Ha+i9f2L1bS1GBFYvmRgVlzPjf0OtLNtF7NtPXLBYJJ5WB2
s2ypMteeGFRT3S4tSbIwpZ0OTIxTH1cwFgZOm9Wclg/D17cLmCzSJxpzXZe2VdJlQVDfY8MHweVT
OIVgvFczS6VjQ8/vhUfCcGJknktCEa1g/zoQc0Kfhd+Y26bHsViDvwYXyF2Y80==