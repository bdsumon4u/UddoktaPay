<?php //ICB0 74:0 81:1517                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPp5WttpAuoDpvAzANwZrb+rm6J+ag3AxCV0bccbP1+LywhUonirMvJwg1GV4BEN58TfZvTsZ
7NqFIEw+BE359VCDuTtgk48IXzE9Ij7eZCHSenGdqRc3jfXGW2G+bgZVTn5sCyJgNntvdDpTYKjT
q2RZtBNW+a5bEP6csqTBZ8/dZOJyMFGWXnmAC95CDUsVhSb8ZH2p4NKIkxK6q4YwijEZh4h0hK/S
fqcxX/7N5xnbUq84leZ6j/zbtR1lYwa7YgfRF+0vYYPGE6lHDJJSj6oAlIiWYi8TPY02Q9cN3t5L
fDAqCw9zOQJDjjrjt+HyO1Wwv9WwEEkYrF6eYkaW/xkF9bPg2di5VRvFsuPTCMPm8BbOpfZNUxbw
8GoK5KCYbx8ABIvF0GTKBLttbbZlNz960h1iKJj7s+lBN0XqCfe6vmvX9Lfo2SB1Z+csJ6L5o4fa
o/3mOxOcDQOpRI9vMTva2QqZcvDJDV21wcy8HkH1Vxvu3/mAQjUKc6rkhWIanikwkgAyfavhjLku
AIedLEnssoJ6u2cdo2OUv760/ubGZjbIHI7GhuKI1fcAv+uFTJjd0i4jKYE9VrQ9StloJkMWu4Vr
WFULuu9oRQQ3UzwbO1jqRufLnrc7gG1z3KUIR8k11y0lPDB6Z59UHlSso7Jb7495sYJW5mkc3Q4d
oaB/jKdzDzfJm6b11HvYGaBWLgzuIW5R1JQpzoeJ6GI9IA4Ei5V14HUMNNaCxtYPmd6mwBHjujG1
ikcYcAS5k/F7RP6J7cxrAG29mkHlLNmc6GBFP2xb2MpNirsDxH5bdmlArqGOTLp8d9iQHHxW+kBw
KQNZC5+9kNNyWlk0GXM7+hVTFTdYjSyD88huQhA5zF8IwmpecTTOY2RPZmokT7bkq9FhY2bC8DeE
uhP2MGiplE367/q6BV3DeMYutOjYPtrqJFnVo0R42gaHc7J5jMBehp1rLLXVHP3k/lL6bv8X59W3
4iF5NenX3edlcvrPFxowjgqDk2hVi8e2U9cN711gRieawe6SWihowThJ4xhZyWvaLAXtvRMFKZfW
H0Dj7Ous54mw+gkkAaKMWgn2LBF+GPa1RSf2mjd5bLufeR9/ZFVRztcu7gl/D4l2r8tUdDpnLIl2
R8O5bXgNvvkmcazV5Ak0tDMTpEp2aW6oCcYkg2cxvQaU2Sx1oI+oXcYygJdBo17IBgUALuw7aHI3
xjsMcrOZ3loQQe2ZqStG14Hof3l5alAV38ZzmaL6G3XLzObPj/DHwvMY6wnI4VWu6S3BNo9qEca0
G+UCdJ+/ZeKV3GlCP/1h2HNtKGEeMoYVibWcVBAauH0LxZlL77+Nphp0wRFLofaOTlyBenktUZv3
ZjeESSEP+Onf2pCa4jQH9t5mHpXdYQrEFHAllbWLxhwfX1aSz53kDi09yOobxLUBaGY8fUps/i2g
Hz01yDxKHG8Ac2UvSX7eP2ZSRd+Oehy2YbVyNLIE/qwr3zIP8Um9nei7zbGdtlmqfTTn+7EEftJb
yMYMOAX2Os/XJH5FGah2o8584Nag6ATfY6nJYOBsacRKiSspCoPDm8R3Hh5cx/7wSe9iqkD62hHa
Miviht2uwk0in3FKJQKF1uK4puj7LxWxvyS44kwp8BKgVBhyB49C6GxVTDlz7Gca3IjpunRwrUTl
3xc+znlJ2yPiU2A52jUZwtAD1AnNSDp3fsrnMhjn9GQqc24T1wZmeqivhN3/yegPx9gYUXYCXEeT
aJyPYJ5uQlEWkjo+ly+hcVd4MIdYGuFwoi9/SwaIsk/MruagwPlYoaOVBQ8AJmFqGUO+12APyT2i
QSIqIyVhrWgT8s3PnyUmfG4J3Kv5WpMpEzUCYzuKd8uB/BPXiFhAgS8MPNAMzM1zw0Lwc6J4sWUl
MxhOz78eAJCXOLrCV2sIhdGdb6roeQklW6C5PT8RxFzAKRDKX9vkrVxV2MkO1CJAV27BJ8cdUu8f
zACxLE/4sFWAy9NzNoTrub+VZCLtXMtk9Gl0RBN6R6djrMPfiV2D1ehaq4eqZ/GvCJVa9T6T3cT/
BCnzUBJInLRL1PMm6TzBKHD5u+zAv9n/V8srOtCIAJcFP7+ukdMOdGO==
HR+cPmIVySv4UChXPYPaxRct59YmZICMCUiG0SMiIK9kiIQvpYmO9mz4ygjW7satmu9UR7DXP+rC
CJkGwbLQNiczjxb8v//ot7J1ysg/7FHUj53vwZ4kIaB4PrdcEdbmziDfIOBdoPZvt8a6dSI0EMkm
XMkRHrpyCxUVeDMb+SzeiLL2CDfoCddamvfbBiRgyBNEZAMZlYO0Emj84TCcOflR1RV9PfPymIU2
Pc5AKVAW50PGzEEGS8C76aGurOAbu3QFevZg9pXwqeOYsb0mIX2zk7nfNXOmRCEkLKjLU7Wt/svP
tWQN24MEPjPnviPrc+E+msTtS3UWTrfU6QrgAr3cPlVQ78SiWs3k4jtqH2wYuXjulJjVMtnd6n8K
4NVCZE3A9n6SXcbkyLAA01jnE2Z/6L8SQG6f7ZHKLBiBgeSYm8s+lJ81Krf4wC2C14cF8Zat1Q5F
MZrHHQGSazeju55p3w609HF4Q+iSnjqBjFMAiR4FBCTGGqNvPkfRdQ52o4b6gWKsZJebDPX5szWR
vqOWnk8mg1aoPvigi2QJlw6Rx0XXmwdS8ThS2VZoKM48oueRZrv7FnR2RLh44Q2SMC+Y9KJh/tE0
DIbbKWXfvQjeT8jSFiT+46fzOMi7JYTjxXXxabFxho3daLWGDaSc3RG8AMnqd+XuxywNXd3lzIpv
TBhZl1DsfzTZUIWck2TU1+aKxtYJbYmSFgkMfXly2/oOC8PQRsMRRl26TMRA3oH2ZdMfOp8rgLSg
6MfDM5H7KJsUp2ySwcTQr3NXJljw5QPLFqyhFhD1z2KXoDa7A99mW71vzH4/ly3i8Y2NbJ9h9KpW
tTOvIPEMA8asFPEySuZ7bUl/aRp1oRaU7vWKJCoGJaOgjJHgTrJdO8uumQmPdmo0SSD7TvWqH4Z8
Bp4maoqdv/DV4/FkizOOg8pUH0/8ZADylOv0mY3RouWYaKnjIWGnH6ENGbkA1HJ95LcKyfXkKz/0
q0IPlIXQ4OhqBr3SjgxP2qO24P79MZ/RmxgN76Q4/24UacFDGBk2pkdM+3vyJBl8Oi7UDKp/oCYO
fQsLtXUFEJ4e5O9b71Cxric647hWOPPp3Do4O1P42mWbxomYuZEbXF8adDmFTn3Wg63LfHQZM54p
3q5WcPlJ960Sjk3louxiGvKNEe0PvJ3qS+NWAIjIENsTcdr4BI/fs4RpEr6wrnI+uuINg0trvv5R
mfATy3SVgNeQNia+D+9avqpFq7p4XPoEqnxFQzZEmPxL33TWTV0DVAOH9yKDzaB8xahptNDuWBup
GrS1uxI3XRfVAGHMWUe6wSeAP4owNQ+nT3hWUbHCQIiQy59k1/0m6EWgO06Kh78BkLl8zJ9dAVR6
A6jw1l0vKuaqx4S4BiFpKRfIiEq00LtH/A4z4uleyo2PNoIdZpHkG8Zj0iZS3bwIO5EDV59opMv9
UX642HNGEZ/cLQLjxg9SFH2OHnUjOXw0WBav2xdMz83+y1RR8Gd63kOipE3lZB2GgYfmpWVa2QOh
mhFlXEPfOJ8mWq85FqtWIQvJfbkc4oiHkgFlmZwTn3M/5O+RAQkWfhALM9AmRIzybPMME4sCNem1
g+m+nErr3tS8na1U/9wJ8yobhQ7B4RfFIi6l+1ckrQDVONIC9AKI8jbe8eDcV0ngdejJ7K4hB5r/
5UERqJsQEsY+SNSbULqNOyeNqrPn12yKcQI+W/KM4AMXAWiD4v3NH8l3gLuYERh8TjPqEZhQHbym
ewCCyxEOZ92wmT+JQSR7baks1+hGyPxJDG4IbO9UM72b82q2ijFbjAearhK3s8OARQJ+y18OMWXP
sW6SZemi3uubiuten2yQgOem2CiT0wBa+rwA5HBiWe5jSdttSU1oOhBC5LhMf36PWhniC5zwIDIs
4dSxYqIrGIeH+m==