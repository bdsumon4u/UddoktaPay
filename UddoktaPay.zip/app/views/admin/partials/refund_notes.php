<?php //ICB0 74:0 81:1bda                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPz+rAnrYBP1I376+FkhsYFlJfbSP425FJhNFdPLocSeu8BOVHcYT45LF5OcRfKMHpxWOvBs0
Dqty0LGjx2Bi9u1nDFZ6UrAT3eW630UigJjgHvfrw81vIpq1vWMKX6X2A+FNekcfJMHNwqT6vSwI
sjCoBjXMa8x9lORRlJu5q6mLneV7caOinEvfhlXHP7kx1u+EC6jI+C9su8e3VRGwAM4490P+cfRm
k8OZ9r3TmcaG5mGK3yKiHVPgc0YsO+gz3bD8Ni6FG/zuftpFjIhieUNys/oyZP4SJW2W3Qaq9Lq1
JMhz19QQ1YY8Xcx/SPKBFniPaIJfUGFjx3R/3b/JB2+Wc9N0DUEF+r1HwTsd+9hsjrpF0iXc7jD3
+Dtb6cVeWv2GB8uQWq0lqE2Fu1Sa89HU2MDEXAtjmsE44rse+9jRFNCQ4w76GLAi4Rf5n7q8nDrs
D16NJnQfl3Xvl9RD41T4dGHZr9zoMIIesGpv+c8HpINRBczliE1DilScNAZHSK+ag5Gn7U2j0SNy
b70fuf+7i0L5mN2NSnONnFjlu2Do4gt7Kq7TYRs0leki3HUZxi6gcCNwlms75WUNX5RB0xRPKq4q
ph4ujpfCwW0617Sc4KlbprFrgyU49S9HvPiI0h6bsndV+DQAhvgrASxfzl0YZMeinng39/wBFl//
GJT69eIGi4JvPFoNwjcDowyGZuB3vb+b8sy0LEWr90iXSp2F2SiMUz8Rg7DbXY5vlEq5pmZGiJvg
pG3SlD0cEw5MDNbhGUiB1LHtkFUooXrv+CRn0f+plZg9z5MssyQtTWNiJDyjYdArrVTv4ezW0qum
AMk/Q8pV7m9E6KZlVIRcGaRXE/WPMrdHGb9cm+2yFImMbJAH1L91w+IdvDeUhyDXIpQXHmuiRfKt
OAO2BLxkbsrVuvrkRJcMSDZZaNaA9rv207AE9WkPG/GWVQ8ITJ3r40nd4Yx5sx0kng6YcSlivAeC
4n5mJKTgJDQs1GlHNT17GlSFI7ifjxh2Z7SJocV+2OKHdaoi804lmCKudsS5A2HtGkkaAo/Yx0du
Z9X851hQ4Gl1N0yQz2O+4sF2nN8weroOsTiidOFs75qGZCRouEuVnPY+BBIzQen9ELvvC+vdQum8
Jo1DtyBrcq5wph9pB1gy2xlMaADH9zA6oozj19CEZd4ckkIQMVfQO+0BRrO4//Ir8n+sWruB67Mg
qfMo9H5wWfKbDNfkNSD9lV+RIM6Yog2k4NtwmxRUSVtDHUY7+6pea/Zk6O9B+H7Q4I/g0w9XcQh9
kcYJuXqq7lfZjsKJv/UnxGWTwaordbc+VJtBUh40LFaMmZPdRucGHaNUq9coUlbe81z4ts6MbpCo
qt7/puDHPClPSTcCpY5jNGEQ92oLLNRcAa1AbFehtSyYeMEnhP8s9ez+X3uZ+uHcojfdoEiSC6nF
43e6oFDHqhk9v4I4puQeIb1YeNY4SFAQ/E8JXq6bMjO3AI5XIrMrhnmVeABLvmuMyL1+OVTuPxuw
4Gs9JzAf7/BWo/FpeIL+T52Ae/6L+ResWGOD9uwOrOItASbvvE33MAJa5q6+Plkh1Hjpbo5KHdqc
e3/O1ACPlF3cosDjrJ7x9Fl6vJTVd5xxbr42ax5cM2mJT+KXzaWWReKMzijjYeo5FOUpFT9Eja7Y
LLwIBuumzodf/sNenMeBsbG3ZQxU3tqQVKTUHCB8IVkmYpUl2TfC9NZMgZSWlywSAxjB9jfMTFYS
+3wkFGdpXxof+hhnFGmeVndfEL+ZG5JYBAm/J/DAt6q3+O0u8myFlGS77z5WhVEHpjPAxsqPCVz/
gcxyO4AzXWvEr0v7nLHTRLldothyFgdLxfA9bvPvYuq6MwldDTAtNLNMcP8QIUV3b3+v/Rr+uuwm
rLXVMJNs04lulsJg4qtgFm+rxY7CQEl2eh8Jq5sReGKt0ej64NbeE3VUe3CpTOPpy+Kh+Y8mWGGg
v72GLyIL2xQKr8EFxNX9dhmBGq3zC1+FQMdQxh7Anxuz68Jt6ny6Fh5IMt2Q67qNORZee5lftOcI
VmF0cQKM30+uOCy+X/ozCvHDKPPf4rjtB5817qPfS9ZWOyrB55uiLsMzZl8cGOAOZnUOdAZY2CeM
g2bfQXsg/c/j83/7M/pFYCXmCCbKJDUwd2lopKkgpL9BEkI+rngL88cP22aFyIF1wj7y993xTABL
ayTAbkIvXcId62ockDwrFTnObWYsmwQLEX0zQynyjgjrrl2Bub9EzlYsU1aYyy9lMBrozz4D09Gj
de/Ky1mdNt9FYydduwOzmmOsCa56/gPo9Jgqvsdg4r8NfGSOIGt/oO6X8JbD/ATvD9mq4KKRiJ8L
hbSnpKzFhVEBfVm8xY1J4v4CT5kdboFqv1OhwuZbmTXm1PykKDYY7KW3UwhiYB1Bnas3U+v6jsph
DmA8DFN2DniEKv+2oE3a6jWsGMF+jk59X2joIQaXyIBZlA/oGTcSxUCRjEfQ6Kdnf6OQeNDqiVHy
b9qM9UCUaWEqlLKHZvTaP6kScPTyg8KVEcbAn619DxSKuWTZMklQvSVStoI5Rm4XgohQNIsNgAX+
2O2ziy6iOS1ld4TEo39FrYNup+r+4bnr/CUtLBhfswYYGiyUawAMrhaTug8zHrtPc3tpK17dt9vO
NGpTf9che+6j5qF+FyjUEwQd7eij2pIm/BsKiWyrWL5xO+gEY75E2nxVYDHx4/h5pTawSh4IimEn
f8bzXHv02XGvluiPxh0YqjRISFzfdLmRTdU3sLgHnjUBC2VFnZeTmJRhU1nJStlMHBDkLB1HnqwG
M9kh5RiGXGya65Wo20x0dAcaygiUKtUotuhL6R8q9m/Lr7x3zp77Imo8wl/Vcl4UGxLHnScUjnnE
cUqEykAZTkF1Zn0V4lCo7F7w2Smc1e4BYtKYkTC6kbX6IoeTmJsMSgJWOuRSRXEJdvIhcKXpo+nv
qelSeU9IXD15dvDbBWNA/S/UJEAhkfCbTQKXoYo5Rl/Sb7b4BsLGWUuh7h3MewCiUXT4sGyJS0pg
P1oeLTTaNC2opRwda1N+uhxVnRqPU61+Y0Z6T0bMJyN5RNRY8DwgA7dfMG+lIYzBbSyE6Acf8Qpr
SmigbcMjZKMrQtYRorucHbgL23I4Z6HopgZIcN3dQCTadHHneeF2olSLtpQWBWa1Y0eShp0ugMhj
TTrjDBL71OoozXZiDkQmL3UbZbqKJBtDN9GhR52cZSOoaeyzzuz14Itx6gJya/omDJ+qW1EVTE9l
AE+ixwrEqtn6egI2CYLrd4EMWrwAO2W6Tcd5YsCEQMiOg6iEEJVnXW141veDbebEkKL3ONGSepS8
pzfIOZhHOAIxUKek3jP6BDkyAQLAy5t6S8ZebX/1zp9Z39yHqcaY+u1+2VmvpVaiaQTFrce8HcOH
loA9Cmv4oWN9Ohy020KdBgl3gUEF4ZCDjXSxq05qyTKo9Dr2YfDaQJ6lZO7+2vlzDAlmU1kSxYKo
HWTcGXOT47/6uhWWyyS30h3qmhVeFyJyHdswo6MHQY+LYVCC4lLvUDymg7ABfj667HJP480wSOoS
2woEfaFwW2GrXGYEe1rJ5c7Utr/VrlKFQ3fTjVyOd2w2skPPlIOlYpIKqNvNLmGjBFKTqOC472g0
BV1SRen0z6NbhAwQj9kDWdcMuOqeOsd7jTKhHKC+vNlDBfoT4bXWV+F+lIGGufHKu/3QAyc3mVYG
VuKgM3iCOoLZeFdrL1D7gSdyK8HQQ+5l3jhXTVAWcZ/lZM+JE0pDufEml7hvqbC9h/DcQ/1mQXrV
jqG/EG8Gowwl1M5c=
HR+cPugStIR/3cGc2V4gI0KqVg6xJy2K/PFNkUu2yCA9pAZon0HC4FCjWcpK39sGtmNr69VRLNOd
29PL4KC+6L30b7Ro7mkE49y9rRo073kxIH6sQTQ/Oql1aiLIYdnOOSvFc8+FTIu92b7z42B1tiOs
XlLUD6JhcGniNBmc8O92fAU90ERRhyo+/TO5vt1uVN7uvDu2b2hRCQC8LNnOBvZgMILwaKAC1TV6
8UTfrVDx3DS69Vm3jZZbBTjmAnimRbbFfsTP2N0JqRZv8UXfIc/poZ8KbDqiboXbGrjA8gOQZvp3
SV3x+HcdkS9gNG1noyfcOnHy72//Ya9RVC1+0WpbdWbZ/FHOqSjF7mcFPJjNwMQC8y3TRxIT7AUH
HXTtneFmwQ2i1lkJCzm6hKckAE2ca/+qs5EOhEbAdLXYJ5LGuTCMqSTQpuavoaBJimQplXdutGd+
pcOeu6S/a/6LWAqxXUqXFJC6pgtPAvQTSkS4AY7cu3TpxDGw9JP9SjGb0Q44fHsaPMfNia2i0S+p
MTEEY6U1PlYBEYjKk5L8lNvas6RpUqdHArxyZlrhSn/qK+OmLZIVHIhSn2x/0nEUKS7Z8vAnsMU2
zO1bTsZlmK1kTPKjBDoSqrKo8UQdNOGO+q7qELMt6YSqQRBtUrWXL1vWRpi7QV7Nd8G7k3fJkMZq
ctIzyC5jwt9S0te7Jhirpj3mJlyNR6VtPd+V47bzV3A2ufNOoxLs5b5Po2NgXgt98Y9x04/oLQzC
7fkfXUN035SnVKFKRwceoK9j0CpJRflxlwv9qmwrfyYMhjr/bzrJORGXsNqdOpNYqrl8dJMfkcxw
H/2jR66ig91hIuJLZpCjBqhabgXB48pKGlvf1hiJirdnuXcbTxKi/Se0XlBuGwNNsyq6sWjapw5o
TLL7WIGmre6v6c1ivyiBrIpUJGKub39qGIv+E/JAMYz2FfGvNF+xUu5kElwIHRWuTVkHt85nIAmf
/6snboHgtGx3XB8uvLGzgWL8eIRTaj2XOI1BGUHs5CFj7UpPb+gikW2N59/flCgRayfLkbvLLTXc
znHjjZa/iBOvts+bWWlfclg15W0SiDq7XooQD8qMeLUWO1KjWa8OrmfC/0nktwz/U8J7/baEvBL8
w8/hb6PZ1W9vNqUvsMGpzDPQWq4rO7HTRKiIfmz+3xNgFTqtd2HO8ZuMpW6N0eEBACMWiy3zPAaI
r8g/9NmFyCBz5VLC1fKP+3s7QIBXRKffTbnwo78Ak3rnGRhxE1wezUb+pE8iOyFBRhGNw1sDaSVp
5OgBhEVOCIrKM9gwgP9jQTcj+sDc2LYyuJzBUuXhXMiSc59rDtA+eC33CPsEVn9pYY5FhTWNt1ZQ
OxGig8MsPYP53WByo+cBIQFAl4BodHKAXIvTyBi3fl0wTMhuEo2JSaKVnmqAIJ6/ly1sLfemtiR/
6atE31vSV7kcjpEm5Nu7meYf8zBhvKbXkQEJ/oZxBFZKCztiwO31rkTPXdXgoYO8myqsVOj//tV0
0DMszy7gV0Bb19HSEq8U+pijQuYBW1tUNI8+Tr99RmCJuqeeDqOUR8JGqhA/Xek8xQ9STa4BEkZW
l9Tu16abWxu2AV1ALdLVQtG+u5w97G5p50cWj71Xgr0EviM/Fw80C0W8MUtJTsFzbD+UP2pvUD26
jM7df9cAK9TV2ZYtIBZzIO0GyO40Oqi1lIAqVcyld8vG4Y1RC0ws9L8eeAHB2xFuLF7JWHCoCVLr
hxsAGJsR0DN12d18p2kDrgDmrwrMnPv6Lf9LUL9wvjEKVS4v+IiAmrT7mVR9Vs/8947V0kNULEIk
JQfpCElO86HiR6muf5KepopLn+lDrfiEcvYRZR2sy/SUCy/k7ZO7bddHiuyZ419D6X9ZRh2AcJfS
WuUYbgzhAjtOenj0BOHuJyjdsI2FiVw96U9wRs5nARmU11eFhPL8ibBAq1KdnWhIKEA481Opdz3o
iJD4zUA1TCSnuoY29amLVFoftS1Z6sbNqUqEtxruwTfS2A1xsCmTvfkrjJADG+wzsiPgZpDGiEQA
pLeCuAiUbdXcmvWlE5NemIOY7n/ykP7tRlNkghLWhtA+UtEbbkUff6NIvOz49BkCK7FldmabIGTS
O5w6ylgqAcu5DMy6XULhv0IXQNAzOjsx2ItHcvpAfiNDTFq0b8xrR6vxM3bJsIL1GuRlY4G6A5bZ
AVmM7fOvjjPCvWda+Xw5Wo4I7FjVDTaXOC/T6cHEqOo66rJ+WULTWfjl9ImNrA7Il64+Brnd9rXD
eEQ4eaDYav8WPixSnVjVTs/oRSZ+qF/CPA5wX7133UyWf1vgKakXMtEj53sjLgk4W7iO4UuXK6hF
fH8bEM3tCBUhm+pyr1R5TQvKa5Hj5B5A9Fma+c4lrbqoQXYW65/mnqvL37bhTEZdltkWriFfAoH/
nQ07m5a1EQOsl6jE229FRSs+AhW7du+Svj5pJ5IQ7tl1C4PDnsR45RY9NVe67HoCJ0dakZDvNx8S
4kOkbwJlbeyjANbCYr3ZzpuJZd4hLyj8g0Xgm+o4mnbJIC6deiYiOu5ysl/2E/aopmLnM2f/HuZa
uKNs660Fv8hsckurrVyjmPjOMhg+XsHe5genPtg5gECXR6rpvAtXY0dtG5WpEZO6/0cL4pa8A4lo
QwZv7wtRVMTWwBY3k9FMXkHF1PL7nVfnyPdad/uG0PYGx0StqG/rHgQzZbTQasdtL/wUM6bQKa3w
tH+hahaO1FJwDdiUby3ApBBX8lWCPCTo9+uA3Q3emC9gVrV/iegLvS7J6ZescpKWNqXcDMgEM7tM
anfptoCHY/1FV9jWbOtIHtyN1hQaYM4eMN+GTW5VR8PhlNT7XQiZskjc+92PU4UDznHuWyjklCT4
TWmhEMO3VQdYzoFvIGol2gLO60Rpp8F69dWVBvV1QCWTfW62S2ApCHXjtYeEckKmDclLs9kVjd9q
Hoe9IxXGfX3kRtv8Ape8CI3z0aMj+dmKVJ+X7TnNA8G/zz7QsAxqnBbPL2i23NqgzCbDV6P5xta0
vKUlyQM02mSI/ojM6lKTiLU0Qi83cBdKf6zdQWA9M37KgDBzii5H3ni9+is+K5xE/9dwq1vKdsdS
u4TYazaD2aalbc5wk9QxEZUhArHnUIfiorU1AxlZswv/veAcMYeNLpguFnMsl/DNiHDJe9Rb31L4
EF0cFNzBokzE7HXQRhy49sfBjaqrCks7Yfa5APnPJWaLEKDGX4j6XamtC23sSl9E2TC+HVvKosv/
AewMaDr3xSBUp1p8XJqS8OC36zDuzJlQxvs1AkiPrn8EnZYGMrJ2bYvUD2WRFXfWpvmLQsczs+LG
ObcUwdAUuN3H94SQJfAiQvVBvMHkgZr504RUrqQYQEfRUwIQbZYTKY6klmea5Oa8BjBPNfcHwfJ7
0oDXXLAgRQbkczzdYN1dTNAtoHPnfjiUeIznv680n0Soyb8tkCf7AYjxw4fdJB+Pix9czAwfr6Iz
4+3JaxeVLGAfb3GQijtsq3eYwXL6+L1wIjwvhZVmSM59lKBWpDqvWfu6MMH3KeB061GRNBiQvYiJ
O2CQvJKjcXslCgWC2m==