<?php //ICB0 74:0 81:3625                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPoDKTqnD7qnaVuFYRyxYOcH3KwYgjLdUBz6QGP+N9kGTCTbCZ5wziVOezTz9fL++Mas1XMuU
BwXjseDG31t0gnveg5ZIov+wJq3Itfj7L21YBVGed030mG1tfEiXDR7bdEMGPiHj7xoDwbQ2UPnf
2HIvkHapXeBD++1HdlHXjGOZpOSHckuzHiQ5S2phY+GA1dpNZkVwWdl9v/3IKqmQjDtbWGM/7h05
eVov2WZl4f14oQkonR8qOFLTJ78P24xlyAFx1JaKBdfnkDhZ9MurwW92ZRV/XOP373OFYFTC1bqU
qXrnWlrO4AYpo8vqZQ7SXNDkm28dRf5zikeGP2rpfT2dmSuf2GRzm/j6dPnw0lqVyKbgFfoNUVMB
NqRqwaV4sNIYVqmD27+uzLc8fBPKcajsiUrtdYIKRR6rqGOAPonkZI7Vfo2ax9VtXD6OnqJVcQYX
JOqEazIizY/jVUQsd2+GHqOjxyURx1fYleESnNWO0E0pwWjunVB7AEJR/L6I9ecDaxJxXxlwoLCS
Z07qyvB1XXbd2MuHR8rE14Jg/eVs7MB1tn07U+kzVD+smIas0gwm7m6kRbyVKpBKJt1nRPg/PWlN
1nMXztIHL00783KDCjwzp5BVjfJc8zDKVxd4uzXTCnnJ58uOVV6+T8d5iLvbnlqTyPRjQusn6oy0
B5oWApL2e3F/xTp4jWcJB5bgRwHwAi3wqBNXVHH86uj319sxQ1dRxadA+LeV/n4LIHe4c5w3+Y2G
H2zjcFKdZ+lF2jGcJZkqC4qP+rp45jtSjGg2p/VSIX08NUnIPOHUI1tecHTADU0Xif4CmxC2LOp+
Z9Hq0Qcap+M246MliLBUH4xjRvROcGeS3A7laRNG2r3HZ4MaQB72Cl/hqasfIAwu9nRz7jFuxe6Y
c0EsIuxS5tpLyYObGTu9bnrcaSUpn9lmX/mfYG7al2RAJrZboR+relTGEYk9FV58/9EezVxuq2ix
q/1Qo4ppo0vcZyszVNzUay7kjysqZDB9YqP/6uOBp47FyiCMJ/zFnoKS+XvSyUJls1eW4yCTCsBM
qDBbxdGH2u16FkXWSSeoHPtWFKvyPsTc0zHqjBql0Ipbiq7RQ4MhpykapIXq+dRlQkLqXpqnxcus
iLcYu2R59l8mIduOLTKs4xDSx0MpwlslOehYkfcZByHVUxaIqCboWlwlbmX6WXi1hqv7DP8XePk4
fgF+YK+D31WezrBfzt7urav7Bl9f6thNI1OUsa6F7xr7Y7RenS3PJ7+6JMeSX5LcTXoiIO4wGCkj
GLoYeuoQHWgpaTRqMxrNSZxcnn0gT5nlOFYy7kbYpMY1pu7r/59OGizQ9m0kegOXL1AhnO9i7hZ0
gV0EmE5n6xraniK2db442Wt4Gb7Gfa08+BAwN0DBX4xJ23TvwYC2KF625lkdW/b38xvfhuKSWzsn
t2UOZa2ubU9L5Ypn68LwNQMhT1OpfSj8rJg9oh2jzHqsLHLvwk96dUq6SQ2n2VM+8tMo3a+zSTgG
H22Tnw13OAWHsbBVQMqNLACcPqKMDJaivBgAae5bTBQNwNkTdsjGQ/VNXcThyICLgkMBup7NYH/H
D4Fp80jkWJFVbNH3pg8z1nVwcX8uO43Ezp1YdGKhFi/zfM/oSeGYM0liMogf7aUksZcsFfZePn+o
2QPEgSohjZLkTOld7d4t9oyaDFQZiXonq3iRJlrRXpzi38K+pHybPxmEeLGX/nKsEs299p2HbIiN
UZOZx5QQzZ9RL8hdVDd+w2cx2MaiAX587PCcbvVR523a3/yipGgjVlYzINMEbGy4oCpejS1rKrlr
VOBy2bwccOTvVjYN7x0qc96yRCIYUj4aPfPqTTlcJZMeyE/siSBb3Tk0qif9tXR0Kch6RSLhUw1v
c7UIKZUi6XcIsRX7ejwMx5IVcuNDRdaFRAx0/lxnAGZxhnFeTOuoL6WBsYl2ersyG4wzrycR7sMD
I9CGtPlhzLUoWLPX2Ub9l7dxUGGhMEbhVIhhL0R3R2duOA5o40hpVov7si63Q/dA0fs2HeNnPhpj
eJCnyLwyLLsFgMuZPg1FKx3J24kfBmwmKELg5Suj5G0II5K+7uzpBF0z2Ew7GDAmFZTAQ4/UNsZg
sClBKYps23V9SiMyheiRFb9clpurRPa4Ud9T7EMhI+Ts5/nqL4Wgl0iYhvPxr5CaPaiNAALquvQV
cOsStiD7CpWAykmGOMJWb+r/SRpw/9ejk/NfKRP7bsBte/QErRX7baaV1njbY1DkFt0wR6vIi9l8
vQhwuj/c7NYJhMPbcvXavjFQ/eC+YuEvC5sjxUPKitnHG3fZk5HwF//iv+nzWh/stzPBo2y6mFnF
5lG7xMaGOk7Ot7BYff9FBcteC6tDkwxEydhUh4vt/+O0YQz5m/8gdjbxX9wr34P5NdcnAO8T62zf
hazoL3DPCXKWDCgEFz563a1OklhwhvqcBkQ7nKfUXtH16gcPepaEtlyXNlr+DcUBHPi49WILbb2d
aZVocNBel5YKyufSYaV767ubZI/HcYRBzMvN1LaZR4VbrQ9n6IoFz6sska/zWhx94jUU/zbpVFQb
qycsSlf6ZNFNZxANqsAOBhZO06AyXua9pVbgyGFNwlgaQjvkpc8OWjwjhPikvNa8vhiT++3jWAVP
YaE65hT2U8xhsEuIo9Ikcg3WGFC1RQ+sCKN+yLqu8vJGllb3pTk2dtuAOvXAJ4BM4v98ZCPm9KCb
JmJwPKvsp5CDhRj7KXVkGEbBMwpjvKwcTU8IG2VtserVc0TX3eE6oNBVqq5iLyzR4U5Wb7pRJBfv
CEgJM/liPosdmq53l6ljJ3jNPEx0nzrREGHW6u9Xk92tTu868vsv3SJj1v5GYEDzFt9d7vqMKEZM
IGDNAv21jlXlPXKXEn5RUg5PXLezwTE7ghYXKa4Y1ifXDaPSIZ0SisdNI21zIxO0PsLU2NdG7UYi
pcRmwkeOqEhDSCyAtZ7iy5v3+5sofmtWi3Pho/bmFcdjB3d4y6UKTuku314DywOmgcPChV4RTOLL
BJkroImJrWCcmcAYXTHFzkhzH98EQ2ke4PXBBKPTtKMPsOkSSTge1PlnE90QrloW98VJ1GSdr8gp
S6FASaoz3VBSymU1506TYdYu6Yv5iBA8LMUSJp1lGnL8GeN5vVzuNTqCYFR1/l7S6FfSOjLBeU40
9tZ2FUItfJqXW9n9CvChq3G0TGBh0ZBYaYb6idl/PaPLhidJREJGXwhaSAl19eeS9PeK9uBFElR9
tqUdiW/1xLq8zVnYZ2R6NK6gs45JZWbHJAhGG9C8u6gy0iSn9U/PDNsjq3IWTf8zuTiijkGGxMnU
jHIBCYLXObhObbtrAFsTnh5TjAwjYmDmdbdyjn2/2YYCj5m+D8ELop3n3+7db8icPdxNbaHot8Nr
dUvTw/YOFXaCiOalhZBzxm0LIAyfp0wAVaFAD4MK0sicwY0fXN/R01CXNttcfSw4U3YzAuZ5UP2W
aKPycQPrmJAsJyXsz5H2cgYnvm+dr77QGS6caj1+eilPj2NnrKRDuT270CPenG3XA+U0p8AJpauL
ZaIE/iIyDRB1FqdmGS/89Edzv+WiTxG0akGn6jhy1cz7dXWWUMrKEErGL1cm64RDxBRFC4imxIo9
k4DlEUFQERicuaU1OTSTS3+mBEj8CjJyVp6927UKOtIs/vRWn2Fp6U6o4XjUOzC0TJ+BFGhvzrYt
IDImpjN9H9b7Rer/50kD2qL/PL4rZDBvRjHOlD/9MMBbpaMx7Jr5KN6FU0HXp2Sk/t1JZ8eYYm87
WyKK2Vwy3Sic87KT3op/S502v3HewkTlYsL0fWH25t6tqjIdM84BBikSb7d2rh393+FOiF9qdD/Y
Rt4OwtXcsw7FGu2pCPSl+77YE3k3zCQCx4VQbs/K6iMZsr0d6mn2Sjm/p742WU9JtX/JNTTiDtMm
zBt17RGds+86t5j+hvZCXTwWCd+ZsYclTeBowIYloXL9vAD7XavKdDE30X9D3VAue8GsySjKvUOI
WI+g1pII1MMmCuFjmyF8FZqqSx5Z6HJy7B+geQW85fkcvkQBxSyjxsA6YaudvdytRBJ58MsauhDp
OFguWkvmvSIbLlW6up1ple+Lbar8j8SdnPPi1Enf4wFTfaNixEkTW9E865W3ujfQzBs4InOqKpMa
lN8QMLfIrq5A0JNt2SNMCPTHaGsmsYniwOyiCxYYWibsoWaw34SEU7vvQdlKyfk9h7nTnRIHI0c6
58Gp+RD54WX63ZkaPLyGU18Nc8iLchvgzPZDc1Qq0U5cqYEtIhd0Y68SDBzxg17wv0MqhQnYo5UT
iS+QAcCCwX4JxeTj9mMVpai6DzIhNSgAaW92Hu3J4SeWZCNjte3QocaRDnlemgH0w1xSk09Xdi/+
ubW2DfwLZSszd74ETRyRP2BdHTCFFjGLaMKVmI8jmAFCwWjXKNSZLlCNLaRwIO0BFpQP+JCtzdOS
PY6bzTAL9tKBFLzGHc637Ay1u9W//+6E/z2ATLn34CDG7voK86Lpyoqk0iwDB3fPIgWM7QAi9UxS
mvaJS5Tjw/Pdmagw4K+2H2gCYyfIFKTQXvMBeQ3iT6uC5yRPE2szJ6gkEcdbhwFFVpIj9GmedDqH
DHWt7jOTarTPBps3uLIcypjC4DKUyfxpWlSzptHKll9Y2+QWIHiPyVuA5EfZdNKUik/z4cIWplOD
VSOTvIGri/afLKzVDSS7LfLCpMEIahAAoE42uZMYVxWUgEEAwqm3Sd1wT2xIdmUB5OieZx3J0quh
AYo/VV5mphSFgqqQ4sbvrhWLDj+gQY3jKPkF7H8ndOqYZFnhmzc1hY3urh9SHiaV3oelf640t0hD
lWFhM/dlSRjpG9G/K7QFXxVsL/+td5zLgetPrUrO1/okwaa3TnpBl5oAqaZFl9xBKKq6NCS5RDR7
7AhdKGS5jM7qfxVieOWBGRo4kGn40YdGUo47bzbOOzyDGVYnywZOgV4MzAEFefZknZj67n/djPDP
WQ2W2q3zoIze56HBMWk47ITeBGkbpnQfw9SUSPfSZiJ1/zz6alIcN1kBHQ7TBrJa5BKojjnpor2G
XSqWSvASjna3/QYzJllP9fhsAn6CtqL4/QO+TzttAAwmtgnauksEpo8pDk9ePFzRV4XoMZDtpboI
dav0BxoimpepjVhk7aKY6ZdebJaHL878P907JfalytBZn/jls1ZMBEvNwQjtU0lBeqGK3Sr4Zag1
Ymf0ThtSIwECXHjJoIq+1Mm9qq8Rc2gcXXMOT6MKGkOdkwQT8dM7R9G1b/VXhr9c09vl4Y9qrND3
8WgRwRFf9W09JuIeskvAR9r5GW6+x03nTXTYUQr/UlhJOLVL+Q+cAXW/X/NO09fF3kvSMewDC3Q4
44fkDdSJKeW0D8JRDq1+m2uq4KHa0X77SSv1E5tfqHOHg2bPOrHcP8SpFrXHBZIJ1wiGaiYY6RXk
y29BEElSwxBnREkQbTkZv/CraePK36s/fJxfJh/OQ4UrqPFbkcb+wuRQCs0ohh0fuyW2GOhzA69P
/oAaKKSRHaYdUEufYwfXfDVzG+GrBRGQaaZeMD8LoqFZUUTdkLU6HxofPLhOT8sCQha47IogKjL4
OTLrPbEMBgBYgrlKoEQHFbjsVwR2jBXw5T6HX0iZl2H2zFQVfwd9LSOZlRfX4PrFoIHR9kGofxgx
XC1aC7TBIe9nztMjdijZwCy8hwBAOcSo87A0KwqqN3bI01hn/p1JsCLYbPKgRIAIc+M9eSZedSKU
agHdgFR9JZXpztZUcdkebtf+QA2jDFg5Uy/GXYB7lLGuJaUlKgZtPD9k/0Z5XQdXcWhs8JGYPgYn
g5ixxQMEp2UpV/p1JtRa7vA9NWEm3RiiyDybgb4t0gm7EfKzuiOh5Ko8QymCFrPRnb5HQEzIY8re
BY2bMIP2G6RC2vU33ruMdYqC1o+KLh67RQ4SN94rQCVpWw8OrSGcJXglrDSsuIj+KTbLkDBRpujB
EyaLwIrziJ0o+vBfctKiaDLmYo2Dtz9BtSo0XkbFD2E/nd+TVMjw5k3Q7MJeOe2zfZSnmL2WGcjz
ceeF55AKl89Zj4eju51J7ad/qo7HfEZB3LAZKjpBrFd7VkJsCUHT68doZkZy8FrdeEGutuq9boIs
E8NZtK/5g+/On4cKB5ispe2oz60LWBtFTy6ASq5H0WwlVpT7DbmnO36ujgVFTpP5g6kM/5zURX5J
mzLM5/+xpLvGkucn1qYGqIjmSEbo6B6sMJ8aZ91yzUBHnTwV5O/3A/akZpsmO86zSw/ov7qQDozS
T8jj5kaco4OrnslVQ0iKOt4A1zxNkMa3b5+aMD7PHyHOkgLBeesd6/Qd2yC+vDrXRwRTWv0x06EC
GIdhgVZW/phDJJ2AyiwGZ8/1rFSloQha0AzmGVw4l7dLQv1leTTvmqqCnphvG68Am2ZDeZN0PhvU
GVm14VcvBSLEuGWG9wXqcsdnfxUyzz/O+G1NAlDqiycG4MemfCX+wWSfZsqGDMOs8LjULG7Ji3VF
ekeUFGHrcqzFLrYJpw3Gg7AyMGdDik7l+LQN8dYlDNex/pAg1Gny4kn0m9AOPlfpy+7f9xoos/VZ
rlQlat3Ox2odEfgOFekI8lGEnYgoDDThn5t8ezLXmx4niDJ/+D0LQI4BTCb9Tvn/jnkQ0eN5Hwh7
KSHbFmMgETjmT1q7VK5nf6y8IGWrWYV6ACB8z8+3GLXOWii5GmwbatBnP4OmyzGtfhLaZbp0+aT5
zTMyb04k92vC/2G6E/RXUglY2qf35wJNXeSxuMCkxxIcOgDxFNliWnaukLh/G4ZaumrbQB7zNEkl
/xJmuqM4hDMwyR1ufumggUqH5lJ9M1JKEHqD5oV8RgKWT2cPtR/7d67QCMz2UsAcwsuYJw5w9TWZ
f3hyXsFjAJS2hFtySyKH6iYySGTGkQh0VABsSYSnmISGEqq77xsanQkZiL0GKPXnXPRTGr05raa7
WGkKwb1XfsT8Ygr5KpilmvJs7IpEkOuDxWb7M2Z+hG1QOwMuEuPL3KfXP1rQOp6G8jeeTmhMQBGO
bB2tzE+rZj1LBA9MN1UNxDgV/M+BMT0ABQASnwx2rqwDEkZQrYwSNHUi0ih1OvYqXQm2sn1dIFjT
BD1XGb6oKpQWGTeJQlEL4NingpPbjNBwTf7VXCNXU3uLpu8dt1PL4nRoJDJElYRzZ2ZlnLmGOFz4
OfM/hFVh9aunTK9ehdFZWtHf4UvHJpvfS50BdB+hBlGckD55T5Utqu487Clsm7eIrfp6LGVy7YhV
fdW7JUNlOl47ZtKdoBMFP7NHFxlHLcx2YwenYrQ1YU4SRdwOtt8GW1+fHUg4LzrRQLCwt3r5A5Hs
sUiE/kMgdq+REWsKFHodgk6dkYeKP8ha+Ss8GEoucKnNg4rQR2D/VcRuHQizMrH9vrBujof4NT6Y
7Vg+Bz6D3xyizTvrzFK/bHwvM/CqAbTWOBcYN3YgCYsb+s+6xNHYHxb32tJOx0G8t8tdOu/rga2m
/uj2TvN+0VG/1NhDZCmvUnSQA59SND76ZEkk+wACa9AM30YmkCLFeS737RouMA9LYl9FU5J81ITM
4BlVHZIVuByvASuQ2Ua2d2Rsucj+I9fg4FL8aQJfev72WfFhNJK44DdHwD2rVDQJ4S6RbSqtPzdi
z81LQ9KzUFYi4dcfhg/wobldYzTXuHff++9J6qSVQQH+P8/FD0/fdE6ORvnEPazFYdkhmCFeOnwC
kys2Bc6S0kqdSRFkXBiWdz0aa77bd7n2BzBb6EXEzIMEWnhhj1Xm4u2bWoZKfMaBPj4+Sd/9ECQ1
cw3/uS2LHLLq85gppSaJ5v903W0fQ3JvbqSpW/jTPJKGgZu0MM52UWBCJtwfW7ZqUfdZVSP+wthB
9FcukQftQ7wNhSALSn75fIkPkjI+LDE/KomdDYabsAr0N9bp6AmX0V7aCd//g4gSokzCo96aJe9x
pHzUJFvhLw3GAE5/kp098+jVw5YG+ALCh1d/2iE5QDpAVzWiWzBzIzqYdMknl0nfMmOrvN65RGqp
ivildYT/R8ZK8xfRmdXZjWcBlccwyz3+jb3iLmNIHaa0gZhcir5TbN6ztjGcU4R0JtAKGosORJ7u
gMM1bhGAqNi2Th4xW183j9ZPME2xD31+mmyYgRSxzZtTx2+HeWyvjfBZWWFzGGEoCqJipU55vo8s
gelYXRbDYFtwOonH2fMKC9m0Sd+ZeD1Ni/2JFrg1Fjd4lgj8pjxDhzwVBnUb4q04MtbZuavJ99kM
DA6M6yTBb2pmo3qinN8kAFIq0RN22deOuTVVET1mDir3EWvXUiN/jGmsNvkypAT0yKB7NFCXxgqU
Mj0DdKZYxFVEmsFiy1m0jB9zdFfv8IGmq88ND54ncQ7+7PjXRYMaQJwweAiUvrGpXZAuCv7c0meo
VLt2gAExhBdiqUxp/vz1ndeVctP13TGtdkvfaUNEnfHBZts9mkTPMUxaNsYnKqOKF+qkQKk4FXMc
CxpgkhDq5Wpe07tJuvuIhsqxmPmqdJle1aYvnE12SsO0xuuSWNIq5cd8HsjvnbFK6vsNl35wDqnn
brEFN6o2xSYwnac5JQOEcoDGvkxaAE5x3Sb/0LdHXlAWY7jZ2YAldv0UB39HjRb8/tsHlXJwS2RW
XDke/vRlYVEVttwghZx/edKJeGOVmN5+XsKeQYoJ9BIgMuRpIuDmMP/6daMB7DIpnUpRgDt5fUDw
yuvm+WgttcZQV6T4V6p6F+cVnAfUBoMvE+ttdBx3GnFM1gK8XBKFoaSYjWNs9H7xwXlplbdvESX8
WDxg3ocCHIK10zOBf/hVGsj5hkn9SzXTYCTa53fyDNjcPpC8ciiqEiyEuks8BcbIRpT6Slu0Syp7
W1Kp23cKhbQld239W7F5wX01DsES+jIgMviiRTrOCzz0+j/5V9QEsuGwASp2caW9slxV0/fiUTXf
6YtLlPSZmZl3Yf5arve82k1bEJy2Vt2VM0ByeDMNdLOJfOg8LUoLPsVWVZG62TaHRvnrqwWunlHo
LznzJcHSbW6nQB4tMXjIrtsjk3b1uoAfUXqYT9jlSH/Ym+3YiHldBRT1YXblXN8JR1bSg0kS+t4b
FXNUY7QBP1JOEcAmaUZ1ipwL23QYQF1jP/mekAKGLU0XJp+znnDWfWBCyqu3rmNDnsMuOT173f1W
g3G1/g+lYu/0RIavdrVdBQ/YSPcETV7WlpIrPZei3G2yqqfPQGYv0zQMswNhBwmhWpRmQimvaDPu
Qy/zCIDJ90nLLVRoRg00VGCD7QWYuhaPUqJWN+PYGiJ0TbqSIc53GyEVjG36L/wx/CzyGbaw1iOm
5VpiNTkXTepObwA8lxAM4rKX5+ZnWqffAUKQSbrCC/noso0Amw51uQdG4c4Z2IWjk6+EcUMNY01p
7inX9LglRH63M0XwxzPt/z6dKvd60wSY2+4hoOBPL4nMoUvI1UT7+9zRevHp4lYtB/zLJHnQ9+6n
4F/lRF5qvpfI5vAIWZtvZaL8mCaHbnYG0rNe9VpuhygOaIZHrQBQY8OC2LMxtkPXEFeBbEinM4bA
dd+wtQSL63YCrZFoolalrXIA5Bb/4Tyj8DCfOwZRLjFReMIqW8ljvGrLGAHHy1Pi780/bjZ9E7O0
2DycH+S9Yr0UjOLdDgpk6L5fmpFlRUlitK2sKa1s/pX+1bNZH0IPmjLD0WA2YmN8jtVnPypT4+Z3
7f6Pu8r3nPbq64i8al188Ig8ajujh3JNhzf53EPTEaDgAOw0MR71Su7KBtLEWAyr35oXuOf7zrqI
hAIY1ytsG3Iv8jjby77n0Zh6eO+F0+7t3HdnfR7yXBlQ/96VFw4nw4CVUAZIwzUSh3cHE+DsNCMi
+qkhaALl4MBoDJ97SYyhfq6XI8YbCBAF+ptNN7sYdJjytEdkK50bHJVj8OKFv6pjfjasolIiigYf
hcEtJkcx05eBGoJkqQOiC9bJuXBNtKfMxPLhJnWnpHZEOES7kIGLEQHjOwDTAaLBPiN4sdcCwAL2
R5fALeUBwhZmFHX9Utmnn1TJ+6jKppAUYFcnH9EGLobv3wEGkdV/KNexXfyNDPrJIzppNzNEa2Z0
IHsXywdwb+jMd4uOXzekr7bRgz+QObeLEulaQhDRwMucHa8nD/v29qQTXwRscWCbA7CnohzlDusY
5PDrZIZBVYnEd7ARa8popnMV2GjJKpST9l5KzMolDW+5emLrlyTKFb8dbisEmBf9lfDMNoIjRg0X
mqKiepcPX+Qt3B0AImf21TOadKaTiCZQwTCHAMl196jJvbAtcbdOGvQ32N+SGyvs/bVtzPl+Fa4a
RiAuowV6tPCAfih2uHs2FGI0Pf2hbVNd4VvW2rDtowSCHlCOMd4EDYrO336ZcEhdDs3/Q3eWX/+U
w3+Eefy4/1quWvpIqPzIVy3xDNvAaU+DStVtIFIh6jMLcW===
HR+cPsLyFxZsreE/+Bogc/3WAct4BuLq8r7ZYi+/aD/lpj5O2HBMm5T0ivlGkQMX8bfmuwXc8Cgw
iySzwdWW3Rk+LkqDimz1Zzg7P4aqyzToTj1aNsYoyTMomvbu8iRO/hZUl6BUe8JMw93kAiDdmSqz
LzYtv6bP0SaW03I//kgXwR+WFNvXzbc5jSFfKgRhdEV5dim+IXKq7lqBj90khgGAF/bqcCfHbDhH
A2FzxqATYZsXXY/3GoV3Efojlpkv2msitfycTvevPKyVqN6oNg+TCjKm1om7rkhgPjId3wDxAgKR
wQYXS0GFVYjKOt1+HFNncLngiXaonMhQCQzUXuAqss43Df+98xRg2MLn1jLA7CzmQgyOgtMB6TfO
L/7mOBLeMWTD8BnN0Yu+GvsD+9BDz0qrwZJBXmAQ+ejP8f4aLxm1SlwWP2S7hJimu6k2kr72S8wf
xcc9Hz8DgawJz9gQMGaosPBoNWSfEg2JVLABQxnre/pSxU6gdt+bJGqU3STWhd5QqPvf47Uj0QRR
aTQnRQFsHZ4liovAnZrkQXl8MA5L5HSYFpGQdyJOroYkFeLucMvzcKpDogJhBqH1kKixmd8i9Ybu
RGASUudFjVpbLRSahpUYlHZTiS1riDEELeQpJuZGFL3U2SA6vNqpQL4LnWSmyceKshlS6XB+gJWG
/XJ/zgh136Da3VvXBU7DqU4mV59kLRlsU7a32nZvSUliB5Ofso5eO7vaj/FukwtOYTuN9OG2rVQa
QbnQojNh9EuXwvqmGua+9IllpGXpN4D/yNfnrX4o8fBqQkzBdJB/aIK4tKhLoO0HuIhSGBbWxzKA
eQ35iFofCkMEgALz3OFPrc9GXMUuY0ecjRabpLMr87bQxjiEj1Aw83caJc0jV6ML6ToN8G0cJjQ2
oP/UUgcBl/oYqwZXmk4OGZMjz/xZE+oRYo2l7G7dy0qO+fNqyQvqgKZ1Sm94cB3lVghW3g/NR6wM
bi/RHgLmDRQAJDZzvjG8a/OUbQGTLLtGH1QqNBzoE0SMXxDmNjX2c6ijzrvvbKklcYLlK7j7RaYp
mHt7uZ6CXcy2yS7MmAhFC3wcjESqE3E5DFMrXLHqTSTPU/l0h+JQdiANvpJbYGqCTX9Xufh8UI7q
p7WFdj+h4PQPrIbcYpBkCQdogxuVFVtTlAE1qFr0Zk5v3pTW+kRgxELItrWrepWnBXvvPrY0DNw1
BdHGC5p7+xHoqbnGVPDK9qXGkSd+vJPuaoICu8NYRQ5u3h9vtk2o9lvvJ/6pxIsX2p/PxpKhEds/
8LZMV1m9SedmKW0Nqc0nPwyYd/lNQWKvhANS42xt7ReADvJ0aFZpjcvNxyB0payMnZMPzHz4ywir
NS1R5xat/ypXReNNa3JxCyC/ZNKNWZNT7UukBDzYNjNy7GPqiK2kQJd8iGodHi07j28nh8KvBpCO
3wsPWGwqHtj5OBdEI+VAO8h7xAS77VDE0E4GIraSEo2+wzAoIzMp2WcoiNQHC1N11epNjkMHnO+A
vnfPgNY2/rWjmtCEmiy4p2glEpBzbJh9Nx1DlKGDcwCH/3lothZLWSfgqgCqJz34bnzZxclhRytF
b25112+E9twLFkvQn6N50sJE91LH9d0JjfhqJNWfh5er0fDRQrcvX4Dlg88Pml2fO09ELU7r05qr
lc4ZMw6iCi6MA7iGEP+Uz5iq02cJv13V5aLzEiLEvh5E57GQtdnl9H+QM0XRmocOBRf0hmhKFvbw
yEBj7TUKJbjuUATwl/hLwhVwzH2Vwwu9V+gkV79rEzzIZkLASA0BNGzZyvmb5y25j9v5HhN8dUSO
+0aBLoY+GZQwbRqDNpjqax4/tLvr7lJEiZki4s2Fm+sL3gDdOuq77NA4ezfZbZDgIEuhf+cbba0b
9TSOjDJYxqJTAplguaa3coi/QztAdnFkHMmcwAhDT04tEHfgzcuM0gbKTRAj11XpXS2b5KJUMLm/
cz+2ANfXnplgtlhkZF7S0rcctYobcS9t1kK1i95fSuDmAwlELoxYqFbiglUo4bljA6A2wKk6a6nO
UUQ39m2/A1ikL76iIBesXf0afopJMSobRGC8My7lc/sMeK73E/HMomdGak079rV9EC8x2b+5xqWN
ayl5G3lrGRMO/ux+fRnuCe+he+WZwzN8D5w0kUbSOukmKPMwLkSTM2M/W12kicyOwGow1jtkfEJE
rAwh1SU52bNQfPO1Ap9mRpO00y9sHzrRp5wiZLCTHhQ9dMRN9Q9zH71D2MzyHC04G/dsOavd7Ko/
rTPpXISCMgk+CxS/f5o6UdEACElUySTxU+S/DqY83of4W1S4HdejVcZBE6aJNThzDIcyo4wxMlQ8
lcfKVnG1RCciZaTW/EfeWS0bzP9zRemAfZbf+H9mHg7M8r20NifsZSpYd4PRGKGSemORjSh6kya9
w67Z+pMokNYp81U5wKbTVrzA+LRsNfwXBdLYK+498ORrsFXIulf8WZ+FKZMlpPBPocugABFbcyK+
kQVu9EctzNyuq1WnSV1fmJM8x2AKIFeb9msvFl3DlO8+elMHV1C688aGicgkS6ovkJiH5Jdth0d1
F/ztOakAhSEYvU6h3mU2qqyZeA7jeAy6c/+fmj5cRkKoTTTqOgNT0kFZ4QIOQB+cRnNqdhCGDr15
Mb6Gcol3OESevKEXUL9LGH7ZyGGl5CF9hQdLTa0NIw3IL2zrX60NqA4Po+aenDTlKT5iRpii927X
zuadVZxVQmx2k/yJlz9ydjn20p/TO47/vu3Z770nNDGxLGUwgQfSZykxihfcx2EsDb1Hlac+NCW2
cH500Oa7AQMqUCjgkDE5Rvqn5exMrWqEIdv9wqMAHBGVNCjvCpt963J/qYckzFJPZRW4I/vMm69y
5sYQ5PSPrr1a/zm4+8TD9gQhINwINVkD6MY7lrZCFIHmQFx7/G3OaygStaYP4Y5Li2tLCbxqL1jI
6SKVQqoTaoqRT+8Ejr6WZ6YzM/86Mo7Zu6F4u98GvwmGPlrFQ6IElNEl2j2bNdTUMXfvAP+QAgqL
pyThDkzDjUwEBMOXYRGEtSDioeQVkr5yVEfkulbS3ekMqpZCNi9iTteScXYKUcrmd79FEJVf+7G5
hLyc6zqqwqYwALK2yuAh2s8kdCnHal6ra7hy/5R8/sEzM2dnwN8KeDqTvcXvPqofSZH3cV0SnosC
5aArI87UwqJ5y6J2FqZbvcRouJeMheDksMzdgdWYT0mod9m75vVTjlHmd7D60D96ELAkPJ8Ts6J0
dwRi3dVJ/cy4x85wWl1r7DXAlsadUcbcFpHRsLpLPkMhPNwS29MZqo0bixEB0q7Q9wUu76Kd8keq
+xCXCyQzJvGGz+Z0i6AVWIolWDqDb84ud8FEvRbrI3Uj2boX3RvytwaMGI2hujJ5bIwE+4aVWPfJ
T92fIupg8SzyOGkhBzUcu+VROhCo0aR5fAH9yUbuLEOJG6b0RW/yi3AHIALn8wWcT6Fl8sioa1UX
3i3UCbdmTcpOAR5c/WZrrblq80HJg+UFwdgdtdIO6c11kimlL8YQzKb+HgMmOI3PWpU080j+dASe
zYF4Pay6OEckI90LHnkcvgkmhGYjak+kbGcIbL9GO1oVbMu9CV0DzB3iYXFF7oGCXueYh+regQTu
G0lWwEi/2Fh7tLywE9RHL6nzoc/M9nd1Nu9brtKUBFpVfUYd4pabiuYp/XsOznG1VYAa54hDcVSZ
0541z8ofeOr1JeB5tcy6UV34RsEwyDLZ1NdWO87rliLP8bGVtc+DMjA9g6SDzdD6aP8R6zrkBddW
Esp/67MO9j/tKD8in7iQPwqCLP9HXlbgZEpvC5TeDPHwvCJOmyDL/wgiV3UexeANrLauhe2rk2QT
MbFDzSk1Mk0b1M0IXzk1UBw/EL1PEdjjb04Rr4BGfK+giq+DS10X7Htdj0O/3+I/1FyODDRhr/Rp
+8utX9iCgOzr5MIvwzHria8mWzs2tWXW2uz3iRDEsy6XEfjzXzl5ql8j6DbKjcW+05rmc8xeFbFv
ExpclJvcOxadfyi/2IvOPnWn+Y3P07uzM3hgyCUUPEHi06fh2p5S5p3RpK3sdo3YYgo03rRK6ajc
yTo6JuGMBtXcA/1UhMV23M49090vJKzVxy3XIpqz8FyK40qModb3D7EZ/yvCC2ks+SdQz3U/OLGk
i9pch1agidsZgJ0YrQYkqSKIYiqxSxG2IVx4Cu7EZdUDlg9ozmQ6CHpGihnMEkZJ02Jzd+2w8E0n
RM3EoEmP2EnQ52KnVz1+z2Mje5L2ljtxmgeN8gcjfQhTPrn2meCSg0r9Jhxw6FGta2zwSCHhZ6JD
n68cr0HxQbfSaFc4IivmmmV/rVsBxUdCy9Kmcv13Ec5nNKK1HJ8XOVQ4JWZV/+0ezKj6KweJ5pk2
3KzBSjB0j3lzxXmbc7xm497EKg9EAjiNX7+Fb0E1PRkxG1qu4BVDAOqJOJFB8Ke+pKxC2On3ddo4
SrLc/ofPkgB2wrJ3khghULqOkrpEqs1aUsQv7F4eY/sxuBdWvV58CBFiT+GbwQHJtuxGFikypTIz
BhhkCnHS3k/zWF+M3Iz1DbDuO55N+sSVDlEPtypWAZ9fj8cMyCBh3uzBjWf0yYdrt2imyu8sFrth
HpkQg/4r9f6qQKjkUE7dMoSBZNu6U8RDo3RLNDkVRO4GHaIzgvi7Db+tpPppLNHOt0+04VrO32Qb
uLcl4X3Yi5NioyX0LfcVl2yRQ+KTOIjFvm+ka37dYUAVoC5R4Y+xQfRzxGGV+yCnTAK9K1P9pByo
gNfyXptvkaLbpiXdO9Jrx+wCynRWnZO5Rf/M66FNcqB/JnXmxD6zxVVYiwJAB0gE0gRryN4SHsFq
R5UIzcIB19wGeyh/mU6BX0Cu9+iQwIIsgbGGUclOYiLHF+m5QO13/rvtEZdLE8FNSy842TJc+O6i
UwFLHc05lpdfnFsX6exHZcJ6cB3hCwD7Ve1KvRHVxhB4nI5ekQWLFpBDXojGZlIxt3Yl46ru20/C
GDl1ECzLIDypgKSOOX23sbzU/sISmS37nsSVBs2xszOr6b32phptZBordVymIPDIgJrwj/W/cMk4
BkTaL8Uf7iYzXsyshBlY7GYJYKefO+RSImZNoZQigMifcpEY2pkJ2QNytKskMt1Kck5vJuewLkV1
btt5Rl+gkUHsuQDOdmcgh7e+w0GDUUkWOu2mY2J9witZ9LUWd/qwMbJllbnMoHz0hW+gOE4Pc2TH
k5CbPGTxWSzKKh3ssJcqRC1U1BJ2FfKS7ZBNv6EjAHPxsOBYHUSJwIfk3IvKpLOL6J3RK++BuEvi
DSHl2gQRnJlyRtsInTfHlG/pN/cuQOP4JsJ7XeZF2Ajrx9lQe8wyTueXfHOvTs2FsdnHYHd+BJzy
fGOkqUnMhFiWrwPG5E6EzMMqaTkJA7gFuiuEXboPOBBz5In9u3Bv/W3L/LyqhwBpdeOmPjywGCMy
cmw0Ki9ph3K2lBAOB0bIEfJ6wBnx9Sv4krHElXXEaVqlH9dNQmuvcjcbQkN81wsWEUbztOi7/qo8
iGRDa9p80ZFFnCNUEiyp8LOO39NgSB14hNQwRuugtMwy7M7FTdQ9YQuNWZ2SZynEkkgfArNZ3idq
ZxonAagvIVvkqDPbhetc+vv9DvcKhfgyqmhjQRbuVkoQ1LQnTJjLsdZqwhsU7Ihj8edeWX4lfnWY
7KLAiJIup5j3e8ujMvSftI+GmhD1mvlsO73AmHz0Cfcyp/moSQa/wJkmoCHgR+VtYtx/ymsGywOn
252snCRmdzHtuktIswCiX0/UYGIFh8BwJMoK2v1CelXz5sV/6tjOxc8oNgfpMwuWJ1CJD2r4JDiT
9aYNAqxe75Tbtw8nQWFylQFUVNUnNzI5XHbq1zXBRlob2/1lkGCtq6TtO8bJ2S3fbS6UaXXXujDC
fMC/En2RbAsklJIDgSxiApi/fsxPDgguTzp9Gp3a++VFTKwYqIoxEmLlbXBGyLdFvTL+9EEN82mi
iEimrDW/AILoHY1SqpgF42IbVwQZiLRHefsA0p0BIC8q5YpoqAsY8ukg7z2C60vAUPpOEPmBzLrc
dhVWWys8bVJ6cMa2zbFF4agWqv1fgqMo7t4GcLfRQIpJBExYcJq8S8K3ajfGsHv7kCSA8NZFeWLH
HOimFJfhci2Eks4XzNqqBK9PABLeck21SBIBwk8X1RgDIrvb8Rs3yNiK8LlJL3ruX4CAplA9/MLg
YXhk2LIsxpUlqTQjapH51x+zQJWSEtH1rZE3ePU4HG24DbkaG8vZaEU0dasezHweEd7Yb7jvmO8c
VcRy5J1PsxuhYc/WGs6yi1qQvFA1OayoQUkBpx6D3G8c8RTOTPWKuSawHXMi9tlTibGJhgqUw/io
hRBlN3anpe0CL54JHFVhP31npOsk0ao2E0q1VLvW85JjC7o7lr2piFslemhquzc38GIe74XGrshd
T33ocUMNKdURkC+Yyr/9AJKbhIXXm13nfn9eovR6Z0Bi19dFG41p++4g7wkLabXluNItJApPZHPS
zZuHMeVL0e52pgOdSH7o0GovCy0lk3kJmMlGKjPECDnC21q+G7Hli/pt40A3dBVA3/UW2eyS0Eq7
7ve5sqJqLLwExBCuwFclTulGPiv/VyAbdXR9r8dv2DNWo3jssnvV1RTr6pJpwX8kSxlZoKjwBwpF
HglFusITHZ0HPzPq07sUMw2N2WilYiXIorpu1UPY7CNeaiIttQ7JDcuPd5KDngNTszQ1LJVJ3QvA
UKCsClLfTG4a+aeBqro0MY5LWWy4Py1B+7JY+mzy32XgliIFm4r6VFtC5VB65d+FZvq6UaC1Fdxi
GVYJhZeGuUFkRqLla9Jg80pJRvthcsrdkfOUMnkC5JL8KalzGi68LfzW0okPutWcT4b3FMyaFRrZ
X125p9RBwsKQZqulelVrleqFKHDi3Z7+v8S5MikFe+h1Z+T1sWDDMIhKt5mAfPcJRv+gCuRUrTu6
DD9BwGD7dtPqX352pH6o6u73kGoZ5rLOsDp3fcTbfHbNIjMTHDeVfAt96u4QqgSW4EkcRTONw8gG
P5Cn3oPyrNeCcVtFDiwgvqlY5UtNW8M5MaFuCk8k6sN74U5pJcjyEOLsdjUWg4/vi3KioyG9eaov
lSM1jldxqWmHo1Bfqzq4A5jrf5nH9VultRtQWclX21NarS1B8nDElnBaPzRJhGG5T5OQKWUVe4xk
gA6un4DSNELCkV87iUV1i/0S/x8D1qHG9rTlEiTnR9qEe2ShoQSrdueQpcPpTZPj80Ka511DOfVP
8uYfBWDsqHp53DgeKflrDmWpG2333GITbK6exnGPzEzNdlw5kffokFeiZAG+sXEVTgbvWcpJ5mBC
hYoqtR0/QQxfFns00U80/bZFWu7s8h14JATeNSuhHN/IeRpirKbV6ZCZ9AfsWKtX+SJwK6J3VN7/
YcaQ6qXzFR3C34L6ktsHidQ0/hGfiXIbFJjBYC55hwpK2yNIAjfL1Y0Kotf/y42dmjTk2GwUZbA0
ccOJD++uWMsoxhZCPhjUIu9NPgsaaMmmIKp41xnAWyFG90CcpCunVr4gpDdFpU0FIdQLmjL7d8Pl
jSeb//Qr8EidE9UxbQecdcib57qtp5oLE7BvV0An1JWxhBl1Vl+7VqoOT9FPXUB/2nv7bHCxQKiu
b76QLdYQ9dCspw0fS2IyJfMPK4RJimX4Zye5AlOpr8p96OUr2LqEbnsrXkrYyeqk/76a8TIP5l8B
whzXFTOPG42/olmYwVCAwYeC0EkPU5h0c1FqsspRpEs8Bf3kBSlgiNGJATb1XznWnl/8qJXR3DFj
Vbm5H3gQkC98+X4kSsP4W87l89XPg8FRGUE87UA4+NQAFXVDyl7putJdMeJsSDk1vq1os2KIxRln
X8Aj+VsTydG4pHM6EB5Yx1BvfUXNrLjM9sAx4jotN4yiL5Ogq3THo+Ysl4uRqEKduFEh68pP4Ve3
UFNvn808dCTZVOh3pKX8fQqSdYsF9bOxoGICGDQOJxrK/HTlfWyzz3ZUPJDG708pRXt2u8tut3Ri
5taX2XCrAfg2FXSp5rplWKyOFJEuLr0sQP8L0SEL8KWOzzp4NIHk2m3zJwzRMnxeqkxYWJQqjoJK
Y5GbUKFMb23EqYU+i9gYYAnrt/rH3WTi4jh515xn483UEET1WaFVSFwVtQ9SmeUKhB4nUVXapw++
auEs//0LITdUrwHdpYwrDMDeLo7tGRs2w6cFke+KGY2vyX8O8M9qmmgmeeChiwklJInJuxTsvUzs
TxFsMHt0XEjbGuM5dJS2eH8+WWfmiqzadrzci/2m7mc2wCL3XPYn+b/0J8uRVuScWnffKmv8n0Nh
h32TK/A98ctgVJCwyCUoBsiCKbIWPv+XwhaIg7tq9MDGh3E/oxlLt3uVd27kusP+l+MPbskg9/HI
YZExS2ACeWbUh5bfZYFn26gWYgB8u3zt837vqTfxHGLgKqoUwMryBVUOG6/iR4HV7VvINYfjmLil
hIqFxabgmWDl3TZRlYHwd6A4rm4EsFOwVukf39Rz9luxOqLivtDUikRf2rI67zZFAaTGDu+9lyXz
6w1ikcQcMIZAzSBAekQ80PZFosLXr9PrXKyeKQCADMY/pkUsLj/aX8uadV9sD9pzothBEtJvpWNu
dkZlH2ECOv7GLILdrIn+Uq2v4XjnMtIX4Q8iAXOL3aPurJ0vXutkJWXpBNgqlnhpe21FS9EBSBP6
FgOvl1ixI99xd2uMsRBpQDZXCFLC0bXO+1945KjXmuIbd/ycarSP+68Kpxfk8qMMFKu6YUC+d8CL
NDdAhEreiqXv9KHYJd8bnqKxTBDmA8ST557GJgBzAdngjSx+gZKJ1swvwkGJpW9FQva7TuFkDDoS
xo/Vp6ei7iwA97AatPq0+a/38yg1yKvMuRgQOJ4p/Gplfiu84oLD01sTvhZbUfAk7D4n1ENwSoN+
AYf11Wsw1K2tVBwQB+nViJK1r6Hpt89MMqB/ICSIQcyPIaWhuI7mPswKSn96+mKGirKtMJIE9yad
YLf+4Q+t/JQXuucYU1F/nJ6+3odqQ7hCaGHLgoazSR8UMQcR3WgyRiQKMNMSxlRQW0NDL5u1eOck
LV8Wc3GAcp1hOzH5l9fh5e5jxhacmSMQj5X0FVawc2+5CuT38dr5VO1XhfFap4qLTyOXxyU4bvaD
S16qv3e+X7Zth88x2JI0/VJ7oJfKDuOidsPl3ibOwo3/bM+LEs42IWcpGRNunMu+KDjxYD8vyJQK
slssJukeHI0nbQ6hALMJPS8NzBrwxqITQfQc2JgjNNKp55j7uF7lxyC9sXg/aK5/xI6//gop7nud
QYWsFPQIX305PEoRaPP3qqa+66ZQH+Yz706O8disgKzdoq3hCmTUbLes6I6ptdiIDjqB/ExjFc7K
6cPrdKx2DzagTxy8CDilvhdpfE9txjfPE/Z0gbnJ+ELn9BJ+8Vp/s7y6COkM6tyxvwE7Z5XB/JFc
tY2Mae+raSdUcVT7UL7dk7B6xdhnsUKfzeW3JPhUlNZIWy6b3DB8QhZVRSJCaH46GVDYXcIyahBn
5vom74fW+ME9ImAMiGY2l7w5oY8=