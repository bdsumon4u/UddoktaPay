<?php //ICB0 74:0 81:18af                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPpTUQvXI2r3GN9V+k/1zGmYYNfIb7V/hg/CiAtA5ixZzRSv6iLuIm9OU4Qpqi71+14p9H7kV
YWVTnqVV3Cq2XAswyH3EueMWefq6GtXcl0c/b+CB/iLEUNCehiIqmK7OAB5S2ZsAMkfFUd32moc6
chfj8ZSgdV1WY35tB/V/l0nIH61UK88/89GODapr7FUlPWihoW+6JWiL2LNfq8mDfiiRULgXxtqc
B1CRQA/gYU951bePvXCQsP+dqsXodHA88Sw7FzAG8CmQA1tu5zk86eCANjp1IZ6VMm8eDzaXeu1t
5pfJ0x52plvfD1nj0tDMJKqc2XDNi1celUf2VG8wQjW7mPa5gsH0B0gortH14CCSP+LUBSy9YJgC
faRgy0T7XbjIY0HdmvFyH0szUiyfROWkGYnxMIiQwQag2/v0PC9zzEic97CbBTgXps+znrhxnLZC
ILuAqCfRwi7CUhYAJLiTHhFaUO3BQsRg4E9R2PeGYhAzHK6Sjpf8WhTqWPcD8w/bY0ugg9Jca7KB
ddedZxsdG7rIL+g1JmMEbY2QzPSXk6gsYRPOjfVRsG0bK+IGCnBzhjscN4jtKKXXMdE6In/9QrHq
bAdMQ3UhbD3b3tcBKV0O7wvEccWSou/LZDgQPDI/MOvW+skKtaUtkLo71sOcd9PhmX8ulJT7/SDc
o0l0i5eMP+6AOgdUXdC1qrq+WRSVXTKNtHQErFgn4pk2YvuNsRyw+fmgFm2oPKPgP+auctk926+w
A4fy89ltSCNJA6Sn32BRs0WSCXtJSKk50z8AjiqFfI1vI5CvWaNY1BrqMt37wmeSNQ2dhF4MnlMK
vHiffoS8W7ikHjrgz/1gsxq7h4dyDNqdJhijotrb86cnyUsRK/Wf7JAGd03nNZ256cg8hhNiNs5M
Lm2V/w8e/4rKMw8/AwtYduPYSMScWHx8Yr07FWHLS/idUQqfmgHnvkVo5Ed/3MgBLwiqJB0UmhJl
QtaHwYF3c54lCBZ4O6d+C9iHM7YXgjM2BGc/wBuDkdFOSiymmUYuf+no0qKn3I2nejDVXG5tnzR+
9FekwMnctEfI7Am1Qrx6lwaOG3+wAfcsuGx9pUox7JC9rpczL+YoQRXklntMZJeqtaf1vCEEzdzR
32Da3IgVspJpasfjYdRqFYP+b9tx8FsN2HPB6rYXoSHyPxn+DqJt9cDeNuWp9MdgcPMRyyxD0lh9
idiXFe/PsB5gVgJyE+5lRrHXT5VL+KOj0jNPnAtsEMi5/hnirB0j2Ugrnoz3IZ2ltHrC1MGpaTY0
9Y4ixHgpgKTqJvtk+lMIBnGl1OZtXLCRstUbA36xkpceXVFJ84XoXaXuPDNhGyYWv+F1/sPEEuJ3
dG5BWTeQgZPjOMWZ2esLYo4JU/9WHCUpNSxw51xYSTXN7zQ7nVaJHw7FAup0DSfuNbFwEncO7Ph0
LqDPiSddobK6VdHi2y+iL2b7JEPeHGAHd4ks4B6s/yfiqGyPTptqvCsj8JSIQCYSyO2DiLun52DV
FT2B/NA4hzvjEn35XCenowqHcVMjYtymuqbYvLjzH4Fxc3bvs/LSNq9zt7D41fusRs2Wjbfa04J7
TY2qaQ87IcUtMXOE/7296cEQM4t9vc9owEwaCI5yshJijkCh1D7XUP+/xGP9KBiIzsBSzOG29ASd
Ffwojwxk2C7ur/lTUEwPNnU2Bj8b1B4FwUC2HeONghcFwXqAsbj7IjErz+u1X7Q/McVrqUeWS6Fz
lFIoyV3c+mh/4Bs03YxC7Tg5TebaKEdhkGLYVCbbE1NmOhWJa4WV51oyTANfF+CGCe44d9pfHSFM
1+57oQdWpt/nJSatmVtkqTRwXenjOI4LGlaQes7PiZNQJXHx2/50S1703YBy47R6B/PeoF5TfF5/
Di8DPqEpsqeWdigwsW1pfROFD+8XEvHp57/yLjy5qSPyosg9hIlZr6HvUQdwsjHdQ9dwRZDNJhQz
toau3W6NhEDUWlMMRKi3v/W2Ym0lExm6uVAuGUtx7txz1wZ18SODiDrQMLpkG6jMoZH5akhHX3zT
ZUVlhBmSvjdvwZ1QQqacO8cpqc9zV4XXEF///60AKoYAz+icfXTxsjaZzUaXi729ZL0TWYgViba6
WHKxElGOT/b/Y68CPhgKUvwIcQjyWXrBpBw35Msx3i3m4HsFEK2ABdCpUFPYrGZYvXA2DhCnVWRJ
jUANvm49Ek51HI8dxwer+hzc63QbTIZNEyR0ApltQjdLppd/FohmJ8/hm45IMpfw9TygQIuclt4N
b+1QmAb2upBAGnxpIGwrxRbx3FGbQlDa7jRRdbTVm4BVTfsC0nglJsYZBdpn1W0HH9zizPY1tW0e
MrQaoqF8pOkj3HyCTwpMslb3BFdifJuprj0kCPV/cePaTNtpXhL8YRbSTPgWOsJR+XurA+ui/vLi
+EQ3HxuEkjV61pK8eAWY5SfodsD1+EEjtPvDv2IQ4wmd5KdDrkWW9VoBroc1Y+BPaItu8ykO5H3T
DCeMzhkl8uiJTGVS13TPnn12PUo6e30LY48o570Ips51ZT8aa9yJ3u7iesbjrShIW1sEq1I3OmD1
KV6McYW9tRLTZRR5QGrkcD9LBtBhsiiPS4B+DYv5TU1hKIH8SKK7wM8lIxaj4I4HUGaYi7H8KfBA
e/hdWcnEl1LqcwTzgyP5cPuxOsYxvuSh5NkPgMgUQtbKMZJoji8WMovajhbZQA5wQjjv/54dcGwe
lXUQNrHsTjOklgOJdJHBAJwPXDeKBetlNto6PwHoPdAG6Ob4duVc769uhghm8ZJ3diyWpExzW3uH
kLCQT2iS42DhYxckSUpWC1Y5O99R54y7UdUeexQHd5L4A/lIMzzx3lipPmISbp49zEUOkCWJcDbO
25t7fWov646PQkkO3DZCmVsDmRNEA7Mupn4T9KT7scmm/ljXBJJNIlyIkoUia2YSxZCe5ScoFahO
mpMm0QJ0atkFqgmxnegItzxVbRPDzDGj40v7N+VPVx4hHQ8rtkrz=
HR+cPprMJZ6WlB86okBR4gIaMUChmAGD2weS6xlFOmFUmJ+vd7ekbpGcwW9rBdxGb2OiCBO49X0J
d+ZtoefGd2up/fkFm5F8mVw8cECUByAb2TyGJyWZ4XlDyGedt/h56JSiYaZLxAL3LU766QIPsFcb
Zl88LUheLoMogsq3ySv3Tq0N+BP2Haw7pJuZPJtat53flycJYuFfGss0Y/V8Y4+hWqqOP3Z1PqtV
m/FrsQKlYnMIy4nWBTLTA0fso85KN2XdugPT9BpF6Hv8CAetZqrtxXpB6DunTCzoQ8zSjBFqfTOK
sTc5v6wKilZp9tOFM4QQpolDyI+QQbfwm2FdMW3j+KReOac7P3zZhPBfxiR2cUmhIEy1VM1ViDxe
Z7ich5HcRhLW42O++gc/QprMdFUjeG0tqY2PGUv6LgO/Da+ARj8qwuNozLkXrhKrEAMfV0iBseTs
TKsF6sCAFpJ7zcEU1QDwAIvcycuuN0KhVrYUDnFr2ZNKDEDhp0q7GXCkQ1CU07smA4EG4gGvnOMz
P+4YqIu3dqWW1OeGaucwOEhhE3fMGcBxE1QZhOeIZtgmgrCN2bAusWiHKLEu+l0/p5DMZcF62ru+
VRz3Id4HatvHBgc2JPi/al917yh7y2si1YIqcty8WuCq5zASh99s0sc8srgdVSLuCKt2Ag4TYKt9
DjfhNUeBuNMwAHkToNCZN669rWqpCFNxvBKZqvFjep5j9nOhNgxUqJfbD7coYn3vkIVtuWRO6a82
Xssdhua23P28qOkGMiN5mDdhg2GrL2+A03b5GH5NSTv6s+8HMrWH+4aFC5SGE6+RNuJRvu98hTQ8
7YCwSnM+MP4VCebKkBaf+jm28yxsVaflh1Xi4D1XyXsjgseAciDPobB1JOhbQYzrJLiS+2GqQAlV
dw7+B5rYffqDtRg75XkskxBdUf6PV4f7ex1WKV3QR6Ug2HVAaY9UCpMocodTAqe0VvPvPoIkzOx9
l3qoKU/tuwX1eB8E3+k7j7P2MwVlwS4S5mLGtHUBpG0V5Kb2c8QU+2FiNgA4ptrLJrSQ8c3JZf/v
VkdyMT637F1m2wc4fMgpyQXFC9ev4glHJW1RxnBjouGIOzjXKAiFn6Pqkjkw+lblUmPYZUDXBgNc
DVtsxvQGbE7Z286nrrxsyo3yMtN8eKf6Y7mAvqKhvqEGl2DcyoZ14v7LNqiJ6+80vIZxa54bk93Z
2qVbOB+RgAa657rkQZ2nJ5AXWKeHAllXiAIXJJ1TTPJdKRLkl0Ni9lNLGfNZ6Boq3IO3ehWcRfIs
DFsdXC3I96pLUeMySFBWHEJ2jr3mEoma8C/bVfSOUGa6SW/eP3dxHSYOyIGA76f4IaqBXI3arCfo
ytSJ0+tN6HaJst7fkiM+sYYBPX2Gz8nLoe8fRPdT30y88J+uXaOoJl3PCbjYawQCeqPVYpCA8ALI
f1xMew4dBeXDXCu0f+89HzD22M71Uls4/6CfOCr6fQo4PCJkHQqnnFRQt5p+5aEoT7FYobsuY850
FwXwN/8skK7l1VOf3bAvP4DUSlSDP0E+UV7nLE6EquA6MmbmX0Bj4/ZWzNAcMRj2n83HpPU0a8v5
LWjfYl2TU98sMeV9RKwgnoHu7EwmN76yVJyFy8IZIGbTVu2CaYXo1jzrhmNcn8ogjKkR3KEC1L8U
6D1vd+uSJnTtdLIpJKdK8J8n/67BIMzEnKxLtglPxtsuKea820gdBs8C7kxHhUWwLADPCk8IFOfm
WLpGbDyPzz+zlPfo2TP1Lcs8VWmZwgxmC/ykP6TjtKhUR6tcEda/RyOUid4He+OLrexP5o9qTxM4
9nmkfO2f6LH1sI8Sbw5r5Av64IZH0LfOdoZuqcr4O9uOjR/7cuD2QvUhDxoFaSw79oRn99urJxnB
dmhq1kpd0bf2kz9pZPNlKmDzS7mY+uBvx9F2+DzNJ1156837EZbtHqFfb71Q1+dgXWR5MAAQYYjA
fKXygz0nBMs10cQLXibs4olt75hM1mndK5kwng9WFlhPQt+FRatW0aFaAlk/IzslIRr0zFfrdflI
ieHGhqCnk5HdBCZuWSdABKkBIKq8CcnNBVFvlNTvNlTUTn4kcCJmtsV2iWyrZSjyfO/X7tZYcA+j
3vA7MPaThABWmY9k4Y4bwXV4vHw6b2p6RjczUNUpGzmBJ5YNKZsc7tSsQHtTpEHYS61Kge9ad2NP
vbQZGJcGUCQ4RR+PaHAWd2oVyZvOiXFgCEM6ExJpxuZBz1zTdVlrx5quJrGm+UzyM72LYdO6+cU6
ea8hqhw5Bttp/4XnczrQY0vsM+cUNyM1XsMqWHkF3orh+ZbZmeyxiBAWpf3azmuTFp0qEjBW81ov
09fUnRJmb4A8q73lq+O7y1+vbCWJE/2FjhomJEjvGop/jUNWBPwr2mwB5Zz1a1VdjpB1yHYc7t4R
lkjND4lT6C9bkck4MJw84CH9LHZpXKgEt1BDRq47QMRCw1jWdiT11XmU/8njCDoWaCMPTY2bUHPG
V7TjDDBWbUznX+pcj1A2nkBQxFfCcBWpE4KVXvWAcI0HpiyKefWGNlk8citbDGpRR7sSs+xQmygN
tTrlQ78gMhgJSWceCsvPlRkcjH/egebXUbtfBmzd069jM6C0UY5KFGXAFPudtKCnm1Mtb0O0miE7
yGC9MuRmmSBJZFGA2EAPUjEDEM1ue5DqnU7hjeSoN5RS/5qiPPuINlaBayn2AUL813tpCy9LiAcb
36sx3m==