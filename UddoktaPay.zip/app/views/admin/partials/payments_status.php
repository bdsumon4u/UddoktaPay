<?php //ICB0 74:0 81:362d                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmaUKNijnQbyNyd4M0xjUMU7aPMLvYDx2Q/Fj7kYIImtMnCu8uaQZZyKHTbxvY5ct57F1+Cw
AJ9pw0vy9kQPI8Uilg3Uis6aJp1zSyhgo2pl8BG8fNOTyw6zWOAEU2BWM4scmdDPzJKLg8zW8FRT
vQpeWPf50YPy0IcHX4O0xf/FL17gruuvZVYOCr7UgYE5+XmjaX2uOhptaMHSwtrZMy6/wJbF+G0K
8ivX+Cj8ei3j98Z5vgpzmrI7gdugu57jBwPjGdwSbOj7DKyErBY47srSIP4RU8fBnjzlxDoIhp5l
KowjMpu6mOtJMtEfadXwACZfTzgCyQY+wdPCNFOf3yhJgo1zEd76O7HHo6g1GOh54gnT4fJydXZ0
yOL/oOA74DGEovX0TaDxhrAuDdt4M5k7XJK8cK3HNDXloWvOVYueXgTWvNgG69Rv9h9AQsdN1R8Z
Km0s5hi+O9ysSCrWcdEK+KMMMsQ86p4KYEElWLWL1l/diBDv+F7YUqoR8iCeDcvnns8S9k4M9CST
bgzyKI3aZKCiCC5DJ3/U8kQ61ambCiVXGlqjE0tZKrn+Z+uMDRUBL719BSd1qtMtNKU/Vrocbh7v
V6D65dFoQOnM8hedyooGMcApGH5Jqz2HE0LPUCii9C14y2zq1ra4fp6yL0bGnK1zO3Up9wLjmm1Z
QEG55GTZlJz8ZXRBWm/Y7eFuRbbQZG8Swo1xMWmXfiWP4R1bBssgRGn9Ois9B+wPnxKfLD8ZEmnp
rC0DoPGk+wZb6PMOmI40Dka+pQ9H7LHcRO4HyLACamZDpzXzBT3G41bbo5iq5RLg7BWbfFs/nHhf
MqTKxceUlgbEp3+A9bAFnZJWOIFkSdcqNv94foR92nFJCvXgl6PjerS/5rFcTs+zGu1BLaa955o8
jvXfkKO7+7VC/mZ5MIxMUfIriD5B9t/HtwEikQI6Wuw1gzShrmFIq6dkQ/VCpRDlstz3p9KkmrOO
+AQ8t58I0HdDq2LTZfy/6NapWC6vifXraem/1xH9ozOE44ek/ziFFrjtl5zdO0kLjcZGBea5z3dz
FUAn8oyTm7amu9YSjsZ0/6m4/OdFBwEpFPJ4FVB1wqP+egTGC8J9D0Zku2qAXyvAd2O5+sf10qsY
uP1nh+nkKK4Qp0C/bzDTaij1bwzYDjuTKqp7SDn20S7SVwBKYkozAEoTrLnNw9Z9D8GQ1x7zsX1K
2/nu2yILoGYCJvyTj2DKNM3grkUmPpUUDT8e8vB+/HMI0H5OKRlsA1wQ6POj7ZIj9oXHbzDE5h9B
jTGIkvm/BEJK5CvQitiXJ5qDd+AptV5C2j+xYJ3RrhzktAIHUhdmDu6EEM87I4ut2yV1yTHFeqeM
rFcudF6nmIj913eTGWz7gbVF4VMt6f/M/isTjDwREc27AFFMJWKKctqhj7wHMLFcRXRCxWq+DSzC
Y0fJJO754nl2sx7lElYGq5mMA7nt3l3ZQulmFJNEWhkrpniT6pCJTJ3D2BLPiqjBvhMPXLE313uS
EUs/DHQXMbthJmXbK1OpIdqdXlXGfAxRX9r2DtyRFGPWocUToNduQkOVyy53jss43JXlzAtUg7iS
jpkVvufjQpLC4OnF7Ozyqc48RkDHBCxVL1FtMcumXLq7Bcc+jjpnj/EwVy96WsIA4rtIYxLzmDG9
sriauajZJegISDcBiKr+4J2k60vneNMwQirh7jIq6LwBAWzkSzvo73OUK27YMIePM8SXCunQGG48
wbNvwVJNd6DWoyaacWjgb6XrMQgGEtfYMR6YDTeIN97zDt1AeDTsWDogrxCFkkbuciyZpkL28w6x
soMYRVp78gyLH4zNx5dzvS/UGSKvDmt/8dBzrBbGH5iH6o0FUO05uFX5A1rfyzQEEbnhpmRBbM3j
84Kim1Jo3DcQ95rwD/7jUGAUgR77J64zX6/9UR5xzoD5KHE5ukS4MD54ktxtPtI9CO4HONaWrpby
8jnuW92AEDr5jwQ2xLYxsvt+Ogkkz5h5PlCOnk90ugZSddLCiJxbNl9+y8LR02cYr0dfDUYiEjBY
3HYWtgLzh1+tzKQ0J9shkForxuX73acvg2oWLCukl7e+gYrdXpakYOEfKUWr5qBdeRguDSvd/w76
JNkUQfffE7YLzGFmfB76ICniXBUjV9R4+tBKqBYBFt4hz6HuNJxdkHZ2bP04S6BLKj8OFiR67gyn
sIIT/43TVpDU60KJixCErysEeC/dvUPqq5Jpqcu+XOpscGY2yTLFQbEGC9M9dTCZiAeVOeS7snr/
vKTBf2iJZaCnPYID0jDAeSbt9kVvV0AzdeFwY7+9YQ59jufNxgsh47N9/+jGb1vTwLhTzq5i54Al
ebNtQ0th2R2nS/fcm2xjhlyRGgb3u/9DVWQ59wCfdVZkWZ8rG1MUyBN1Lhr+SPpC1D2nda0lZL1b
92dE0vhO5wG99wjSuQPtFlah9Ez8KN2OhX4xUx14a85T6pO/BCztWSs25D976vzrgG0uExReHaD6
E5b1T9O4KiOX+sVzLw7Qme+xw5QAKLDZC2AQtCqoQolQQ+qtByl23y7HCi2GYsq1O8sJJ4A1UPv6
lr1N2BaB0/Yu+RxaxsHojgTM46ij11mGaGuxB9ADD8XHq5JF2ou4yfnEy2ajZzv+bqNymUsXKQSx
hQO+uGwClLarYDlh8xE9Q2QzqfOzBefw0YtTW6n7scgvG3bIEHWhqAkZ6lwsv9zUp3gj0Ak/50eN
aDJMclcPm2mUFMRr4zeMgrdiIT+DfL+MmFcLFWCPZDnloexTeOdzHRUCVUkPfHBsPa5aHqV6a9p4
zqVTdhYXd3spjIYuMYQYv1iiDCwka+2lg2t9CqXsklzwrkEbtDmOVGxYOsDOrEia3McPINvyldMe
r0nt6SmlFnOV6MVZcdVl1i4zlnku7jWUTHixjFYvCqAhb/CItnBqyH2D6E+puxMUhzKaAdV0qOZn
oQ1Hre/e3W+BJvaFj5GThNbcbVVffpsEuSCXj1UaB6UeJjHolpRs4muYj203lFyjzBE92yU5d7T7
FoBm5rwtxAiYlLkZvqXTnIRA9garyOalDFbAoU9pySdXJD3yuprNVthAFyvI5nSzGNkaTfDFY7aS
ngMDJ4F6Mawcav1J1Yi6+ZcbHsnYCZEI74HczZaO65MoeU+lM5tPqYr4bhDDTuGcCcJ3SfW6Vo7C
eA1RzmFJpKXPPwwdV72ePfFtlpuIILQQKDGYMABlABKmbgZySOVoKBIP7RLL6MRMzYWlkO99yjSZ
gR62MaPxZL9/ywVxuswIAlvX7RtSar3dKoHRdR9gLh2dRSVNaIh4AL2e5cXdlbe/AtjD8JsDTtSC
fHIl/LN7o5ykSYlU4h7eqcC7COqA8gXxnO1sJqNi8evdbpyGHLB3a6w5iBgLCu0cArkvK0rtgq1z
vFlPaepmZLNWs5KluToobJHzPTk9U+BHAjveYlsL+EhCk7zEG6c6SW844xunIZl/cI3JqCz4WxU0
BGOpOgfVIy9h/TfmBQ2nj0bHclWsVUmDe733mCB2j8yxZs0NWoElerlG+n0aWOdF2djEgdBFOXkK
YtDAgbFrVzJzPNGMCkN146NZGUZYc4B81sKAvjmXiJ3ihNQ+P9cVQZfNONrWCBgvE3wVvWAOchMP
kEmIrSKTJAcaa+f/d9DMUZIqA+9hLCM6byvrNItdIHNCY06jlI83falrA5DWhmr1wvjRz0PzX2yj
g9tPgSoFjBgwyA7TI2QsKBhSMoHSFb+J8SKS6VaVGRt0wr6YzgBcw7ewN7hcKep2UqfPZcIGj9SU
9PQDnKpGC7mxL/fxXnXknFXQ9r5MfbQ35KUY0b3CC32cBuecZVRd68CnOv8Ulc2aOQaX7kiz5CKI
W3tVn6xhSNU0D+KpnpqlaT/XweT8huxq9olYBk1RKKu8LIpQxey5qClRZQw7BHojr3BZ+8nautda
jwJ61Hh/fjzo7L6hZvbfgoWmoDes6Gw/ya8KXqIRWP2D6krc2tKhvnxEo3zHl7dGFoWAksURcXWp
d+q6x4KsW7TuxRzXFwVBMiyjFaUoCD38nE1OEG384/usMcRkrXEV7isBveKDv29SL8Wn70VS4f1w
0e5Qg/xHU5KmlUZiGS5iVawucy/KvacmUGDpur+I8t3GSWmQXptRik1q2QxumInmQHvE/o13Aqc/
y1T6KJEHcstraoyfWVfdQp7RZiPJ2YF2IpZ+nJIsMhQLgcW76v2VeqxlgaPWHe3D5/4RM2Z+d/h9
fEhoWGaSx7nYCKfKXf8PCKDQDYf0WButFdgHbXoPf4M3PlaRJRHk/XERtviKxis0Psf19R1XRzbQ
Oq9C7s7s+wFhxeXM1uCG5RXr0mvF4mc/h45NTrw1cqyZLQtT0VR/PEHnsSLROpPvBK+P8G2fVOdw
ttk6xXGhBvrCkIwX7eZi4DwGM/o76mFK3dncQqA0xU67QRJQ8YqcJerIFQgKtnTmeXkCDKlkJcZr
1DsLavE12uVIGF49yHUKra1cf1b0AstXUruDRNacXw5qpPOUu5fA9NDcKnTt6bymUGHfBS9npJhV
/I8nPrWdnbV2icxBlnyw7rznSbM9uK3d0le973zzPvxu0pvT8FMxWRpI/AlJWKCzv1eFRk1IvBin
IiCLONG2Cx9xvRNsFTE8PAHDpkfqe819zscR4oOkIm535AmU1j+3j0idSWW1JNoBGnGWLSZk2TPB
R96GOHAXx1eSIX3qhM/i6vAmgT7hrh+FD0LopO3wzfFpxOL4cXtVOXw7PiYMrH/Chp7n5GIwr9/g
+wXTW+RiR3HIW6jIsGriWHI8eSUDZSy07KmKXL+TCBnq1dnC4+Fw1FgMzs1UmzZQypUjFRhF9V/M
diNW9keDslcWzd1chO46123JYMbBWnO84UFCXYfTxXyjWI5lOzf5jw5lsnzbpQWMKPGnTRdlBBYX
F/f50D2WjnWcYmv9rpgoJIveTdWPdeOqPSmuhoLoEDgRqnyEhkpBjiWGTqkqCS0J04AN5Bsb09Sf
H7FyccCoaG6MxL904th3AVWsnKZEEm/4wXC8rKnqGepsWCZjANlgHVkvZJkMYYB6EfXNv4JwMsf0
MpYrGXtoQcxSyIBYR/t1wwJsW2yePdRg+YuOOWYwxlHi75Xh9h45OrzdLD76fA1STIjbaoT9HCbB
wURbm+dLKD47FMy8dEPVLsfUE5NWFbG4UYCX/yVaWA6PcHvBTaFx1oKl58KlEGnQHJw/d5/1Vco8
PitXe8VseyrICbhPYjmu9co43dYf39f4an3pjpjcXREcRoxwciGKoBDJ3mi0cy+SaYhIehly7ttD
i6hXKhKnu3Mg14FHCf1I2ADeeti++VbNjx6czW+RFpV553+3Wd+GcJf+XAKtmqVHRLqf4+mm2RRQ
6LDp2zr5iRGg5ysSM58UibJ/PyA8qX7kzTdXt2HNPaqoqsYali7hyQ3zMcyjoTWVUn8/ifgJ9xT9
XAHedlkfHOQSsL459CyBB5VWUJyCuoEDxn0Dl6VbIbwAp/zwCIi2DRUBtjJunQDTCnKD6mCSx0d/
ywS/usqUb4RX9eATwk6v4ZgtQ6AOha2RH/xmIRM5I75KAUIOuvkIYUBUiD4b1wJxDybq2xEOCGz9
rrNKAnk5sSNgv/d6RYAu1hT5ksM3t+8gO2x0yoBu2rEbiRQf11xRibD/niJO7JSTmUDDDGDy0taO
d31aalQeQUHzHGj6hnN2NSo2YDK4WEHe+qr+A+sDzv04gVQAdPJv155YWn55LTK3Q9pdOFkPJ9kn
Er69frmzEzeETA6+CBaMDphCwps+GCC8ozFEDDEE7NEyeBiFNfcybmwvZ3KZqwPhGT9ICm5GnyHJ
1rjW63Oac1cp73+xViPPzOJVKDdaO6VDNmSRQwVi0sujZ2d1OQXJKL6MZnarmtGicSbxnrFjupCc
1VjtshJBKtkI3J79ho34/lkg6a3goP6x9y81fFTL0kXqigdbX/SnZSmfhGEvzYpsE946i6/Z9QNS
CWvoSKpYGzOuTTlxLIUmBL2G4SVuMeV3Wau2Mz7OK/TCtDC2RTv0Np+opAkrp4+iYr+7RooUTS9m
/9jp8oj4Vp8ZT2dUahP8EXEogdslB2Wu9ekJM0aDDve21rSc0LkOAnapB8BvJTKL0qEi6c+hdi1a
3UtsCXnfA2okwpvRA7WNrUQHnqox2BaF/i8AtIKsyFz1AjfscQGi6L4+FvjEh2zonGdoK7qr/TKG
g0H+Qt98xiaM24K9hlGKnyLubZrS1xaiSG16yNYSXbZkbKSOXecTrkqdToyBlGFI36PwherQAK1w
vyHLytoY9XbqWBUd9x9EE/FuMuekTSFNZDL3u534XpVWdRRCcLNlFK0P8kMNqCpREBnTC+DatYXZ
5fRlw0I18AyWfE4xdqiLJkZ+eVgi6DknWNcCw8IwWr58593JIhYnuuSmk5r6ek/xrenoSZhnQnHq
6+kyre5+rUof2axBstR4pnU0DAg0C/kBSgP3Np4eZf49svGIoY0dV9AR676IMVnPC3I0IiBysnXb
YwQylBKrmo1H6MsdN6hr1KgEqThA4fWei2g+a0dSNw4trnYWq6873L5extveDFL68jcv1jHDQG7M
nhDtvcDxrfIhWWzk0GptSvVy8GYe0tfLjHwdqMmYiIMWpH0Sd0xX6q5pPH1wj72JhQMq6XkIUaCY
AX2jwSiMsRn4K4UbrBFttLjkkPJrS4GsVcT4Zye/VhvX9p2UXL5SA6UhyjmYrS3cb/Soj9E0q/a7
QkZBx6aKOFGzzzs1vju/fv+mQ2lULhVA9VeoDmAgPRDS372PeqWTUlcUgp4IqxSW1eoQm6QfNUEi
2b93g1TcsEOBs/UR4+A8H4AHQpWvq0tDuAUoZG3Reboq74EXaJsdHBdGfPW1oCQiXveCbp52l6vW
JlFb6cxJ926EKSq9WHtVMjZenNv/LHpuMfzbavaPuNvBs+vqGqM8ZqWUPY+y+sGYmj0cbQDXulC+
dZAl2pIKaHIaP4m7Gwhr0QrDeE7DAeRRgv7sFGWP4KszdVBrZWizMdl6vDmtLwH3LjWWCagPlIth
AuqWwYJAc74LUHkDjxzdToB9L41GoKlRIl/5bnJuLKzga07cHLJSZYcGGsQuuDi7HVvP28qeVjJ0
gFc6xYylGnGtE6LqC779iGIjOxsoBu0X6hXFJFiAbOCYrxeftPplkCgq9dYQ42IaTWScor72dwA8
WNT4lDwFjJ7pzFKkONhxyQJ82vpJj8n7Sg06n/P+oYHgkPhp79fPWIXorH8Du+qK2TutHFDx/ojU
Z6x/kvy7DTTO/B1Lnfnymp3G3FjKucVsO+w36ny2fMCXDpbP7vrg4TQhUBO19b9m5HFz5kcnPiOd
buAhrv5BamsIf2icqKxeuu0RcwDkwwhXeU8dWmkZpL+Wc1hvbpOq00GfcbR2rF7mb0YPpi5qlOfz
QhuBbCoMrFcNAJDsSWIFGG5JkufnDJZMwJWn05pQQ9/uC3f+iXzXgkRQFr+X7n2jmnqQ/WSemOCc
DnvlMrmg3OdOR0YoUgoMGBaTHMlEPfE7tFBJS1Fx6z6Ao7s0rIoaYNAroL8ABYC5nO/pSrbLRNBA
lmn6AxEeuBVfVKFpRFnyywK3XDu4pXO0gdQdfB3brWAaWcZOQqOb5oUUJokk0IpPlolYFsUaPzv5
59d2e0UUD7zlfxRM5YcyAcRkGel7UW+ncDk3HA036iahq3hYzHAauFgB0Cpnw/ymLNueLr/qTq9R
Ex2waLF8zEQlJxmP9rIoxgdyHTTimVe6ENLnkvep8EamBCl41BgaRABc9+jo8gHHzQlDznsaYizz
5Xgv/71QhCpT9bdLCh9MrqwUSQ09TSQMgNrNn/nf28/b1BRm+8+kqvFeSjdKv4cUyJKdn6nCr2x+
h3e56e6fE8BbmJZjE5iQCBeHnVuwefYZ/Bh6+mThKf8HO+R6fOBRSyxOfkZj8Zsbhil7YepEbjjD
LfYImXGLJ6itlXIzhF6vxKpIY84HWTmozwzCXxBtjOZRJLta4U+TrM/IdtbhoNvvXj0nsCgP2xb6
FJXajIG71x39uO/dZxz/ZQn/b7zeeBBt9VKv6ErcgLDCD0/HmbLYEBXoBYv7tIomiwWN+C8/qrdn
C8nlxuJxh4kAXISIJTlbw0rov/eB5VqV5g5EuofRmQyZ0GHKT/YeAvRXOMO30m6xxK0akHhC90Ei
sIJHE6MkxFVCSYkJTzN+ul1aKbp0++ZGm32v/FC6JJlH0mXzQwY9zxyh50oxkrXk3SJDhF3KJh9u
PfcTh+IpAHUlMFM5pglqm/fe7pgoprkuR3+t27PC2STE/uvoh8rDhVqKYcAb/dUcqiWFa+eq91Xl
glUJZc3+cv0DhY5UPytuklPvX4Qf/1TFYof2bp888eBZGhCnnL5NVWqAZvlnwn5rElP6VikBIilK
4B8zUYuBLDOSIBW/YdtiX9EsYJ/gzAuxtoLkTXt59WMfTDuiL+2+SVCTxYZ89GIcjX9yhWPjQU0g
0b9C+x9xUWieT+iN8JcA2/NPH/+AEjnjwIRzOq5tfh1tvHS6ZlYK6ah82rPJtzlqS/+vdOORqKPq
5gZ0kOxppCELtjKfVhMZobzThgEmOBVR24iCLOlEaPUA++530VqJqs84aE/SX/vZWdA/VmRK7zuF
iH/7vG//Qyl5/mZQ17V2DXuoQ2W3HnNpV7Jlhv9vXGaskQN5Tkus35c3MtJVUsX+kRLlLbxgmJV2
R5iMId7wjIKxAcJubwsU9luqjVHuddc3fGsx14rWRby+i6Do0CQ9t3qQyzMJBuanhhOouHVR2KSp
qV2oCCZotZwpMdzKfz7eWa7tiiKL71I/iFWfEdv9ksHNOS5JgjW/KiTFOVbk/lOHvLHhD/PXoDum
p3eouGOSzFJguKGH1kbVXlMuZM7pYqAhx3f5MlO3GipBrBmScVzMI9cendI7O98Lz3eRuvD7ekBc
9W9CuNfBYd+bK0BR5XEzenH7zQLLwxeuoEYBzg7UR4vgI6OGdq7IELg5BwWDxeJkKO0HD5logoIu
cHv1lmfbckWpc+q2DX317YrPwdqrFhjWdfTBWo1L7+yj1tmMFioqt8tTZ1kIYstrtMJwnelgbAbd
LAwsXcyOKICPwyr2vPISvIDDdFZ4EtQ8CnEOxEwb7rCazjnTtR2TJAK2ivUHJtURDRRwePkwTJb8
9l+oWo3waRz5Nym9gHv+Rqz2ibt1GgZ8Ig/tjVEI4doKqlCTtcT14DNM95az1cwQ/WwjK7Q874+E
3JqAhdBk+GM+Lr6tqJ/998oPc3OEBZF6LaLDb1NRWUuwJtogayuL3IFJbjHYgkRdZu+f8zaRhG6z
RUCjv32jD8btOfCB+ZqqyIcxQGjKMQ6MCDGL2f59RNqDFjr4uxwW+efMvpPg5gJQl7m5t2p5e5H0
6DI+Tm3nqNS2AcphCB+qqSvoc/H+8BQrZHehbSDtpW1U9PSbOjq/Q2+VHPywnGrUSh8JbwWcMJLq
Ekd15tcTtqiY8MVlLeVIw6FcNzAb1HDuGcRaDQ+OWqcVrAMgsy3RFIvME94i6ruqSPv9/xjH3mL0
YpzqN6bIl4WvamqF1XSHTC+N82INDzbR4odH45NQXlf9GbWJ/2mUHdcLqALXloglZx2xJG7+YHCU
dnhRTL5m7rXGy9B/k6FFDMZaH7PYZJMVXJrPfier8tescDz1H4k2I57Hx7voBjjFwSAF8wRM00Re
czj/NNrpSHpVYtow73KcR+2Bs2wPN249YDTzNZRl6COmsNDoLfwQ7VcrLZ3lXBE2AMbfDycjBxXZ
KgE/d8RWD43z2TZ020Er2KOfMTUfgCVH7glW7nI9Vb6N4/U8zOkEyTW+3dc/dkz2ZCHQiwFgbzvW
H+QUlL2aIz/Jx4i7y7orgkxjfmPsbKMdVlxeNpfaFXyq/DBcqdcvi/LRsP7JYlwM0u3fZx2LtO3E
WnfW8OW40jU5KAC/7M///YjTC0TaQBNfmoIC/tKzf+Pm1wUwViii+YUM2cRqbze3yw7MyBode+CB
gXLN2ta8BlyzFtmxwwSV6mPYBF5ZvJtNEO9okEXIgCp8v/88H5luwvDB2vvhmboJqN4YBSng4XP8
nfq/VK4C1GCOjMrFj/zvBT5VgkhbDYy6pDSQOMtos+n6PcJcMYQiA/Ne1dLFFPwmpk79h9tj0qHk
j8j70KehAvs7xMhTe84M4rkCvg0OyPPe7TKmPx9hBy2aAYhsqw44pYMiUEE72++f+w2nPomDdcWQ
w5DSurvMWgZL4Li6k8GQyOIfGoHFzU4kLb+kC1vl9gbr7/p8jiQfQvjaEc30r2rHG6c3rDEOcW3x
iTGw0GRu6+DxKlrKaymOI0hw8gfPu0sM3LgjZl+bIcQdZ6qI3IjN4+0mcQebA/2J3NihA2omrj4Z
QHOxAwRYNFVNuONzm5Su47LB+7G6RaV31yBKV036tYzFHdQWhw1vwG===
HR+cP/8PBcTxjP98TTcxH8gmq2UJV1lp92uKaVrTAQgv/R+hagHV4W6BSAoolwpPX5Mg75xa9CG/
8z2suk80QwAREnUDkyHBnL23lVPwXjLGs+TmhqqaoB1DvsnW2zmjkkIrThCzhilN/I23fyMA4ZCZ
47pl3qi2ggdsvJUNddN8GBzAFYsMIRaiIAvFHc+sLjgyanO8SVr5NFMLAli0kreEsJCjZgBUFNw5
4fK6i+qpoy0AY3a9q21wLwlpUS8KU6rjfO3yOySx1nWsqO9G8dN5eMTDbRCdcoy/zyfscXjR5yDJ
5mYhKp1qlSjJYB+oSwa6YiGk/BIDuJXgMdl0OV+cI2BBnaKibif7q+e3lK6+nyOcY6bQ3Ivlvvk9
6fKM9bNKk2IesLMM578cukgqMZYIraU9Dr5OXjHpapRmDuzcPj9eCmXWYVbAV4+2mNTSwsTrFYQT
DpKlnDn4gFizt+8G9NCwVxQkcej+Sc4JChh7Zwj7GBGZRJAsX+emZi3FVmoyL5IEdA3uiZEVoCed
M1JM94zIpMfqdfuiTExtWbtqbYoi0BwJyQzzq06Bc76Y4IPns4gMyDaR2cQ3rTkuN+TCia65NNwh
xOoWrvOVLcPdAK/ECQezAAG1jrqSex4IJFxbr+6XLtnPcNpF755fCI/UybeGk6s4MtvXGJZDWGyo
0uPXtv8ADo7oHVxtVpux66lYGDTIUXhQONDjciTt+vMxe+wvR6hl3KwNFqRPheAsJcl15hBBJNM+
9o77cvDMYCDDfB+ZRPF3XYH02wz/bcAPEnfoNlFhFWDezbrayRuVe7aFgbpIm9DvOvAMH58f4rsu
Jmt+vrAwpw3d+3sj+fDluTMEmnXtw5MEVOCmx6MQ6P4VABn0cwt1O3M1tDS/ujKnsyyutdx41Lp+
8STju2FZDYAEkdfADc0u8Sp/BxIwLql3w+wx4NSIRA0hmcqsV5m72dFCScAqTR0zRV/4w5bEqf2e
eMJ+VyCb4B85NPHBFh1SEi4hBv+GMjWnJ5JEz3jE4KXKYXh/CTyKBnaMm87NBZxJIg5xJErW0Fdo
oBfVjXm28nO7pHHQYI6oWvhuv9xNscVh9nZ4JSV/DfkwY4hsyy9RNHs9PgSZNnHQjiuk3krm4oSl
+L/UYeM9ch97/ebu8vQ10KWcYhk2NBIfDsoSdcbuL1YHqBO24opmgPLmdLmu28vc+G7Sk68Q7B9N
bYTdm4KE4U0kzO+L/k9u59o+mhK0GeNyA4VdD2gPMEu3vebp1l+Pl1clVH2poSFgZizy2kDA0LJH
1N6coR6+XCQcHaegoIfJ1334wrvScTlSy4YwxpbbjpdbWw8YI8QrZIZ+zQw/RJaFyVjPyPC5KIep
NDkAt4IFHV+iD3Tu2aDKbPqCqyG+kzA1ZSXwX0S1q89luVZc5yHmez2zr/u8em1m8A+5n3wRp8sz
3VSIZAzDbnwXwa5TRGNUFLI1kpTbrECjwhTkLa1eUu4BspHKm8J0vvFAdzMjvG8c9bwqX8cmKRBz
vIWQ9bevwzz9Qf4MALfeSMM9B7N3GbGkeJMqWYPm2Y7pFq7f2JP7b9lYUCcROl49eP15P4GeP+oi
HE/yT6+0uWA1nYroxSwy7gNP6OUmCo9tZM1f3uMbQ0FOSUzqwXpNa8L+NOH27Xd7/wfzUWlSXAYl
CAxcI14gBrK8SHTGUlHZXCZ9Kqo+sDZMpHT2iiIpOR7xSbbZ/uKxX3A5Y/U6wQHxpg8fQwADZuU/
i/Jj+QX/+foC4UiV2XE3qDA9TfUIAsm1GQ9nEs5jNLrN9MeAVE16liNkKTvmfXzaHGscGCKkWBBD
k26eaACJYn+wHXVpAs5vb7Pgv6Ci8tljUb93xdu/vx0YtDmkt2p8/EoV14z9wVHZ4TBr2O6qjsJP
d/Nw/rwTT6uMO5fRO8JA7gXNNeDzVhwSWpZCG6Bp6o23MeI8Ar6sD2CAH9RwiE8z64PuXvXF2Zvd
+L+UyIr6YMXgKtRAwLcdUE3K8qAVXvglvecuiFu3MciRvFDQqhhUwGnL7vc4EBh/O9UGAtukYABP
+2gX17DOp1Sk6WIHwo7lVQK5lFOat6f0BIOaVIGxBfcJRcZJIGgUYca6JvCX1CkaAQvcPhXcSPS3
Sj3l0C35bP54vbm0u8bsZ+ClkwM7hMPU6sD5I0bi+anW8lJA+fezsbmxsMAAezrB6g0X7f/x79li
Eo2duBwAzbBD7E+IksVoT8m/zoz+BMVz7HBilNPlx3SMwgIy3gVvdrqBBplac4UNRuGvrktBwtdB
LkGRHd6xlyb9zXlT8Xd8AFW7gZynY7ueiP27czrIexHbZitlgDlxo/UQsGFoRxPG+hy4AC/2Oupg
M/Wa1Kr06lpe9LIK/i0feKWGoPlNi1+x7Ppr4+Q+Tem2PYibUZTZNiVSyS62N8sb8T6oCtp1ca06
YE6c++qcmx1lYcGSvEclpDZgYY2Qpfz5uwoHNt1/axmru5sFoo9vR3BS7xtpmPQJk5V9E4GB8CVK
NxdVFbafi4r9JmlhaG+P02/xArtvr3IzVxNdJ8BogCxxO3sDbkoVVQHxDJB5r7Rb19tE9zHPy5sB
XbovOyX7VOmkAWaG1ULP9Izi8310a9NdyFGDVRKAA8RHAM2LVtIQglOFz6o18VTgXSBw3DrReUY6
gwTvVNBU4ULhrtvudYzfDyY8G8HmKyNDavtM83w1vOo0uaZ9moUQyzZ7SEBrh7Xf7UcdZQ0nKLvS
2vHNzs0w6hTJMK6ppxiGD+wnJOWPJjsXdO32aOK3iHZh65Ao63F187pTR9PlZnlCrfC96+xsxFcQ
oyZP0u1BNoKdwWqaONEGI0F7+MAtYOvPRNvgn/nfOQwZRpPyJ+X4OFoAqFqd/Lm3DDLOVh2kXqsF
muMOVd5CrPqJFsAFVt8xa37BEARIHBac5EBOIypGueT5k2xCSnYMnI3IzbXWunDC5ixMHrZFlUAj
bZGBOk3LJWmLWV3kIoe4FgAz0RNIxLZ97uNjHBp1wYk8arJZTjHAI/bsqmz9OxZOECv7TfoVi9J+
OO49ySXdeUqjabmVc6qsD3y8JCan2N6+YOUaHS1/q9qfVqZeERsX/XF6e7DWXHGDDwyizUUqgZWk
fJAWAvGK070o834+lG+FNOhpeew1NSfRxXdXPmhwTwz9MVc7NX4dhAKF0VpwWhqwfU6xyFA1WCSd
EfiRXu8GT82HWQLXmTBLSiS0BcZPFHFlOQembEkK7Brvp2NOs5GhGTbQCiAFyskIQokEpmqmKNx+
c270d+K5W0f4Ep1l1EuBI9te5erPbwATXVz+IeaTdBr0UAsYYFqq6+leKDxkPRxz8Ax8tp89qXnV
2WCp5cyPRV3lM77sQ04IY41eAxSQdTl47Yq5s50qAOHnoHXp5NojsqeOOYZPmiSPO3uq9bHr5b/d
dJRbzIE8NnqNIGn18+79G+La+O99rwl6LRpZUSFd7aDITDW5UF5bqJFGBEjoZSRNqihnyICfh0IW
CAHdT6TX7aBcAdxSs9WKWCS3yDh7Jnmax2no9+1PQfTiA0Q1NGHpbuzuLbh5qC13/sb6DZ+GDcAJ
hRGh0QO9/ij5tlwIhvX9cjyhcGn597wWnZIYQoqKqwYgeZEVaZyn36zzDgc+P4i6zeU5Bv6dRdrE
UUn8w/X7UaxEqoQxEIkn20ejdqvVHqSv2rERUbIs870oZr+BROsu1uTOi2wOKyWmTMbjkiYJYjP8
EKlAmdU8JbcQX4bxTEYG45EFUAV/De8xPxpN+RSEx2/eLCxkUNCkqFi9jbMdQRDpPB99TGNipyik
DdPNpjzlXHsuS3CxlfMjtOsva6By3iTgqHxt7lotQFCc2xCX/sHOcf2WHRtCmcpPL4pVqhSniLtS
yOmdhiBY/cijCvV2sc2JjMaA0xA+aB0DaApiCOb8OxXRqPKUTquXqvSVS15N2lAnzQQAHi6ljX7P
KJtHhGG/Pah5sJuQkwskHU4rlrjBMQJyf1SL6rR5c1WRVYKkTLCe/3+9O1t5pjcnAVUwuqH9LYTm
VpPBDhhx2KJJNvl9ZaxoJpXP1XlPCOy/Bm58b44ZuGGe447qtduVOPp5LjLO2ZQXmQO3aGP+Mk/o
WGSe+LzMCaJO7dU/5AS8747ApFDSZCXRm0Dv4k6kT+eeKPIt8NBR4kq9Sl/zQFyQlJbgg+l8qILB
NeVSCwn1qbFHpaBiGK6Dpe5jIsj7TFS2OKOpuLsJipYIfBRIG/EjAXRXGCe9DGpaTFuNVV1Bt0c4
iO25wwu2Pe6e2jGZcfEuaKxaj46ShVRjZWRPYij5aP/v+tsrcXbwlzBH7iY4fL2qMmv52ZeEr3N7
jd7k+Fu1nQwwFx+6sY3BwkGrH0d5nb+5X4wLq4Dab6kNzI1cdPr13TsAj4ecrdgk0o370ohMUUCB
H+gkm/bImfEWkQkduVLnxaePxv8Vn2e9H0ud9K5YdLP9Z+kNfk9xXLdbFTcomgqE76kKii06jEPn
nZk/FT6LXJhgR2JO/t6jscXi/qGkjgdc7twWR3EIXAJHIZV2elnzByLWV4usatnPBhQKAhoA0fwf
Jlu1jQHpeDVG8Q8pFI7ZILI0LrSjbA8eMJkFacrzI01JattO6MUvfhXL5yl/P2+2d7pSlK98HKJt
V32xKKBDNegIB8JoyuM7VrE73idwY73Olvc5JnyEUo8WtOCxQOs1n54qcMMZn2FU4/if6raMJVgS
CWc17qqJupB4xmNY1nlGdaQ6nTcZSF5zT50q1g1d8pHsvCLZP8D4+RqFMSOKXLQ7qnBL4TwKp8Ny
50azL3RdLROjAOW3Tu+8KGgjbEBKIhYhI1c8KifgKamVba8qL1+EsKmPs4CNU1GXNcRAtcgGqFAt
JzFJkOB4Hz2AFW9knaDFO7YaTcki0s1xb31+tTAzvm+AFKPCAOpyC+0AL/5SnA4Uw8UwndYctMRD
UztBx0MqxSalWKNBFmHMSbhbFYHD5wCPu+4Oqn5wQj4Zxe9rp9lG7k9Z5GgfUgCoLnj/pT0wmXPS
iUSO/BDOK70nYDdrL4gWmQdBdjPxdC5aH2LXZ8DXT9DCpxEY0peg62StFkYI5oqMzq+QaTmMJbOO
p68ZdZ9PwStSkEOrXtBI5oC8MfNEkSMwg9OS3JgDhEUOlg2dcA10/6Q7ROo0uQUr+tsnmmXfRUr3
PIdmFRciuTal9ffSFQf7MhR7kAc7TV+kpiaPyfWkNAxJlz30yKlPk4v0UN9cwCVlQ4SXFoUwY6XJ
HxNGo5i1IZFcGailJB3wpo7eNfLy4j1gpf2f9jgbcE4P7SwzIdNpV3FyyL3iKbau9KI4JYak7Duo
HqEMRtpGh8XINZuSuZQrkZR9yTyigqxko+71OweZCKKhhlrGwbGx0CtUhExP37Ru+4KxFOEiW2Gv
Y1GIUiZmRz/clhG4S/NanWwxZW6lN81myelEPCG42T8r8Vv0y1OeOsG0X7yn53llRZLeAvFxfQqf
ypeAaqYPg+ynLQcgmb/JbAOtnmxntLg/MKc1/wHia7+5iBahUL67q9g7v9PYrncnhtSd1J+z5AFl
XsnrOD8u6lN/sOMmNcImUah3tJNHpj4Xm203NNbajrCLqH1+0dT3wEWW7q+mmTAJvWwWq4T9/c22
IIbPKHrWJnoGeLrJzx7gvXkyaSH3gPPkrXON70OEaWQ8foL3ZPgBHwgGc9KbFLYLCypWVL6CUeDL
fSsgoHbYxP9loo7Rs/wbEReuaepuN9e6/YsDF/birX8zpfqM7uqCt0uVBDmqlswYemmNbv4GWGLf
sYCCF+zkpOaRzaVvtM2Ru2jwfXwBdTrO3lgjc8+Vm7PZXeixGgJKc2XfC5pCtSIWpVlIil8aI94v
HS7vnUSHzbFmTTT+1VIP4i5ZO5oKexTGA/OvZM3FNTJbwc7/Zi8zoL0rqjcfV4Ohnm9VVGzvJQUz
wsNGzCWBPWdBkHugVNAO5eOFUDIvYgYpCTbEoWwmfscFZOLeA23ASa1PfTK49Zdv2uh01y2verLe
Of6/J+imm09u9SqJIu3fGpeMb8IDKbT5V3TqgtFExsCO/hPJ7/GkV2ATH+6g9OZzcYDz3gTPoQLY
1hJ/tmkgZaTmPABpS3a7/kyM9PxwFJrC+NupasJtVWO6bEaaOxC/YOADk+Lq3C4HsGXSIL7oAOqY
35JEXqLe2GRXj46YT4dn9cmZ5G5al3XXRTshwIPWOEODCQkQbX981oIGSSfxYymCxA8SoIa5OD7F
OB1SwPsoFmKhYsZ9MP/4P1r0Yn5EkY7jH7nJOkT7Uy4LO8nVb4f8uubU61iweuJMUjjYSWNBcuru
f3Riz7yehNOBhIGXxvHCGuPn+Y//1Lqz/KXqCnAVZT+qSj4MHDVNDAUrPyiCM96+3saesxf+zFrU
/3u1d0Y1aUx+1bjBNO16e+qds+yw+fG5zH709sPTw9ZkkF4fVYC+i3lQbO4+JVNxMjR5shGYHW4a
r0MiYHU9bnl9HVgk6HRl6SpYyDMOPjd3MC+bHYjDHKLYsqjYbefRJ0eLrQfsweis50naXo0Jx0iS
oq6ym1MeWHwkm3dc6R2WaL9MIw+G/bYFo/5uAzeTTvysN+3OKZ8s1DT8AS12VaQvrXVWxnUtnWgb
6THUr3XZZDCdiSq1W6Jlcxe+4GuE0XUrduKvY18ETdv1LnfQPWESTaJbCRRtahAcotMDUWvLab8e
M0AUrL4APbK34FBbsYWqUmiuLbbHYpisW7XLlliiMIDgelJOaSxdubMgca8CYUyfqwdzPGGO/bJI
bwx2TL72ae/J9L65PTZs1mDJ4O+m2CrToxQ1X85HodIWtnwEx48hZh+4UAvl1B5Y6EEColy97PIQ
qK5k35X9nYsDD6kih0W3P3+TlLdhET/D/OBtTZ8tJd7OSGCUT6gD/J/aLXjFM+wBHCJm51r2FWh3
1qsujNUrpZW9gJfPg0InCDKFrlSDS5s1ibUihZD6jJq2jbNBCutYAyQ82QuZxYXkSGO7b+bNivGC
QEoWomU6ICpkBwxGQlcp/BQo0TQDdpsftmO6EUPuR7nGfVHVLzdSyq/j75g38xqliIExCnjsAdwm
xJHKgcFDluM0ljj7NlG0Slqs7eKiiQgCr7er8aKD4CGsoB2ulytCdH0ZAVn4MQFcBGMrxKk4LoAr
eT6C3k21e7zSGt+NsHz+0c+co13TalDFaZW4WuChKz3RBxTZ8n/d84V24LBIQMsHWmrNVN/T5SE5
6kDmMiwzvnIw/IZvJBuc93Ik0odyZt4FzdnBKU9QRY33VRPI2lO66Ie7z8kjdr5ViUnJq+KM7AS2
31phJB9lEU6lJXjtySw1ENtwNpdDsENVZxdc2yHtZDjnRXLdTknxoYny7Uo6HHb4yfCH3oFGg9Cr
WuFFTa7W3QcyCqvnFcAgAoIZ+B5HxvGjhxVe32sCLIl+UffCfPgtn/2UgwDP9V2P6IriH5q98Yun
RxyeQSqpHvwo15oGtIt06idI1LQXl7lwLoMWffg4aJTXCf3nC+VHZQhW6R38jfcau/zx7EcgCU2f
JFFTH6yiuboFzpXgz33O6W4RD3/a3geIj+fqWQXbG1bTRKSfLheAf2rt5bjK2XyroHqYXBIGTGaV
jHbGkRqK7SsufuBEEB07p651WCPRJqucz401MUz0ynN44Yw1mxeFGYWWd/qq3ewwpyuHmbROOM9P
7FgIuhXC7El/vkzAdgCxjZSNMrR5TLefGH+1i6CYxo9sp1ftv49tk4oliPbyiakPlCzxPhp1xnCG
RlykGY+vmdTCo0zX0fqAa1tomRo6Z8JQyM+00l88XPiNqKVpSQVaA5L2TUEmN/Ae54beoyp/JkrC
IwA33hu/IgwkkZ73rDWabNhWMt0ZnHzYRNDjiS6e43RBcYPuKkKP8j52a/Dlvs01LvHD/PQWNkZs
CkVsXJc9h756xPgtDJgABN+5qlt8SD13OfI9/q6xdOLp2FKoBBlxiwkkr4EzKocokyGq3etnKHZv
MF8hIfcvGs9geu8M2aQUUFGOaLi++9kXzydeaH0Mrae5C8J82gIv9PI5RY7gS9mwx0P0INQNVNtr
R67I14q6/Mm1Tu4a55H+HkmD6dFaVnYvBfeqAkIzQC+HxRFi1DkM3qUIBq2rwa/Vf7oKrC8E3BZf
HUSLBc0UAMFhwxH+g1SJxCOIEnFoVVNULZheAvz5zfUk8NSz89QrsHNdlE5b+IFcprlT2KnjcT10
R/668s1WFh/EbwhBoUpF3kdnIFwm41bcW7UUgtjgVx9GATStCfjWpxXB3RGVuBVzF/DWMPf1/y08
gAEpy310GqAY2RlZkqBFiyL9JzTNdtuxX6Z2mNYajQJhcOnuIPiWfokDSUi04sFm8ka9w+FIZFSU
VzixqwRubhcrCicfpDMpYsEaCnAO3LWW/nOgicel2TK64jN+VONBgiXbFPBFuvZrLmTlM//+isma
0BwjO9o0tPALjfF1fgDVeULa03W1lA5LJh/c1tJM3GIJnJeJd6YilsA5fp50aU4Mnp1uLheOtvgx
EeTTsDcZR0NQIueE+NXTCpGcnHHNrXnqBwlWQ75WNYO4mG9xLj+2YaPlGnumIGWIi0yAUD6Rosg0
Frk9/lfyRNuaZWppomw2SpVhSSHwrIWgi+0nLAN2HAupW3ISVbPXL2orq9P3yQe34XzsrHyR2yBl
kB33reGCUHK86wnZggEdGAT4SaKnnlPHvg0NVD5Hu6ACkHjGp7R1NcX6LHlV12dALV6E8MpMyWw2
7t6ZuGfl+u3+Za8MGT912MOMIWNlXns6+sFHGzp2bgek50UV7o4Y5I6SYA/7CHyZDeaXZEoLuzPz
ppyMlSjk5HkAG6Qjhu2hDKuRlE74ZdRIQtxdzTJdy5xUhB0oXzLFRMQ6a0xDfvGfxrHQmY6pREet
x2knbxWoAguXTArS6HXvNoTwT9Yx60EBPnwyWmwbCUKm8Hx9llm7xLrwnmycHA+B3HCl7nhG28+l
pwMQy+PS2KYxRb+rUZexD2HMu4QXxkimoaGNaLKv67Qsgt9EGJKQlUOdjuQhNpbBhPXIDaaxG7EF
g5LFdLaBvn9kNeID8ZOEdfV+9m0ufSOPhonvZV+Uwx33xYEi5V/S99IFbbqw4TvGm7gNIpfek7wT
XHHL5bipQIVCUFuSn7DLAMjhDJbKsWQ+GPI+2xxiSK6iVLXCX9uJags0jtyboQj3ZLrC5JQVFGrD
Quz6ixFiMr6rUh4TPkNr9TFw00uCbs0VXyrerHQJHI5lJNc7j1PYc6VTqCx+y4xRHFxxtBj2op/E
x7CXLGCZ5xCJxlUyolaZtinqiMeZ6mKZ6GAfzNWMBKknNItjALkzml2El3sh/pZGQr+cBBELNylb
BZ6RL022OIJByl7zTIiP9Fm6SSWZu7YbW0VIk2Ls3B2zO/eoLHXuXwi2mkTOjkHCaTmvPbUAOVf+
Y3h5FcHKaC5nlnRiIdLUtvjCBgdb/9fiQr2xrx2X1X+7rIpJLoG70DV5MZHYYWMxTvg6Xu1QEux8
/PFVbem6y/9uh7KJ63Amj91epxfJ1/rfQ4JgQPPga66LRu1WpYpvijORxx1S4G+t5Y+RbDX5Um8s
GjYUJVO75dfVQoBZS9dPRd3E7qZx/96gLiN6kmdtXMN9q8pfqBKgQxDW