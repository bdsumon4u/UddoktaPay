<?php //ICB0 74:0 81:1a91                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPzm8mZAHtZO56yDN4HEceMvrLPmbnB3K+kY5dVkZIzrBatuIGaMA/YOr0eXGdsJMoJFU5soA
mFN2q+6Qz06Eb83FTjhw8gyoH9cL3MLbDSGZbW7pKoOcBF8iLcHMSxMZmAlIuY7OFJLoeJthTP/2
zh7GYxB1qSwjrYa0dVHR19Bvn5xsIdPYE0TAdOXAcp8bi7LKi8y1WgulHDuuOMXLT919yaiDwCiG
9O86w5DwbMsqTMwmZ+l86N8v0oy+mUvoFYgJR6awHhYI613Nnj1BTRNiMeQP7gGOitLSAjAkGDa6
G6ekEDkKIWkzXaXojiLaLHiwbpPBf3afl+eL2sJlHozKWWZ3V5ptbG2602Bo8WvIMWmLVYNxYqY5
fcLEtEKqPXnhqfZKX9G1BgYQtTFmkUQ/YzzzAYlcGlkWqt74vlj5BNaVEuBbaJFYY8dYqJw+lSaK
aJyK79ixeUhQUuT74CUm7toOeWozBTVoaoZDsuc0vB6VI8ZtH15hruk5Zavr3FWOTKZBHyX+uDMi
SfsW5YKpO8iuMlxam7t+0veF0hjkoPM6vYVrSVuM7DJF8Dcd5lABhow1MRBiOuo7yqfDBICnVcTa
2p6h5RPCmFlDkRFnhgp6kpXLuFwpTEro8Xt8uoGX5uM1Jkb9XLot7yxcde60K0nXMe/9M1sRe69f
3JWjW4mj5o7iZRuZBzBLEGjyGwrTEBSQ46tJD+wSGyM+cRIUCZqHPvyAAJhQ87sCW3Ie7O8r6Te4
2LzXtw9wpKDRSspBumG50b6fPYplQKG6iTMdxjqgr4mgz0hpIz+4buI57Xe3Mq7+8UX+6RssLcjb
hjuJxpE7w2asq5k4dfUGaqKEZOi4TkOhWslm7qhEJCWVBGnoYkvg7r8Yre/UzOTMeooqpnUF96xQ
I1HhokK5LrcURQDgeJahR+hhO2LJfp1928JuYgSYdJTcH7heiycvoXNzi/UbV02H/g9SCus2HtHs
KU0laZSxJagXNOtLV2R/x/rpoU/KcAs9goA4bZG7tbuo2Dq6amIh8Y0EFjyZyi3v2r3mnUgXnGCu
iyIPPmv9P3burtnhNTjLczr7+b7/feNWrLSMuRpNfyGlSeGWmAJUaTguIW6hRze6zTXdM8kss4mB
9a3Mabfw0qLf2xzxZCFxEtHIHesBVWGBSI8P5l2AK8Jn747K98QRdv5oMkhGx6tafkHcVM8cGr0B
jEq0CAQzOKLSl9ZKS/PbWs+AbJrf30oMl8WhM5SBzqdStV4AZ9LPX245KylTPVdB2MBU7h4fC3Xg
yjQBsF6mPxeNhaKmJjcEOu4CU/piRtW/vvy7kxrShJOYiTzikqw7pxmjVfzzXsllNcjpwJemitsB
Zsz8W6j+uo4JREA6AsyfjB94SVZHQrNwTMl2QivvkDbAYS3khvjk9s8sPinOZYwvGA8rTLVUe/UD
RUfCD4irPt5BPkPHQDKOaTS9L3BACdbzUoejsltewEucWMh+Q/K2Iv0oUeegLAxEA7W9vHpH/EL+
RYfJpdl+2VwOkq+B94IF4vAXFcLGre8MjnH2ddkz/ePy16Mv9lSNDYoDaFTiQntO7kQ+jJGQEvs5
qK54jVWF+/Lb23Nlr0gm0KRpxPERsLRP5e2z0l+GXlMv16569IWQWno1Jxp/XxO+gfVQKTO84j4N
KFgRL6qI76/SU/EeOCDssiKQL+fa0MIlnFuuHYhJHL1L8Aj2n8bU46DbRCiR/uQQ1eTaikbN5mRK
qSUbEMju9IBceTnGIccFTcT9uQKIwrohZFjZgKXgOirB4JiiC9TSCOJ4MJ9Fp//YGKrILZTYia+I
O9JDNP/k4pxxTsLfwhCQJBn8VLAoKIO2R0IWFedbRBwubXecB3D9AVY9H4ytLu1WGibtfZCErTEE
kiJ4j3RHTw1V0br1iDzu5SvW87ef4nhyym3zM90dYsrr22TZ8dc0PgOx2Mfq7H0p36Vv1HwVdsFC
1q/ycIQ/B+3g3ftGKscCi91eBuPhyfL7Rw4IVpSYC/eTGLgd9NeSo4YSGgN5UDrWelAo62SjtFtU
z+59S1rG0ttlBD43nGilOdIy2z9NgXTYbatCrtsx0+Vk4h4S6YIE3+vbtb65v570qUuL2BWkXW/k
G/gmq5v3Dt9uMQWb77D6MnmF2xMr2DDqhzhqUhTFFZ8EQycQCvJgmbA4Ibxy1ONYhoyWkAY7q9CQ
8+CDakKXORZRw2Of2nvhvUJrJx5EsXvbThOdr4SZrjUorwIcQFPUj6iYLfmhAVGeRXBds5TnzOxW
TkbEh9P32CxeHoMzMQfiAMqxs5HqWym1c6iXk4j3zA1FEo+KYob2HNq27NElBQTdUT7FUZ7Jg7K8
+yJ95DubCkRxmUpV9E/V1g0cLmXNY4b3sKQRHoQbzcN86FDurlPJ515Pk90aaYpvReoLN2jy/Jev
pGr/jGL1aiGfYYRvb/BtHMxHEZ1hCsxmrCuLQQRFmbJ4jwOmV81rnQjmQUUKXgindRn9b5ZnRlFS
37YAMoVMoVDhToF695EjB09jT/jZhVD+zB++viZYvEQX/pRvch1WbfAmdoLFnV2s13CdvQOnSSOQ
o6dZmVvmSsSTCnykDxBXRADwaevvSdArWbQrhxzmQksWJy0YJuLQBP8BAdY3DMoyWfhaJPPDrYM8
Hn5booybWTIM9NRR6JBhlKNsA20ZfenVCk1iaF2FLMaKwtMK2gTAuifmt2amluLoXRGLX7bByEnf
w1wjMwPebk08ly4OuJfpo4YEfzJ1MzC723YY5BT1hFR/XzKiQ4UfdDhC3T/C0tEDE4h0RU/X6LTu
yrX+nXo9aO8TQK0FjEDCP0LJv+539pNf9TTcM+Zcgi9TMsWuH1FxbqzJsJ67ssy0f0DjLht3Uwah
3uvbUrYfjCOcPjxFALJRftIuIRDpCPZA+AorZAC9ZSJ9w0CmNEvXewX0yYMPy/ZPQF9Wma9L8Ey7
Sq+f2Hiqr0neOOODM9Ehsrusvf0O4Qsq48KTxaIecwL0SS+k63HYBS7GjUG/fx2ByhcJzxOLTbOj
u25wVPetoJKss3FUkjghrS6yR6OUKPWsXOPohrC5izJE1wVgCD0r8yqHyocoDSo1DHzJSRxpXzdc
DI//yL4E3e6yR/7cXrluiw6SDfXoW7+7cU6JGft26R8ZESgjMdz+T95AaSTp98XN1WGCo5V0aC2O
i1U74bQzfsncLOSQmQANom/hvqgv47EEFSUhaY+eoXWzWcaZRS8acscRrx4eldGeRWvSC67iekoD
i0/QpG0QojVRk30V/PsR6sWH69ZwRZbt1LhkvgiHztcOfMt8sAlbySiM542uBLhzZHSPJADlBw22
9sI+hNQbyRBM30hOhTbAfiJDr+E54Bhcsk8Z9T+OOmi1T8arZYTGgOw1L9rs6FRQN6lz3HIi8RkX
MQLP+2F0BfqVX0+swQqpKWQ9IDGHvdMWW4xBRciO1n29ZhrxEySKWC4Pl+V2P3wsg/w801C==
HR+cPn8UL8uHvwoXcwl1hSW6KrMkKPgpyaqOe+T9P4m6p6niRDEGvsQhkiJecA2Uh5LMClbw+CVE
LF4Awj/fTY134UEbQeLE+WcjT7MQptuWR/NYbgEO/w5gKI5QWMwoWWF40WbB9Uet0/BVSxAQJY3j
bQdZI2RBZ10Sd6gqQ2iFVPoMh7K+N2NKrKJMwZXcuA0OYXRj4m46waO084pE+lW4Y6ShCuf8cr5s
a16TlfDOGgBAJvrYMSA3JosWH5M9g58MWu5XGY1j0gJWw8C0xXg6RQW3kQuMb9R4/ooucFkhuDKp
3UihRbsbcz5Zmh33h7MmGMb4skUg0eSkUjPxm6i53KZQKisB08q0WW2G05NsZQO7rojzXT956b3l
G+Rgh0235A/hOiw0bs9UcKk6cTTggqfbiir1VuJrKuiXWKRQkGslXxcTGOWJH6QcWAnuZQ0QFM+e
wKZ592LeAWZfBTxZ6qv0z5uCy4U0AXODd4GWiIwFaBgep6foTQ3ypkKJzkYT4feR1/fOzn+fYQ+8
tVFAMWX0pQlW0BhQQPBu2a/cDzHDbkmHm9h0gVthAsEgMxrx+bIPAOjjxleEpXAoeQ3ApKKSU6dS
Hf30LsnaIAPLSh0fZbJjpF3/FjYQZ0mMTV/gWDODjaQqeYn3yYJYTYs3xAM/KfUWeZKjFeoM4r7E
cL4YPaqzQ7H661bwX1/RHVYHpbbeufwTPzJ7VdtcOElwgf/kOqypqCFisyUZnM2wMiKelzsjYsQ4
pl0Z7lo3Ed9y+XDlVvBoLdMB6lG40fh6ns9NbsiPmSZDQcSY6Rpkqp26waJ+X2d2ki+WAFuljdwZ
xKA1Ldhg3t3bbeWMRegY49CiOuHF+INZWYHs2g6/qO4qFrtEmuK1lsxZ4C/j7TsGBztQoinUmgzz
poW4qvYHD+RK4j+4/yQww8Tkl7EXdQFglcLbWs5KY3yWZtcOCoIB5tUFps+Li2jax5MJ2TYdf2zG
UXJeQEchkWlsd+3WywbARcHVSW50hEd3VbTgXk6dWh/V7alfRS5ZH2e1aBmskmniVgJ4h8YK6B3i
iRnAZOpiaUup+p8Y5srlLV+CBTg2CFG51zzJ1DNQVSMWp3kaXKiZOmcVZiEWRDb7AYCiWu5DaSTB
JV0c2ktvFr8e8+yq7o6z7EcdxKVSiIS8SuTa/85if7PwbFlHnKCPLtQaDeWUwLrOFYZV8lPjGqki
LhzbOS7Veieww5QGBC69W41CpAe0qxrzBRDP10Y3UiIdmtz9NuPHtUntohFl4Mv50b8cqmYh9z7F
BCe2tL6DKLE8sIysNHWgchdKunoc6+rrgX92LooDY5ieyDVw2ertTuJSpU8rSrhkf8u+ZCnoA0Ek
Di9myDZBf4wRvg0V/8N0Tnx/M+tS3L4WwjnjtKGulpQkwyQmHxn79phfugA6GPwuk+qcJ02mISwv
nkdhImiaETylI18/BCEac0XBwama7/YbX7siWDQat6ozTz0UY54Xi5LZjSrJimAvMEM/hiTVcHTC
um09nSILPHepf9nkHKDY7+pzNnSnZEgL4FHsMzJVkzdo7jjoxvBPpljsxf+D1tPQwSnRZHn3yAjr
qfTcStv2KWUc396vhjib+cAb5Z5lfa2XW+bL7kuMAoLithri68bXt5bQMABeTCChUWmnrDWdKqao
gdQOrePOgnUKc9OKuslx5iDpg116Ws+U0u9UcmeWRtdK1koYw7xIgxDgd3v0NV+ZsGBn4ntXuz0k
jO2VKrieBoMmPTJi8L04bHNd7M+EPQPY82LpR9jjbF6efDVWISy4kQbIyh/SZN4WLlYNRGLpsIVU
916uFLfEPlKPZgHvyo3yOETWpVMVMh+dZkggBDULbRtIZ5FbtoNSpJ7EyrePzCIPVHrDYm+IACbr
18/WXlPT62dW+HrAm5OWfVMFteZv2HHvNAb2XxBpGzoMCW0K7MdEGx6tS8JhFvrmIOB4itOZqCQJ
Zj2/2/A122sNM6lw53fuKnugqKWIFG1npn9FUeEcEmkMzLL/pOhlcu6sE6a1xTLWeYhCY+tNuUDY
gFIp31gXPNYu/idbMCNfdoPN/r9Zl+GW+Ydhnt2/+FyXqqV7ynm7sxEbswdykE6V+JcGxQ06LG3H
8TAvxHOv+NALDF1AhBo+nOscVQ+tk+Dg/cYpanqUmfus8++OHpF9z7ppJgem+OqHGQl/wjtWepAA
yBgAM7QDsRLexKsVqsouxOoOQaruINZ0/Wx1MhzhCBhnRmAelCmwdlIQ84uGA5UuhQNWCrg8ak6Q
gr0wkycJOibmz789EVdym2n8aWTlK+++FPDOZGYjyIoVOx71R8p1TtVo1jWTjxixJeTeJfHjQhnO
ErxTcq82GJ8BXUBmbkpZLwOfAIWerNPx/JQqBWkhqFCBZ/1KOU8/CDlc7+0d7a1k+ihT1+B/BEoz
5l9+6uCxz0pcPr+Hgsj6YeLg8yWzW2VONT9bxZ5/QsyDczZZEAuYd7IafpRp679TyuL18A6M2832
RUyvQ9CQFUzE2VeXvUcz925BV621XeplcX7SR8OjH8R2p24MvyA5SLiMoSQ0nbg8ODwPXI/IP4+o
dHM+eKMtr32wUFGEBSVtNGglAIhfEzt3QLdb5MbOkTqFWChIER/ioUyn0PCheWoRZrwk27b3fxd0
QIssfxOPj/SLT9zsb9d7sYoFHgQBvPd5JjQiZ16oi28Sd9zD04Q4yQc9eqGITqIfzV5p/M3VAlDt
DQ5s0/Ua/H6IRX0ihfec60U/KDxsiIi73lzGAjHmjjQWwJQxqsl6ynC/3fbF0qdw8ISnN75Vh+4z
CssxwSIE9KRdU6uMJQeUl23NdEv1p/GNJaNCmf1m4QDUViCs5m1E+PRV124sPYNxvsZ/g4GmlNvc
tDpU2wA2JWnrGTxdzihlSwOTFkYpWlnxgEEwyCphT6HhjrfKZhcSkCx+88lyjIE5RQsPTf/lvILs
uA3N226Vi+9ok6ssHRiGgwna2QCZIq+cO+RKR66up1EXMGx1Pva9HQ1c9YgGq/NifZez1ViCAf2n
mDMYguXZb0S48csOvZVH/wsfpO2Zp616P7Tgs+Dh+DblkA7dLn0mekpeZhP6czH9t9knLUzD4js7
6xWM+9hcYF7LtkWKFkrmvRadFM7o