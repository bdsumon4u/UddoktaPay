<?php //ICB0 74:0 81:3609                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvk83460ClLsAb+POiTj4ImUW/NU6a/IxVykb5naqsh/cR+GexCS9b7tR2hZr/ot3z9Mx95h
qEUds9uuQHLpfVRFu8m5s6BdJSH/D/CV1GtwYtmGcl9zRZ2kYXe0Uf6vdC4DWhh4n7woogUu0gOe
B2H7hQZWGDn25CroYeuZQOJvqw9F4x7VsBIdWpCbtYgz4XO5KNt7oEooocRDNrZjfGaB+F1MO7Gz
UfgNyGDkw5yJpm1je+QoJN2EmzE9fqBInUhDuqTPd/h0cP0WjdsMoIn2JLM/+kEwufyWZDoRkq0X
nN324xldBXolWA2fVBAryXUh6TbomkMHVRRgS//tjoMV6m2jMnczrnr3SKQlo6SUgn5raYFNxa3g
tihrSW1gvM9794KXbOHQPs1ulHqSM2JaefK8BQpcT/ZvxPodTrFUGHwOSUiXTVJMgQsohpk6yjR8
cQptkPNtykyzyBd7g7nLRWkUDxQqIjC2Y4F1m3ksIITdZEYgCe2FPEX73bbRcNf6FXnNag+LDizI
njavjTK1DuSrAvgAeZsFPx8Ph2h1+PBIu30LqXl2hvZ92WikKKQhkR0M5VhykN+iCB5sJBELqT7c
/8sY3OevX2RJedl+iqWoD4lZlUHJJ5L2sq8zgTWk8tgWQzkg6FVFJ+9eu/gjFcmYi9r/H92eFVTp
E3Om6pZw6Wz8b484Ta6KkL1+oSs1JRkEzhrJDNdhdsgD1SY6jg93OPYoka18fZNdkF0t6E+MFiDl
aqXaMcvBUkPttsLOMwXAUPNocwpcTVczWNY5ltc/xeqr7S+yv/wJKHcRsOT2inuXrnH+CjpJL5XI
y1YX3S4nKihWyxJarUn4Q/XRJw+IcH9rC5aj0FS8WfmMGxSHLuGh9085UuG6H6Yp+B8NQ3lIdMDp
YkF9pU55vaswX+zTfVy+djqs02gjnRa364+78XYQsqLV6OiomhO8UQbPsVdj0OEdfn6pkEvwAAx9
x4t9hatYOrIeoOIysnsNX6NhU1+OHWHKookJiLsZhMIiYOmNf2x+5/7BE2OEbkB6129FoDCjLZs/
CpiOaWpmipTyMXmstD962VBjX46kRm70sWgsOKEciQ65U31JndX5u+gz+GW/GKLOHob3EeSIwSBQ
5wqZstGXMjaKXebI6cqjpJ8r9Dk+wkI0HWZauxHsXilNZeIn+MpkoQU0/yLs0uxGDhKuvR5hwNE4
lmqRvNYuoVrQWXaOA9dvVMT0xCrN/mRkQP/mOjQ5vGi3xBaRQrY1K6VRiIa9G4w8mOK76iDtczo+
USOBo8D0UxYoBy99BFn2gxDk07guiXM33szDAjbJ97HE6d2RffgHOG1vzkjqpWDgKLws0ser3FJO
Eke5902paw2EvtV/acNddpHLHvGVTFdaLxbr/f/6xv3GMHzntnYuBx0Iv5QdKLC4eapK3UfnRvIb
jnl5+c2IYImwX4JX8MKvNz/bviX6cDv5hQ9Fo8HjH2mtgxZ8onThRS0FwdtygX4s8Fu/tMbq5Apm
LqU6LdcA7+KUVXi1C53/Td6ZsIViNKMT/8PlyE4G32zl8TxuAi9HWt8ib/jIWmunhX/CmCGIZ439
fFdmGZ7thi/SlH3WNAqnk0cS3ZTF9ZqwTGH6w+wy2YYzExwHotD5Yg3AM9XlHIWKXVhvaUqqM8K4
Mj/d7ZCwU0KDnUclmyIjagYuSyN/8nqSdeqdyerqU4j9EqjN8Z5JCr1cfKj+NrZo8zAftnHcr9cD
55G7pwb6mQpuhXXFGSBwLMUA3hDEtr8UYndBQ8KzpYfiyAX4bbmgYDn/SSkOkSxMlzewGgWsvHN6
f1ewvw7/29EzRouSLwNO4rtiD8Jwh68PzfGv+byc4KuFABWWZjqc0ZrjoJAms/lRXac26g60juKn
ZyHnVt6TLv7o5YqdRrXwni1BJ+hW2wdLsu998C4zFjw9RXyFkXXG4RRe+TgU5uMSR/2qPIj67Ce9
4AK5iDYbVFz8RgP3EOszWrKu4jZjgDAUs0DHhE+IQJivRw4LHRSQ0ago9PngRnMwSPWCdS1yC83a
owdutbInOzdlwl87/5Kd6Kyd/uHERTA8xL1/uSA/IPgKwzAnQv4MM7vlFkOYVA0p6/JM7fVECB0q
5a7NmTiZEWWbObAXbCPYtGeb+q8PiRY9rcEz0iWd1x4EjpYop/OQSLlQp+yCAoIczk47uIP4G7Eu
piI9JXKjmaNWH2xoqwEDoop7iVSfVuBm2U1RU0Ouh+Uxrq+JlQi66UIu7f9Z6N3YbSBHITdmtEto
1r4pWl/zx1MU5Oi2qyeOWPYfYoZUwKaqEmjsl6xX/F/D319a6twxpqgM+HPW+g4IGky+Xse1jPRz
lc2Vt1yREzbmnO8kb9GN/DGtDnU7PCOumMSquA8kHh583kLVxf8AqLfIoBbInsd3zemMEft4Rpeg
dS+UboyhcWwks9J1jTT666Nq1tiYtnmO9V/djzquL2r+C6zyDpEsKwJempyr1xPCJr+jsw+WBEop
rnYO+8QbEmEXW0SnfLCB184lRZNAI0ArDowoiimJNYEDWLGXiaSe6gdL8nVOwROaa9ze5FyYq8lW
3fwKvxKW8JXDg2y8KajtE5Z3UC/jwlVjKzSA2+0SQFRUDic23XD/y4N6zDqqdebVaKL0hM4M0VJx
tB7dbT+8bRGG1CrnxoXVYT8/EvwYYtuUOIEPnZjsrsaHCwUO811TmeEzeJ9oFr/FHOJOKzWtTcpV
MnCRPCcvdV8wGh13ETHz0UscRkiu7l/Cr379SXf3kGk6ekaAjcngvoiaka/PeHNZug0UwD+HNJ8t
jMdilm++Qm0RG0T+eBQiAI/naNE94tB8Lraib6cUi1+Pjnn175KmgGsCsDk9glyfBAJ8lXAbJhrK
Tt9bQW5SThVtdqvPjQYIhezeiMcXxLY7QDEaJ0itbNf1+XKL+ZcxGUM9DaPjRZvWOGRPrRHNCcKK
FOdTXsKXWI9fG0/hvDWU6dHVCKwYt7iVJtwgEgwVsX9vdSruqNg8x5vpFzbANbb9Gc1URZtVotwB
LI6hnDsQNSxs+Xa24Al8+2XOc3TLzIMQSC4DrqxPa9Rdm/p8NLYQ6RWQfFxpXNQYDcXWn+TGUx1Q
8MWQeTY7CVV1ku15X35fwX02xgryfxslrnmuH0E8XM5MvI5KzVbNic58lCHVBFXfUFbpAMVGfNA6
oTw5XiXyCDEop7JnQnaIoxHjaIs6CibInxqwkGqFu01D37zq6DHhhUqrkmDVjwdjreAfOSU4301R
SK5t5m/j48c3eGcz36ts/uLUxtawoRtFDuhxiVnVs3Yft8XQJXlucU3lvNiAxUGumDu6dkYGQC4Z
NgWCahVSzroWbP+wUSj7Rol9ZHyZ4ck0/IipxlGb6etQZoSGU1xdsIT+VrGJcCuoqatgnrbOjIb/
r+EZKah/lxGDEH+TECB0VAy+Mn6oYtK30ydE3YyTH0zJRQmT1GuD+/INs4DL1f5maRdciJEpD3iW
o4gFFMZXwohTE5dqMX4N/aXOTnlDFVdxKrYooa23JN5kkuBc5l1e9MK2X0zmysej/2t8McQ1epCz
2JLZgC21nfFOY31Nq8Bi0CDC0I8uUiD3oHLz+yxf9lNVcPRuI9sN+nKHl9NVSVgge4eF/+eCgGrA
YQf8HJ8jwmEd9lp3YgtskEI8pAoO5OSeoTj8XSJT6zSdd4LzZDu+scRO6ONTgOfuImtXTKCaxRkr
lSv+6+cbJFrWio88IVUdrzg9/qoV4OwkIOHG7mNgOtNVfubDMrz+D4PlkQ4aPa9I2r9KdzqIzHv/
DzhFA/y1OBy1YgbsfI4aSQEN5k/nc7qR2VHa6ssQKiNx5dByqzap69NdhQsL+xRlfTUMTgbR7nV5
nZuwGLM0UJSSqNoA6ZupJEer9wsac/6IufXs9w2bRh5iehna50CENLBJkCoFAFQpw0hU9kJRWWoj
yY/R+gp9SjUIkg/voG7LH2vZm+BBK+pKXz48wxNRJiqW8uQpr2dMnfs+pi3nUxmz8MoTQ8f0s4iQ
Rb4BhI+GwLRHpz3ZFW3vj1b7/fa7pDOrsbggyxo+0lQ9ehrLHMZzZj9y4n4+z0/BgbXSVCSaQp/i
Bda05H2h8xVusLWZcKbdf2owxa9sskQD1qApi6qjw+DPPKreYK97NbuTz7ut0YuIj9Lig6ALjEQm
ZQNbDs4Li72/9biwU38s+ajQU8bIKpxqQmvVAjclBdM0Qk0E7/KXQn+GpFQqOCG3MSzL0+nmit9C
Xr5vnb+fVb8RJkcjPQrs5wdmsrGRcQ9gcLIeuNpXdsjN/ObqcmRkWyCwXgpicNIWYpKi6cQpJ7Xg
Mm4jWoimqNA3SYxd+SNkeuLbNVGWSGJkoc5BDuErwRzXIDTJJtDV3/bd3L/QPRlxRyE2U2Sga8TS
lR9OB32cIuhZX9QI+cFg/dQp5KBRPZL72jx9vXi1SR44KjRVScVOqshvLqxLRmoqP9Xl1RvUPLlL
08NVUK+j6GwAvVjVkvTJEyhVjG/M35FUFPTdmR+uyokTyCP66dfAjtPJ+lbsoki6xKturG5p88Y/
VmTcVvE0sfeqA2UazyjKBJRujUiPydmFjbzqMvfRzzlPDAeGKu96crj7p6EJwS+tyyRFkFvNMcKp
Lj7EllEFCHqN7Crevqm1z70Uw9XQUK1tqhPp3mzLV1hfZdmg9IyVEipTTPqR7AVYnXfm3SyCbxja
8RLXJLIqpC1BhPYQbUPNbE2Ai4DEZvrTx1WldnV/9PDdynqeW35QbxAdInW126j8npesK0GdvWJS
ENvIYy2vMbVpW0u+DBbv1ROzEhb2o8NoTheYuxexJiElgNxwQcxhPh+844EhtyzY25BYuEY6Vrvy
tqnV/+ctdVODIX/slCI7lmjZCs6P/7eO1tbVlWpx2jRmdScIPm8aXhHcXRBXCwjFjhaVTa28aEfN
kmiVMJxCTExxuGcG1Nde/TYntukbvKCJjO9BJduiIk6uV7h/3TbgEa4W3/AGmlkODKYVdJNr2cQU
V8uV5n/HSyIL8NCJaMZqTq2Uxr0+INDpQsVjA+VR0GSY6m9HJg2aUY57Z2nOOKkDGF8045iAWaKu
PIrJnR774mZAzQ9IhIt8Z9zh+jKePI2g/rjTO+vZ1jFukl6kExCgGjxfbCXSEmgogVyO6xMtLjHB
85/cNFm2ORejoXc2hcnH/I1l/suaMIGMDvB8jqkSqCXee8Rgc3Wf/wojVMtP1a2GPxBXUJlMf5Mu
VLii/wJv23/Ep4M5sjzikpJjusaLoe7JtgAb7aQuQPTJw+inPsmhr1EG1ao4csvW/OeDr+Mf4lgA
EvUBv+ShApJvb1rI/qavJuExXgGPDgLxYtRGYYoyGtfeAj5nl04Di+URAJSFYosEfkThoun83rBj
6vjuNNMGzmmL0KqhVNW60pDuCkGrGugo5KO+libv5F+fVwtE1Zkb5EAKMBNvvA0EUxSVOL12qMUW
3MV/8cnyqwYQoVjWW4LbcvwkqhDOvgyzMNEpetyvLhrkXdopfxGDkPjoXPiTcYs1r/uexqeZ89wl
CzVk/JifuZ4cRQzUmS5BTdMprDWjqHYyO4K4yNT9QE36SH2HdJHJj+xEHcv0FeXnFxCUU+dzeogE
g7JacjBXvk3LZOeuGsSzRFnALCgRYWQH2mOMaEP3bpY+4jjvMwXdYL3pfs39S6qH2qcviC3iuXnb
3kT6w/QHZU5RVVf6Uz2cbrgBOO3JI9yqBIdhKHPCz0060/7LUIs7IF7JfI2Y6ccpsODCz1eft+iN
6+C3GkjymPE91iqkLcjEqITi/DEVinR3sDwe5WTuy2oJgKlZAf6esawv4lItFtdsQbdQ7Dpx9t/V
mS6w43z5YDIat5OvgmaizxlhQ9R42o/sArq1rx6Fl7keUlrGRcyPTF3GmN52JhKewo/A5LGm3a5j
wWBhI2UBnGNsjdJbPOjaLi+gRdjfnO1rWB6I3Yx4sJLsvuP8TYA1lFLQ+UfOg1RKnVu0zREXt+8V
Aj3KVqD81ZVl4/6K0l1My/c/y0QKq3s5OKh7PYT5QPwMfZCl9aAOp+C+V1ZOOBW4X9DNWE8o8ERz
ysXi2Nk346zzdTYatOgMP69YLi4jLImzCuQglVcyGgVNQBRS90KenGGESCQ/3XhAJ/VF3PzzL+YF
7EUU5Rh0bc50b5H+kcT/iCipMPOFd+dCLY8Cxjllj5HG2+G9c1jlFHMWmjn9qTufkifVY4CKkAs0
SWGdVfJgWHsWRX6EyQRyxQRjwN5oq5FcHl/USrGHsGRlmpO4Gqw4aK9WYnfj1pRbH2wB3RcTmPRB
zmOUE/Wdg0/oDReleoou0F5Has9kZv9MN0ITRnWC+jod+ARyKOykFmWTzYsGi6kI5IjyJk0W6bma
hmDXlzyPKZ5AsAFqySG7jttFVLzc2CrTADmQgQJJiAjgzuFlYrQjSSAxKV/v5KT9pLsZoi/oU/zt
XrgqgSqd71iUITQKV0P6vX4numcPFfWAh7CJM8GfYYz+65JCiu2ysV2ZLagSvigI8RQQMoCxMmvO
tysj3Br7T/bJ7Pdr82iqHKK229hXkm/eKwE+SNt/ZGekkkavajalt7JjL8JWK9ZrTL1gPOYnA5ow
V7Kh9tF3zTVWfGxZxfpuaXf76INgIS+7TE6baoKMuvKBfgadn+ByIbDIBv89xMAdtifg2eDKodhU
MXu42Wxf2wpqegDefOdfFlDgd4ltTkssnd9FBJdWuWRmOpzZJw7h9XFUg6YeGC9dtmsheBhWu5Ex
1nNS7r7CkwxWInls6UJttxscXgoLHY3/KRLimgQyV1iqSgbHfjf6efd75OZF7+8ImRyW4jwDqC/t
ExEOSciep/PovP0TuBIJVMZB8DhSWvRR+hLIFoXa/h8LAhzSSOsPzgn7ocXbfnFRmzGaxWYKcFsE
DF/oMwjGFTNcxjlywWm6RF4vjXhDA30ogElbnQIJPEE2GKtkLrOJkMk7aXnOk6CrEd3I1WlPRtk4
YrRevL5Acy3a2oUzzVWo6dizIscRBl7eFkcJ7363gZ3vvFRZ7ublfHZWo7SKdM3QwjZZlRUrCoil
6ncGZP7X1zzHUBBkBwJxuCJy3fg8LkXcWr2CeYeO/PkZ64KAThRVgAveBLWIv9U5kz9oFsqO8HMl
c07KRj6CxWhN6kHHtpVdBOhl2QEfQpzSWHxH71vp8Vmq2mlx5evZa2BTrSNpw29olc9M9ZE3mRlp
7KVaDK8/ge1yQfKDXW/LGNk1sUm9W7ouX+YggYDXRkp/n4WZltGcr0hHM/DvCF7mCO9Tftpd67CX
rnn00vMCnLgFqjvGkVeIK0hzA27bxxy9Zcyvy2vhdVT7RL/5r7HEWGfLD2qW2EviG3XrBMJYBUsK
OVZ/8eZPa93yG/L/XUZc+z6U0Qfew3tgz1JwWKagaClIspsnTqIa2IWYthdOf0MLNUAzx/3WunRs
vEt9AIpT6wnJ0UYdd9ttiWDVRJ8te0pPIXW3D8L61T76sOAvetN+0dWE+rC1mr3ghgVwu9hX8Z0c
r5bpmnuJzGyX4EztVEn2XIOglShwX433u9K7vzTemRc7Jcx9U6sdv+wHf6KEXKz0Iu/VCrrSnzUM
0GEsM3d/IcNtFLuoLxTLhAoznplvyIMlohP4ajz+oTi0JPBq3IKt6b0fkNZZblnRflSPWnziedTy
xPUVMLRDw6qjHy22Jbto5L0QbB3Y8YmHYS/IFqd95tNtICo874OwHrXAOCfqWZgwFQ7W3gk+mk4N
g2fGFQ0aKRL65wnfrS+Un3yA+7WQUdX1RwvhlvNdtEVmM+Zdwomi3B208KtS/ixknNwivYOlnrFP
DuE2oQKeDBK0vMc5AKYLPS7MfyGqcAabhL+280n9zoqxLyjLIX3mZuo1qGqsWRES0EXZkjmGkx52
P9QB7xcjvZ/m2wkJ8ca6n2tfRtHfaxh3Esq5A+9Zqg7v5F+kYEW+tyhjfWv6US11B2ccplskEOvw
XV0YoYqxqbeM3rb6/cc4I2C2lzeXDXwcV5/HVAbAL10YaOPj+/T8QJxPgDBYpTc34FYN76OxFfGm
cg9Ogu6cRd6pv0AtDI606hfPtpdDjGWj4MxZ5DLhLEZIbo52DVMK+4n1I5lcV2JsVqQc5bK4YIBd
CIrf70rPI5nlx2ZcWAr/c8AeYhJXFI+ydY7aZVAu7GjbXwRaluBDc3Ha7+pHoVQSs/uaWthbRTXc
LSO6CaaJZyiJprs0z0JR5gHw0ASM9QVtjwi/1c5gNx9XC/GzWalb6oBzb29qT24Vai4iERppP+Ks
vPCV04OD+g0BvrD6R0rFTfGg3eqZFhpaO0eu8h+NfPDybnsNVJ0Ix7Ofzvr7N4cAmsQA0aS7SgRf
I9qx+MlXqRW0+E7z5fRhL3fpm1FV3k2BIhx+Vwl8YwNxFYOTcgABjhqu/Uk7w6IZx9WSBpBQNGKr
SwVsdYzRxDZeiJfRri3NZB26y9sav4nnLNmQ5rZgYkdJE+8S3MPzirKF7q9NhgpafnJavwn4x7w1
coQNVT/xpfq8iKtMCeSIrsT9SqHaRbOW2EMbNKdKEcZ6aQZO/Rv+b1A+Y2EJ8T/Y/Ec0qBN2yUT7
d4BnCSyi+nKWxay4hjiZ4O/O3zvYVDGEaaitLzgDUWK4NNt29dZ/5CkH84CN/LB2LiXjJPTLDT+J
NdYB5BJvmmUX3onkkzrYmO0x0r3Jamv+24Okqi/qQcVfsb9ohgDMdEPeiEPfZDeUsuKgJrrySvV9
jvtktmJs60L/o6zyZe2tDmMsKiMAIW5TnAqM5oLELa8Sn0mzwLTQB6kO4PkcaYcjz2I3VHZ///6K
X8fR4SoOgVKsDdqm2WubTK5+1dl6Giq0eVZWZBh0maXkSWGW8HqL6skfd5Fol835JuuaykRIry5M
YA6Qo6EzYEy1a7GfpNDTW3Ci6gm5nDQm43FYsIxIZCRMCD/Ip+OLCaav87AkgqRPIUyKZL+jd9fv
LIVvsnVQFYrl6GEDNEQPBHRxUpuecpBKmEeo1hSHNWkDY+ZkOfBdsFwVED+BGboZc8MArqkMYXuM
UHd3nqbCcj0/R7m0xAABBE6plfrwE1xFdPwfyECKzrvxd4syUDlZVIhrW7rIDvcTc+yA/2vANZcZ
kVOucB3FjeAAG2pRHdfuMBS8YZfWXdiYroX/wTD/1Qg1IKYiNMuCe49sTFg8dPml2Rbqw7s1ZwPg
KJQz/EpPbh0H1lVVzRVlH0CN2xFKrrWbTA1HIi8T/YpQrpxPIS9ZNMml1kBo+oHhSEYD1W5RbUOT
MtVjkUR5tzpaEQ7mITAZj7bXEGhjWWTgWeO1AsmSqCYyTsE0SlMIsZvZxEpCNpilKaa3rEIRsVCK
jcKdklCGdxJOByOwBb/JWreoKCgnHKDHqeCLCgpAiyWfBXH4kNBpDhMs+rp2dBo+c5jpjtXrx1gN
NYzYP4iHCnwNtGAr+rLmgJuj4V9hGDaU8jWKabHkExgUU1dYf9cCbVEtNgiQ66LLBp51OOoV3w5L
wpeX1cJlhhU0J9XTIjqX5TQa8z2BzI3b+LO1SBCYeTcrm7T2+CXzQ52whufGJodzuRYQ7rxm9Bcl
qmYMA1Y4XqwZNSqr9NVDvR0RmlljTuhxJeZ9owcOKqCC7uNh+XsQagF/rFkNsrtqhW11WoKq4jdX
sziuxPAadg23qVM3Gbw3pcN/L433mWqUlXbF8bbY1n/3e3Ii3293epS/HfMd5QIOiEpezFXYWhS5
wkTtdEpW8bRo3brlsaUGVudOmmFfNdbD57CKIqTBRUbkh149STOQlRULJM8mBrK/se4XT4q26bek
HN9aqD7dlHP6wjyGdco6LYuhefg+/pXM3yFEYFVV1xyzjOQSh+CrzBjf+mStLtAgmMK77AdhNCKH
CUy9z7Mzd0vXOGRWUGSxV458q8xMv2nPpZB8XEZejAloOQ4pug4Ak4Zebg00aCy+aRBKvPgzGU+k
ZMh7EI4nxsiAG556tDBKbvb2FRhK98eTKeLXz0rPUKAG3vj39F9qHHEaaEF5LXSNeRCFflROMPwV
o/WPZ1PmBfeUayxr79Ria+mCvftSU1qLHskHWD50gClPOncU/W89s2R4xeA4LQFUkvD75mMEpW2O
Vzh0Ov7LhOsbjHRkxeksAe5hDaCqbtQj0ci8hTeNEZJ5ADxqNxgaJThm+iNcyd5bqDL19+YreteK
aQSvV9MziHUqiZBxlfYCcjiObC2fT6pxy9eaap6OA1Ffrvq/sF/bnTVrBjB/Bs+QvBgysAn0k9JJ
fjoozKq8k5TscZx01u096JwJ9QB2ok34fae4+c9Gm7d1+BMeEjCKou+aji7cXCrk8Hvj+qIO2YXk
o3bWvh+wpEh+eCGsozqV3VflXemYV2oCDSXa6HxlXM+flYi1nv6+R7NtPpuk4SlfnX4DubkKuEdf
qTVbgz9Bk4vlzx6mtsHC=
HR+cPm0PLVmUjQtpaDd0tp9i4vIIsugHpKDWxy2YKyB7rhPqFNhXelupNkXJbi2WCSgPea8AXcUa
LrO4ug+iKOncb0bSRqr7Ye0tMn85nwagCVzlxM10lPN9PZvZvahpWoMfJJ0OiZshdUicbPBtcCzG
xFjAfaORvmg5bSTe0dvF+GHlcp8ZU+gyvcml9iP4NjW8dMDevW9YXFiYBvOnQp7V8xtT06EZtCtV
IN4fmyfujkf4dd0GUkP9zDt44WZlgomsfE836v6fABAbeSozdqGjpEXARYUTvnidttQl6fQGbr7M
5fdAVTN3s1GJ6Urrhi1zUJXCPgZo/SBMTS1s/vvse5Uleq+ZXcGvQt0ALOKz6/xtbDoxE9OVTx49
30VD1DVNtr1CC5ZcuKke1J1muhzCSGnxlbe/Uoc7/LctPtVHzDBK7++DyqHg8SoxuadOozLCiJ3Y
5mV9FgK5rwuu9XVhLIej6XaXMKg7Cu/DsFbAyFKF+H317PpLXYeqOjiJwCM+jdqmvbvUx9nHq+0I
5v2wHtupom/REVuYSUbrFpPHKKhkA+0qo0y0oaFx7mzo/okRYGpRLHmT4zJFLlvgCheBxln8ddjm
S5BcywBhnIAvUrgx6egsR6Xcmp6F0fEp0Ho7eu58SowRSPEpsIUP9zY9NWAZdsUKTe16BPwk+Yt/
lIUviEkuxvtzrxYwbeZuUTHmj08W/rw2w+Gjlsd33A2G6Pz/cU28keSW6vQ4g8mqwPn1fp5euoKK
Sa1ylebWl67XvcIhStLOIFvSr6vKx9L+lXUVXTeVtOP5ta8IQvXY4meCkclJKwHsr1NTgdmirRWe
yRXyc0xhuqbcgaySBSrxI8kl2D6CRaHIJn5WEDugRdoB7JkZsBbeMiMF12lI9NRjqyaA0DrsP4aN
//Jeri8bghG9Bbt529DsmKB/L5BFBHvPt97ifHIpYJLLpFH2U5NwGy1LdKvo12gxXFW4BsJGAYYi
19O2sOA5DIfyP36/DrQec8XJRu4z4Pv1WIf6Qt6wLwZyZlNf8kI9iRsRqlFAB6qNO7ltjbGacVOm
xO5hrA1xh8da/hpEx8KuLVb/TEkj5VMnQPDrl+ubaIGto671tgLfs6r9LHJzfStIU6EwhJN1fsPQ
dGeHqARzVRHUjfECdQIQosQJZj+QErkEUZMRVOjkR8smBD0Y3B3vLUihou0kFtacMwP4WwtX2Zag
2jq7DWbgHEIrCIkWAFtn63xOiwaQFv52QthqV3s+BvozmQAUI+PqXkjkzm4xBkaoBfAlJav11apj
kvzBAOOdjfQ6aHpteruEWlCS7j9LrLRjav+fekJq8fqnqXYNf9UOoBHSaGd4O+BHvGJ92puY+CtJ
64vpleEw60arC1qb8TcIYU2ttFHybzWJXiHKWftZ274Qsmf3ELGWMAZCjmaxv28Usp1/DD2TLjHJ
UkElmqVqLp0tMMQ4HvnF1nwRMxc+gdeIPAqg7CGCXGH9BCgvlgD2UtNBHEpW74T6osfq4BaipUSr
V9aBmGXdt1o/rmMYjiHmW8dBavlb1UbvQEK7COOAZizTYSG1uagHuOCPIRvPZnlTlv0idmKjtCKc
+U3IfjOOizMRABE6e7/wJoGpFiOKDvAJkd50Jy5gV1Ylm3YdiYGCneGosjqRYgoHZtIvwezwin8k
7JFzKBxjaLcB0cqnbASAtXd4OSCN7vbBHxYCOR+NUKEhS6t/oPRgXdOiDwPL0NN0tTgBgY1svFTl
YVjEmtVS6AqxvqTm6lE9eG+8nqo1qvM7PZeSGbnhNAtvuvvCSp49hBpVbCucK7BOhOAL/c8dLHdC
OcXPgETpctZD0fp73LnnCuTJ+DDZks56IeBF9fBaHRIGiXtIYtXXg4EYMDjvEeoLMtz2P0jEQBt3
4TwIIW+B5zA83k7H/1o1DOT8br4KhW3Se0+RRhUNuXhOnPrvyJF28ShM5SVK84CBsbFq3F0+PuNv
/QXfGFj6eocpkSvZugQISMi5lUHXJQN4O4Wpu+qPxP3JTWkJNmROTq6anuRy0io+0qfTjWeVXkHN
uYMgtuVq4nlJRVfB9FepevDAX/CzDYfTHXN8j8WAuQqrDoMJ6386QNiYEm7OahzkScxkCghx7LQo
xIymI1oWswi6b0pJyPHJ+G9vLv5YN39Q6XYYgb5G9XXXP6u9cryh40k7joqsBnJXLkjOBdbYkeV+
xK9lmUPNYQKS74AoEkxJwjoZZjzHAm1PzhmbAy2yNhSzXdHW7x1NuWbPjoKOwof0UeutMMHFAZEW
n3L6kjq5KAqY0DQzwo2EDot7FSIwhP8b+dzUzKSF1vLKtjlUAe5XxixZnX3dwzoh/BRpUGPqlPzc
TaSuDspxyPM77VFdz3ULPFAZcf7AGZ7D7Wj85+x+So/fgrDs3zIQcQjE10+hS28I/qoz/9VPGy87
O7sqkMP47rodzyoD8e7UdOUJG61aEa2ZUMJXEYnhoWEmBS5oAfqjRusav+YZlUiKQncKhDzdJV9o
h1lAIPzpgpg5+TM9pSQZSaNk/XS0xzv2IM4R86iCvAQInKWjCkuDzuWI2NfhHEViFlZWjfbOqxOx
rOY+5Zem1h23vAp6c01cVMX5AmPQFW/R3uNSO/BxQGBQ6YlQPR8t33tWUlaCBrRWRZr2OLiMnL6c
UcsVl9Mceyo8dOmn5R+ry2CsMEQgk6iA46fmlM4sPDBQydNqNTNsyZt6s/uXNWM9agn3lusZqNaM
NgTjlfMa7zTz+cFjYrwQHl+c/qIc4WgTpf2DXgicGBS/NsRpnG+yVqVi+adJ8J1kso3YL6EH0mJq
GNaaYwirQL2abkUkdA/vsRLbnp3Hu7jCWFralqv//XYObDtoPfwecOooE+4QHVreI0CV7eLcLJ3D
Q34mIMqKwmbz8p6mjGD3gVgSu6aMMPaWuHNLGdUTVoZPw3f9FGEJ/qKF/7kfI8vvUROP4uC7g9yO
c3a/oWkTJGyGiSunmQ5YBOG0BIjcmRWd/ymVAdHxm2AgvGDurTDyRcIcxUeLj61ohinJXfnmeOxH
CKVvnZ7SZVjKBCcoP9uBnUhhRMQECQx0kcfV7FtXe0wPU+aDLohZvcu2khqwcUovhQIyHSOq7vUT
x5yQm/BN6L7azrm5Q8udT5a4GfpMKBLRNAWQ0lAnyJO9E7tNw+FjcT+LY8T6+R0uBSRKkwFQ9x6W
tuiZZZvu0yQ9k7KbxpwHXDYoBAli2Gu10NKN0wWnnkIObwDRfkfgjBtHU/N9XCzz51L/hz1zXanj
mifR4bF7Q6eImds/BmT1ktYYRhyq7yKtdoU4VGm7VHAeM9HNds9EPpWQqT82y1t2VZD0G9WOvcKi
EIxVCsPfLxzc1/zxvVIH+lqrAlSMLXgTRYIQZT0ReQbIKwSpZiNQ5KGv0RkQ3Ys+i+xHTtoLgtQ0
DqSDZTCHxrulXez9490hkPd+rIUKU3AdyvisJM4xDuugKmMiFhF1KG+9ZNiDA8s+59TjVrW9IIAH
98xCncc2d2Ap2dQqpwsxDaKDjEbZu1ZIKrlSawgRf6d7yJaRGqqNyf9dLPLsEvyGcAMyKdM7u4D5
HD3as5sMqlksHnIHaPapOem9iB2Nk1x5gp8LQzgZmfSI8ORaxIXXBgtBmMDRPTe/J+Dli+Wchtri
RhLAfeUtVB3EDjA+oYpLIeb/gT0QmGSFmgBCSPp29eRTcKjle+VaeijhbHTkoNtvGS921l7fWzTa
wdiZhBPPFwSYuYYBLI2I+jP43fmU+GKE7RuqXRLRr5yYH3usB3lDHIA2CwmLxzvsfVTrGkdi/SgP
QS/2eqF/ktk8GDsqgmLumnEXQAfNVm8/Eg2SkeGUiCBQNtzwARCmUq5zRMdBZbGT+YbywUMNu55P
vPTB09RBncDdS2p3EKRX7LVppdcF7hgYl59x6w0K5lpNKOCFnFcFGJESwk8OFow4md3dKfaGlSwm
/7tkE9hxR/odpWQu7NP1CEsWTFS9csYk2ETy7abmQjW7H/7big8JRbdl/KPLou+2shfmtomdymGj
yRgkNcXnGGGwf+gE6AMcSaut1BXizCy4QUCJuMl62us8QjBGY7e45T75JRHL0Pkbaueb0MEfUua4
5857Its8+JK+E2WIbcjzyPTVVbpGmxNX5E4/d/D9oDzkFxhpNo502P01vJQzejgrz7C/bcg/t5ik
h+gOBVTgQw5CdfjZlB+uubl48VhPqRbLDw3VH417uqgkBAdwGaiC9rQOgSPa3/YACnC//m4SkON1
QqTzxoPqYgByFzd8c7sAZEZRBPtfW+j+OffyPc+viuYwrKflx3eHIHcv11tSjEqh+LFRqSpSMInH
HGck7AYdlb6fX6wFaQ0FBtVx9D0g2wjNQtKNJSUMkJZs5GNYbKqdoef+ZVKc/55OXMgVIo14AQtC
eRtBjlOhbuKGRgRaBIiquetn0dLkjb6MOhRzun+dpJI+A/M/fhNt0Rr+ZVdedD01YLL50ecKrFi1
eu1udFLzq9CwN7o0FW8TBgsWxtcai9fiHB/ccGHXpUxsuOoEdqt5x4nNEGNMVN1NX5g5ohCm+vVZ
os+eZSnU74E6l60E7zDChu/q0UNQHW22pkcj5+oquaeh3C/WDaHJ2ISc1kmqch21i4AXUwv+lZiP
rqEo2OnSBu9+11HQiQI/mnlRo/okAFWVQ5QhFpDeraRMtxRiCNmLp9dkrn4vTiSU6ces7Vz1VFMY
48DhRFpYwIhwt1vvTmionmOpt4/TVm6/zBwxQSlYtXlVQVYsB7tVeI0+UoV4vI+l5OVg+EhMEZuV
KFp6fFTevkE8bNQNcPC8NVBhjkqM7E1yTt03TZeaBnnGQ/qap6W/UaLR/wcCDP/xqSAT2wa3nGHC
8f4fDZzh3ifULfN9dLGZ6nB/mEtSptphPHGNkdAe+y7Y5S3PHnZFqrJflpMVOiVmcq8uucmuhUIF
aWwFy+6pd4C0ld7j2/NjmuAyxpUSnoGefXG1SwkJzwtLoVz4T4fu94f5HXueZHnrr0XfFernRCjZ
vcnoLw9JHvcp4yt9AdCRzFAn6vTtjO2MD72katetTHjMTzUdajdz0qwqFK5jHyySFWArEawxlluE
Fvo7WlCrbcMfX+XawcWDCIVwFchyiEIN8gYviZ0DjEm9k7vmm4dZXl+mZ9fCRWTelgJ7UX7rBhM7
vJP2Rqmb+bPnYREppXPTgmdr2cnqKfmhI8oTW4uFVXAUksiakdhrmrzGvJJlX/V1HAfIcC4YZ5nY
0FLEa4/XxFRJQ+HIKBGJUgaMzF6bse2fh1Sg5fVU0FZdDPoCxWMapVHK7tlRPYeIeniIbaKCeLjN
ToecLlIG8LNkCqo9/ZDUl4vxnXGekqGxDhyYyIb++6c5A+M819ea06Jw1ITRGTD+uWV3L+G9cDgp
hatNz/u8YxSZRSo1y02qIMVcbmFLz8psG1EkoGi/HuCITVl+XzGx1HTp3GZVkcSACUxTZk9DuxnQ
25tfWna5suhT5Yr6Z8iQfj1f13bR7qvrTXN+mDxhHQI/rVj+MuVk4EAXUqBQPqbWIRSAxscAlJDE
U9Uv6e3QjZhxr3rsrpLMqsT5zmzTiUK+vPptPiJE4ZiaX+NhTx8Pm1JmwTLUzDvH+6u9c+6qGP1r
VIAVriEbXxDwjVDKaGDnPjr3eXYOCqm5WNpSu/jQmfhpgbenhlv+kNG5B1QtC4j045ij6/cuvL/j
E//K8Lb753HJnlXTB94U9KewrL/wgFw3QddT0jGGOkIXsY6kPKZQGyCw7+aHM71l0nWbGDwMhk9j
EPHw/lYtbPcGhhLK040cIYJANufcqLRRieVZWprX3Q0SrfPkpmb+TmclL41ySYODA63Uk46o/eIl
b2C/NP5tmsz7iI/36OsQk7CqPrHq7KEOFxWZ179cjpJ9ydTJPYolJsW2KPVBlmzRxHfYb2DfUL0b
dQCBEwJwMZIH0H5hSisM0CKhGotHon4SeQAvyi2Pc9zPboG4uwcsL0pP6GgdIuswnuIaT+3d4TGf
J0sIlq3hqpNkhxcI44EyYmYQ2tH1wQUnKInL2cmU5KkFTqdyvlVJ8SlcL1sK09e69NKv+SuTPUK1
fnqOjo+9JWrdPTyIOR9gH+ApzIoYqfsoi7VLNaBNtWLWbFPjZBRMu9ju+P1hozk1bu7e1XsyFefr
5NgKICXhZujMaEahjhQHIEgoYtjXjA3iIZsDWH1kDXaOb1d6yUYDuVVx29ddY7ij+SXtTDrqTnpo
xv7+NMkd1/qMDWYMDvgA9yhYWf3oQ4BtiA1AxE2qJ2smpNYvwZ8+41ldVKDZYjsnuAt9Gs1I/YBt
sr62P9SNzzpWEGhpeEKToP+jRnwM94MDSpLJIK06dig3Zr1P4x0ig8U6CNjjoa9SE5NFDHRiJvmm
Sp9qq6X/qtUD2QDb/fhSNR3Lygl6OFO+FcQILpfHRnApxEfWVx0/jFiHI2/9p84BAA+zOtAnRB0d
3CdfQKOlJsvQrLz13Ey/uAwWfE4/Tm/9usI5FOlV+5+sojZ289YRmXIXTZq0DedDoxQOpyGrZqDe
Z4Y8FIEpVQZAWTFIO8YSYoi7Yc+Ccp8jgekdUWGHBUSuMl/Q3tokAYR3fLG9wqqClkhDvweSwJhC
3dDx//+lCnYxFMmDkX8NVfz+T5qshG1meetNYSMJj1rwuiEG+z7GSAjFTgNVsKupsG5Wuw0nvpCu
dvG7Mr/Om/Z+paETywFlziZjYfSEV2uzg8s0RkY7lAnIikIeLCvYagmpG1JsTwIy7BeuG3l+8Vrj
6W1poaJ7IEmqqTv0spacOYclHN+m1XoFQPbJ5sr/LTLHs88cORQt6gst+ISDk8StWihet2XEMOEi
8WMt2l0zQYX5tj/amq2FSfPbtZDAwtQTmsMd935CB18GnBe6SZ4H5ohqOegldFP8NfNdQ1OzLKcX
6h2+OciaFf0KlbBcLhe4ELW1sEZXhSKwZicvJM8ElgdsrBnzBeMGwsbeieCdnEyojDO39jHahcL4
3KkId3ZgQNZo6CoqX6rIm8LUSg6jezDg8v9B9CVHNB0GGwWQ4F8n49TmXMwaFnZ1Do+MFyfAtvSN
+L7jBdBf7pbYj55wZlWelA6KvOiVvFalUquGbcMuurFotEhng2fmgBWskmffN0rkg2PCNKje2Wrm
44Yw7z44o1daJ3QobP7FFxrebD4z1ZhBkH90h7ANTvUNiY6pimAEfhy9+2aA1N398+NiuZvIdB6Q
lMgNtU9GDx4JWs7kIkl9z52wL9w+symHJGMnnandI8UIGvbSUtWYzSDjLmUcvwJCKgjT88HE6c5I
ubDrAH7UyY7jXuL8FozysfXxEznF2XCL24YaVrPEg9HqetzVTflEx/e30OWSg2q3HS3C8BNrWcVP
Km+hRjkJ8wJzq8MsKBE/lCRRlXTw0M3YkZspLco1e1MrDJHxoharhlPa59W1KNVZibr2s1BcUXHJ
cP0Qw8gD2XKqGpw9iVrX1u+PW315RshuS4hwORO0PfeGo6qfdm26HAyer5HeaFIz5JPQAVC8X89Q
iUy601ZPbCMkN8hMhWZIUFm6vQ8XlbN6OMNKeujvmRGALw4wg9BpLl6MWsO9uxcxcR1QSHlHvtTq
a4x2brdaeHqM22K1EVzZMUrtbqFb3vR2fCqxQKvKhKSNsKBwy/aJNSYsvEMpxVZdPsYLJvgqWnb5
Tuq+/TvuVkGhej2MBo/GH4yvwPVdT8FVspENCCyYCxFHwGYbeh0x/OdOlll3uUttHuG1EnEgGnDM
SME6lFeQUpJ7zfqBHTWJ87A4aVSYBvm2v70C1EqH1DxbIgP4VKyFA1gJaoN2NRoRmFn5gKwUUO7p
u+ZQVCm1TkrTJfSx0DgzGh3YES0ifhpRqwtKDuE5LWnm+6MEWKqDLRLjlCjEeog5qLh8u9AVreP6
35M+8lYOPrEUVcippNYcbazkdPqsNHXlWaFO9D8JvTIoDs1i27Bj79rLjwcRPGMKsDkm7m3VfU3x
KCYTGwEuOMehSyo2xzDiXLBhndY19cYIBHbzqV38wHpH1bQz8g8bgs2bzGON2AMbYuMUZ2WOdpdT
juyTeEtOdiHaJzMxcjsLxclantqO1G89wnhxrHelVkp9OZLGkpbkiBAm27bGu9wxLRLgeNUd8Ql7
tqw1b4KliR2XK2Hhys8/Et3XjiQk6FEudavmZc4eojxHsZz0wbI5JPfrym1lfbZraeNrkURXkPKC
H4VUtuft6+zVTv7nybY9M//bVTBcRAnRjHoesVRjvJ81EVpv98SkMSi6eQMf4WylAoyv6Wef41tX
/eMRZXsdo1J1/KzPObRdTMPxTLR1zfp+Xoep3oLnEr8ExStN8M4fG09L2vyXBYXc6HsiMzd7JxI+
hv5lu+i30u09b6ImyC9qHOrqBL0gXXx/WqI9cycq3N7bt8td9XRHGS8E5qyOnjoCWPgwqMOolrw0
xO1BJa+FqESVeMcjpFceB2VbqJG8SicEigFYXWbn5PK7bNJIChLBcLw8A+vuMj5ZJF5eOf6bE0rS
PkZYf4M6EU88pjrdc0j0AlXB9Sc8crTzlRbH+ThINAyZzUklHV1q3AKBwfSVPJhBb77Kz1ylfakA
P81UM3H6rQLDeoe7n4kW68HKNOhApzUMiJWVKaoiba9+0OXzI1/vhKvwzbNNLLSGZ6ZxBFES2P6Q
UZSw9NxzXGSWbDZH9x5ZNwVlHeRqqUpBEVFN2q8RjZfSdO1cffhGx8OvNUtHIKXReT5OaQ60etY0
ckvgntEn9e1EsxrECVUqMX0wO1c3QMYOt9N+n3V5xNe77/ERK80sdqTerzVvk99MJFaLmRdtiS33
pAW3gI5b38tHSXNlt770cNDb+An1mG/t/BkffE++0kL5t7jalbSU8GrCtD0h2urt1oN2Ke3x7v2l
rZtjiBA6D24S6SydGUipGc+enZ5KT3HqXIDGhAmg63PPx/3RV7pH8m/2VoHRBcrsV6rmWykj7jCG
AB2iey3Ofnusk7r3X5MCqxOSKiZI+zlX6F4LLr8VD0n/ViOJajyKfTV0K9lYO7tw0+WSZBXcZGiW
KQ+vw2ysBV8BVRXLalkDpAbqFn7UBy8auCfF4NaCOYf+tC5GKWWukbZbedle7LNwUCtpzx6EQznY
dnZptmej7SKzzzwCiEH4QvI6aw3WIu3z1+j+PTXo6xe3eF7sYJG/ovTHB8Qebv+nK83bC2rAjeYf
e5mkpQ6CXNPctwqmQ78g+7XLEOeeiYR+8r5Bvmc5TZHvLR0iyRazPixO8I+Eyio6KASZdIW/K7WQ
sEKrS3qM8u/AzSOmh+JzLJkE8iEPO9nCSabUoLyutNgrdkR1fPTyCFMxDjzgJ+sd8MylbZ8lWx0z
kZRqVl2ljcT25rNIuI24OzWYtD3S0SXAyO7FEFJlPJwI5Auqunq6Q45WQ+IiJAwXZNb0dip1MuMv
1NwgK8WhmKyucwVn3BlABpAgXnDJSTdvXKM/8TnBNW5v+ehsu0Ye6eHP3VcGND/qMPZqYnF1Cn4J
oxNB/6KrQvVb8m3+ihtIk/4TTMy/ReDtZKRen79VJQaXI6C+wK+oIMLuUT+oyAhAjVbyXoGuZKk3
+3YqtCXLAlcgAQ5D4ASkNPaTpRv0am4S0JsXjPQ0bG==