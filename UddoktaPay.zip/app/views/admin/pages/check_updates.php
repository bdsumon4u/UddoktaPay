<?php //ICB0 74:0 81:30f8                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPt/xs6jzSY5C3o1DI36UOfN6LLJNT4nDTEKfLkdOzQnj/WV7JqRbXodvbnFD3aG77mP6U5yW
PivcFWJyGgnyWAraEuMFfV/VY3Ap6xkYJ5bGt3s0UY+9A5CzJDN/UUC+w6LLQaga0337r05Zw89l
GBE3Tf0bqRBlhTZXFhudZpJim5bXMy3gf6nkNz2gBVyGGeS1e9MRwPN6OE3aHUEfqLK2rMQiXJlZ
hqIboFbS7ZITCNKXMnYugfLTpWnT2B8grwpVr+9doxZtHwXRGr0DKqA3XiFHBwUTA0RGv9L3VoUA
3PshPAvLroFVNIDqWsJDb7Lopkrinf7zXUapvydsSO2jlpFqeDGx6Z9pEcLQm4YmwUQAAI6z0ku2
IqqJIvhWtcGQACbAkMR6djQktn7scAGlmLo3JRSs72k/OAQYPULPMmu26BE0S4vKs4uaV8iZTz8u
inURbMro7SuqmDBSDK10IsPuw4EZdxyFCDkpHxYUDx+Pv5O/VSB0wf5m5iVh2Bf92S1YZOqpy0XZ
HjwyDumGixGp72MOUJBYwibeZmjGDT1U+EvSKDku1sMV9PKJsEAX7CRqgnnpZfvs43hiJ13YEiKb
d/oEGlFK9D8NvR3EHBSWCEiwJQ31SN/3BFeBmZIeUPEXLXTTn7bPJuer9CHD/CHll3ejexqauBu9
QXi/TcKzQvonuaJfgV++/YbmqlMRHeu7h3e6lb531G8UP6zB5o8s1TOtCQ4K/RkhnU+yj2+w8gHN
P+Dflt6IM+6pcwiBl+9hvQMIyY2IrPRb7xMkiKy8nayoLhhfCWWBfA2IT8vzsQV4z5vgXMsiV/Ao
im13a9tLZdkdrd5El8Wqfvea6pxyzjwi2bv49aPhh1L497/CGv7o2/8Ow7Okgb11CZTdu35c7Fge
0Ql8+NKwI97h2Sd+cF1LwtYNLRFaazcI8O41d5KnZGOoeZKkheEvUkvm1i83+y31Voai/TAi0h9o
tWG34k/xjXKJzS/kbsXojFMAIiddprR4rhUfPK93JCoJSFzTtLUZ9/uTiuSdD+g6w0qJKAWuCuu6
sYBwTTIPg4Vz/op8xjgdwv3S6AqZoFPEqOskuCv84BZCqc8ecTrw3HHI2SbMceB6TbxPnmoFWiK0
yKK6m19vHrD3kgkajjr1awt43irNk2PmHDCY6GOrC+fhxEMMN+WvMM+aGUmuXDaP6ZfGlpaP2QP+
5s0lGnLF0jM9WFCeJd76vn2FB2rK8eUB1mPL5/MZ9pZYu51kN7Xv7SI5WKpv9IbkuY1nu2MUIrN1
rF+R6b4Xe8z13OZDqP2+UNviPTMjoKLs9aqFZSz0xo3MZ9wgacO7ILXj/nhdOaMhFNfqP2bpfsdo
/2aLWdflN78b6ivFx90RuvFH0uiL0ALjXURhtV6Lbk1WujfBdvRdmtBmIOyV4gmwMediXwNMW3JE
tHFHSndVvOswtR1s/U4tGBkZtDWXUGVRwTGm72l4HTsVH2iFl6OzR/n6Z/m2eEswU1E3MbZisVbg
17lEx+Fmu2WR/E7ubsObzYoThkwKPAu0xmWk5WzC/SocbzGYe0eCJnG7FlZqsvXgVW7OgSkoX73g
W+fTSnm7N6wUNsHK61Yg2Fsjl7ql5LN8cTz01djIKPYWCxrAPoF0egOLdj2OR7kxT/CpAXHakFDL
LRhcZBRHV7pP7xuol72tv+3oIaG3+U5HJJ+Ni4RScRixc+M2zbG1ZIx/pPWOhjwYQn3ADozgWoip
LT8YaEoxmYBu+r3JYHlKjCVhGkkgecLYVo4U+yrD47mmJnKOfQXcSfMyaK3sgxRDXM23KTY6pHsb
ADQMoOiZP3cbJAgIOnKUppxEnc8JXu6GOX3+qT3+dUTq6pjep+sHUPsr9S2u7IP4OE3rwCtm/ImC
ZXnlBODcnlTnzleL78cfJHLPfmoXhRfuPvsvo4dyIcY7ixisYL82yjCKFTKxKZS8v6woqTJe+ObN
k6p/brCWScab8NqLht7P6IcybvO/Wz9gx0i+yHNk/bP06GMj34U4eHK71VGIz2HjsH8gcDAeRrYn
zy7cmnQ6jRe5UT8NKAi8r/pJGo06srWb+Kd7DqfRmfPdrbOSeHDC8/NhT7zN31EXhMb1jOvcnmNH
Tx174VBZSZStQbkThYIrpOh5p2Y31tdGD8XvHra98IR/gcIFAsV/dUxyouvGwRVfvbRSn39pq9Gn
PuYpShZ5hMFAx8kaW+Kw/ldvOE6xyX/hVZj3UzlGKAgb2VJz0x1TqvNP1/XRy12/gScG8zA4tjwi
6gsVIHtDz0qHtFGtu1EGB7KNzwPCWOXVhGQhxcoAwDku4JkMc7S6l+kLOH8xvQK7GJ85lP9VLAS4
3TLK/gdv8YynuXN7zpYq9Ns3TOleFqmM4HjDYikqGnfTrQ0w5qFEvL670kUT8+WK/muBlM+wKavw
ej/wb+eAhuWH8C0pgv7+5jpytnsXZcjhpiR+3Tm81QwAwWXsmGeBjDFMmwk4YgAY2D0V2JrIchGv
f+2KkZsZhQboeNL5hIMjcZDD42IXUuzggilEAhkYtjA+4EySrCQEtKhlyPqMStzgwDrs/CcUjQoP
6iAjPnBniEin8UPbY9hoUToTZF9u21Vh+yzKQnXGXwnYn8FpMbPSpuduMthKtNcOFmSmP6jbbXW+
Muf8hrkQpGUi9sXpWWBWTA306z+3d4Sq4UIBlsV+o199tpZIdtVVKPIfp8KKhXbtGlcaqc6opQXE
cuiYMHBr65cK70G72zkI0yAvEaZ/VjEpWOUmt8NgT6oV9/tPaedF4AlZHa1Q7J84vfbIAbMKDWPA
LuURfWK2QHx+nwhZgYMcDWGlJIxFozwOd8aOvEbtafLxCBwVUPj25ghkHVkmAPrnLGgTCBS+Rl3a
4CQKnLPK++tK9AwmZYx3omzusKEvL02rvsEp1xoIBiwQsYzcV2wINeKEGYShpxGYrhjzcawvV9Uj
496qDyFR0AYFuEMyCtsrq5frOdyZzKHS7f1ba5VqQBwHojk5sBhoNeuKU4SCZ790p/z8Z2ebFtJr
pxzP8psfpxAzeCgjqByaKqvKTlqdgvWxM3yW63BUCoi9QS/9LXyYyRGoCuuPIIYM5V/fLjffLJUa
hFu1msPT5r5oUnvDpK3MtD5fAFT16TohClTZ0GfKZYfNVa/WoQBqzTJQHYbvc5sIqWc2jUoMbS83
OC4pdq08zCqUED4alw8kVxeidK0iCV7VnBY1txu2TXR2wB7GtJqg9p52vwTh6e3XdMPCAV8Pd+CM
oNpG5vKwv0nRGIfUsTJTmbeCKcKTR687zIgzVWD/ZqKuUaV5iKEpMst26+545gaCyhoj/8nt4wMx
+jjyXo3q3K9TYruVPA25N+24yBLMdapa1FKG8rr3EbSi1WrrR4rwwUFZ7WWrqDBCNHkQmBLFQGfQ
0ss1L4U2zx843oIKo6qW7nyjRIGD/sLmA/0LoJ6Z6mEJp3WvUyek9Nzbhc6poFs/cdJZ4nqB/6vh
ay0ZbqLlJ/CGP0KEp3tnOPFQKyYAKkH3O9lbsPRX5Igf9HSXlXw+CAZR4JTRaic2OY4ksZUBrcWu
AYROPKyGaf6P2kT/WN7LIKrGIs0waOnbSjeVlmgzdLifhXm2OiDvlb6ZQIuUOw49PBwrgD4AoXmz
QGbiyFYZbXkYHKEpMhH7BlG/OdMPJ2A8p+mmBywN3/sKx1CWQpNKGB0dMTAyvBw+SQbXy503DNaR
/lrWyNObg6Yo6EEXWQCoX7r4rAYhpW5bxHDzOrFIPZUKnCYWHxcMBIQGmRsJepVzUWO8zQPW4bq4
vxQ6snJPOEEvUhtgGgOCd3QUVFg7Zk2Vmq825TqiPC4j9ISkO8Y7K8Eyie4n96bjQ0LzWCxJTGvt
yUip6jwmlfcXPT0rDfDZRRfwOSlpas0TNrENzmMDkPUDAuXcgeTWTO0RY39B/xg2/qBUdPInl/Ba
YqEw53AJX7lf9icZYgibGL43fpA7ny7sokfLio4cgLGrm++UJKNt4+NR0XqBm/60LrCSciy3VMew
wzx2YHYW5iEfGmlNK4vbhkpgUy86sUaIT35tRLfbkbmIiw5eXQqvn43XvRre8qN5RKg0+9Iq2Xny
aMuastykZ4swXsmWNufNzTuDNIzhRSscZez0JFzhnFjv8jMc8SxG3kjgAD4wVsr+Cp1i20i1S+b/
s76UpjzpJ9MbLo7OIhlo6IOJQ9zHhm6rBQbVo23RHP/gkj7nfZce+a0KVDmx1WSDq8tczHYL8I7e
uxal/QOig6pceCmEIlEyj0scivDLArWG/fh0WSzu4iGWwke6RygcBwQXxDfLuvdFME7Zt4b19SUu
N9P8sAbzOVTo7IfoBTyxSOfU4MKBRCD3V3E12VWiPdmdPPgyeMNYSsED74D0jWu2Q7f29VjexNQ0
y0ZkZ7Xex52qJjAgXnwzABVQFWVVeD4UbkDgxpqYz88H/aqw9uwtdQDKx0vAKllrfnwQhQq/YeuC
DSHbXxrD3otkgo97kGlhEl6DPKIF2nRgCVYt6TqYSl4945MfZ6cxuf4oXO4i3V345RzztBe3Z1b6
oQ748aqHzTSKsIo8a9ynMMl1Joatl/LRNbyRO7yk9vh8x56SxvUglHdRVEibZHGadlV/ai68sIp+
TmYHjGAtWiKHIEPMaw3IC1kTIf4ktap91lRglAdZgYdjMi+pUZgN0MjiGKMFnUCnpFd8EuuvGhyG
F/OhST0Vo8a1k7NpQyNwDEgazw9bhBnBp9w30KTHQvvh3C4a6gl58EGjRYv9gNtXAiqZPax3MXKd
bw1k1WtfeNKYw4Cx3P71HtGbIY1GEipzfIMwFnR5FMPMuiIuuhZZ+rhy3X4z3J3rRtXLfP1ycyqd
jZQTDGX3RMnLqUdSKFiPFjjYo+LqggIjqz9FktOQAWSAQmtdvn38kWFOom+Hz7CTX2SScOtVQHmQ
kI9sHJw652Ee2C+xlgd9kPsnIrbOclqReSDcta9iNClNDFbyi4RzxNyf7CSx06NQNBsQ0JGSlce1
lpgDVnA2HlBTUQxl6FP6Hf9XYpzsamDIBG69gxTJf6HxRZREgMzH9fz2EKaj11z4m+NmyWemASwC
OCMQTdR5XBpK+RoDKC3vQmBYn3q6u/tL7QLHk32HV/D2rrg7zrYlT48VQsAGoqZy1oGbga1Ks5rm
fC79NyaZ2Jh90Q9mqGeCl/r3J0480phe9uGXOKdwsd+j/f9hh64XZdAaMZr9fBZvolt8EE3MVlCx
HSvNy4tviadlYLXTn8BxzLAmOSfk5seGqMIqwnGMTcCszW/uTL11vaE0eliUJ/QDglfZ/0Z7PBFM
InTJZM6N1Q627Z9V+jA7CjzS97TGQAmhJgJV2IEKRTFSnXcAfiohwZQ1tcnfGrjKf8zxpxYaZY64
He2Ci2/wItJfZHnuRFdHp4yOd9ks9FqAcUzFk+MsmJ5my3OtyPKuTildTaCogxKT0yDgZhJaT01O
1f95nRZjpFvZeGKG+YmIzN2MK0G7o7V9UmAjvYdKyRu89XgMCv9fc9hBjPYdBY+KetR/iM4hRTIA
ON9pPk6n0AKdvTznK8Y22HWIYYLpGwRT0+zlvT8597GUBVmENqNW1l+ckwFTtCePXY5El2bXyb3i
TFnhOd1flIWl1fxzaNLFoBsKjuBGuUQbrhwQ/oTcTLCLLgvYoRhkCdhnl/7D1RDYP9guwz+hFRdr
H5/lpF5MKY50OmguhMjSx0BiDY+OYPn6Pirn4PHBgTncIlYEE931rvpsp8IMl9NnwzAalDKGDW+p
xPUnGTeAHbORaI3yZa6uOG2EcbYXl7YygdvHj2VzfE1FlOT3vnBSKm0/jr7Bs0aPpA2SeMQWleoh
NbHGMnh6eDlP7XUNHJR/o++7gaP+YY6+IwEQZHIPGRuksuUzwIibygK+fQM8zhAHxRx8bAG8iTXu
BeIqgwb9ccW5XLhswefyijouuc5YT8mrRbJppttEEH+gBavgG20lTTh1tOkfNcCQljl2sO6TUVxq
X2kXI5WFYTBRKnqisBeT6/fSaUza4bG8UlpfltZf9KiZqasTG2k/0O6O8R5ENtItumIjrxXN7Uw/
94kcwc5LozNZGmegC52OyZU1GYA7Ia5ce9UwlZqYD/ibUvwf5qfLXD54RZkJZRMpsCuhIcpDQf2T
Nno+qNmXodjwN9RMXCL2v+0YJpJs7Ky9/OeCSH2hvrqSRBsTSIqbCuaaB2MneGyPcy9dRLDRKqb9
wrj051sr1Tb6ziBi61fX7aqj3moE8ShHZ588g99oQdKntmDsIJbrMpCa7MJd9+onnNptOXpWGs51
Okuz2bLcib79daPGBGlQBB1FBaPAPkXx53lTjPQHac/SjDXj3mJAhM3iwKP87/SsCRLFiuxMCNjg
dy/2zBLFoJfI6YfZRL+bEzpU1S0RTTZGe2mH7+1hTcKO08lrIzmvz5pUBP8SYRjhThfYlSkleNcf
qsWKGz6/qUrwvkjSepddlf1u2i0w+ZlIT8ZYQZ0vItFtrff+gxJuAn+VmgpE39mt9+aRmMZGI30I
8YpUutUrKjtjK99uMLuXI3Z/MwmX83+WsZZjTbN3LmIXyGYDIqVM3H2ExJsK+qSkMeUX8f+yWVKo
f+P48JflVYMSPNFkwlrFsDhPq8NKHWivZpOPKjraoZimjLxhCL6Zna8M6RJj5kQ1Rj9OlFyqhs1F
EqN9q/IvNPn/ysiRsFaBooi4DUBzRaDB+BHFgx6aCq5xvSvfEER7cqh5+rFCguXQEMn6fq5rHFo5
qkl8iVoSLFyhoShVo6rlrhNcyodzfiFxzulY27enDEG9AanCQPJxMV6YCHNqSUjnLPGllQMjadn6
DZ6SsQank9Fe2WL8+FsKV8V+3/fAqbjtepWTTd1ZQFO7RKRYeEArWK1aEZwDUvmIeKUxG8aaHL44
ERs1tP41KqMmPubsmH/KVkWXhfX87OY3wR0oFPrFZrSJy4Dg2cogKQbMDFX1nmik362EAfICRcFG
7hq6YOazP6IJV//WbAfX520t6NMJC3UqPWw4XjjztHQvodPc5Hx/yCyPQwJ1+VgpGl5fCjWJZHwQ
RvfO7jk603wd3t81BdC5lfTP0lNj+rqWEJYocZfAwQbGgY+HS5lidcJqdWCqdCFn3W96YuWHnOss
RcchkOLhKi+FiPr03JxHd1ftRelSuez+G9bRX2xnQRMr3746HFEbdF55zwcMMbwf5Qmgb740WHlU
4odhuZs9T1LHt8q0S2fVdZ8eUfsj6SpR/ygAQILiUcLRKemBZXhNbtVZUgkjs/PeGR8Rj9tSLtFN
dtJqfl/kWwt/Es9XNK14BnZUP+tzhFjtaTUZ4vp+O8qXHaYQNj3+q7r7QzJLKJMzgJf6JzAi7EIR
aDCDgLNM7/3XHtWNBq1uRbzP319gPWD9+DXQbJ8U8YpkyiW8qC7fwOzyIuMYyXHphmKQpT8TnJOD
123xwfAp178l6Hn5lqN+WlhfT4H1fP/s71YWOV/MQaX+I+Pg6zuG9YJYdiRmG7i08kH4LeBggWiB
klbmFaLoMDsgP+AMOYN8cIdzk5yOrHLY8F9NGBYo0GSKZkQJwChZwYLNBCs6SRZTGO0g72rEc9Ve
0BxLS2de0niA1ROAdZ8IYkrNKFm+aWBlnTKOfYovQcwQh60WBWb1mkduKr8bEwe1SyGJwuSzzOEv
BftbHEX3KotKV8kjgPcryqGIqjJpbE20Q4R3j8XEUf9Gaz8M72hAQr/ub+CGg8F+0o0KnPin0WFR
7SjRKwsOaUCldLwdeCV35IPqN19C1Tsmev2gRZgMJ2eJB3jFudA7ioKQxfGE9o1pZNacPPm8J5yi
stdhxk0ClkbU+owStPACZQUnAGrw0LAZAzVcNfvk3jTBt9XFG3y2VwGsrIDP14Nrqgag/+SOtmMg
Bzl4aJMq74YaoTrDEwHAp6IiFdl2RRVnQbFhSUyaCTzyWDCpULyhLCKQE4SNS9QIW71x+YFYFMSU
KwvWhoVEaXzXhQw7q2FdOgmYhgRxzib9Y4gZLaLJxXz/tO3YwhEMFbPmwlLCmerU+I/nfKJW/nWR
ic4EtaHk/CNPS3H4ilv17NbUD7o70taAwHvPTNHb1BtSzz5LrAuLeYDnjBe8m15GHYRRs9nz75wQ
CQr1N6fh7yD4d+wNr3QCa+dmIeihce/qFHrRuMH/YhFnPgic3kK6cYQTJNBSHALni8i5gDiGwIIh
pDSHVYCZP5+YNGRWtFKlCuS8/BmouNMUeVEvKpEGBPMr1lYMwV6DCD/AXgP8Dsgf7gjkd1oGU7VA
LlDET5rxHVGP9xzKnrCVq/UCP/JznQT1Pqkzy7ANnBunluiN4D208AA/T4hfuriS71bRdK3fMTzt
pKhDbKm/RBnHcYYe67Qx+eJwnL8JwPkQATulW26WFvEXXRZ+6/cxjRRmvvNOH3PVNwF5ThBcV7wE
TFHyZaAVpx8xEXw7hF6ywGBzs/KG7bh5UKu35AIPRK3mRw07EHM29UdgOcsOPRS+SxRH/WtqDhyz
XK9GFZx2ZaJI/lqMPc8lhErryngFO4Z5hdkCaM19Y5FX0nZ7sqUa5HlW2lxOooljZP4FbS9VcyxI
88+To+kMAhoVWJy9VQQEQnwn4q64sIAgyalW0meS/HHUOnxgXv9z0QkTgMS8zfS71A9UdEzu/qul
GFOMTvxQt0CG8nCCcmKhmEF5mVL/dmDkeDeGt3PckOqchUjdU8OPcs/FPcyxs7MKBujTyGgtJYJ2
PAX4RKmeQDxSdNb+ft4riiCCxrpRjBqkGS2oLwp7dQhulLXmaWPbYkWLrNxiaNWVffa0bBIdOW7o
yocwi2EbGFV7+PeN428vl77i+C+od7U2toXpDSCkUHbDRKutjgbQQQTEh3fb1zS3dO3jkymMtP6H
QVtWKOaYWsEh6+7NRt3ofeSwVivyEece2jCPLMsfUCrxrafT/DeqTSVK5mIZA3xWWuyLdpDAlAtG
s2QDQRuVzkXW7eg++5foSD5sMIKeyXe/4Iff8pABSagI45Zc7i4Mg8PUL00rbUHTSWz9oGCJvTrI
XI3/T8J6be8cdH8sZKGO14Iix7/8A/Cmexwmho0AW57FoY5xFfUJjxYf0jDGeibN3u7Gqnvde6mx
9H1AT5US+NJWZwp+IGSn7bFCirtPSwe==
HR+cPxmz4fg6bURTAFY7kHWB/bpv58jQbqrIBCvl/xJpm/HDMJUYveiig/4BSa7OR5cHlikEuSRI
yKOYSmmKeepWsRbXGYauhVlb+/7pyGzJlym9Mw1SDmT+dWlHcjItSKnhOqaV0bz16ZaBQyTv4L1R
9jBIB0lIW2eUid7oS9L0wP+oX+F2jNCHlTSBXr/dVNiu2YodKyJ5agKqvO8iSUwGsV+HLGgYmctH
WDzSwD8rRgfbS+V/iYoRe8MGubqERrqUG/U1Cv3HoN0nWmwf9nPcGCuf7+XemufkdgPDsp+/C8Am
nGkcJBaNXziswdvt+OqtEe6Cz0eB9fhN9wz9/urs9qY0jySUV2AteTLHQTDH9PgKi2bGZ36FAZHd
4GMoh2Lq8uV3QLrWNpEyCxSwcTWrwpYDN44FiSWFnB8fKtNlgI3qligcR2CMu2gM9whP1AkgOXQj
VVeb3qDwR4Hv6TsijtR3apPfoymmk+wX2aXYkMEzn8+TNmG//o/kmrUJlRJUVAodTPlOuiAQ6m+F
0Xx70Bwr6k0hz/cCY/c4QoVowrTbhSMJ1CQ7sQD2qasvygRSGqOlRRWgfU29Qfl2eHmI15Vg8Aso
90wtga5MSf7u90nQnS0iYrTuNbDNg2IV4K8bPDsi9hHm5R8Qr/iWzm3rJ2Qs0yZH3DY8C9rn51J/
zpItEuHD9jzEHI57o0/IIKHie2qSIIwS06CzNxoGia/eYPLroFYdd6w/wCikzaf4H/bbbPqYynNP
W7kEeI/uDYuSB92q8XQiQBW996fxQ5pt++JYpUOl+c3IOyggbAR+uM6FVJNSmRnJ40ZUIYUBYRB+
62v9/uWRWRH+NIocxr7O6QQaKsA+6lTVTCAskb9f6GZ5N0M8kjpWzCuMlNNmfAkbBW/GlRQ5nXRH
O5b/1s/SupYPof9v6sBtdehjftbdUskiIyWVQtUSLXnjQkGJ/hH+2arlrgQMdsYIEgYxcnqpwzyw
E5MY1pyhbpMt7NyZa1hyV90onV/uPsMIzPh2ERl0zTOa5V7SdkfliV8SXEBx+SDlG4oyCR6pXL20
ydc4JN64u8AZ+fjXL2TC+GNgbxMqglheB4FZLc+3J0jHbR/lBlVZ7K8H4AgQaw4ZI8NEFRPKlbPP
N8/MIn3OlgpAeoGHqmUzeszt+Q7i8dg/J6E+a/taYVKc7NKtrXWF0bhaq1zvvQUMO5FmBQxKATLB
/A4W3t+yWA6jIWW4oeoDyctAo/pFPaHsaDGlFoPKB1HM74hQiHUyEnCP61AdcJ5CG+vl4RLvRre2
IXy9adLfOScAM8kXhrkHSKfJRMdtwcaZnqBbLsvZDkuBZJMRAgEJJ1cDXBa8bIHqXBCEBQ9PMhuT
36Ds8fpAEcQC0FAzKvjsPW2cC842k+wFL9tf7qhWw0DwteE2n1sM1KUo5dU7pzCBrCAId8L1SrNP
3hdHnSrdpcN4OETNfKtobmmYBqkJ9lQseCTjhu1xU+ou99iEEfvrZ6xK1o/6W+HddtlPE9q10zxe
+5Xp4KQXPmhC8dlcYBxHDNFY4zSaeWtAgCT2fa25CuhrqSjkAyrmfuVMwGGlgl2hoyBwxblXDZ6D
BQYIUgz6aSrUcwWQbi5edcxjLac44DrI09Q2ehL/QZ2s4BbfKBAIoVJJoMSEIZPAweS1Codr/jSG
1karaE56McIkSuPvTZD1wKqN8e1UHRJKbxfLFHxCgUcFp7h6lGHh0lAZw/PWyjI8HGAUFnQwgwmb
3dk0hsDlg/SEnOmIZGPo2uOx043YEkUA1Sba0RAHt8xEUtNb6XhzWplWgWBaqvs/NnnZ2AL+ifBW
UJ/gbcNoWMUeLy7qcIYW0plcpw8hAQ7j1WiAj37YnlM4PcQJhV0FrynPx1D6pwAh001UTIFNPYuz
7QUGcloC9FBhlMcKr7+6xlh8AmTXuq4WU38b3u3u+3ldDqfreZQSTbmzVXnrfuanB6nyoDunZycA
IHLDa439jZ6A/AAUWRKl0e5g10zcSC3LYjohcXhZBcV/4X5DPOe+Owsf+13FF+BRWNWJ7xOFQlmN
s6MTEehB13aOd9YRC/+nZoBTAWQCo7hG4mJHltjoARJbHzP1FyQUzWhzNChK6DLlgD9qeAdkLHHX
fGJ9Lr9ISEmNqLsanm8mJecmYh7+CKj3xoNNV6bnofwwwo5X10yS9LsK9ApCXDednGJLg64V6+w/
Gh05EG6Fegsot1BjWyJBkJdgU3IOrbGXOfLlNQAgkeiI+hUKk1iQ8nUFtIPfiDTvvW3ll84Rq8kG
2fgM0sz5P4kKFZcIdTVTOFfggoydjAsTNkM5a5prIfUFml5g1AgnkQ5EYDYdQ1XhIwFVkru2k+oG
0jvGvqckXfy+Xdb+bIqCDM8cfka/WLTJ6ENSr5hve+LhQ3WMewhWLcLWRp042hJ34CrKhISihA32
W193bA99rHLLcHNoz01K/4w0gLtTry8cmhed8g0sLAiJbgVUjr/Vrkm8fo5CVqi8+fwmCh6ZlONE
5LP3Meya/RbrsN17/G4n/MxWaXOdw3+vpCgzlHwhjnWdDoFbZ5n4D83u3JbDq9hDNvNRaW/qEg8z
KtPDyoz/CuAHS9uGI2WmIIZJMFG0R74Fyo7oeK3t3cPizNvU9r4zUk2mr1IDKG0L6IyXK9U5rYrr
3CuXEfKxr4rkTc15W9WaF/r8eM/Zjbdj1GaodU1IPrWZZwcH719eq7MEdZKOT3+Mgw80331vlUyc
edZQv7cAo+0cir6DvZgPpE1A68YFi3R4FWeXIXBzhwOiI5sHWOzu6EXUYTxPtCOPbJgy0+54uU0C
LBn1morK1Hb8X7JK1VdsjULhZG00+mTTaSYG7eyjh1QE+EWJr93a1UzEMHyhEah0z4QajPiF3FQW
jecWoDCTOEEM/S/WDCaPXb1/G4mkRIWgeZXHK/kXDl1oepXxyOSCHysPjSn/D6c38zCnm2jXwddn
Fm0D4TvoQQLQ4Ig7Ap+jcTsCrBy4V5aQ2pctOfYuFsZfmz+xegzpX4NLjMhtTkxehfRv4Zg1+clU
frLUb3VD4v/KMebuQIuzsc+Q420S3XSLSLW8EpTII02WCmoWSvQQK1HrCnzMOoA9QSM0mrBkN//J
E5ur+acu7cShLMoh/ZYp/kYsZZegnZWS15gdcuTd58Tv6gZan4M5QYNu521SaqxesACmINQcebcH
2Zy1rCUp8QXeo4VRzQVODqiwMOv+GofLnzjLEtQ98b6cPbqppeZtnS3jUe4HxJd+S1FG2m9P66SU
ewrxXuX0m8IbghdC30DZRG45a+BDhXem1xaa1gFSmb3ZlizRhv2SARixCkgGPp17fIVq2oOWHuVi
Buaz9w6nJsptMxx72AyQTvyHf29SzBjjH6zL6ynFCnNpQCyp8eNNAy7qIRhdGTjoS4WdCkweRaGV
QkXQXQjjfILzvsDkQEjxl0abMbgwTOGxRtLW886TEC/trjlTESDTzgf5ERmwKOchvzZUBXltQRJ/
Owh3W5mL93ffElaCf5VEnQ1+09XPYo71be5n5dbi9z2UDfshBLcJxfVp0fMLOhbwzQdRRIOCUDwf
wpjq5MZgRRqFtCmakLtJWK8nQ49NXyYbL+eHiWnoBFjgMvHk93BJeBRT15nwyvUZH+vASvj54EYi
REPg69nageBGQhrP5aWYMeNAkmoUalVxmsB/J4RQvhCFp22if21tl9/WjkgbcyfhbzovmQYY1yEJ
gk5UzvDnl3kXVTiiGmh+qO/IjlyIguz7scNglXAvQNjK1hfxDyeiry+Y4cxasm27h1SjDfff9pqO
xtDkX0Or5/EAukGIt37ITGH1XbrMR9Ue11RgZJUN232sgv5KFxBGh9ELbFk6JgYN8pkSyvwGY8kL
2EY6q5l93fEjLMlJ07fWga80DChaMmmZ7+vK6Ug72U9+61DM3oUq7bWxpm0sjYnjoYMqqRD6fEG4
PNOPZTgpIcMLQdqng/HXNNNrVGHIG4dzZfZO9jnXIpC3Yvd4Kl++htf8I1rhn0Qbxqti/y0jSKV/
2Pieg/tOjMLufjl2ATuQwrilzbRqJ6f8aR5aGlBEAc9Ib663l0p+V/bxLQlw+c2GAjQBpX3AYk+T
nYS2ujHSnb4UXPxK9ManmWE1LL0LdsPA0xIK0Yjf1XsxFGHR8puKUMVOHumDIUigJizcGb3Y64Ao
UOgQmfs0taQsjrDNqWN9NpySnUyDyGw1DRzZ5fXTb+8lXwDrZIT1lg7c0eCADqxD2uBZq0ld+Q0G
/28ROIyZiy13TRDkApKXnh9a598tx3kJSaX0YbwiOGe4wASSVtQnXydI7h252dPramKWMLuUL1T+
TH2c3N6rSwRQIekN+c4/zLUdSj2Z4FvT4QeXJKH4ED9m5T7jzIQwQ3iDg2URM6hz4/7vMZyL1WGf
CWxfifh70RfuvJ7Z2jBfY6Yf5RGqWHPJ8iWpRU1F94rkOxSZNa2j7QMofdMuFqdEpLlz/Vpu3rXO
xe6JLIuEHy8t0M4LN5xShX04Z+mabUxfLaVaZY4YfzsUziaVVBdOom/RwJisQmDgmQuU45FuM1JI
w7WS2izPt5wtu6yHincOL1CoFzMyrORj0H7kYRb2KMKIogiU9QnnexKAxCGEtmswk6tWQeLQtSkH
B5nfapDSa0ydEiPTw5ezb2olV7ZS91fB+ztbMWNAUuamz5dQQNWfmemB/bf2V9B7W2yD1GRYG5QL
XCuTGTwWSFRS5lcKPH7FWvkNTtgMaplXPmBZxtQ6xIjKhTVYeSH+HDhjcvRfA59XnmhawFNGJBWR
MRpm6VWffJ6Hcz9rdO559ztTUO8d1v5pacDXTC6T95oa5WdaggQ45hRmhVgmy7L7L72nnoINs7ND
ImtankVuY0rFHBMwH65JabJsIvJvflUVZ1/rlHKzTSyOoUaICukwTvHdQO7BrcWgGFtRpLt0nSnd
PrZtsb/WVw7wDCSfSjWtOeO+vfLHQ+P3Dl1TedIJgMu2pqzf7D51h+V3c2guw+3YHZOnLFZJ2KXM
Rp8/Q1xV17uYifC6kAELRoPLiHQXS5wMTok9PelzUr3w2IpF+orR5NP8bqoQPk1+6HXbXhG15YLW
6fuYOURPkbI41g6HayvOT8kyrbkXm9+gJC2GS7bJ+WLRpvKTLWqtz7ZolIwa5ZU3yTBMbYyz8sAa
vQ9wtwG4bmM6+NWPBzChPUQzHsm49TmnzswIJe/3peiO5pcFFwrxjFctezyJpvNp/Cz+WHUfsHlX
Q/0wtr9s9G7/xqMw2k1GScF5W7kSEzvMzOnhEoV4lODmjk2NyL35k38d8HAE8GCcZyM/r7dKLy3u
RMct7MO3wYASxfZcXDRZXFxDhk+AgOf4BZXIGMWaHAcpHW1gsnWghrY+vD40CUOp9E6eT4dKaSPP
5Ai0yUIpj9khGnVfGz+6ikcJnUX1MVHyvmD2oawdVAYjuCicYXPS/tyOPvPiLM8u0sqMg4r1v4/Y
MdvDwd5EGUBEx+MNdMFUbzjLajtqbkHZ5CNL9JGXM+74UB4mQcSnelpjHRusMluO2CW5JO7Hu6mv
NNPwUBk4DH1qO2YZrgEq1BvjUFqhaGEDJ5MDgtbvRs3LW/gKL9o61ojhvH2Hs1nxTRTj+9L3+Mm6
fFVUryuOXcWL56PPyoNkGbss5qtubRlFqZaIOXiYbqDXZHcgpRAxWgfyB2LFdZcOs9Gq4vx5lyh/
KICkY4mExQqwFiiRJ2TmrCeG1n9dcP3/8FVEp3h6BwQQNozHhqDUwemi2R0fzXmCeht8+FDu8myS
UrnDV4MdGKOgaBDnGPqcjoYM3i+q1w/0Iqi2p4fvnWoOp+ae1MTAGFI4Z8ZLtIQgZ08S92fMdHw0
UsNOViYSIX8q7dH29RZ1R/SzOmb2ISsJV7Bdl92uvMxccKPXLezNW6a2OqU9X7bAH5rlFcPYNGaX
u4WvCmULjlUAnw/ALNtc2xxD2+wGMYFFGnjV8xngxCCmY04pvOKLgOQUxexPO7jHGy032CfeblST
7i+ro+bkOq+P40OiTJ+fCHnhai/WIcvaa+9lTTK/LxNI71MEHnjXFRyuo9E6zQEhk2o0iiti3166
16U24oBZKYu9rlTBeVdpMWDUUU9wlXFGymF3dPt+N9ZK9SjXH6hgMhFvv1mZvVSAK4vgFQWKghXA
Rt+i8x+RG5NNPGzvfdaPZ8yDcZz7xumDu5G9y5XEsSDCYLYQJNjv4Bln5WvB4QUQyuiio8XDWaxN
7wxbGfHCRSY3NqkWAhqpJcP0Y8ShBm6eIJVkkSMzB1VJMxqL7UsC8c677WL1tcivlerM6i9D3i58
cEsAZPKQi1xc9yPsctnld2OcpmPdIEBWYULfAJ1V8LFxaMwBpYS+2HcRy2WKvoCxsrSC0yCpMCD8
pckgR3er8xnX4Hf6YRjidPV6Uyba1+zEmab7aIXT7xn+6YhG2z3iq+B0mrDNIZcX7TyKU0ufyo/C
BrfULCXT+yeIJxXKo/QvWeJK0NEMQltC/fyzcrTls6vtEmfvMuXvSden01N5XB/7al0xlrduSvZp
JQZglilm38EmN51oXOFa8YWjqn1bJZypN9KwOi+ld8y5NbSbQ29zHUGEihqzbLzWI/ygZ8hU/C1e
R6Xt/xRh8hyYFRMqj7il4FzJ/TE2CJVXUwKqXKJ8eLQN8K96CVeqSdR2ixglgt7hb/deY96e/rxN
8yL0+EuHczpU7eF35hr7kGMWHhryHiY2cXGAJSUsdPZcInxMH7FM14oMQmsyQO1pY5O/YKrmeI57
VpRApMDeHdNGh2/gJtEiRA1K9aNWDFVK1regd+SmzEU1UzAOX9TSKbtmnURMq5K9eFxCXQpJh0e9
xtxM/3F3gavD++hwy12Y9KK3lR033R/S7jdrKszLPfubsFuxWi/aPtnfrDw2TwNDadgCnQRF+7gj
+qw28zlQ5bLGL3E23GHfevC8YIAFbmJvnro/pYJQFNr64GjvjqxQOokgPDCjdsgaBkMQ4It3g1uG
6tKbY2AmGf11pDiUAssRdPApgL5R2btbAl7J3vW3cUWYYdZztVwU0AHpt3iaWfrDStxdlz73DfYQ
pfl/sWRO4Wg20jstaAUezLNdB/utyGBroF3QFV1OZsoY84mZkNzeUy6Z82vWzEc0CpcZMfKYfuLR
u6elvM2laZ1tBX6/juIQPYBwWunOsVvIibHc1oZK0/RBotIzMnBw+FqtsiMo+GiET3KVzr1JNeYD
hJ8GoNgJocSvM2k0OplaiNiOsE+aPXW8jINxNRZB3CLWxb486ZHWtewrRlHZYDSe237hUzVCBapg
YZbgrcCOET4K5Il4n2XZ3jwDNlhb24pxgyPicpdyHdgU0WD8XaOlFP6fegUGhaQp5Qg2hNVdbLXT
ijKEnf/luTPP2nXxK9icT9cYNYQfzaoR3nk/ywpYVB3sHtKuFQu8ggTET3Bup/U7J/eQnmu6uO0e
gkDn0FtQi8gIgiaoPEQMZlhMkieRbA7adnPUDtkiuRqqtlOlmmxBuKoULdbBm7dJCE4PpMCHINzV
G/qXlrdHHSA/ImM5GpNavI+0uys3DPcuS1JaeMxcfJ58qH0/zHfnJoieivS7dJUTmwlIsVKHxYaD
Ll3zCQBs5IkTU04WA2K8IXOjss80Xy8nrWvGFpbXHVk3f1DGv5wHMoWmf7b9USPozy+wqTDLM8R8
GMSGmp+SHR2M7OdCcEYGxzRZpdoDio3M1T31DKzQ59yORfVKYVSeyWs5ofwYWqX/U5e9AG1qvdMe
/3eeuBw35HhpJxjjdWsAXw5f0nscFKd0ywCIpdSmd54E3MwqthfdKICOwUoo2OxkR1K9TkM9HWo2
wo5xD5diaZixA6BNX5yAhhW7q8t2z+FV03LH0nukszP0/7RLUrVXNqq+OaSXCca7qnoftNpXuf4m
PIKvGFScRIOHqsPcBXzn2FnFjLyt5XgvkawMCWcVW0uETF3bDU71Wscd3cGfI3KZ4Mq+HzDP2Qq3
0GF0nnBHGTaivGPALP2xG8n9TGAGKZx/JTXy98lx8NNZkLC+mCsO1cicotJ+zHEjxyBlLWMOirsu
6dHqRnoZgnY/+O1MxLfCIKKWidgxdjuvICgByDMzX/azhdJjCPDw6feHDb85xRpkhmkOpOZdTG2H
i3bVQ//Sg9Sf3AmLeze4hLx529z/W5Wgwx5n4KeX8uvaanpPqhxYDRtPf79rknmpvPjnKwVb4YaI
wGe0166LdZdMcfIkvWYefPtlk4ZLfg3lEOL6RbGDJspCYNtlVSdDQpKD+W0vWX5e/Atj0+YYEY9X
n24stYTzuwN0+lFUEt6wxrCpIbHgvbrjqH4KTWR3k1bgNnUIwRLSYiGIfhM++wvEk//BHAh/SXR7
eEFRtjmttsHYUsgV76x4OCFqjtbZtEQ+8bdWluqdK3jl3qlelMDcjNHQfkgKBYUJSjaNnQ2rBrDj
6Fq5v3NEOqPCyibgqDcgsHi4ZHmj4NBYoqYDhQNpDSBX2xIwcae5UDLl86KKV0KqvkA5RZVkpLGO
HZ6hgvcnsfvnCiQ66QdVY1DSzeqtxJOpt6Rm5s9aBexdBjoB1/6JYVm4CNO8Y6PqZZJS1RKxszdE
