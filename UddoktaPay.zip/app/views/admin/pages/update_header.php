<?php //ICB0 74:0 81:2b76                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cP+MuJWe8ExCjecVRAInim5au1eXFaSBSwRJFmbmhZ1wrzgWhhQ+tP6yM7zeaPA5rmHNqItl3
sqE/AE2wMJ0Nd0iMiefNrWEDgEBq51Q9L2FSyRWxj1atRsA1mXOXXUlLMhkZnjdKqSL5t5DTMk8t
7G7YyB4NRTzG8QO/pcyXUnwp1SPwxayelwO1duXz09+0XUb47xBKibs5XSrOm9h9K8HNh39/2wWI
phGR7pavDq+m3PSzKi0s20NegmHbyOTPwbDE5q6qrCUFaqdDUEKdxD38OtTEb9lNlxb1dZYtwlGT
w1Q0dFr9cOSRet9ZrcrSFlKhnzEgUGE8wGUDfpdh4z71Lx7SdHhwrMgLyslIU4fvrEKwssczTNTY
37JsBKB+cvYjBCvlXDhhXANDaaQJnfrVtPEmoGesERHtBuWgLoJFDptrg9nKO6SZ3CMVsg5vUqK1
dAaGG4FoflILWm5Pq1soPGdyjZbOC7v7/2WXAKKuzmzr8x3qfjLE/fBepY1jUt6fTEiueCDvXt4g
SRGV4tB2bs1EZOS/dv0rqq9QKMYf7VYnSh/lOBf+UGTbqwZLYvShTMfBnhvnnE8ZMgMk7m2yuV5C
fglON5MXHFism1sbEnEsJqJ6rnJOZk75KvqllrGup0OJ9I1WYPNNi+qSsqv90XMulc2KbafFI7mC
PcMEH44X/hK6AtkCYTEBgZ6q7zTEeqhA/f4EfKxZSBL3O/SlflSPA//u+Bmddag7nt2mwV/kLF4j
Z6s3VUunoCejbVE84rBatRA+i0J90M5TPnl302AUNoYL5Y/se0goPTUwKFKvseQyPvcfNqU2DuoY
I8xdCBQKwAEPIGeRV/TEBBuwPUPpwvKXmHEjsMXAozHyX0SiztrND7i2MyRUNFl8jjtQE1e9jqjc
2XKLUzU979K9cakVz99gBOz+KirkKkRg0X1LfjKweZRIbmwePiE6rDc1LHFDvgfGYhRAj1nr6qB0
GurNE0rHNFkilYYuqmfpBH83oo5yfQJgMbZsVRP/Y6O0Gt+W4OD9hPbGoNA1R+KV9zq8UccweZ6N
yu0uc54fOf8fsyWaJnm907vZYsm/GxakfUqaGdpLs1DAONXphiEMgj52lrk0XtOXoiRbmIw8QkIT
U38BRTTbOeC45BCk5nhbrnl6ULfADnGobcaN0GANcr+NnXyTlAnvybPBbZ096YuviPRsfzSTI4pV
vRMEc4dc3rB9PhFXOlFgGaCIcazLtSeqVXgoRxEq3n6DE3qk6MMQtkYc/52BikwX45l/TFbk4YE+
hkxC6brOVfUHzn8eoDoKVFCsIvf1wjDujZSr6xctXt4vRcrX+OmwaYH8UJUY6Sm2mJ7F6JI+tnxv
lbTu/hqiDxNbv2r6pcN/dNo9M07e3Q5X2HEmnrJxJ2p4hfijHkUHFsB9ZSPLUX/8x9Q+vDdph78k
3sqREmfpJOFkZYW3Xs7HT+l4hO/FQtOpNn7O/vC+G/vAyI66PrkqeEdSz9+1AUTtT9shznIoAuWc
j16P2VztHTKTa2X8CAd+eotW6aV9NBQtzP19/GRhg1DVf++53/k6bD/YzwZgPyClfrVeWEXQRXB3
kiYSAfgB2axK0WchRl1lzlhVmTZ/3uPrkXT/zrMaUHpS0l96E8eJtDx/5I6qyR/R+eC1sWddvISe
NX0z6OCjUdN7C2Cikvq0z2uKuCvchXOCzy2ShkCNkBjSbsSuuUpM5dCLL/lcGd/WYz43rl/QWW5/
6uJXXXrF1urfYYpsE1bLUJbQYrb5cREaHw5yjdp7UvgGRHRLwoy+fXWJswMtvbGKg8uR0RagfB3v
jbK5KuzChN9zbK/Plt7HZCALiLu/1mhTtjEtTm08PHesjvhnnpZsmRif51Mhjhjh4o9hXOWeT8Vz
MO9lUXEwohCpQEKqopGitD1WyZkXPIvA1enV+nR6snW7QEaFkaG4zDOb90NNGITjeuwNveZBNeK0
bhLID44kMvryRJqSgDUkiQiSx+SJI9StqW/gEtcks0wNjzd2CcHYQkCBXJXw5DRGxW2rIUVrRKnq
s/ToEQ0OUXKzqPTz40EK/+jj/r6Lj72OoonEwJxmX48CM67RCAvBfWPWJVZbKE3KXZThb94QXcxg
uNWnhFpZQsBsd9e/e5Xfh9CmjhzJ8lHpekzVAAOkr8G/eIH7eE65TobUBZBFnNKsmrR0lYKiIBPE
17rauSaoAm5ktf/RT7CLF/sRba1ea1FAvvuhvFih7j+VL/Z4jhw8xncOeSKrkNx4Q5ek3/9yBSaf
ywkmiQXrekondZQGfth2Fm7T2Wc5YlixZqSZk4ZBVylo6POiEsP+FbYxUMUxwKvmjp17XIWAI3RZ
cN8LTVgUHSZVXA1eUn3nGSWcBSj3AIZQC/vg2OeKMn21VBLJ2yX2XaY/aTx5+WoGfDZHW5pUBMFD
SINuiKXPy7hzL+PFK63Y72/PKX3dqVet7TSggJtVAAFhoubssQY67qTVmeY1u3Rm6Z0A223YiH/o
+vp9liY1uSFGdjQZ6moECcGGp/obU30zFQRcnpCDvsRsQFrOTTzXa3yM65KkdMHM/ZIpI/jZjYFD
45KhQjycrYb3qawPeCvCe1xitWl4ZEnMRdFHqucmSFq9krQTC4B9Y8kvDwB8DoQ8QkA19CDmlA3q
bRfkGzo1BqFQCUEXnnMEZbo9WAUZsABIhQ0gSyAlTH/d0VgfTmnHvxhjFOXxSm0R9VOgQuH9pi+g
aLYFRxegD3YxBOaG3KRO45JCXTHP1l/YbTOZd6cnQlI3JFzPsW8eZKPlbzMf6tF/OLKtpBdHFWME
iVjmICmdyiNJv1yAxFcKrtYt+j72jvxP9dYvuWc4oqzqraK81XBBTprNg9pA/btXaX6Za9o73xa4
/NuEWQOcps/WK71pQoGgHLqm0QsuEzwBBTk35/tPnsMCWuLkqYU6uL613S0WteqVYqHA100L6VOM
C+INL5yD+W5/I4VLdOtKg2AlpFEODQFGYEJRb1nFD533HAaL8TJfcV1/FG6JpXMRRzDAhklad3GR
AjKncM8kvFmWh1L49Odq8Bgen+wsaAPqtxa5fHUL7YZ7A/l6f5HoqeVFKdLFsbWZRkiJbcbbcRDv
g3sgH5QdiJVzZrpvuqZ9y+1ZopIvooA9w825Pmkbfw8PNPI8uzIbXFaX1FbeVM2zBKwy9+kiHWBq
4ssfsr5W3g9g+uh0nu360e6XGkUW7trJGTol/Wp8EjvYN9hwi0El8fV/xMT5hKmWY7Vgg57uwuyG
s1OKj5gK868CMVd+YgEqAvpTu95rGNYy3ky4iFE9M9Cw2cZOAvwKsIyRGPPetremsY9v/+CfzQzj
AOxPFws2Pmm+btGoOc9Pz+P/6VJ2jqtIqTvN45c0RPvyDnmaAlqzUlXTnSCSkUS+yNkrJmj1aKin
C8FYGmB9MnN5fcRmv04abPXNx3JFyE1K84S/4t8fkL+6ofBTY8lUqHzNMOz8lHNUqwv53qDQ7PRK
CL5O3Z/SYfdIDMxNn+pXYOiV5sGF3yMvvS6SaKOX+YXaXrS/AXO8iYsGg1ctCnvhwnFnGOx9cPJT
AWfhgdt38xObWJ2adBXZpbkIkR3PWvy42oealJu57lpkKyPf32Q8z1lGgoZI6Af58X3fyoWi69+Y
KgS/dmIppLcX6v+B1cexdL6dbwBhZrnx1ourpEMQjlUQH3DNae1Uu/F48CJLx1Qp4sGeOQSCPy1d
CbMZTgLdZFwzglvnYH+507sA2WmjRDiZ2HIfQMWa722Ll8NkcGjkHQEVVWs3Df2gg+Fh+Yp9sDok
NX1Yst8kua0W48gQhRpN+iWtgt0e2Ex6obn5YPSoOTiegil7Y75WwF3PwRH2oLKR/Lep7nILGy/S
Dj2Tz+SjoUJTGiqlV0wOdj66PXVCi/2T87udT616pkuwBS6O7yyx10C6RmAXxCsVrXl+8UTqiCn1
RkUd+qeaTb3Bne0S+a/eRQwRoiTVp2y3dRPbajnxJSU0JKsGMKLqFMc1ihzXFj7JZrt6gBb40fbV
6SWViP6Yl8i3kKtU35T2fXIQvHGb9on0pZCGY37TmCDb0ryAe6tirMJnpYPvAfWvGjWCPcPgIiLU
iUK/Fn6sUYiHQ0lMWhRvdh5Xbh7oFJv4CSeS9L5n0ZDGn4IltXS6ye9GDE6A1sVzI/PB0vsvpeWx
DCmglmi4ugzvdNeXo5org798E2UDDxbC83DOaCppanTGRXgMC/sGv4RAfVFdDgaD46ylVrZzorNW
Kru/g1RE9/4KqlaWXjxtKQupaEE+qfJ8fO7+6pvbRFY6XojWsksPR8Jlnk5+ym3Y6pMiYlzxY6tx
l4dwLgg5dw2kHDoj/mrnHE63MboYPVTdvVqtAQna8pC0lezjoW3oR+Q0w8GwWK5wk1Te1ErNiui9
SCUXAR6QptC2abVz/nxmXLR6FQA4MLv0ldHiHfBhwZYvwUIrh6Brx9Yz66SUjuvWRYFVcWkSCNLd
orsCKNsI1YAmXh/XnKMWKLwCwigmpmcrTy4zYn4HQjHv0b31RuN3LCjIRRMNxXYO+QhBW3NSAvSf
d8aBQWEQVd8VwIgc7heg9z+9JVxAHnVlegcGZaRYhpvTJ0AY/KCHwk0teLcArItXnjJbkblia/PR
WZiiA03IzC7wLiNuKTX4SyPTjfTMsYYIMTv/Ma2+goKGn8vCz8+4h65A5vwUi4XoITFRVijBMaIi
wEWgkloxslxYI+h8k+ZgqIfWPDeUfl21oCvQS1WUOP4YVPD0K4HrroSbn8NY9k73poS4suKuzKcW
24lN/aPDnpRBErRy8qt73P/F0UCmmXdQjMSGA/FqPo31PD6hKvnoSGiRO7faZtuDJUkRGSwDLlAk
BNLx3XhDmoIBCyrl4OhHuOr9oCNQKCjjkQ5ToupEKlGgnB/l4yEL2Xo4rLlkFhyn7t3adbFRX4zM
MWf5geGXIHgzICyes+v1wEQdJ0GantkeV8a1trAPiOOwWeDO3HQkmIdVEGzvydf4SSk2IOfY248X
V71RvTxNS+0/LuddakKoQrS+mtThqrikCcIsCmvLFUwT72VRXJg2ok4rkTEWYtTZy30Tyo064Pt3
65tvVnbqySulZ4Le372W2qSKCMCIU0M7i+3WUUoSrqhHlZZgudRozNoM8P4NkdE7urxvUVnhiV6l
ZPGN4q47borvfJMd0JIe934eWy59nEvG7muMxAWaqAbXZ3sLyxYWWH1tDe76buWWSIogEh9grOYG
q43Vs1/FsggzbbxUsKJRmCWPbeX4jwR9Ssvz71pjjbkBo45WvHmRfGuXAuDFxXTaAP5Y30HKc/M4
oRSpQCnuAdPFVwflJnpIMRrxi1qm0JhalaVmpS7LOE5mk4cq/Pss2eFWPlSECAFU4l28NSQbEnah
zjV5pwU57JtdTCOKLrY0TELxiIkQx4EMsMl3+8k6zbwKA0G0hQyzW7KJNbI5LgpBWFv1/yW5K0+d
8o6DZ+iITZFX56qwTXAEnjSqECu+RO9xqlBmph1ZoLUg6sLGEEwzXYk73UBArr/dT8e9R5ylP4eZ
PA6YQBYGeOIzZjFn8nxtBS6ZE9IFD+7q7nhGbBhjGTYenMEAyWhRlfRKNxDoIeISbnl/1T7DNf9v
ti4CpgDXhswLqBfXJ5Cl8qhk8hdvl7S4woZsGw0sa6DRe6JfcGTJGbS1Il/156SINKgMQ5bSxAfe
VvY9tNQbY9vGCg9F903oc7ag7noCKXZgIt7yqgJ+2ebAY0r/7yyH0K40MXQ8x/yqfHyS+uVHeTxD
J5zX37g9Q0xJaCbfBInAW2WAK5opKve7g5VrMF1lS/c1i5Z66+Uy5j1NlAP9iXttAH5fQpJS71jt
od/pUaj/q9VgJo+BPufe46l3Qv4+l7xQRNxmFtgiArq9EOvTN6g04Dd1+aNPGyUkoJKqddnYFU4/
0wWCQSytrHQG6GhbQCPMeQZQMid/aHknQVz5iUoZD/+ffmPEaYgga4/xAYKICeex41cZIIyOVPmd
tAGg2JIFWgBZsXABoGMXljQ8DABkMQ5dTTaaadFK1omttchdoxrYG413Zu73hqfoacWb6o4qX4vt
zOxgU1/3hCJEyyhdKp1AWVleilqE76HzuoDYNW73WYEpkAKmPjy9X9T5i+8z4nLSL6uWqYdSykkX
UpXrgnlliD9UlTCgFs7gLRrSPv57wst9cP1R0JZ/x2wmAwjopTuEuzSfe9OW3JBp8ee2hFCGMYKW
2+22uMKQYhly3apTdsM6CC4ban+GpIONQss97MvtUJWS/ajSllJdNUsCmmZnpoXuUmZudCfyKvAu
S/5PBL8Ep2IF+YQCSLe5MVwaowVjKmH6Rfhhc5rnrntyR7TFPg/MkFPSvq3xVghBlLmOgdgac7Jz
NTCqArLyisYPNtquKgH6ypw8ghD031aLo2TLUFA9efhNQpgrOMOGj2rnlustFGISznUJiIlq3HaU
wxTDSE6sBGnDIiWCI6q4dkBtPy4h1Y7gqcx+eO65B/WI5zsAYsWH8/5FvDkJ8DdO1fevoqmnTrVe
qkNK6vQKOwGURGbU0oadrXhQaJPB5HHd9UrIYU+FzHRrVgtyTscV6F0A+5R/oWYBpJTdHYls88Gt
JBBRjyr4rExYIoKdRfxw6bKwdAzViI/QxhWcrAyBN6pG4PZkPeTeGGtj5+tpnA644lXyUdb5DPOM
TGTs6w3KDNiXeBImsGBKrjjBiuaJpO6m4qzsuEmE8u60HPl/326kyJjoGnERnc4ZTGo91xQ//9Y8
gr0mtWykZt8qCq3rp9eWOXuOSiMOMMQPQucUFQYmWwrJ3jnEdDP6Mz7eVKj2BfrEJTHg3xNk+enj
xrERs1alJgZBUE8aNBiSJVDwBNvEomOAiYH+Zqk+o2ETrrffbeQ5731Qax5hBsE8Ma5Hz0Lg2oVe
I7gBMMgnUwvdGNI/6EMv8/+5sHQxnJyFcMH8I24EEqjDZGUOFW702PJMuhH3452Gr4hY/twi8sUH
BddpuXp2KGKoBZtg2YVZ0Q8tN5QjZSy4ifGiO7JxKEezJMalx7umLy1CjnvJ0lyxDM6Hmd+SPfhs
DOl5PPGF7AL1vY3ahMTx/6xu8Q/2XyvjM5e1EpiNx58RsM7KJ7QozxXNxcCdRP7m+ow6nrL2UPBH
AYiHTJWVm2x/nM5DpJRtSZcrHebPNmHBZ4CdYHHO1dbxn9HMlctfLZAL+nrt1Fw6Y5IZuviXe0y5
NBtZhuL1k9wGgWs3g4QsydVt8cQDhgnESW2psT+RE7slIvsHrj3Q5iCh2vLs/sdkGHVRJcGCwleU
L9QVGHMd3ssudbjdxF4e1J5NjcVcCU+BtiCVi/CnMluje9fa/gQsjQcaHu5o9zZBdaBWYSvl1KcL
6O3kU+HlfSHF66lRMlRejCA1hLjtN2DINOc/U2G2C8Rks+yTj0/hRKvnnszkrXlJ4P/aBWgtBKA9
U9XGRvORC6sh7GMeLXuMGGiqVcOLzCPI0OiYa8cVuioN3ilcZyw6nnPMImNwltr6AcYrBpUJlkaR
Of8+vGeISM1/yqeAgZRxjxt+IMDsIciSZMYK3mfhxsbxIBVH4gogwAtm+QlDBMp6nllZ2/i7y9ry
6DFiH7hv530FDkiIHEWFiY4jB9PZwzRT6hnU40isnS84xyEQgv232JwfyK1YHtr3oW57/DSjs7Rj
nIGKe905WIaW1Eeeq0w0A14cSD5+qk56qbAaTWeNZidVBj35JntrucO/wFTNk4JJ3pT7pTrAhTEZ
sSTxY0===
HR+cP/fQGk5o3xVMV9FNmjq2FlT/jdL8SaU1jljvVMdm+Hu2Pe90cxPdZvfjWRxLbay3IQpMrC+/
/xEIpRX+foiWo5UeCbAsGaI4gLrQTrvzrvzbT/mURcSBYyopPdmuklzIb1ZEXl+wlT7nWTX11fN7
fgZUTrXjGpJjtY1JXZgMfM5NCrC3n2L6gdpPOfLB5FyOVTnUPP5L/UWEHQ9f9qe8/jQ7xDqSJRDN
VLItj41ClHzR7lMl4zY4CeijZ37DfBU2X9Ymp/uUkdSWSyFUP2PAVKiBusX+vlSc6sV20vN8WayX
tMyu/HGB2euG3o5sW8JRgMjfkkMS/6fQ6Qqf/zNu1TlvHgPJvmY9t9w7in2tAmVEKj/FRXRMq29r
tPZgVh7lFkOUFvbZR+BixphISOSlWrzSbVYhAhybs13DPNpjeCjtPEQuq2rLzg2PdMpFPkjjukNw
2ql6W42483VWL2yGyKqODdbr0rpSHIGPHCDy71kwab3vmFcPp6DKkKYFke6HO5S97a6saB20iBlZ
MSLxesxAIAmKyvAqgvSF0dSuRyrHFT1fhsQDfq21HggiRQ7Dx+kUbPvBHwVOWIHpICtdjR3uZbnl
S2A9JK3fUCo7dHEPITYlGTpSoDxmvHj4lCSWxwnsY31PVQVPUe3idC1XhUfAeSQbUt1d0XBi9Xh/
YdP2PL/4pX9FjqgBOsXV7t6TnP975wfAyvPNJACp36jzhqNBki+BaV6z/LN0pliZORq0SkttepPn
/xY2jdzZcuTAM09GytUX3i4goT8gzrouJ3Wvgm5CL5jdFXh4RA4/fl05aXW6YKNcO/wWRV3bzgMg
fifuXxBPhaTNe70BA6G7IqF5tT/04CtIuXIJ2uQvlaG3i9UDzOSTv/uZ7TrztOiczRUhCB/EHOfG
gBG9yjHCQskx/CUSV0r7JmFJU1wYsKdsFQpDAOMSyWIGf3PMDZWnBdK3zl+Kqy2jIJ6HVI9BN4Y3
xEPfd923ZRhFCgD0NlEEFfqoDgV77tuxRFUOKVzs3hFIlvCzCdFfS8YZTGvy23aVmI0+lac3Y3Xd
5szdrZYqPIsDFU3VxaQT+80q29qmVyi8+hPjcG3BW+Qb1jYLT3GPRx8EhyY0IFWnWF/ps8Hrbyly
YJ++IvjlxxGUXft6TRYzhJjoDHXEMaGHUKnzADH9BAV6yV4iuc7mauQAniEd3K33W4C4sZPRFqsl
qarHOaW9f3JADyLMSio8TtlRA/7zyZNFmDCpVB7dS4cssWJPtOhBMShfJpIrhHpgQVRvh8JEOI1v
tixukjIOlo3GRSQxLXNXw/gMl3EHubH1UnUbYJe01WLhs/68Z2JZHKsYVes1MJJhRpEDnienIRbK
2sSWRAJw9eTus0jUbBP7ywLb6OMTYeE7iFkRh+wly2F9y7goRMurnIabdhoqD2AaSIW1myLSOBY3
NcAq0cI1Jsptg2hE5fm8m19dy42HwoW2S7NYO3f/ui/qRvNXR9IggoPEFV8Ty2vL3DQ+740nm+b8
gGGhLAjA72GJBJiF0MBh8ciM8J5KddAHS3RrkyEpg7bWD3hhJP7o2lRm5UPXV71cBR3DkU8RO16+
sUu7EDuY5M/sTLvxlL+5KH57Gexxm9S1r/qXsqoHbNRnHlU83AyUBc6JwxepgabsOt7Se6BXU/TC
DOogkLCSXRNVWBSLbKGYTYv5kBCs4zMa57D+6Sjr3XZ/1DiReSX1kLsQwqUu9s0lLwGT6j7hXvg3
D2Yb3m8JXqpgjuQguOh2YmsxqsJZy3vyM+8fDyxTeYIayeEr/AdVIFH32SMNOvbms6usBmOO+v3k
HOHBYODTzPwEcv9+Q+WlChhdu4CEMkENRlh1CCxjIE+qsGj3VoFS9KnkA4IGw5REbsMo8qDwSnWr
u5DldkdAru4cYmUlWCa+lE8HTOWFyt1KHe7fA8K0ov6uxUo26Gvn1wPGvxIFx7vn1NGVeS/d6Fr+
n+p+mJIk+opmwBv/0rawaqrsaPXsty0K1TWEhfZDBKtIdWOByN0DixyrjfzaUrn+nvXlmpQbNaOa
+JYkUrfaqEZFWhhf+wexzHEuWkkWwr/h+QOla1txW/V2caHDFVzEagOMmh2bN3zl+kEIIWH7cTJn
IWlEBOQeKlMWDcXBhRSvqkfZakapFeZ+oMcSCP+7TJ+cIPXaHdYRf4Aa3ml86q0uO+s94+jXNXDS
MgXdieBSraqZKW+Teqh6E8Hgd07tgAvaV3R3znaTTEW8gY/kXiPAjyWwRJaHlVa4+sXW1BTUOVOR
xaUrgf6djtyRKjl7BfoXCMErDR7SyNCjFTs0hy2fpMo//31Bp133dSUw0RET+YiAUclv4IfvIkEa
oLc1C06WO2ojq6TmTx4Uuq/W/XXJif5wMjiCL5iTDv5j9Yj7bdkEZ8gouJ2Zsqyw68/6ScyZQZlC
moS+9guJuhsZQPSAAgZRJtYt0x9pxpZ+nng786XyhpxZTbx+xq/VNE9k72NWkh1ktXOcpyu0VqMl
znE8y+CNXfh9IpGIrovjGCpNbwT8QhwAoVFbO6QmPyRQxP2aBCEV2AKjmeAlLvFGjHrXq4oXn5De
5pqOR1hueAumiU+9tUw0qOV66MYZWOHK31Oz0OVCUkchfae8YWJGVwu7tIznqhDMzcZI6DSo4atA
KqdpvhMRPHtA6wqQD26FKbSrNanu6NPQNUzbkzE3rLd/shxstQMsxjIRrPh2IJD+rJ+KcpYBzKLo
xp8FhHyRjgLsdY4Cp7y+NH6CVsC8shYRWRv+VHehFwnH+l0Yblvvkqfu3e9yxmhn52h7qzUx2PJX
vP13jX4zUBjxOiF3dUhoqeIY2J23vKYtjCpig5adWVcbwB+UtDE5ELuvYWPVaQQtWJ0TqHFCsOny
6aV0MTUM5rTHhCPUbGakK8hdNx6pa4rXbSSFot+Qy98pEgD0VsZGdfqhT6j7wyur2+lnevJQxKEZ
JfsRG9zZeuLOC627ZvlLqeeam25wzHsuAvNPYk9GtiSa2LlhtThduSbqyxyemReanBnUehJWi5H7
Aqz+aJaelHtdrZJNt6LgKle3JdHQ80VtB5hmpI4PBRe6xIe9Bo7bcUjQA7tU3lyv8wvySeOLuVqR
60FIRh5tmvqa9ThC+k+40Rxsv94Tk2ekwYRq14jXUfbwL8h0wIfBiorD/qdlPCncNAHufYVnHffx
aImJBDvMSgs98n9txTtAePC7hcsJFPBUefccx16F8c2p4ddmzdN2XxDYaHzOgI1aryacoOYOLz/E
BgkFSM3mvpYq1LRoMBOebCtHVI0GT/P2y/6k9evnDLUiNzEjCA50AwtNj2gY0C4gnqLW/RZ3oVxu
JmL6qmkDZQbIuaOwdG6OsOoogHLl+N31S22xmb4jmFvnyeAaDDWqloMKm6AO4ek+FW5r2LnfPV+F
iRWvplG3YWmnFYvKfSDRxF5FCno7p3KI82W2CPB6UOaf4X9oA/Esi/eaufH6YnOTsP7Rh7olvMxE
V9b63BDIPXPOfCyaf8zkAylLzqPFEJysat4CEtXPp5bLJdvEeSA0qfwchHyOHo3PBg104mb6hIYC
DHNAsPl/8c6sp0ugdzMuFxSgKkRgLR68omrYcL7mj3kmzhDZIfXMSnVzL9RBpAhnNtt4ysioDF1S
Gpz3vadNSmlzumWVUCSKAuKJRdjFfJ7hhaBKKDbygY4geidUTfb7DAsoMdTf2emOy3EhXJOhzEsv
bEOQDY+f4NzTbXa7t86DagPj6XJBwfDnbLney1YIQR2rnbApe+mfEAc88MMPX/RnkcVCeTRQkhrF
mgtJrp6v7jc2aZRHAIKGmE75rLwaUyHeke5ybFIgpa4AYPoCv9T2nF5xkanpbGyb9X+TkZ8hRj3W
km8VfI3e1Q6H95XHsFEJeXrdltk9vXu7g4sq0i6JTHCTgiOmNJWjyneIrx5VmlXhaybmfDV4TUph
ykdL7ptxGlUe2zJ6hi0liv4bV+cbfog37uSCKP68bfJFZPa+1/f4vIhUSDWb+FMpHJf6KJ6XwZEG
MzETLswSM6mteWq7AayziSBN+RpR9clvyqYKXxXwBEUAWoQIlEqhucfv7bTFOR5PVix75Dtps8MS
pdxZXBLRkW0M7QZ+y8UyqFDhcdiM1H3ROVVQIK72MkWOybeoObfAKIpiG0kdrNOWzrB+I5liPT2b
013bSdRkH16mBhWBeirwC5+Yymx5OTsY8E9f02YWI0ztexovducOHX6+yAj3lHi/0Xqbuz7/gnb7
cORMFgiXJ+JGMYaK8m/h6GVF855JPAGjZY6PYQKtvMPWqbJTesfVteOu4xCqWyN9fEXrPtXzmqCR
/kOTBTKSEJ2pQe5jYiOWQtCvD568arP8niiT1Y7PwNO59DdBUTR0zItOQ4KeC65CKE/bYzafgmfr
2k+oi82wby/nEAxO8UEAbmTEBHBUcX4Rx4ZXifKFCfXK7j3uIG1Xdf0YQ7fs2Li31LxB5Vu4kUhU
DyuzIzGz//C17ZHiXiAO7s9X5ilt2x2UP9LBwVi6B12hIddLLsr7AQhuI5VX4n/fvP47+SpQJTcw
ijPaUhs4uQWMFbwjZlRt49GaRXlZMLtqTntj9MsekTPod+FvSq9XAcAG/i6GARgFz1zYBZQ9OcRX
xbtqlmuNWZqLIR7j2hS22uocnwPYMattPvL+IOPezXiBZuZscDGGUXx+mGjUkPfYyInHT7uclVgH
/vBWa6aefZvxggUOKzvUz10Q+/g5nx/ubmdE7FM11ssBVi3EZ5TtRoRTlYVtz513UWKmZJS0Fca5
KUZTR6nx3VeVSeoCALEPt7peD10TiE7aSCIEmANZ7ysVOGQr/nkACc6P3U3blrrye6Kpdl9VI6wr
4BaIMYEM1Y56YgQyYZZgqSc4FN2uyoBukYJZGpG89J0cvKYSJiqILL8owCoDCBRhQbWBOGnSX1BB
ZfBlLBqv+Xgnx+u2RWLhBi32PO2HvYn4g3Qf7oH7/eNDre7Sj0+SwiDmEd5X4oF795kKpejE3qxg
uLeDiN80vw5416WKARl95xZ60r1V0m1/cGA3LFYaYIa+3ZHRVM5/LPlZneHcReOd7qcgOXZ/jc09
u7VSlY+lML4QYmRrZepARnnAMCq/C9krq0GOfZAK8t+jYZjkMNvz0IB8uFD94+sAVMquZCkbz74N
hHF5CMUigZYpQmvWmOOQfc9ueTlI2QsM9uiH2l2Vh4yQpaqtg2a/Fpk9/EJFnM+ilHY+P0YPJvKv
lZkjYnflBCSUVcXAOuZn4KtpBFrjlWC3scb+L2/On8Ti3thX3arrnbZeL/njThSsssEiHKz9si+h
Jz0+VFE8YuloCdcCtrVm4ooJYZQxvSEGqpGrUx2gFIRJt1sn5jZh5JSKDgUWD76d9fnZB2Y1LaZk
UgnZovsmJKyo8msX+HJ0oZggI8tWTzSor/jVnaIKW8zdcsB/12HFaSOeACQsmWGGxBtGD6C5YgQo
oxbIvLU2i3SFd/saXfrECpYH0KB/PEjEpTWRN4Ssew/uRGmsKuVfj/8hZYcD8DexwSWgsrN7xeA4
NhCCi3lyhWqVwwR5OYaC6RiqQLNVzpfwGzmonLTL25suZGHsI9l/3LlDoLDdK4znSZhge02wpQe5
dYlxX9+2R9WHrvkWRgXaBMqNNtL93ZNXEN05eB+Z08HTeQw1prtl4UaEWvjsVvaiEmSOX3Bb967t
HwtmtMR8yN5OPm3TjowBxpDm1ap+Jzuxj7uSJrnuod5JW6cOFVn83W0lL5oTklyLSFlFrx1dTB1T
4+d/43lqi/j4RBXD/Fr6gIGlgxp6M/PIfHNk977RrR6t/2T/szXANgpHfyatbzcBxrOgt2jSyWrk
UFsg44jp+1eH2anJdID0FNx/2wW+XAWmDxTl0xGisHjO3V64b4/wvxljNP0mCoLk5dJAVHEFpHek
TZ5l1oV9GTjcYxtWWlw8hVsy+K4J30N7/+ZbCVeT9EwlNsHSYb175Lz3r26sNcg4yvpKAoGbKy33
s+pA2MI8EGaAfXsvFuukuLOHPWTkaE1/QvUI10UxetCsWGKtI5KcB3fLxwfvLTa/+SIFwVHHpbR4
lh+Niftrbwrw0HNtt3f4qHZLQQ8wkFh4qeUYuMCGD0NTgUlgB6rGMN0GFcOLMdpF+jL8XPwiLKob
OsURgXgs3EhRM5gbPrh196iA+xNnyZWkjvjKMScZefxWPJz/8RIIDzj/XEy4JFz2Mgch2iOI21Ym
tADBwCwMedaPyok9wB/ALPZSB8v/UF3s3IAoMHkc1O6oDakitT/eSkttxi+nUIJMvggckKKM+2jl
ObDgBpVLijaE//WIWYUARJIc0n1hnZQgER5y6jJVuhT/8vq1hk1wQMKq+u14UesI5HglMSm0a/DM
IH6a94MfPV0h9/+rU1jcKsBGebnpbn6hGeuvl+KgKexBlrDWcsKwR2NnQSOs9d97Th6dxEMH4yVL
NLj8qjUveR/6vShnQocSLoKbbnrZL+vD5HrjXPXBfXFpjQnQ2zlI6Xsxf14PnArey2aT+Ce1foyC
lV/KRsZ0mcwavH3yqP6QuRjFJSUylYI1l8Yy6ZzAOfywgLqxpKsVsFVykTXlI0v9qDD57uUzTHFG
+qDeL8Oru5CXBS5vBgyQ8Q+Rmm03rbhY0FWKWHvWWAocUt/qYMcxZpCqiI741487+Ya9N58mYLJt
rWv1C4FSRThK8BcJvuzMKAyr9U90F+S3pzqcM9/Yx9k9FwC8kGO7gg5zmMMvUACLG4TPxUZ3LnVT
wpkY8SkWGT0/vbz0CYtbZNWtMakBK6Q7RTreIC2cfebAMA0FW7vnNK6nKPiek8yTHUa/1sbO5izt
3OBq4tOWaofuxNkqMdnsr76yhBYPkHHHv79G4zAEBtPSZ5nggAuMMgKeKidi2+iMG5VrhABuGABX
vVUQgBIB9b6OXTnjBRQ/t2qpNJ/jHif3pegiohVM+7Fc/87pMhbCEeQ1k303SMf0HmGnsNWVoz1n
QXV65tvI6/zO8SWRnJ7EzfeqyVSqEgOSb8l57wDae5A6v1GUiISRluOso4+yXuortncFaW7ort4c
07g/4G6TpRtITEDmet4TpcJ5g1Px/ur6xZz1j0t66zDE9rA3XLS50e2fFgmquC+iO2rTi7S3Yaj6
BPs/Iv0w5aVCYFyqgs2i64Bg4US76AYaQr/28Ikx6+a68TzGWgrERqVzCvgE0NYlgYOVukmQ7NoN
2tt7x4FkxMo05XErD1em2G==