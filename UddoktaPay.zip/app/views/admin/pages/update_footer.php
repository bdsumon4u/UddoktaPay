<?php //ICB0 74:0 81:20fb                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPmkD3tzYHFHm34gQN9WjjXFLBIDQUSBeGfpF4SjcswEs6GcruA2TtKtlPWSeTO2dsf7eagWg
XdFXg+vnFseC9t2FCMR/PjO46ql7QDQl/ryzpcjJvWYc1Ro5EFZRlq/1ERIvawrjunuSSd6/TyrP
r/+h7TFglV/P+0d3SdpCodF7C1n3XzoBFhXn4twdRHa4VqPBnxYYpCR8NxGPU/UDsoRFfFM9sCCh
y/S747fMgc4fzq2hbXMoDwzvQ4oWZVPf2cfyAsJa5CFhqc4ehHUudd9MJfgvkVSPjFEj4S+WiZAQ
a7MniuZ8xwEhYthGScAT1kxivX4QYQU7wHRcak/TJQSdctwmrlZ3a8TV1X9S5HsG/+UTSv+vjKVi
LaYjG+AD268Yz09pCz+sZ9W1gubR2A4ETt92HqX/7T1INuxDLXgIIlew/tDIfRYaXAV3hn15AafC
j+HNvMOv4CQ0VDd1Yn8p257qEB+HQZLQpWH3hme94VLKzocR8RZobEL90qlG0LXbZLgoxWhFjg1p
xa4DJ73ha/PNN+d9N6WKUYvGBNOL3yYlXfa0xre1JamxlQapOncbzYpvhEc0C6lTT8W7A716qifa
zd4kAosxIwe/oX5qaI/IhSy3ewRR6RJj7WNj7TEMGsKOE7Q3jzqHqHO6aAejKieQDmf4WJ/ei/rM
33i10mRf1M9NzkEWDSiWt4z8pSODPa7LrZ8LbXvWQeWmprgCfRXDPvg0D7ZUfZkp8Hplo//2Mx08
/xqubYy1oe/j7NvFECw67nnKdTpmxp+5BOJhaOhNpJykW09f5Mn9/KAR7/zLbHWq4WioYBUd/OTD
xC849Y3Iev6b70h4Szw2F/GGJRjIcq61Va257t5ddYopokqjj/nei01xq6vWevhfAv0NjnJSo3D0
JDaUyNjbMgrQohc1J/BrJJwUQ4zTLAQTQX93gwo3H1Hb8UrVvdWzZqUyD8e4jtsFaoSBt/C3WIFx
2OzN9l+Vx7JcKb3R4+o33Wesa8pd/9au+wGaucVQQumKL5395cPfvgUbqsRpp9I4mP6QMDQoU/Ig
BJtcfsyzCDMVdpytvKlSGF00rCGqm3Ix0g/U8phEJw5UbzXOYJg2mAXd4cev7oQf9xetVz9sar3Q
1y/vY4YI6eaWfE5bK9DqBFAlyGkKa2UE8K0xkHlIXjSKbRUg5t6zaEqS8pzN/EomJNM/C0tDKxnd
QayNMznDMTsRNWpBuauDeUfYeI1HVWN6suo0zbNi/5A6poOGUehAVO/oMrcnhGIAlYLsvndmc5jR
gOb0xsYbSTYtWyPL1SyFJzLP87vNar8fT2LZovu3HJkdHQJX+Ggmr1YYnZtj0oPh4pjoWOeU85Vf
/UfPbIlBGU4Lwrj+JI1aZmjQE3M4Gi1vcFnSabvh1FA7H5aQzgOokak1GcoOPuqFIQVHuVidHXn5
T6/moqxPgL6c+KSt2nVMNMECnyDjktVliErdl/CYguSl7v4mKWEc7nwrNCsJEMEHcbY/ucn6RNPI
NdJ7jQq+W36p8K441iEjESzYpm0ik45A26srOBhsk2m6DjyakMDE0ixCYPFQXZNsWPdHJ/6CDGPR
Rx7LSNixI3JM/LfjWcOz+SddXbL2CrjIV8ugkw5z9bB2Q/FjT58+2RFyumFk38aCHZQvlTfTIM4N
qAFk55imNH/YmW8Mjw7zZrjo0krxebve2xWh4gaQC8BYYZhrlWa4Xwh+lGPMsFvrfunRompm2uDr
i+TDCVONPnuKB5Xjaz75XY7Sw76BEMNB5U923g80+POSUrHZEnMx35Ui53EurZhtsom+9djUGxWz
f7U9LXfWFa47htTGJbNChLMqcQy91ooh6n5RLQ/Fs3r2x6cAXGMwIbn6csY9M8ror/46E0o6WF6q
m4q3/ZVzanWJ6ed9hNqVhEciBS7khp8tKAYcGthupaq8Oa/wIFOZxUCkt6nqbRGFLr3f8eX/WFph
+NJBV7ONb5aBz/F3vNXcI97Xr134jjeAO1EHe9CwlLMcwvLTdVSn93GFZxlDqNenjng0SG/TlpJc
AK+ex0gYgWbhj7CSsetkSL/jwpacv6PHK7n5x/5OLOJFFSeMXf2X6oQh0nEQyxAzey6VD0hl1yLB
a+ABHAbtp1oepX3fPhqh9+AoSDm4kf6pJ8d3s0v9lSR1untDXc9gEZbauBYHENQ0XZirhVl6d67K
ErW1KZU81L+1VyPS//Py+D2WDqsEfDlblSsFMvD9KvBRLfmgs/hMiyqG+3g9TzloRbVNaoc0Mv4N
AjN8vCorietsqpiNHPt6p3CquOJi2osWg4IgzUMH9DFQcAHp2+G6QQbXYRUrAb+YqBxa0oFJ+fyp
JY2hEaXTPVZsux0qxoiAAEvseXHuybP/n4MuUkQ2+RdMemLB9rbYlbab+4zCD78VyFbNviQVAyn2
JOQT8fuiQUkVK9NAOKJ+XoIH77hvUHw5ZsemiDZxLQ2Xa952BKwKyRWYfDJZaidxqRmY2K1x06Bg
bPVpFc6M4TnBzqjyVhcoocGgP+WPgNABjBvzrB45y8PzeBWi5S/SH0bGQZbT9McdiAXhts2a/YsE
MnoTq29muYyrlvsQG6EUXGP+tlMW8DKUxzB7XKEb0V9I/vRLzkRoyYvlIaO6LfyQkVxFgGMQ/FjS
o64XzX9jiH+u4dJcFdxXHHEz4rpkt+twgtTGycdsg3gB0G4onI5l5PrL0sgT8aEHmRG0eyglYSwE
l+RQqzRtbWhzcthwyuNjxijYnKDqARUxHed5BG1EpR88XfWZq3F9UUZ2STtcLesvgmRX2tzv1P1I
feT3WYto+VyduM4BCgIHi+XmYDc4kjzCX43W8htahBMIgA0EwgxqXG2jVWRXb1gqYLFBc+TFaHP9
WCAyUGpqhuBssz0a8CGeg2Iri7gQqCYgLmr3VqAGzx98Op3KHPOK2dJwTiybtRHaoOkSWIGv2FqE
YuuF3Gv/g/fV7i6+T5N5SIvSxTconfFOPU2WNJEhE+vMau0zaWzu/16xHTcrFxdUYq/DMshuvumG
WH+2YG+z4zgEysK31qTFXPiGBKlXOQrb5TsHrIKi/lXAGTjNt3/cjLzjvOhH6EgZnoCz+TaZxas3
WcWKiqejWqS6VTfn8Jf8XtHd+ESpdCP3s1c8nWF0QH+K4fsZCSHVZeePvNrPA5E8K2Lq8xYQ4kYh
5Dd6v4bUiRX4bySZnBZK+66iTHzIOUa7kr6gEVrD9EcAUR4qvIZjDvVl2UCoRAS/+DVQihgSG/tn
B+/VtPuSbooEbXK81QdWlRnk/RjK7LCI8Q93d8BdDFXc6eo/HIk/83W+nS/izUkHw1ycPdlays3W
YbG49U7S6pJI0tsSxlyggYzCerYJ/KDP6bJ2I3JN8qJnsjSHo6fW0aaPZ7Z87EFi3UvrHH34aR6p
s2PcU9UIAE1FlhL6VycQ7hab+oV1DaTZ49dCTqQ81usvjleW5L5Z49gF72JZSQ+RcTL11fuCKCaB
rOSRsTmeGBTo80/ufMm+/y9q02h/0tlan0x8wm+xLScTf2YZ/8NOZShGnITT2IJXTbrAhd5QmBBx
xJkEwcCPfOCrBRSJckodTarGZm2RPeAdksWFHnKP3hn/2DuG12tvbiZBDzt7pgyelC/NNwwb7l4m
vWH9bwUmVYXFi/ehhtArK61vbRK+ie8waEe7P5pi2cAmvhNaJFuQeqZboPGjlKPggMAd6Xp9xJPJ
52FoILwlKCgPoiiq5aLQMefZMrHSFw9t4jz6vejIhZlBzEyWUXYenxEw9djh1E2C6Gd1FdMShlQN
iMRPi3edpnznj308vvTm/nx3m3q83qNpjEX1VD8/xIJTxaEEZMsOZuxZrww3WWGZDnyrs9oZJsOp
fZZUTmoIPhkF0PFur6b8C+an7Pn1I7HEOPwFyHj22f10byGq7v0VaKgUXjIrcfcMwr52DuISWYGG
63QGzq5fsBMoZE7nnYiLKa/e7fu0M3t1jyWTkEIpbA1KP4Wu1Ii3cEhFhcWCf2W/ySqhB0SlaSgT
+7Z3oOlYuzScPwew+yQGbZFAeYsSR88v4Mq/cfosXrX3q86QpPReQBeL85tp6Ck7AkWP4SfwLJkY
eAr6GPNRVgqhNVS7YYuhwMbyZBsibQABKn4jIHTsRPCFuOHLYX4JGiwUo4V/9ya2NJ6pRJkpikMv
+Se/t82BoP2VYmR++kjFEHnC6sHP7xbDJngQOqPaTnjQb60ImwlYxhvM1hGGpqCeXlg0BE+BVkQw
I2xQ5EDaZWiZ5QNHcl3AzgCB84fNZBBmcrxZXwQ/yUI5k2MyJY33NqVpTEgpznAAelu7pcWDaa4/
PuZO+Lm8MJjMPxdm5fdBRj3PkvIAXrq6KmFYWQ0Aad/T3Rrh7D4LD/nVj7GX05QvG5aZ3Y8tl6d+
+XMDgRaVVAVHMz0Q+LMyJ0LKsogsv+9gnIFg7HDFPTLHCj97OreOBElIXUNHbc3j3Iv5ZmtGBKWF
ZqL5MS6UK2qg0iqf8LvNSoZ4dxgWeJKWR0mxg2+znUAmHtG7589nnpAgFUuWYpDLQR8HD91A3pNr
atr48h3VxEY7zRcbjf79gH9B7r833m5GCpsoyyyzB3fSn/TyikU4B3sp811ovstis6afVNXrb6zm
AFvPR0zgr1PDFV2VU9hBylVwNDJHPodcOks4tr63mKG6+z+UqNNvv1B3SOvBxc8AUYng7aKMTYub
utev9xIoJS/yVwGacVO/ZjFF4oTtJSTxAUTaNBsYe8nwurMUGpVrTBmSpd5IdJqzrGJhfu8/RXi6
h/sWgKbzBbHe28m1RND/0ZvSyp+YeUojJgros4t4UTVnLp0ZfS0uPbrgkOtNDkg/obWwIdQq+svp
UwC/BtkgSMZT53TMohOYu2oEWIL/yxvZm1a8QDSH+6UEonbgmB5fVDOKUyXbjwjgdgMoMdQFDtlv
rOFF+A8A7nbX5A1mcleiRDMJ0LhYVRh5I3DWdnsZHsiRpgzFuXlpzz0wKwrvbjtNoIMGS3cepMe8
LokVJ8UiVVir6nm7UU3CvZkmvUlq2njk5K/sle3kp8QvG4DBCmBn1AVePcJE10AxkGpRJt5yorJF
rhKpuexFR9SBVh95wuhJ=
HR+cP/9OJeCUfRAqaEdReF4vgJWUX62xu9ymykzJ3JzrQW9/NGdLgYo1+U63GW4Edc4P2mmLfBox
01BzS6ZhQWM4lLsOgn+xVO3tq9SPylGZeKIk/5EYqnEVXiu2CEpy6I079za3faoCeHq76n3ASqBa
8VFjx/DNUmcrRN9+1Zf8hfpYqhfd1pqJ+bv27u9YKlMLbizKFq1M1slcYZeWClawzB9qD9x0wrPV
OnMq993O7xgTqS6gnFxPsmsmIf41Lal+q0zkkIJzFGClDdQjav9IquH6H9RScsIhCI0dMCV9aUtT
54m0hGgVkmGGrsbpSt7PwGK19S8FfeC7MjuYhIrl5TNGuJhRdu+KBvMcm1GkexrPgDlibMMvWRCR
13dcZK/hwWQC3bQ9NYShzZs8Fl6M+deGvMTyzbaIYIg3aQsJg2PI7gUDe4gxy5Ft6JI+lPMC5fNF
tfWYXDrK2b0ZX9CiKMSAa5PnQFjtKVWj8HWoZIeXZouqfAJqIYm6NTItu99ltVjETcnztErI/XML
33DnpsjC+CRBU5LVinfM9lIW/o97SdGzAdVoTd5Nwf+OZr2ZwIVW932kIOYIaExUUV10FjpLBWTK
ot/mlCvGEpv2wfYjq9cXblBzsAvhj7iTOA2Meb8F+gkzt+GvkVQIApr1Ju4MYPVH6ljPrbHoPI9H
TUY6UV+32JMaLnLj2PIgeTcQ3Jbh6V+4zEk0GPy1wY21GAbcYl+YHR33Baygrq7ByKdNcJx28LIj
fVmgTXWg3Xu38sAaHF2NdIsbwHUAAVxBmCmGc6Uota3ZwT5HqFRlOdMjWBXi0zTe4+hUIZYUtUfv
o6rhpnhCjTBNr822Y/t+l8vHpNVt/XM1rBrJZY16c1hvgGfvHRfGrrpSSKQtFvnmMFg0emlxOCXU
L8pFLx3Bw8doUDQWSOL0pqtNrDmV4nwDI/QVzZ6rFJtQd5dD5qAY6huFWo+28Pfkw0lD5EVerbv7
2uPKgce2fuQYeWC9UIwPq6gr8KgkoNljNJ07kMnIggD6V/xor956RqBMaizk44uhLCaiVgmPiuM8
VcnJY9wR/q4Z+0mKUG+jWoWFLOd+c2cFUjWBYMOXPJ0GaoaxfOnSaQfTU198ioUbEVl7/VOOVwS9
dfAT2rLGs8EHZr2hNoezMUV+SeBFYU0TyJItaKq717tBAF1uTiwXlqNSTn9QJqs6A3LZvAys9ODK
WaKW7fuxaah6SMhs5iQVExAiNF6OweShyCsX5qeLSK9LRRTg5UAb0YK1pyZdZsbUsMwksOFTJIpl
Ongk80NbwJ+inSq/yAr+rrL2l8GB6jlchCzTH+V80zv+agHYbQCs6m7uyk2kDrq2rUFOzKlDdHD/
O+ON6bxaasnoZ1p/EXnsWC2ezfX1Dvkhfed9Mv78VCoNCQsA8xq4gaR25iWHHKUTVFDzT5qQvtbM
5Q3t+Ji8hCQ+7mEbja9w19sp55F/RuvVNj+xLU0nlD7fQ2Om7EOV0vRd1bG3mSq+u8Z39/6FNlp4
IkCtM9ThJJ+q/Xu9NaIEYkRzhfhVWWUwGxWeAGoz6aYc8Z+/3uZa4T123+J4b2HIPD/ceo1a8rGI
AYy3HyXVOrxyU6KkMLKgzNB4m2PLHCMY/VnWJ+hyxB0qU4oqYMNCH5HJ/fcBZWc16kbzPYagyfnp
T7p9jaX8aXVAAjigIhuFWPlDf1S2WA9f2X3metkynxQKZwoKmaNy9/zdDIZmxD3A2E12O+TbHCId
vqVQuCSo4rbLpzZCZ9ypuB2oY0KQkO5B2mf4tmVvjQH3XZWNJzihANk2wP5D56+KFVehRpGFHkd5
ue1j7TGsHdQBLy180RTFfYudQrXsFfbGq+1A/1xn2B2yduIj7NVPnz5Y79JT6yvwQGZmv36sMJ1Z
JWD6Q9kuYxhRscqfA4l3Hrp7gYPRJFHOa7Dtc+Tmfo1imLR2sHxuCYEtpMM/RpGFnYdUh1y/ycx+
EjUF1hZAGtzyHBqfZHtp3IB81idVvuaBFzcLHTuZrqswW9V4/rmkQ3iqFsf+q9JOfkHdNlrvzC0G
tJOT9onarOpNWUTB//uYODR0mK1oLduqZ+A42RER3QZKfImvbWbW9fOXuHVCB+Dgw/AiMWR5SdCB
VdZYhh299nrLKg/H071m14NPOI4dzlNpji5b8YYHHIaKUCFUJD3KD2cpUO+/g9An8J7U9YQlJ9lF
oQv8XOsbPhZpH6LuPAhPoq6RaPsGn0h2PCioepGc47WMkahMLsZGHE3nwwi30W1ZxA0xco1zkaDy
QBBrC7N//W7sOtdc3M01rd4NRTlu1XljUOhVUzxqjWLvHkX2ooIzjCdUwwTYatZg0U4gfzh591Wf
9XS3liCvmnO8xA5pp9QiwqWNCDuK4CMlJL3CfR9Q1CZxC6BHDv3WgmuDHDH3eOQHTYmDDWyWs8xx
1F5Fzxh3GnWHzprjZYqw4FKf1D1ngsp48uTwWo3zYrlieHo44d0YZlqX/29sZleDjEgR7QBBofZg
rAGQZK4Uy5uLN1g92NUJU6yKWhiV8P7gEtt2UmochgkOWiK3fi4cpW/Drh435yossF4dXKZx/h9n
QsH4qw/gXUiU8LK+hW1sTCVr3AMmVVZ9c5M3hXihh0akByH+748CzVk0x3X67Bh/gOf6v8j+d1gK
PBelBle286qDnLnRJBeI+p6lud8EZjRTt0ztDUYVePfTXrjWUY71U6beZn4kR0VMWczS96q9qL6R
hE1SS7aRAUbLExB4B+OXVF/H2Z0eXzZWPAv9MNAd31tcuj5SX6dC8OX4tekxiZtBhi+lNFv7sHSJ
lmkYcWxu8eHjix3cN1fPaKJbSew6gdoI1oeJz0+WrEL67+Bn4Hukxe0sJJ82MlD0x7/pgMq5cylN
Tu3zqFpJ+5dWT50UUIuOEmtR7BiZ/4nw5i9WcIq8sC6I2w8b/+/5uGPh+u2H58zOx+6cKm3kJY1F
2LLC3bfoGNtaAhh3d97yNd38nvjJx56TCDUtM/dPfADeF+1dq0Yig1ci6U4rzfitWLWjGnEZj1eM
N1NVigA1W5fKItj/qUgd33NhpWS5GZ6F9SYLJbd9hF6Bx1RxhdM5jkqbRHqhVogxuSJ5c1PfviqA
wTA+MsOqZU7n/1liAAooV+x2bqB1udwlm0iv5dRe4Q0zvmpN0zh+ux5DNpUMs/s1kteFBMDF/2oM
lilbUA0f2048CbggrUI2hwcmVJPkexvonXT/4Ve/CkIZuzA3Po3XtUEY4JvawnehSEtyzGZKXihA
PtwBA2v/03h9m2CqHYdEXFSX34QIAnZv7eCYQOuxRQM1805GowdQLm1gDYGrbqQB91h764+9KVl0
/9OLEFyJ7MmnmA4aJYnXL63ylrwwTbRFvVhpTpSEaEeKfFSgfGSRDBcZOdrIC4UDBqqBU/T+tLTj
44ZP7lCb5BanBLOflAroSZx9xGd8n114pgu963PGB5MEuR/iG6tVDJWAmDdrdWb6Ab6QsHKUE2+w
ymEn6WFr77J45Sz1ScKhU4OcP3I55rZsFwqchLEDEkRoKF4R3BQyifsM917LX0UlMXCMU4/YE/i4
mTtTpK4F0fdhVEjNprE9MBOn/vINBWIx96XwEcfhjZX/rsFSOxwPyZ66BY2jLt7gAtuBUWCpV5Xj
NYRPtS9o40mc1tTtnZjJCCq6QWflPAtZhy4fgq7Uv8f8MWtk0u8EmdPnLO8KACSjk/g9lLus56Tt
8pIwyQ64K1iEEbxBTA41UMEIA7cxXS6krGoDQ8+WwBytnwSnHKKPvE5paMJC/oA+YLOgDT0Scuhx
lIEErTEYrgAhVTXue5TYcT0a0iqLE0FHI4ST1l8xWoZgOys5w3GgAb0e0sP5eh07yRTC4X/Hb3IU
mMgLEwjFkDJCbggdR1KCBUvPBwZggGGfKQhYgeLnEgqDROcYhBTZfV7KNKVRxQUUqrtfXLZWDw2b
JaWChhH8cN+Fz2q/0UzjK5x1PM1L4K/9dANaTvPK7kNlHY3s4IJRQcMsQVXNYvQGo+Uh4M4OkR6y
U1q4dA7nOv+hE62vap8VokWbZPyxRa9rCbvNclza+KdjbHe9BWCeBZJtehwMwu4DvLDOpBKqtSXj
exurTE1Nw49Bbu2Evs1EJLo7C+cvPngkpXmgvt8AkQRijreNouTdZF1vCdyuMhTKjqH4vNbqDrgc
SOCe+Ft75NYHGzx0+/AkJ4iuwxUtt9WQq8aErGy+EJRpCv4+YIqiEockjODNPUoVs39N2bJQEx7j
YADb0RXAS1Km6sUIQpFD3zKQ5pb4QdpEmDhzLNFyYTqxd3hU4nbD6zYBBxOcAGQFBy8Bbfi84oN3
OgCxS+H2KRJ9EoQHpZIiOITgZY2wS2Z2mGX1GD2xJPSPMD6hRmLTp/v+aUhpWdTkR+qf815ybPuD
sIx3xk9XnzbL2E1cY3GbgK6Rkw/OTF0lrKNPl2qzLOhW51UDxHoRElGNVYDgo+3OEKSVQUI00vnM
32DmY81TPi+GymIqZWmQOYZrnHlSvNIXBGYMv5LUEhFv0KV/cF44MneDXKk6W1OPcgOBtiG1ELYq
ZXSBmQH8/1esGHSlvfHXpdwl3u+8GdLul1zBC+4Fe+nLgtPe0AaYQ85gLhUerZcT9HKc47LuS11b
BAK9A3vA