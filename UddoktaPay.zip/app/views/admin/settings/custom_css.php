<?php //ICB0 74:0 81:2b39                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyEKimXvHmWlSqicAzwX4t8sdIxQijQ95AVFQHTcYKxXzj0zNfWMA3I4pm8cmuyPo1W2it1R
qYf04pRT4PveCVP2luIQ9S2o2gclohWx/imzIyUhP/Uj8NiZIr2NFP+5vlj2KkjcfFZsTTNnxFNj
3ycgqEBZcOVUfMeAGFPw6rap94FcK9HPJ9Y9fAmqggPWpDC7h1joJBKvC7lQ8dD0mrqKsZ31gx2m
q4OQZ5l9WLWnJGKHSchOk8KDCAdyiv+CaD5GktxRV02pRkZqIKMgNXlh5aAcywor9PYLThh++jIy
t9U9x3hgRGtgkdRJ09g3nN16na026IYWy3IgZnWumm533NWFEVk+mEAnOCWVGGvUkzt91vZcYKns
waZDRyhQjAhAsuiTHRPz3RQpPPvKHuUzyBAL2iCSjo19HMvaPrZS5Bk9fk4dopHSIbWEn+h9q91d
auvI5LCe5KB9jahSoW2O9AwuydvvVri/Fsop8ll+3yp6+BD89AjVseELBNH6CwoErghOr40xQLrd
1Cvlvw2gI3Xi05pPvEbMzcH8eZ/A0KIwlJcKAm5KhEXSOkRftCU76Hh5z7TZMl3q3CqbyRtFrVQg
yoJon9je2U7eoRbVMk8bDR1sMPryEE6wfDnR2wY4mP+oyZ27EzMUU1xXNT+/vI7tEojR9fL1otQn
2zyJS8V93vLUjlU8+NyOmPY2guzJyChH5gchLyximwhSvULDvYPf7x7x22pUce8XY4PB9WSsfcyN
1jS7KtkfMDPKamHPuKhpV4dHVxAxsxcsGTvyWUkk+Ojm3etuBWbVycHvlAtKu9Ny30HJ7c4LcbyR
B/P0Mabe41JZ7AtDtmRjgQm5mWs1k6OhugWiVZI+dGsvHvSOEMVWimCHCL95vhaV02oGtI11zqxU
zFARhkWztMc5xeBquaLtivzyCh1PRt3+mrSidHoild2SYr9un0wRcdpoRczZCK3K3j12vthzYnv2
7pKCTEWjI/yd7VuPlmZE+kcV/AHa9QJ7ByK3UpOCR/5Z/p7TSBK+ZcNfJIKebDd4XS7AmTB34ear
cGhXL6vparmfZxBF0EYUjwvaoE/5uKnepKqMo5UG3HwNEKklr7CbbCFQnThjTmV9NcJaoBZoPadW
bcU9H4rIUleRywgXWUSkL2qBJ7Pg2DAEEaEfDbeEcimENSd7dnfcxk3RIuwEKF0b0YNJioN06i70
zX6TUSsrOl43NG9scyZ/zTIPi9ezaB2+3RQ63MUqvs3t/gPUsdcfiEau/Ed3fcusVE72BB8Wi/De
cOAgiX43KVuOfdMfr04GutkYCZdGHchtOpwalwlijuhdb9GaU2OQSch+0iaVs3+PIEww3ICcmfid
PHeaXZC/YGqeVMb+WFlWSdVE3z9spcEHWWIP+tHwqbfy4cQTNPkoCHAiH/66ivww4Axsi/uF00G+
MmqO5D3uV4+35tvva+Dsk8NK5e6uGynZZrylzjrPmm+kl7zp6Q9QOLtq0iEiN5umIxyzibJ2zN2j
j4+jVgrMNPIVYsa9DLva6YtXnYdReqbOwqg7QjaeJezFfhkhAQKocOBSF+i8b9tCo0i1p4UKvZ9P
DqTAW9RQmz0R4Gdf8XyaHEtWQTpndDqlVHs8OTgbMXrxgjua7sdo+UJucaT3jcgw/6e0BrXlMUCb
X30HKLYjLcpw/ApDL1TWk5PqJfjNQsylL3XkOJMMmIG6plNoT9AkV7OGqUEJ/b/JKHOj+NbbQBwR
kPG0ON0XLfd306SG6o/BMYTPcX32H/ZPeVJaravgbI49KqJzlpJosw7+0SURqYM+3mkhwpUG/3/h
wN4XWuz3b4xXe/KLuPLK2x4p4EqDRdg7m6A53o++xeGGKReRWCDQzvJyfCBpd4njYChjQlEESOgt
JM0iGgAuNWHMzuzZycrqPIp4MIHhWrt3Ur7XAlA65hGIGrwTR+Js35LnD8qk2Vg8LL9BYO46rV9b
JQa4celb1Ukdyo25Tu8keV0Skp3PDfOiAI4uK4HZuqLhJocNWRb27AJMALJgYRQ+KrL01BJEJOZ6
eds5xbCYvMj3Ins87mOHi8pRgZ8YQ3hdFIkhI1ajQkDc6iaJ9FKJ9UnKIH3DplSiXovo10iNBpD0
lbybFf4ujmODiYJplTCniS/ZcQeTwO19xo5bc8XqwcFBLl+cZx8ri+o7ewAPYAFvVfeuo0Kral6L
kOeewex7QUpGxvvgWkQj/TSqKIymVsolZLBz+PlKRHYuylpLp44EYpqulInYPFUlLXgffM+I8LoY
RE/dWJ+uSnK8RqmVos45TzpMEsOGaK8PJjFPdz+trxSxMV4479mYdZlu07fXzSJiXcNSP+NaQe6A
Ve+lR/GEHeKCVwUtXcBWiAx++stR+HaSHS/CaJv0llaH3L0FCeE8Tzfwk3e2psKph7RC0LCCRlUh
D6cr1d/TFX0AwiE1BGpZkcH6OwUIyTinfKkr7X2tXb3wdaGIkLGbXTERXNnGLnGjJfPZNstDyTtP
dSKw2KtDJ03nPSmvzUywnf3BTwshn7dE/7Gd+pX9XbSTjzmP69GNhAVFT+WeR/ouID3aPfbvcnar
+8eIhuAvO7lZZSP06dgOoDCBhv3P7dF7BsdlPDo7AkcMl/rDwxa1Tn59CXcikUQ4HOZSD5tdAE9C
XHxThTmZKelbazsBQOOwnMOSTN1euUOwJjK+n7U5jueo0stNY0t9DI/LaFASKH1KlyCYVjkgC31l
9SJ/sL7ZYWtJMoiVdWypnQamqFDXc8NoM/zyQw+ZfjUwxprqC+ddCwu2g+7okBUBCSpv9CI6Z/2C
+6+piHzUWCgRBxKVPoazQC1vFHkpwZag1zlm4X3OwGsBlS93euxkKPbAviK6MgGlJho2T3Z7zDGM
hXlvRRgOywwchofMRkrBca9e5udi0yJmSYjdzLQVnVbRN2WKYABeixRDLXamNvbFxrOsWPgN0VjZ
FgPAO4TGtoRI7qjbSas0o+m7u3hh1xJxScr0LKSkOtjU+xOfweQQ+csZNjhIuv+q2puGLYpaabih
vvL6NL1bZB89PyvVZejCmJykw5sujQnosTOEbSj/t1rTb9UHMrjwRwhwtDsICY93U44fBIuOUMeU
WISOGB3cohH746mhz/UJVTLj3T4m6issmkLYn/Zq7x/6hgQpayvK6QwN4nbmlvDRRn30MgngqkQD
O2qMvvx1hhFn7E+iQinhz/hxs8UcjsD5Svj9IHSfnffXwHvFBvdR60hJ2j4GhniXqVzrqembN9zv
QiwpfukOrcU59W0+Kmu04sxNooiv7sRwZd/lmKBRTmvxP5d3PLAvxoUyPMdp5BTg7Hf+E8nA/fC1
QRS7kwICRtu4linOW7twZI8IixIgXEa4IJSsu8ZTiCvCGkqdbNI5rbZEh4dIpp4VsGOlE6GU6pcy
jKKgA39IacL4V73dgP+8vICEcg4FyMCC+Y0e0tZ/pSfAevDRMcEXIh40tzaBoxVYbokH3vtZFKfZ
IHa47iiH5oLOOdWwimn5yzNWrJ6mhCcJ2V8rH5YgZsvT9Je/C//3l2o54mh0/77jBU2RrzFBU242
FxHmZGGwB1etaPgvNiD5d6p+694twkKOvIOAKgsekzd4pXf+ncjVJXGQHzLZfkeaAz1YqgMwKPnI
8vidSqQnezDFztBBlvRx0KCvB4kn9fNPy8N/gwva4hhRXJRbnpcy/l2ko/svFnrYO5SRLjpYuiar
EjVuWKqNH2cKaChtkhI3XKzGZqr7UBHMncKRkI8xm+eMyPKpg29iRRy1dhJ3T4q0ye/y9HLNUUFB
9ngDx7lMnzYiX+LzXiWElBGiVzdBWtdnOJYK0uSe6+GNqFnPuVXVMH3geUdv935Wjf0cnAyuQUlt
3j3jE8GvG/YgPkqEB25o/FAsfnDC67FHsVIWtZcCFRrPR9skoKpc1gvBwvVXqfFGDeV7z+T7QQTJ
1b2NIEARFu9OxSsK3e3eY6/QuqVefZP7blP5zds8NNx1dsk4E6zy9dXwlnZ+tyo1SAiCrFXptOkf
o/guveWT9Ugq9bE6sigWQ28ZXqjOI4DZ99/l36BvsFZXKUrHeie75W5oNy64RqY4+MHMTlZYggyd
4yXdmCmGFk9guihOSbNuTRBlAjJbYwat0EDufSSK2Du/37FgpP9Ysoe/aVShZf/RHa84ZWykI4aa
PbNHAPpa55fFaBv65KKO8GnB+IbW/Ctpc75moHKVFI5A11U1VpLAeBZ+pEdgFfkPoYQS1Ap0I5rD
VNo6a4IlzhLt4lYzQZ6PgbKWM8u4FondLMKrnDyAEZaEkxMAJVpgwS6PR0TvAXYZxsp6GOS5t9wT
z+59TNaV3skauqPR4GapHEBvpvqu2GJTAogHrdr23D46wksHn1nkdvgqC/1d0Sl14x6IVaWtOuv1
hDTl3KangCmDkWS5iqfZwpEcVSDU/wa1QFXOS3C8A+3dsZvECe9+6HQSQRxdJ2qPw2Ik9corLbE/
C4xnlkC56hKlFZw1lRw3S8q1Hxpep0eeLuXajs0l3HF7hF231XC8nwo+UkkcetjbTHBmKRWWd2Uq
Ffl79gJMljDOp5xul4am2p1+zGYflbjx6D1lH09BBzejQTL/UNzoXgz/29g2YzXCOWxMdOore5as
4CQ4tG2qHzLC65IRfQDDM8ZGXbjZGe8IP3c4dlv6VJTp20tIQofSOvlcN2CvtgWOOHMPFNBlaZwP
dhvEAhudPE7ZmgyE2EmA96xtw0kwjSxDvXaf924szz7VR7s2h6F+EFk/Yi+yHlTRBJC67L51QN0v
YdDNt4tDSH/2swDjWOiVHhujOsrp/xMyDkVnDZEFNuMQoZDA9lBKsfYeFVzdS0MzujIe7dSNFk6n
3Vgd9A2RnCiWK1RJYUPF8LREhWWzJsirlyK8aS1yziNj/6SsuhiT5M9QSEavmcvWEOugCF6No75l
zvfvATozhbKtLYJrhjqnKm3TfvMFCbGOqo9NKLT937bcxyhPPy4DzWQgXmvst+puDdqI9xpKZy+L
pws7Eykd2jAt2yCwQX20xLPgxlGNZuS53Icli/BnbD2vFKKZdR1GpCMdYZ4LN4cXGtlxBhMXURi6
Ql45/FIGTN4baWeVGlkLvekuBjfDVIhE8/yxwG8p6u96QUQqfpu1WQ0l23FH/dIFHyOqGJGSZkhb
FihV8bK85TyeNJIK3RL5/rJSR68htSL9aT3tBrSYiRgYbaOeeZDkVV88v2AVTsAplUujagHRPXaI
M2eMXDHo2Teo+K47icKTsBzyHHnOfSerd9z3BPAEFTTUbt6DHO255ET+LINZDe+8NvxxirujHSs8
jGVSvZZO8k9aEHaxkw1jTrtOUrHhm0xdXUBSLpFlCZzw7ohv2of5z1FYAn54JwioY92bQf1GSIwG
IvSE2ewGyL/28eMzixk37vSrHb1AGRnpnQul9moOPLf93pGQDjl4q/Ymz8q3P89jG27712YP7FQi
vs0Za5mU/n54L5N3DSfxHvRfFIjMBI7t+fsnVRb1xZDLBrU7D5vjEiPnvcN/X/BXxg247+fSrmUh
FutsY3XKP0g9Pc5hebrEEHe5bGI/dn+mwWcf5m/j5oeL/hNTn7RJWuUNxMe7gcq+nEOdRDxwYa9Y
1heTptiA1eUlEtxFpFDQQi3wHp3bKpLTLVlCsq+uvIK927l5prci3w/YHeqfguU5OsOim+eWN8zV
klEmt6O6c6X/bneZUZxoNbQ1UDaFa2keqrF9VyUX4cr+4kba75rChLCVFo/5axZsbqgSZpeBVJyG
LKyFkMdxUmBkMDtb7iEo/s6Eh7+xjGmJGHjx3p3tfmfioPtEE7stZNkt/CQwD39v1RhHPQZ8Glsr
xjGaSG5IUse1DrkmZXyzI+u/WhFXjPsvHxeWSsy5tQILqXnp//i5zEkYkVAtEZ8hib02Ll9itpMx
ZdUEUCOZzpqiW7U5UrHLrT4OHebS0hMvxzIvRIxvBJRdlbXrdmXa+0+RehihkRVeDE8kRgJXGWiJ
uChHlU26Si3+juJjzamw++88nczjjP6N479qM+j+lltF9WXnLKSJ+Bjj1IXY3DqP2iWRD9SF8Rwd
Y2S3AiEeFmYjVC2NntFOJYK4ye5MxI4fOLFRGHtQJs4I5YRS2VS1NQQVGsNMkH7mJ0eZvM51A+M7
DQ613hjVLGCQpFwqDcUq0M9ngqWlx8bWMNIjYv1P4C+K56jILboJAFdPnemiQTW60lYyXZ9hf8lX
90OD0Up4gYc9D0cSH0y5SFyxTpiOWz+la+8HkLMCPIUKo/+nbwoIKw/X5FT5d0D8H44uxaNuXyQo
VI05agy7fVymV7aAadYfVL/JYczZiajY05BhfhwtpvoVvp6f7pKnKRUJ5xb09tqucIaqCn9WKWSO
WWRb45LkI136IuGmu2CthZPT7Lpn8VkdJ2HmMjFwpNsSFG9JfSweSSzWa5Fed/GCYxeOLv/vvRSO
LWfl3pX8HyBOtQtFajq/SefazyZ4sEl6XsgdETnellsd+Ym71ULyfvI2ExburtBMgeBTw2I3ifHN
m9Zwz82zrwmG8axb3Q9GUEHh6HqYs7QyDHuESF1Kn40OSjLVM8v4RfQUms/631DhQ+L63GB+1zsd
IdfY2w6RyHDXFWbtcX4ODqdwy/vIsQSuq04Mj70Yu1eSQtmzPR7KtQ/W6xypduvpR/9Irzf1waHk
L89dzZzmkznTfSWhBToE6Bx+OnuwqtWngZNu3WDOfabh3I6zPz+krap/jQxNIyYgMlMRHlfWvjqa
cIpuBVHpva8PR48TOz8Z87G/WoIQf4e2Id7FopWdg6w6ZA07iPSXPZcCiUJR5fERSAaH+6qu0W2r
K9JdOzSAxxuYkSTiwRK9ZmOCAUE3G0rDVaRnCWWWFsIRfuV02MY7RTe3v7NbdDtQ0qTcbwDqOA3/
qe129iXk2WttTdq7ykpnQBc3Vm27D18OO/n8MY4VrRCVCIPYuUoCHsUxZqyxKFJbg6cLzFA5zvdW
dD5A2d37MiFmryPeBCusp+rdfy43C1QR4S7lyY+to/2IISCDXnicKS+7+5y0UmYhXMgXRg5ia22w
7gerri5h16r0xTs+nnjZh5vle3sw11Qd+UV6Uv0GRyQX8tIzmnhg2uxRQIBxV7AM7p9GwAK7ZNMa
hWIrUR3vrC+WowucUjosyt++NgMDDuxTGJTX312HGN9e18PZ5JOIgMKY31sU7hGcTpVrP9iL65S4
Oycnuc+Ri7QaSExpRz+hcH2PG3EXlxj/DANslKAezoc0+Tee8kO93fuFvVA+B6lps1iPZwijmhHo
eB+Eic9uwLSMxe/rkU68/tpS+F5WhWCSrD1xlkPEO/P5BhqutckgpByJEtbcCSMcvigb6URl+WiP
+b1Aftotm6FhIwSjCwEis+klGmh1Mww1E8JKl/7XOGR+UuGg+DyXBTtSkrD6T5/mhRqScu9dmsRx
Hwdozy9EUhp5EU1NWyh/C8844geAgjC9j4BT4qBstkZQZRAA8e5Y3/gPH0ZRg0TZoLaHoFyroO8P
BFtgXBOnqBbTaJygQADc39z9PKg+8fiWJ2zkWeDuvoxYNIS+fZ2XV3qm+Ocu668aL22WEqUXA/iZ
AFl+w1Ui+7KrkNmwWyk3lJbvmY20TeDuKRanhRqqIso0896aTqww1nsvxdZrMx93OONhdtvgep8m
ycAhfq5paf28oxJ8qQADju01=
HR+cPm9t86Qbq9X9nxwrHHchDMeTHsgNNfwYhBdFvZC1UncfxruPXBfaVL+HURm60O6Jp5axA1+E
pXOkRCgJIfg+gq4nRhAAxIhYYRvgEpct46ZvL75XPj9tzey2BeAqLgDfsCWgFTs3gVcCLUdeE/SK
94IvZhdZxbrwZnCLW//ChV1pGk2UxOqpNIEPQitnXvP3Va7kS7fDIfflRRdmPNYXEIhfn6sNyY5B
57FjgU4F7KmYWIh1Fy8MTpe08xi6PpGNjSXU2Ow7U2bomosK3HvXC8bHeFmVp38KrsjyMEOviaZz
q+lWCjX6SJ97Hd19dsEfiGTRHmRH6jnwur/Vv13aC08uTr0enpY0N3BkPbdIuHeKXIIoFN/s/pIL
w+feNE62uFhTRVXigh9sjBmwUEKL/xnBrbYUCOSrz8vu63XMTqLhsIF1eqC4i3c35vWc7I57Mgr+
ehtJxxGsNMIbFlBz2grY7yMwXSqVw/4+DETL7Ev8bi64cXa/T/bMzTLxCSeB9X3SZr+WDi4vzJRC
B2oyfryo8Dgx3G5FUgHz54QCoesiePs8hsvk9sskSWrnWWDwSy0GM4dI2Dit7hyf3Q0Wf2RQGO6U
zpqU8hR67XzRNAWsFzj3nGUFIet0Y9zy6n+oYUjO5OIEw7Vb2/etWwh0hdo0tivd+ZYi18BLo0Nv
FZQSg+MRrLxVMrr+cXu9kR33PV/OcUcYxHptSWaKJwl46TdNCps7ek152GD/rPVO+1s2DJlGZ/EU
35ICBqqjpnu1elHJoM+htLGjxk7oAMPYf5rLtRjpU91r/XELDRKw4RdvyQ1LXWVyvHi+PDhj56+G
hm4KE8LkqHlD9GHMIGAVtVD4k7FWM8FPiUXR7LXeFlma5wfsiwiUE4htG+RDL46s8T0WbHRc/UKz
hAqbyC6X1dIRKHbenkmRzJSoq4g1xnLnTvgOfScKas4x60EPAtrQ7/VWo5+aIDw8NAJYu7XrbKPw
z2v/qCHigmLJO6jWeXXSf3D8fYfOKnUVrPJfhQ5UpWS7tGm+4qdotl2hAg2hkFKWSTJQAPiGCqMU
x6m9NaSOGYn3tw0/Z1nKapcF5yrZymDSFzMQBJNEIQEhd/RA8WCKzycn2PKr6rdIntOukgv+4Rr1
9K+bFZvlLnLPfk3ObW3wYTvTiuk7x76kKv2ZSVG4G1cy8TEUPsgYcSBVk8x3vW+0tFGOLdN7xswT
u3S0BnReH3Mi6Ddt6U77j63oePVM3g2w65z1Xj+fefMZnRKqbSgt4qbhAKAYHflaM9IkDHKxw+L4
XsgtlOHOxcb3HSPE3WFTugkLfcGtj4+L7QKDyaY3l6mx7kIAKs1J6Df60f8CEPNNUuvZETESs/M7
mWQVy6FawqCQ+QNwrMaiNV0tf6UEUTppbCSEarp2rC1o8suOUxrbhlK3RLu5gVEAxuFDk/k0GvaT
ULStJWW2JBWFkPSjr96McbPNgMYSoi3NkPD4gXZD0fW0p9U7SCoAH0FOuEI0Ea2ps6e2D+vgEduM
5K8vZzDESHnIWbF8v22WQgylSRQ74v3X5KU+H98MxTqvRwA+SMhQlsAqEb+Uwk5speTsHt3f9dED
FUMadXTxV0RsNvs3ol4QRjQ1dmNZjHHWWdz6OnDlrDn/BZC5TyBuLhSVMpSTXoC9S+WOGb7X+vPC
yrGr6o1rfLYrHgXdivzHabN6MO4SRiw8gJSxRrKbxcr8+kJIY/6XBijUA5xvvcM5uLFv79QWqVWC
TRfbNr9mI3QP0dO4UsJpnQSG0dQg3D1QnGn86jisjM6NOeWR2P5MByIV6yxl34quMwRINKYr8tzc
HIRUGGCAtP08qV7G5jss+L85FWpc0Yw+TM5IuA0DKs9hb0ib9wv4pFX62bNZs+rItwiBeY2LTP75
tyuFuOsk7OTP1Ca7H6bRk0vIKN0dROsyKZOhJjHx9XsSvIGd9f8o9q1ylO10E6rM3fAuSPp6jEfJ
PjCQRYxY/j+TPYw8JbYf8/ujX3rAGEuf/t/xgDR5bogyJLZN77VYZP66jBmPRMzvc1b0Bl6Ragmi
8U1LXQNWJoYE88Hctq8sH/bytDsQg4Oftw6KKgP7iN2Plroklmd4VOHOJuytvSIh6voviVWMZAab
D3Cn0IkdDV2yfccx3xLcWSReA+uWkZaGNj28y21EGsVzE8xqmiJT4wjR83iBBrHhPAaSjxbaHZgl
DjWQjQ47kFd3VdRcM0VxwWDfB+I0sxh7oQr0CAZIt4ycjaP1sFD/MI7aeve0dNT1JOEazVE53A70
Ziw6D/PswbHnz9/zhXjrIfPVNJbAUx3vKEC6Ml2Ct8QaTV5Kx8VJ6Xb/buQ3n2VGrslW5uFbwd8E
+ZZq7n5q3fuhckXzCmVMFk1fRMgTVlO/AgvjdKmUZL18pqopSl+zkY5a6HwhJfLlqoZr3OI4g4L6
LDdTId4tb0x/R+X4c0aCsy1EDwiPSvDWdPRSaBnFoMV4ABXfr5oO2fH8losx1Vr7MfGPnsQXsZP+
VHp4PxyOoPeaiIX22w+LtfAeHR6LIW2NCe7eQTWcISD2ANFsn4Ctij5A56jvRykPh9tz/17n6qpn
D0MRRXtq39pREPh/MDTa1xOoHMGP6BlQAjIs6TzfyuGJKRH07LTjLRFaIG/RPY8x8L6At4YwEWcJ
Qxmm1M8H4JZnX1CecQMNg+VSd6Ck3SL9LKo7dPpwlqrNFXbPARag+k2bjXwej/lzdggE+LzAbdJc
UmAkpvTYIYtFGdAl0L6MLSGgoS2MdvIg/BPczKMbdJ91tMqWVlDf6TrJIAUZWFu0z+HvuOo3CARK
eFRvSzaIX9zpqrdF+OR3wg4V28JYJZ850NRG8Ju0xjdIwDkzv+HIM2jf77mCC/xyL4yAKH8uYY2d
sM+4Hs3Z4GpZY5H3PZBSz5710qplS1fOpTTFoSF9tzMAFL0Pxq2pvBWNXAhz3XS22i3yBc42Us+0
IQ4ocOw+y9AbORzpDc9fvoZqfaIV/KFUWMmCvDvr8+8CKWMYEwT/EbK9FzvjMfa06TioKH01b/eo
Aop0krbtYA1/JmOk2jODfaJSWpx+gNQtW1EJU2lKpzBjvKtBHrU7dvwX4C/ze+w7GmUkf+2U7Yy4
LeaZ3O/zH0LAXSxneOJQEF/WJvC4B9HZLTYxUZbvCSRyF+8x1bG9Jb7dI8Du6Di/CCxS+ptXkPwM
cdnIj8HGeC4w9T4NbDVFkld8tqffRT0RJgK/VZiaCpq4WFiWD8eTxaQVL8s5lHF9lunXMaOuniRx
2ezJP5gH+17wpDIN+UH6O6O5wGths86+JkfTJ3T0G/z2GirOdg1JaAxvUQjmveH4KdIjXAPIwxWR
1iUT+iMs8TitxUqYjpGKIFSqSnikYavVCIWAEN7RRp+Gv72Y7Kj1eGu5AaGqxGsgLMMBkh3VdQJ2
6Oj312KuPjhk4vn1DqTOWRyADz4jtUq1h7hzH9yZ/tzNd3JYj5Ia4TnwlxfPIKbIwwlsniE03g+R
xk3U+R2FSTV/7qbmjjQ6jFniP+HWUDbsmNvbxdUdpFUDrwkwHcAP8nJTgXFcmuvPMO1eCWPX1xVI
+APLFX2PYtwrWFbF/EhK1C99UysPyOvGgoe7bGDRS5mJWcjgoN0s+NC1bdxb6yMJuxlqbxlqMBxR
/+lNFOObbV/i6wrLKbJpiKHzYhcWOi/+XFLrq8vt11s/xc/YDchUeDMi9l917seqk91JR7pcb4Eq
mZ6Br1bm3zL9z4Au5k6uwGY0l8QqdzahVZqUZSE5JUeogQvq1k/P3nhv7/HNMN6pk2DySER/Lq3x
PiS/CGqQwcqpNaBWluD+Fu7iQbJ/sXlG2LdXOqiAhXTXOk/Ts+HHZWTJ+Yu/v8G+PNwe7pgrc1sq
KzE+fUlm9iSUIBBslg9drbIazfs1sPN1EIn/TM+/oaHNpSV0fu+49oiZyd3+A9MoOsGV5i21071T
zn8Ox+DwZ1TcqrJ/czmbCpGs7i/wfqm39iicKBFCTHKMYbzAFo7NbUPmO6MmJOmp/Rj8g0Z17uJf
KDBmHPUjk3jgyV6Gha+rxKLN10RGOpktVtQ+s9rNvVwtJui1BpBF/uEORdGaKUmRdQWfA00g+F6v
fTMRSPeVSmL0Zvq6YOGKhZ4PC6mfMDEyTkLtXGCq68++eL6aYz6NOqq5g+KVcB7d21+48F9BHEA7
YzlFvrufWxcoy8+Osi6rG50ZzinYYm8BY98w7ZHMgXphk8s5k3a4aPnyGU1p2XJIROy0BaxxQkMT
Tvhx1cV7YcrktbJbU8f0IUP2LCLWzAaR4cViIkCGvjUlrot0t86SRutSGEoH3f50bD198ivLSVbP
Jo3VzWtAowh+dmmq5kTvn1FzaN7pE47Ywqg7eEx1HXZLeFiKgqqNJIZPjXYhVtG6n4nWXYOoMAj6
YKWoTZPG7LdI4hnh8J6XX3SQrjmn3ZZeNco10RLfw0MjJRZPRUCzYgrkaqAX+g855wjZOtvcz4+7
/GLS5PbWUH93W2QdVVzspOEWEFHhKyd+dAZxwq83/sKHI+7Cc5K+tLng05kbYjeni+cvEeP877gd
v6qhqde8tif03mfBXNftgiPtH5petv7WtUfn4aZEwJ7/73DHDLTsa45OmYEmHqwUd/t2n0glfbxw
k/7lo7PQKwXVj87bs2wRjA2y0AgKyMjxSMDz4IA/q9X9sTkD2jh2ptFkbAJ7/RT9O+7+m3jLUqKV
2nv80BE0CogXa5ebKlRLMXxBNKIpQF0B1arIFg/FdLXpcdqhKQXeUGMGkGTApT4TS7iDG3tXxvPW
XaLgiMZVdYbyfAF/0nGsEFMdtWn9+o3nN1n9NRdos9JSN+xj/iqJ8llSkksS2iiM+cKgysG5WOY7
y0y7+8UCaLNkReyFTMmriU/u9Da8FkmVQEgDT7+85injayk85UwyFc4iVhT/6wiQlna/6GupQwe7
pej3Zk8RGAUfABu9EE4YaLCds+rZyuHI9+oDh9T3fxm6aCZjXU6+88El2tvjTgSXHsAaVS7ssWc2
SZFJSTV12R2LNNWOwWLG9uePrGUzabszT173IQZ9LAQSV9S+cB0F7C4s6RgSl8M9EbZnje4oL6wx
Ak/sUPkiStrm166FE1f6Cgx5YkrCnh+7yvSWtdi2wliJpwgRzArrIWZHE8v23fhYHhEvmv5AZN4X
56nR0qMcAKm81wWPTQz0kb+ixmqrMB3FYpW6B9gw0GtpysLNDkDWnlldlnwa4s+6yTLVaonAtXTi
tU7z9h8wGils3u4l5NBhcCHJWeBdNXyvgcuGrWJsh0WuN9NIiA6UypBCuVSOIZEyeeBFzhgobLRN
MdA+hoRqsmF10V8zbuld1L70Kq+wBRD88YBj7YoJiGQ03Apuxz48gq4LYG+Ju6gFZ9BApeS+Vvvj
UVL6MFdMi94n7D0L5yDuhn8EmGSNz7YANrEumY1BgApi0gIMlXC1jw/eIfp7hW1AoqnpQ1DU3rQo
4naP2iBoHNwDmRRsU2NlXKB6sW0ndwQCvMh0ViNGcZj30og0reNTYT/VCvj3JvIHA43A3Nzw3oFx
L1Mlv6JCmx4xvoM5890QEfQiChKe/r0TRfJWmq7ClXAEWTHUpu87E8XLQzubNmctT6XDg5OJOC/M
BhbgBpuCuhwRBgcxo0V1oazU/MHgRZbT2fWBFJ4fpETn7ltFl49E9Z5JcPrzIToDtoBTzASqitnQ
/53CHfSqcwALiLbe9tKikI2yOktGFQwhingpc3/WtS+52s+A0BOK0P32FjCQwed744joxsDq/05k
X/dOdTdS1+4XBU296cm8oe4WYYV/sLV3PNtue/3kd+ojg7hZJi3Uv6qPOA0fwRurXwfN+SwLgAku
WCXSBqj5VT+VW9SHKj9FHiQ6iqtrBt4pBdBRdUi+dNZWM2UA7ctslPVycUP99/y7yrXKLbycbaUR
pZQi5SJE9oI6Lw/NBbL5XOc7xN0rTRmeslEmdagrLFHVnV3YRZ2vrU0zYTNBZl35C4Mq2TUGA8m1
e3wseWmED9Zkvc6ksAFp9+tnGOyQc6i/gaFmZnyo14XtaUJx6gyBWWhCH9EnY02bYdRJSqknY3AH
zFMSMsBD5aRtwbS9P/dHZYpCR4qpCYR+Z0MQCepM4yhMSkRK1lQLsO9sMvuxe3Emqh8VzSRKduMH
26nDTYuJbQsLmBYQ/fa64rVQqf9rmausuLFBZTItdo4pk7BQDti0fFNkyROtyOjV6XZk7JMu6/ft
7s4pGz1LOesoWV09oK/yDocxjIQ6mqcG6lzmrqteHo3WR0VWVwP6N+TYRWpqblHaK7cTsKVZCehH
JuRj10mKIbIjsUvC+iv9pMxtGDblPvOttVvwxmn++zhaGSNIknzETyZEebYRK05gBLZeQ6nwzfbW
ohB2AjKvLGGl5s1eXnE/xp8Yark+rbf+PcOd6YpTruOYyID5D7RO61yq2s4Daj2eiFaaL5WspJG7
kuMWFYSe5KXNdaB3Idb7pe2SEdf45c4QQjv1liyB2M8OlNviRa97XEMngGjNaWj1cFtizXUlP+ZS
VwNJCmFHWN4aNhzyHmqdOQJS4hRf+sM9sWB8S6Cl4qUjJOnE3eS72AW0bEDaSM9zmxHspLnXjvna
Hitk4UV1Qd4H+y2xd7KW4hjRSLmN27O2c+c9GwtCueex2qJj7ASX4ANQEWOBhMoB8TO2FUiZV2e8
D+KTWSn2TknHUx8XT5O4JWe51+7gB9Jot0YR2egM3KcyCPyYm00enUWutjS++yiGfMz6P1d8P4P0
XrPSQQW+3p6sz91UMcB+agQWSAcbHMGY/D1Fo+t8mMagFzqx/lBLLp2iOS+UPMKBV2tf3DWFTpig
ifU91mEsPsGjIO7R7qSShKzQCA8Kk4iR4q8uGQY+YIJ5H33ecyQbGysV/8MQb+NIRzXNc6fObv1+
fAQ0y8kOne1fHYPBqH62noE4YkzBsBx++v+mQX+K/BCzWHhDcddElDfkAFHh4HG+AQfX/yrJegoi
5vPcVshDXk+caJDTTGQ23tdvIJenMZu9Zg9ZeKzR/slxxGTvkzZtz0IEn1K+uNlk1hRHmbw2gm2y
rWFA8WSRw9NYHOs6EP8RGR894gdPhF76NtLDzte1z6hC63M/Z9034qsY+mTvNCaKFuf91uOJ5vPO
HRvg0fKCkAtvvIuw