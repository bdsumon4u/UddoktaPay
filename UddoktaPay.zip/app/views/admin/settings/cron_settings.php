<?php //ICB0 74:0 81:2de2                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPww+dIcREcOE5MS82aIucjt2aitvZVCWeUmHA220VMk5QwIQPsyVx1gDTeoTlLTuDWpKVCci
Nv4ovkJoQptZzsZLYhKXFsfvlgdYdUyhZ1lWNwolRxluD+I8GzUJxaEEaKN4hLlYmsXJTPZcbZ3p
Sj5ZI+zIQs+Iq1aANWzjQsPSOdyEGEm1GcWUivAoMLxNYCgQbQY5jYEOIQs4q2oBnSbho3vUAb5A
rRUpqA06tCzu/MvFPJevdoN+jqE0ejItn+QXnul+zpS+MO/ETwJ4rhfmGbMxSi7Pvz2KIiQYU2LB
nsbLbbR2o5ka2xbx+9pz60H2xLODNxby++n5x/2EO+eHUyS140kXkh2w+47FIN21NeNjNaGvfFi7
Kad29Drbt9uCJwwvoXU6H7dwSNcEY4Q38UghNeYhsE/u58qP9x+h0A97ObClR73gVXAiPCA+ZoZN
C8MF2oZscDm4eoAB5mrwS7uJQp1IIoIBgknD6uTBn//08BRVuxMxI6Ax1tV7eX5Hx+B4EpuorKas
BWCa4YaVApy1jdkYYDR8aAhhQpaj7TBiu74swGjDUw9Fy2NpD8TzCFjlkKWzV/Q13GSxh7sqQXvU
KZ9tMHuNwofzabZMD1IlNGJypAOrsihYgFmOhqxCcpDl2XubASIzXSTU3yfT2cjUNI61y3/4Ych8
6MN/YWXFR4UBsmY9SHwab4JW4nsTdme6bsi9Nsm7NQ2zIwwxnw7cc8+ofQFPL02vz39SH+FKcPRE
vdc9oZdEGaYuX7ArZi+vt+9PHaoWIcT9ZTZ3OcoGT17AkraIqVsvY1JqXP808/H/plKTSDZg2A/S
y7HREoYihcbGPdKjoSTBxcQh+lGVb4hjf3UhXuit3pOUD8pHgWtNjpTKdIZ85rcgxjshKgppSwrg
W9VMl5c4fcvTC84wFub9hpkZYHo4LlMQVAHnKu169+Ct7sAnpq9dASw3gSeOtWmt64JbyzI6KCib
eQIRZte2oLPp5+qB+dAIYFAwg4rb3omvLSaC9tmHLj89OJ+8pHOp5KmMy/qcEoAHjqjvDivOzR0F
q/mWX89nwm5JapJindO5b0+2kXiFPmz88F7GvTeT86zhZX8hMTKs8QGpDA5PujRYEoaKI2bVpIPT
BEQ5nUoHzj4L5d2iA6E/dqOz4VowJ/lJcWXa2/v3cbd17LiJcldpL75QPSJ1NO45LkhjT0PFBVN/
FvA3iuBdgInN74z35uIDA+uMp3CBqnZplrj30Oq5RBSHCksgt0BtUO4xbM+JcLC6LyUW7n6Xc0Xq
qhSUQbN8l6qSZI45wrsM3YCiXOTH57/R4hrQl4/QL2Bzg47BMuH71utg7E7eg3Buyt6lhXRXRH+1
em4sqMDRuzJdcie2cQiB/gE3bMKelcvIhq3coL8epjLCqrvxVi3cQDk/nuRow1UVwH1hZIdHLSwe
SvZY0vQ8bjtEotrrZYRnD/QKpaWAX1FfNnWDykfd4bzq8GOPkljBm6p2LzN0R6NRf9IeQ8qD+7q6
HbnTaKbItGuodceDGT6bd0lIg8OXNJSEMOHrjkXBURHRUtSU7weX0EnfHM/d624n7FX4z1QSvL+X
MCNuyvAkqNigwWYtfWc13ZQjtrHtcNc6TH3AulV/FIsOg9hnnmIF4rEJ4/+GKRFptpu0s+rjibL9
mWXe/VuCcqe16yMqc/iA2+lBHcVE2ZJwkB/fb+UdVFW6xU9vOZV8grMDCK+rJ7Ud4ybACSLaPKUY
WRg2eFtd/zWHJFSSc1IzuBJC7l0jtpQdxWXDNIRZXPkb7UAVBoWr3K/9ohfsirpF02uFjhHoYpK7
RlMLDmBmhuqM1mXz4ZDA7DhSJN7GOMFumtYkx95NSZLCP5vcDj+4LKr/4cGWncI17t0Eb7fkqDKb
EFMCnioUl7V2yWeNsD55eIgkpoMwg4dM1AzL/fFB/XBPgzh7ZNSI324ZrAMorrI9nfyFAivtWJzG
HNOHtqHdCqFY8KYN5HWExq4olK6B83YQqvYslFEOYYaIwZI1gHbVn9R0W/xNEH1Tt0GrYJe557RW
vmd2idCWQd2aykbV25KtEAf8C/+Kb7GA2WVlmVi/h30fL2o4qFOJY+Ox3UrXY4+DgPrfEd4pQ9Ro
0Ktk0bHKUmXktfR3CtvMNqQQcO6MXoiCUrBFf+8/RGNvzthjJ6h9rxBb9ya1SmpMvczhGWihc8mj
a6QoeuVT/FdJW31TvovDk5dSVFpkV0xUc7b5TUJZuBr1AM9GTMCXKmZ/Nw86PY6/zkzRk7TcjAnf
419XTjleIm3f0UcSEL4G3Fd7QM4ZXhvaG5BBw4VI+SAwWX8WBq0Ygl/m2H96Ay0Cdj8Pf824JaeL
Jg0Ae28aA+RYo1w6gEWtJ1Dmfz/sIPu1mlKO0+0VG4JxSB73kjmCIwDzDlfDiaLCA54wTPdIxpbs
ksGij8Sa64RGVNrXL6tscseTQ67WswNNNHBmW9nA1zECsb3MxmSYCtsAmtRAGzByzXhSd7nHWOjB
O0W7cuSO6pGpv0vUDIKWdvp1/+tvFoLDRzYOEWnjLuS3SpEQzrjT8ZR6ZTTrO949bUiSpdrmzytI
WuYionA7bKxH5Ae5n9AfinU6TjjBQS/ygfT0tda9gxUfWRX+5/cJQnJ3yZbp4mKgLdRG20FO29TL
Y2U9jQUkTmR8gCTW+UUrKsr5iyFiA4+QQLsuTj172FNP86i8O/mbjfpCl1qa0R43BNh3rj0c6wpw
tsGPPQrqGQqpDw3/J0OB3RnS+ra3QYfH4njBhbpThM/bwvg/MZ6+cstlyk+qqZf2Wj8er7ZfQ1RX
XpX7vTmr1LO/qChZNooPDh+YU5k7MnN3qHsHx1AWn+kqRNQunM8+SO+KGcldVYhhYc0phP1GOdgI
cbSSrU/50ToXrCDllZN/6MERgz0ajVu0WZ/MaQCTb2mgxmaxTZg8hSFCrzuQNChfbZ08MmErmc8b
QCu70Z55Wfkd2hOUyFz7MH0+e44J5Pk9+xVY7BQkQDx43i/SLJGAGMMTkxl3eNXWFMBmvB/YB8vP
bXK2HdKrjg5PRSmGHG1mZ1n2xSM03NK5rsTEczIfanmz2sY4A70PhQ5XgcS8lCnzykBGm2VI0rgd
YGPp0fMVvWW3b1PDzMTCf7cMjDdB9N2/9W9j5B3iFoycTjdpZobjCXkrmgEeKZlq/Uo1yZGcXu/g
Y+kVs9zEqh36kaHWSd/q8oxfPgdEkNrBCHA4lYxPuyU3iZiSI7ux4Vvgb3ZqT7dLLkTCapOEdPIF
uzzfSrBu2jjx6eUrL4UFhsPI76YWAxfqMVjpPkJprbGb/hnWqEazPTv5Iq0lUJh3xN8LRscovnqk
WIZYFVmWdH+nPEAN4Ds7fudJv+Auio7XN2/C2NWcR3WbaTSxAcxiJV8UBIfKc/aN6whitiuDUNQs
ceyoPsJQy+47J1aes/gWo6TDVzfFle2h4bmGJXMkz8fYHLSq6H6nfPlWScNtcjDmNu6YI/MTRkaF
etnQhXSSTi7Ju2oO1t1G9HrcYJCrrBxhPDKSopCew/fE+wfFuTJXOsiwi1Ekde9BABbftYXk8gff
lB9zh2s97yx2YW/ccPR/TDIfylq9uGY0nhaDb8ePTrku1KtwIueSLcQQbH/D49WUSeH78EzgMPBM
9gKczt1aP8t7N0ZJOWrRz5ta4j4paoFpHz/xXDF00m/JDxsTryrmBFDSYmwqHElwr5bTDLb58382
Grw3L06g8HnqGnvmqY5p2DgJLfEw7NvBRxArYbo/NQH7L6HJlHd37y8wx7AMOyh3QGgR3E4UgEwF
q9L5eReY3IV/4/Qbsb9/GZXtj/3WIbZC30mNcoCuf9ua9jPUd1k5V8/Cq3wN1S/7g0jJodNZR/aO
b1qhhiY9al7N/GYK5+FxYiI1mOjEzHIpgZ1oGI0q5DTW1hlE63Mr2FeSd/vNEMHEWxhiUqg2Ls48
yX95DmKSPcI3KStm6P7/JsoMaxRfSqCkA4OEC337jBF8a/k+9dR5hlN4PGQPuOSYd2moFMvgV21r
gySkGNmDxbNkSwPtbjPPALQ8vbbnpbD+yE7cpRnpdeto80YEM7v7ZBYk1Dr2Ir5qQMTGxsljKEnu
QfpI9FEt260Nfuaqn8e2hsePjbRpdjOBv3J+mxIRKsbbqBKPBe3MRPv71EEjJUi6Hyo8c4/YtnKK
kDnTs583r/wwSEWO7IxDgwb0awqvASaTXNPu/nk33LGDVXfzsWwZrB8WwzDc9N9itAJ+Amr87BMr
1DVHnfmrooOLXPYCyPaDKt/CmuJXrmAc4gFz+wPIyB3CIS5ItIj4InooBxFg3FfeRKkPQOvPAdvN
29NFvd+QKMA+J4fJ/9VexTFDru+UEabqvuJkhN9kFrAPywWSUgKapV/cgSIpQnVvTTqbXruSjfZg
7G1F7NISRnFd4ExfEmLho6OH3HbjUL39/RdqC6JTPHIKzT6QdrGoxAmRgHIUPy7wSpHSkGy6VY34
KGQo4wWcbxek6hDm/tkMmaci2B78rqbKflxyrUoLBxN4wlqZECxjza6jYgWwo2cnXg/iH8lpO0s4
pGh8A2YuukdGftkzIxqLQStYOcwHdHg873lhckc4P2ruBAwVL/fvhwK1IFH9Cfyq6Rl8WGYGzdiN
Q3d+jvi7yT1zaorNcFILV7nJ6xKs8XWnwmeit8YS7TinjjRh5BkxTintRsuI4Pyr7RxrP/NyNz/H
ZOV5W5n7uhoJ/Rjjk9ZoHE5Gwvo2BDMsNgQ+xmqIPTYFQKIHakeLRWNi0JchD5AsFNKqHdjvmf4p
ITAAXiHhtw7GKkBPZpIUHu2xzqwl9TxgXFJIWKITJOV3vyaksGzv7mV/ckmp/F3TDXs10vku/iVP
P9jMbGRw+j58HDtUy+LAjiQq2+CdSnpKxUPPuv7xAWB9sJ/z4aS55+tfjpuDTj+6FJ+9ckdJSGB7
bC2jK4YtyRv8IbXbn3W3QIwQeFYsv4UbTUINfmSlQ83M2BjrR9DeqqD+gXXzAzY37pJ8uPossRwZ
LXmQPxiKutMqJO9MxGq5KwHKsJBE3AVS0Icie+mcUezY0mfndMFzGxmqwwC6bPBE7a8r0eTdG82U
ARWO0kBguLI6SOK4qOXv5G9aT1YRu9VhhJ9xHFx2stjZUoGPrkiPW9i249ibI+oyfE9c/bjSkrWu
M/TyLay6QpYHaJk93V+IA5K0YQfFyihNBuyBiigZ2hgRRCvdcRm126WquBoQyaYXT+r3ssm9asgG
cM1f37l5aqdJ9HaWLufJc9o59bchdc0VIMc4LpfvkFxSIlNFBrSvjAuEWRFlkG+0hR+d1d65z63d
Z9dkM1mqEX1m2GwGwnt0bqNoK8l62vjv6c1nc7ZyiFlEyDjWeqRd2d3ufxgzjcO8UFvIKi8FcK2L
x2hbfm9nq/g8B/CtSfSl13/XVrYtr8dubDBz1258fZd0b/kDPu0qhzXUWxmph5YoIzDpK7EVK8Il
q3R0R5rESJzm2PoH8xW4OSB+XZgZclhmquadirWT6olO1rp0yg3me8n6/o2pTDiNKxTCTgywdaCm
/UIK1Po3CHTsLju7Lamd2xOCGxnOF/e02FXrJLRHD+7b4YWt8LntLjAD0FiWT773/eykAs3GZvqP
w5bACm6w0psrpMfNLQgIUXwrIgocqstSEqIyhaMxvy9d1HQwNTwZLHfaCAQ/H4CA7yk72fzu6wri
sfhWUSnIb9jbmJ/u9B+5EoPnK2CW3SQv5ugX76FBe2cIbwfdXjZtNhUj6FJ3nWidmyEus1KCwS6s
nqQgMvsBknxIj34WHMVl9sPP5TEmQJNN8xCRttb+Zfu6JZ6XCdNv1Bx6pDNq2apWzS+YrXy7M1vw
BO9Sb4F0ZvWDI03MT5vnnA/Tw+ZIwck/1uuOy9rPPBNDRbuGmIzxcb9xSAG9svaLu0M2CEaO8vTn
zpv2ngZzk5G23qIPsY0IvKDDw4ApEb9fBlMgTLOO8fdTTEh/p/ruPTdSREUutLBkuB+PdQWHEs0G
uDe/M7QTPIt5d13zHhMU7IIDGHX/wKFk4SXKPtRRx6YT5zGYs+E4CSnmOXqwirlxsnWzArqQh9vw
TRNL7oeKduElk31BNjqcL0Z7Ri4bZlBD6lGk/3r6xV44Gr1MavJ0XMz6UV62bxZCh48KaRKXsRek
dBb8jEV+sqzj2kel09Fp1sGKd0rFxsMrm9CGtTstTdT62ficy1UtjCwADrjAEBNEutNTYBC8Z5Mj
fox6OYBqMCpjgIVJFptQ4/J6m8xVaVoGtmYck2kOSMda8Fs0rpjb4+F0wRt2jLWMARDl7S0JEOD3
klDpkugRfNFyyCeHy5knG4yH394z7XmpW/XCvBYHw+8I3FrqyOg20vvDWci9Sjyq+7Dz2Iys5pWv
GnwDsgKGTkVmNEFTfMp1diTrAROhLgu+FXY1Nmkaj96Erhx+jz3vGFwe08zZvU8xa+XKRHvapoyJ
cDzrIU5gm4hDGubW6wuM2FPeDr+z1K7YoCAJ3Qkv8Yw9Ge+hZ6b2avAtKltpiUOCaWqKpW+/jRKs
W1zk7RHH+i93jSAizdWtpv2GFP0K/xOFBAD2zW2FBNzwHCOOVLHrW8VCEMZcsGf2VWhBI0A/NNKr
a157FM/4b8vcmmcsnzEPZ6Sz4rDyuqZhSGH1MhSrjr3092oNXSpYJgaCneQiBqhi9MM8tPcjDStp
lIb0FmOho6iHVaAz/sAUHY6Cmu9SOipHANgEgkREgdS1CC366WMCxGxAfWRcsyvQM5IcH3wjiRea
PTJ7h1BYAU18Vp3cBM/h8x7xh3+bnrzdJOPEs5WKcgLmT3e1PuiIFP1DlToh81nPiDUh3MngjfpA
nhoWBwd0Fv6qL4LPiKbeu+iQPHZAm5kbvIxC3kohYfS1p06NkCwDyQAylkf8/ytqP1U94a758aZi
i7tyhGHm/K+DP8y+AVpXMY7VgDc6Et1Y1jzFBQ+oqukYgl9R4kvjFlzmcvIh6Jq9vyo7aH4UfuxX
hz+8nueBC0AvTqLX1HOoDE59L8IXtFjGii9cSuWwuYErvfUKlUTEsYf8NuPY8hajR4d3xPbRDqD9
p3sZccBIVEdneE6lYOLr+MINAGTrFy7H8mJzGSfcK3rDcAt9bftKq23x+V4eNiP9rNfZEFVMyDqB
yQ3uBQkLWR5dKm6/rtTf9/aZqJxpfL3OePYTmhkZzsEeK7s3IuHOcq3u0xDFcRw/Sckk8DjOkWmi
aDAP4+5gkDxMGFkMZ3yLToeKKMzvxohzLIRYKVGKNjmCrwo7tlYjnp5v/W10Dyy/kX2nZUKMD9wK
maTtm2ehTPLGUDXe0fWmd8yjjyMbmMPrV1gGRI77+fBEUJOfDtRSDXc3aHcWOkUAe7YjqD3giMCT
sgGQJqFYXeIHYXr7XUiBhn4mKCHb1bLe1JwfDavtWD/MYDgvLiRfcJgVks2S0vwzTXI5G3N+2yVg
CrKvACV7/djk+QQQgG/olQpIglBcgGuS7206PbzocIOWHpMhsJT1fBQVlAW7Jli67XMilSWmfZ4S
QmZwBPUT/xYwjznTwigKjRIBCR0Lhs/YRACVArWsejdNAb6Gqt1MvMIEJSEasBdbPQ9ngfWlh4it
/qQWESmx3YGD/gyAuP7BDdzgoOrL5qCJtda7IrZ5CkUuJdKGaE9VoHBHJg2ur3kB84/Z2erhzAp+
AxFKrA9mmJ9iLGLm772K9Xo+GW9bJ1HE2MFo5ka3fyfnhe4/UtF5wDMrLrT9GlBEIZvcDBK6sahP
VQJSSS4lu+HJrabx3KKXj91OrNGR0Wwd2YCzIB57wzNYiO6TTnFQZcOZGJu+BCJ/VznAD4G2I4dn
cEw0bgDrcaKbA8sCLvILKhXis42VPn/MgPKkUUIc9/YZjGyh4xs9Fn1GYzD9PcgNIw/+BKyx3s/8
zUBnDknzBbPnkjucmxZ6Q1MknduYgGVB7dqxJX//ZBjsjH6nDJAdwHWKvQhKV50eWKsorKUHJiI9
tv0nNxWnUdzIaHCrnz9YZ5V2PJAne1g35YAxplNYHL9/J9pH2H+C1orjzXjCpZes9BwhPMlmbFKC
z7+R+duOvv09MjeZmBTOTPyhukqbCnsxndnDJRDxcq+NG8AdUQ6f0TfMclT6B5DnWFM0Zv2RmEWf
FkeQghxGOBDzWewsDVzi8U0ESIxswKYXftLBMmwWyFRWEtdhH/HBiroSFokqc0LlAeWccGa2r7Rr
0tPUWjT5N+om0vsm6/CgmLnzD75QLhzbXElxgY7Hh/RaHFkunh9XeTY+MhHdyXd3n5ZC09pVSiMZ
EZhFDsSl7z4M9D26TA9sBVzXhX9XH5GCDvarJ3rU2k4rT0afiKSBOworjTPd3Fz2mmxXqcqe8vNA
KHyojYobgzW==
HR+cPxMdxnc38THUBMnwEc0YWxfIWEhxtR+c0l50Ij1AyNq9UEP25RdzzJGeysgtMCd0f/lHaFsH
TOpZBzDrTk9BAsFrwk9RDoN5Hh6OJc7mur5rM12Y4RGusnMdNEu2yr3+MC9q3dhV4hNFcLKBeaTk
qVh5jRwUtMrLFNFT4t90vd7wwhBu+crzxDhbPpbTdwcvZ6o+nqbXVuSWOhAl6GyWNvOnRYgNKxZO
rkw1O3hNxjyHnsHyvu3THOMTCkyKzez3sUCf092LrpVQ4byOcQ9n8wzyWbJV/X97M++WikFPqG2O
oK1BemmDwsGG87yZC7sAAO9QIMsPIzjCUjPruqijetD4TSac0G6y59ffnYtx4XCIqKy5RyrXxTws
2gpYpR3SB300QqxxfN/1/ZxLYm2S09G0Ayymr1R4nQJ7AYOnrMqFM/5Pkzk9g8nAnpehwhj9bRzJ
w5WxJ7XzHPIillUqacRtvtdsqbundFCQshsSxh/edtfZ2cR/xQJIOzks5oDMAw7nVOtNbUNX+v6E
hHCcSC4q+tVoFueftReou/oe2CMwHTHXZlC2J1egAo6Rf2iidrh+CDL81l/tCM39zds1TU+UEeTC
ZN4URkC9Bl9VSLERThbd7Bzlf0LFkhQ0h1ErKc7HZsK1og4vUumGZEIs0GLLigLDFayw+Qi1Rl22
Cq+OS8PVSoV+bFNyIT0wVOCJHlz9r2kVcESsAQKU5K7iEuxZ+0IOFuWvNzsgFQP8MO0gcEFBWJO/
2+t8NAu/cQEmk211+a/945vx1cQ9JriNpV7nqFlO1fKaTtNjwK+F98DjiyjennGEQZzYzS2a4/Ct
Lf/9ZoUoFHcV8c6Bgryb1zzfYQR3adXXnf6oseVTcyAxWbW/VQKHnBJQS6ixlNjebO3CGMHoCoIb
mjptXxek3380LbEwf5XNE1CsgwQhmV12Yhd+NGQaCASUB7PMYQ32QSHTfU9ucxOV2FMjDP5OTRnd
DQ6eJqdqi2i74gpAC4nqzzQuEwoKCMSxCnJQk2GVU1U+vfnhpIldEjmTur1HhR+kcYYpJ6WaWFxS
eQbP25wVNAjjBDJ/yzpsET1Akm96QeySs9HxUSjsNxkFcdAV3aAqQYfsn2CAWUP2qsekK44putGo
6E/ghPtVjiUl8UBTN/heHOdjPGeavlShGq16CrKhVYuwprUpIy5NWLwjYChWCJvm+u2QrD1K7jpj
wILBdtnQ/mSadgtrc9TepXDbOA93wZlc7nVTRJEkImI/WNCPxjc3C/FrYdJzJxQc6o9aa01hA4Q5
o/ZN328sQnXpVnVVjkD/Ml98MKwEwBp1qJYnt4UtKnWbd231pDmwGslLYvzm5ojJWeCB7SDhQyW4
DAsFoo627gGKUc3M7ocoVXfX3rFzxYGc5MiMb7MRi4AwIF3S7/UsKqNr6JfRK3cLlI1j0AUgivyh
DjN1dpkyGHHniK+SrRORmMlgHW2TqSoJUzkBsklP4829+0gDEFzRTE1cB2gd4d4BZWjtMTTcth/C
3jstV6I5O9IDXh92Po278NrxQrZYPPagcfaJiJ71weYEpWNc4iGMOkBRFuUCm3YIZMtG+4x9EQK4
TOHxnSac8EndX/Pn4ZUaObCVQI1pZA8I7l2GJFyvdRB0NaF5G+oAZWjfwA5hfz/0MwzYPhhBgvDk
zJlVO4owAk/cVAMZeFN0SM2wwbwhoSJCCtAlQiDRvIAsyzVj1WtNZK//peuEJEqJWaJmfsajtXsc
C+T+x0g53Zi4PMiEX1Kx6tEH1goahlAMSM8SyHNIshXfOR4Gv//fBeukE8pyCC5p+rbl1EBugVcN
3MQmoc2mPHIEErgocv7a1qvW4IEEBsRhqYADtVUlxSJKMa6CbeeWJgFz4z8zP+8PuoS5LtW8kfbz
EyQjh4UCjUuj27KF8tIZebQwnM0DNow6pSjLKDcchjHuSAWsXR4bO1u/0zMsOmJGhNG+yT9NsM/i
pdvQMjodHu0pImkk6LgpeyUkci0+ELm6yv59Sz8aVoGAASS+eB0WPxKnN9J0aYrOa4d0ScHZea8T
dHjqtIWZyCLAf2nweftQRXv9Vt0nXzuvODzKMwc2VAkliRFYdroSwvqC5FEUpAsDpoEySR4r7ydG
XgvRW+TuOrgS8mWks92B8Csh97feAZvbEkX63VX0xZFE0Qd60GUYrhNOLQIIoV3MfjzgFQy1Dxo3
ZGydByx4pDJm3ElycCfXfEXZHilzaRMuGTFTstD6Unmm2JyAGKRrmdVop7+lqq95dY8ACHJnZod5
1gxUBs51u4lVoURGGNg5qLmaYJeVu9nUfyMd5lNohJq9FRtA2W6mKwUcvO2IwBw5RJwkGqoUwjQ/
Bm4328Aqlepvtli8ifL39sHFSgGZhTUmsF9BOwOa4JIURpq6Gj+K4uVrf3xbKEheaHKSABqRKIfY
NVEsspXQ29hnvspWhHDRUlbb4un2CGJJcUdciA46/2xxivvQMnRH+WGlU5zjChzE5UiuvYsY+spM
LHROs0jCU6S++rWrh8IFFMpUQFGXhpXyiPNkPSz38g4Y9tvpu9eF6rfo5+FVAs3ASckI0oUOTaJs
BH5NpSNnvF5lzb4L2jMqeOuHCbMw7mk6K5cjKhOWu7BWSbZlcTy1roflYWPO3kNrdLL5q7JS7sjR
LZysGClsJwc0pTNNk/U8o6CN8EPPhMQXnLVHSDk/MvQnjSemLWVgTkk3s2uffz2uPs6tKQdgr9pv
mV1knHHqIzeeS3Bj11qrPb0ZEydX+EVMGL4O1xrT3p5wTQdGXNZH5OVwrepFaPrUCORMRzdeuhaQ
kOSWdEZbOqBTUyf+4XYOFVTwDpDuwnmXG6WcNx3UeMvtbQA55nkH7/fEI09J/tXTrCdF0KzkPaDV
7Mtb/mlZHDURJjtLa8xgOGHNfMyLGDDxVMyH+v68cEM0w1vlnYi8yy2Rr/FGUDGQrLq/O98OOCYB
2QN5gNftj1cjUgN3P9435MAgmmU2ITJ55uBczIexOeFib+S7Aq1iYMBHC4prO9QruXRBqNeXPUq0
LGNK/iLHzNSOQL5YfbFuYGYs+nXhoGBoch3iezgHa9V8lnF9Wy3bnTmqr9EEzZr4+V+PxOK1SqgK
BvKRQmKoZc1qa2V/hSWOYt28cBk2WeJ05Kr+AaGRg14SjboqwdQ72BSfNfXneCvUPx5Kzpe6REfB
oWgGqEA1ioQbJ77ICsGgbdF0xggv0h7b8hN+UYxVdV0Gx0+skJunjcbxz4XxEG2up0DnZgBOJzQI
dQkkduB5TwRCnekriVH5Famb/nf1FkDvV6zLdWi3jBPOIbsJWBF+at+BdboeohwktOfE4hMxhuWz
MmcaM6jWrYoGcm+vo/ldw4s1b+OcJWl3tWa2NQnuprRTgLrRajKBc1CNMJHwjjECqqrNkaoEhnCr
/ImItGZi3h+zNLj6DrXiAx1QCh/XED8mc1iOczFGpRACZ1aWe0VpQVz8v7gYlSTPB/BazSFgxPqL
lRGVjFyFY8LTjWfRlVl2tkAsDQ0gUfRnboJC20/XXxpS9lK5+AcN8QzZhnyiifK13PUxNGXhe7bb
XPJYKNYNr3KEf3e6Sgu4fVy5ge6q+Mk4fIfdiDBRs7nfS4tMvd9WmN/edcOqX4JNXyF3f4GUJLgZ
Lz/e1CYSal0s5+drFhd9J8KiLdQHfAzQ6LptS+tofb8Gm9ne7VAAcVEkUeMjuRgkAurDt+CEKwxl
zIAStooRCeQPX9+ycZLXqNXgosccmrVOux+fKtgDIx4YgDUsEeGDalrMTow8zYP0Ef7t12jXeuEj
i3wZ2bL1c0CIka9QM1L9ABa374EL7GrTMpeDxVWY7/0cvJMD8Hgm7dH0DdkYRiR772bIfmYeJ7Ld
tUdwmHecynis4BBBr9njgvkM/llSJFGRVu5U7gomgQARyBBkGN1HRUHJ9k+QRLYWvMYQcG7bsJvo
FxreOqX5dqqOnmMGAJC+t+wdyLwvclQJ+8KGescWR3Hg1dPR0HG6oHHP4boNtC1kwtCTd6i7bHle
r0rtH+Cljuu74hZFueDe0v+kUYu5zdBQ22K6JTEgz40YzvAqPK6hafX1yXWiDpYh7UTgnzZ/LFoD
9nS7xqaRYVh3bQOK0Dha825Dm6lLYK9E/5na1u0RHs1zll+dh9WD2mKCwpAWKH5idXRQDzQTSh/l
wXFLZZqF2kG8ZnBbi0TsoBeDD9ykn79BWk4gmw8ISl16e8WHe0ZTeAbCm/MQyZcVRRJVWKxN1UM6
lf3Pdb+QRKw4+tA/MHEUuUPAgwq4f5x4pEVEpFhWDFQ5+Fo1ajw9ipzoaPc1cGqWb+jSXsL34gvf
Nk5Kt5VEmo55WtXlTbk/uYA2fVkpnbcDwnbmjjiZc9pDk8FY173QWT2scdzb0uc7HpC414t2Nd1s
QXXPMhoWJN9xKGKcPNLZ1FIZjuZNzyVtLsUj95M18AYw1rbBNCZQ86P/JZTCUL9GBSboBAj/u5CK
6DEB8jVIGVKfC2N7R0TH1hXzx7ocPYtm25Gr7dQAm356Ml4g6WAUHT1M+72Uy5fE4ET6IgZqR5PI
tFgh36UCU3GKC5pLVELP1I3p0RpXqGwKs3l9mwo+DsMJXXg74Ayj7dNaUBj+d369jZHaERd6bfpG
bBTp/x1OJkuhy5dP5y9rJy4hDpI8TAjYAE8qz8rUib086X0GaBeYtttGMDD9a1af+Ov7bNq3ReFW
L48J8gbv+gTOS7m7GkL8NBfZeB7AJefYAhb3wODybiDnnejxAu809Gp/DrrAFQMoTKWCwL7YTCDR
m2D4QiCTf2LbyFhMMTGIAKibt0JsrdmDU1klilFMcwGP3gIeJRGdnYBIzpa2yM9EOjaMr2HVYyxy
4pB9D6CCB2bQ246U8dDvbrRiz6DMTwkHBsdGZw32ttelKvROOeNL/N5itfkMMzwDsFUGwfDRBinf
CPLOc9arr0Fx//lCQgEqsXN4sJubzZK6RL4kB8TQRgWBKmSDcc3fS+qVvgw/xbqQROPnEniqGIqV
JIqT8E0VzWGi0e12kmOFzwD5UcSl/d7QBrG9v5abbKeC7Ad6kqy7GJVX0wV9OXpw6+1BrgLMTJ90
7AzTKOpVQp7LRr4p4lblYoqhqHwzYsUxZuTtsbFKveyYhuyLNvwi7g/JbExSLrBlDUiujaBReMMY
0YBDJHWYAAHFZOqduySaLH5vYaRVlBVPpbNLAW3swrzkicNkoWO7ujJGU9dMY+/XTjE4CukQZnbg
tegg57ILlQFtR2Q8brhS2SjHKRJRNtf5SEoNYuZqenxfmSnmqyQyn/9uP4BPU/1B9v8YAdttN8DU
/Su4weamROjCa2KecpPk9a+Pno/oJvaPVwLnW9kVXv8nbI/dBhJzdwOgK66ORZfzT+i4XhEhm9RF
qBND0CF96zW9Vx09gUM/5SFSYEQxIO/0GICbmsyet/4KMKfVJ0A2o9gE8Y1ClYUZdcxz38vRTZ+D
PLBt52q2nyS+uYQuZtzI7hP64gxAJBinU8bWQjbYYjODxpbH7AnbO1h30dmQIE08WsM8bB2VVZcK
8P5Fls9tmdx/jmpbb2AVVZHsiFIgOnJTSwzKNn/hHrlwZGSxEs8CYRXGYdcetjoXjdOrR+FawrGQ
uD///1tD+68P8QNBCRbExPdiz6DUZFhFczCPbCDbClckHhFjdIZ+ZnY8u92pQydM58YZpY0G2Vtu
Ghh22S9QGv3V0MCrXaYZHAmQW5kHu1Q2pOGqWRygqhqBVef3DVh4J7U1LZInW2WcWHM/um+Gzap4
3xO3X0uXNyjMwYreIClcLRhRn7WKOFl9EEjohEmFBmcZZj1Ww9zm/bRzmSD2Jlxsf3d2jjGChCpm
tzus53/zZ3NdOPwHrhOW+BhuNmYZ7O1cgx4FhMgBYxsmjuTPRCJQEX3YSwJAnQKGiGbTk7VJzTgn
12wS8WN/Jn9HbycLHB50AJyJWAt+IH1wqXt8g1z2spXFqOnc/NoMAph142OHJhFvw8yYA/T7fBOz
ruXB83Awo5tpBzCtaHT5BWN9xJElp2jCEPhpPP7xHXcaLuZwCwYc7YsEJpu9r2mYT0qMh+7SiRwL
CDCkDHBWHZrLhz7V4xnl47muW/NzbiWQPAQZ6t6iNDmwnZPWv5Q2mRCaxrdhFnNG7+tjU3Dd6R/t
D2/ZHu17Z5LQEeLUlXMjSBbEe7pHw74Y3UVEX/HSoUnorklcVZFyjpFBnV7mJsVq95JqzcWNbf6N
5aCxuC6vQYY/lnbH/pBc1DflM5V+oWflIz7yD/wPD46vh09UrbHZ3nySBmOlpo21UcE6hh8a1eWt
1cbeXTyh5KV/Qpljya3Rw4wcWOnzDYr/J+MMPQvHrN0DDu6Mpakao9MzB3I8NYxlbeW3mLh2scFO
Yfat31Tk5MM1BnDg1KcK95EYFePYOce9VsAl1Oq6beQQcScXfuG29wF/BaedRVLzlkIGGicqivdI
nbTvsLLUXxv7FhLUfBqaXm8kQ/km5cplY9l+dqu3cQRZR/+D3xCdI8x4y3ZwJ3trsHAz6pkuLqcl
1UDp5DfR9EdTk0qOyvtuGNhjj3jg/UMPjNyTzQmeDAF3DOBpBRPZULK/CpS0dwpmjGrt5q1y3qly
T7lMJWBNzHQas/s428ilgrEbiz3N2Zfy3Ob1o3iviCp65kfpt7EdQvyxSCO8XlPlbVzNKV7vH71h
VSTSB931/sUCT2eG48vbZdr0jkVhX6iSvFUiV2Xr5KQk/YtNTCorjmnaeode4FllVsrv9MYfocdI
aCOaCvD1NO/pVjkHdjnCnh0DpfTXIMqOXI4djUy+8lvxT70QakwpogWIFsgBGimeCuwwLw8rUs0i
ZlwrQRm9kuHkNe2Is0p6uhM0+0DAyRn8JSbAt/mNdMLtthpRFfIbwz2SUq/rz5Ja1J1iwWPsQ3xr
ytaAuEt2eFXB6VPBAroFUhbdJl+35tsHU9mGZaEEIpCQHFvIfP6kRveJFPcDjPWEedmMLM+TCB5v
oxMPlDymo5x8HaSzIolWlA6mcFwsZsctGbDOTZ+oGfT4Lg8E5zDJe2agtnmmR42wv16VAEGp2Inp
AG23T5IQWnco4SvqsXS1h/Q19zkXv0yQIwwFPHY2PM/pylepdP+HilRF7bygWpKTMsxr8HtgDwbD
QeMAsaheHVGvkoV7Wcjz9MCC1xmAzCctBnHICKwelpPLZPZruin8STPdYvy/yV9eczsT6JjcLtYH
kvB3dSMWCvd3CzYYGmzUGasNccmfSDMqTxO9YCMJtnNOMrO+nuyE4lg0ASUFBc8S/yqoCHaYfynK
tjsdVT/6geuLxnZ1wHHCi2clWSbyqEkdWXbjshEw1nZEfmtF4K43alH52y4L6oN7RsxCvCpZIEvg
HhJL0AWL6/ty3t86FjgZDoRBeZRk/TI0MYMCOHLQ07IsgwW3E0jLwpI0EY6vPmmDp9dglUvDBA+P
TGeJ/KlWrxIqCFc4358t0itX7t7ZG1joBXgS28+rnbmhJox3bqNv5nwOfh9el8bTI5esh/6XaGGO
x8Tk3XBuORKRcUCTzuljNAdY5/23rV4ormbBEuio/jOOozqizyu9deoHsIKxiasasgTMTrzWY5MX
mavQACAFc5Azc/c8BNTzTxq0gnbK3UjnwEpOvxY8fcLO6GLxEgBKmM4NnvqsxvUlhYX32N02HPVS
9HR/xTCNg08DHMQEjgbtzHJJmYuoaYilscUY9ZYXB2cxYjzWkxOq2ng79477s2FqcUe5EU5C05n1
3VO47slr30gGURNncvcHpTv1vN/e79M3TpBuHiFL6mVqpGw/7Q86BuvATfPhtxOrIC2wbuNrSIG4
fY5qZjJAMs0azrwT/bcMQ5gHJcSWU/w8SofITnLARKn3Th6Ht6OAUUTVt9L963feBARB11qK