<?php //ICB0 74:0 81:33a5                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPv/M2tB7d/15wGEUKJ65S3ZNRFyZg8nvTPRFJ5XX1u8lq1uHC/QQi13EoMGMu6w4WEmzYGhf
l4kVdLKQUcBTGrY7dfq7qUMRjKHW0CoxVBYMoXGpemdp/sPJfuergBgvU7/Pv+bsmHI4TMaX/pza
04uzc3dpNyAMKsLJiiLpmyrkUiOqpX9UC6xxEk2WRZfQVFvbk57x/TzdAJuPqGJDGs1sHya83ji5
zD2dapY1vSVTxG1uk8PrB66EHqR6sl5SSQnnWCrPu6tH2W3Woll2a3eP9J2BfszfUL0L+n4jMyl6
PH/j0f09nKB817Mqj14sGE4qcVrMuQp+x5Bwj5+FZYAQpR7vJ6/FqUCYxrBCLFKWNQPFBg0Z4Pul
GRqC6XF0OkocUYDUVbFVaanVgxcX34FWTXVdVA3mamo5fICq7fGa5sA/uPnViaXG4bBcJ4bK/xEG
r9JABBaJ6wlo6mZsIvgEu6fchFw62lkA1viMkhBq9TBrWhAEpyMOcFX58y6vBXsu3DVvn74ZH69k
q2tyCYADv4pHu4grJDtNyx3SttmdTKHLiesBQkiJTygNsJyjZ/fpPA6lQugP1/8rp6ajlGXZrIJA
Eb4t7zcgz2QmhnYZJMgoJJV7AU14PTpvS2ix/eyfccf2CyEMxQbpO1GmdV0mrNVqc9BY9GJyVLMy
IE1uJa0f1xTcj+C3woPEZESQAJ5S6GIXXZJI+ydWN0TxJSUhjJPbbKfec+qzIrB8/YbOkVKd2m4F
qCkEL0YagaTqhH92BumorXPh+6WYSgtceP2Xs4dyZENoA46Tv0wvyQBod3eXlBTepUxrTgFBvHlI
9UgPKfbjoCuOrALZ75ozDyZJs18XgMM3lV9AoQjAIvLAdnuBIfSdlr4ObRIrorHPLhrTUxvuvrKX
bDWuZN6BmZ8n8j6DU7/zEhDJRUVEh12LewcCGhokeRIsaNPIvQH0n7gfm6RJYy/HoQqYDT7uMOZ2
6XJPeQ+IKaN5KdceGTb6QTWxBm8JLPgsRmd0QQ/YEFGf53LQUEOCzKOc9WOObUU7srw6pZN+FMQO
fev0C3Jt442+dK/Ub3YRLPp1U8m/67Gvc+0LNEr0yWsZlNeV/Pq/KvUU3GyAGezvRrlw36ILP4dN
24NyHS+iDIm+cgOkLTgArBBBJiZik1kmai00DNopSyPblFa725dRrIpbXfh/IOPwCbh3aLtPzSNc
9WFp7aE0ogdr9H5KIIJU3kTANQKKwyPdwh6/ZE+78aerPGAj+EyHYiipGBhEYinhMe2EUQh06pBL
QUK+5sCZvhoIkGyvPC3tFkzQBXNgG642JMMW15SABvb4pbiiEc1bKqyRMqzC4o/+85mx5xZUPS9F
LKx+5iWpEBpiIct/sNHtJf0KKeyhIPZ1DXd+s/6TlK3DC/AaVB6y0uDN0QgsD8GEy08DMUi5t3dq
W7T8arIGqEPPoyXAmAshS2IqYiAph6Mudf72gaLFc8atYd/qODMsRTCC45vSGCJNNM3TW33H/lyb
OBeDOy5gk+gmuPpQIaiw3vwdnCbrZQkpVGkb2hYIplQLuTw1M5kWi2doclbHlsMrahHzXVQxBMOM
CnHDtvAjW4xMGLI2tSp4cs4FftcQ15jmJWzdREQ/j5WMIsw8iKNSmq1fffNmKwJb4qwSWUDP+vm0
WD8nmr2s9r9rVaB7TmxZFOP4xUYi/bBjFfjWRQVuqX2jsPpa9yG2QPuYZMKP0bBpWCNS0aJez6UV
W3sAw7xxIuMeSwhgUDr8TEKohrKsIklfAHz/Qudcy3MRFQmnQ0ExZ6rnV+wnQ4gyARpAIvRQmDsW
qKPbshg66epupMQfK4BlcLZkzKK6BnXAqqD65v1J4xx7JKSfliqpLRoqEMKH45THynXd2MwKRXhg
RwdW9pEDyyzO22mwi6c3wMGJHawuJUdIczSiRubAPM2aGAVaKd7PW04YntJ1ukN/apkuV7IPpXMf
fdAfKq1mbREsK+53RZar70FG6wNYRN/cjdrc7gqYwwrj446qHwTCWOpP0+MDJKuCp6eRW6S6n1jw
OKodORkxQKrh1xbtqj5S/m6WWOvnx7t21yEzlnWS2bvobhbhjrbgOWW5qnquAH9KBxDjwdboXPz/
rs6d3wBQ15S0htfSCghpU9/CoP1rDQETHxBGLA4YuI9VuZNCUmyUBNVsCDyLCMuexhdWKPgRXT+v
TLY5juC+5SMiCjAGbaRQi5KlyyM1RBUafpYF4pxqQAeBGL2RXR29iyqo3jH/WEqly7gsNBIrWGXo
jfzRMflmct3QCJ8nRRlTxmu/0y3oUwMl88jSqh5mI5SQ0NthXGkyy9FPLa9OXAmWS/Miq6spi3qu
d0IgWwyGTThtL757WwuOzjdDpMKMI9cH4UFovuLbgYMvYQU6vFb6jOGLiGKU7X9kaQjhRTK0eFUh
D4OdEXrM8cWpLwFegRlBzLdWXP1Nu58ReLXOXX+l/fh3t699STc732uOi88iFYBCUDXhI+VKfFgt
kLpijT5SvbcGZg2lTu2ClfAwXUJ6RVQjpYJoWxlNyWzfMsQy2kfb0CHq1nQAXwgSehEIaxcQt9sc
ikHo0DFvh2pmqmG9WToQvJ9ClKsPgw+YDq36g0mK2wm4YgsDw4jEBieLxeifr2vFX/8K1W+GX7YD
LpgxCgazL3LmHlwvHejxTc24n1fbtYitaqlWZnYOpQ00TeGCqCb6qtyAWupQmKTR0Y0jeOVjXfaP
Eyd0citLJr7EgV8Beqja5HDwTpxLVxhPJ31lrgTxyxaLAC/kscta1RHGDH/JAUpuDl+Z5GVBv1GM
yOejnIkS96WQXpQf4DNvhClFuHVy5e+RWPU8JRr1PRYW8gY3pPkTLG4e6Jz2yBI6A6CaSt2gQGsE
WzDWHXvrfQeJmUI1igAV6c6g/jUUbFL1PHQi+KG0yX9WgDTNCPnx7p3HXJzkIkYIX4HUwew7cSyH
nOVyAzUTB2fEMwFn90j+wY+XIWY6xsE0yzzbeG2cmpb4bLUXy399RGVXMaUmakOOb2a8pDulAZz8
4jb+ye35+ZbJ8FsCGSeGz2FiMdRKO8TD786KlhF/OCC60WFBEq5pcAuGygdEHiED8sG2FlqlFLxN
1UYZ8UGfocN596bWoY3zFZ6nhZKtdiO7lCmQ/98wvSrAtzLPbQjDpEannRtw168RLL5ch2aupcBB
sccF56jw6HtcTwPQAfo/UipolHFiyC/58negrXJ3BDipR1++S/SQkOH/0itp95TXvPfwFKYppZXI
WFcAEWlUeZlt9jXNuO/CgvAX+TkJZT4vXnsF7cBJqYpv07ZVPdraESk0wzhjcwH/r9mX72yu+k4z
dzqx5d0LZlOMB3TT7MUBVrn6ngCecf79m3A3QnD8AGa7Pp3Ff4UF1C0GCtZ/qYX27prP0SHWFxfl
/KVsFoOFPtYcNmzGwCrRj5PTpSWSRofb6NPDq4qJdch/VSSrlN+ne1tkaBWVEBxmA2da6HDWYuHW
wRYYOHMSmEeemVZpccZiJDrIpvIG+5SvIic3kMeXhSWH3XK/2vh13fsVK6M0N2CUXOHJ6I0SxfjE
KCO+hzK09cmeLZKCTLs1EiiZw5G+HzDk/qhDhKUS1Mct0kUnpjEzydwOJ4oTbVMbskYttNI1iLLN
Jbb9g+8DwFq7mnsWlrf0aRBb2XZQ+CULuZYtoWuJofH/q0Dtf7kKQkRUojXv9AzAi//0x8skx+KY
Tcwc+1VvGwfWbz5woyIIxXdOLpaGKyzKnL7EjlvzTIhAudWDqvwTNUGNWsZn2cFRdyeQkeoc3stK
uKIh6NAQoVhGCc5hEv0nZA89BNNyn58FsrWsFVdUiJulwW8Hwld85Ytkq/0oNi2/TWZcx8t9CjOz
mIVNJx10fjh5WSj9d1X9ukKpOvJZI+YDFok+FbHBdogI5DRRkBt3gwqXmzHOWGaelSDBOKAkK33Y
gjEMZ9IPWKYCxi+UWhmJbSqjK70J36sYJm+IzUVKG7emqb+EKVFJWvh0Cxfbh3fp9CwWxCOYrP69
RSw/t1xunQEp3B37JOHBLFEDQ97NlCrQl2gf4p3CeMCDIm15JyZ6IqbgklV2L33LWmZr2tiCpduQ
qPt0ULChpRolgIkxaZXgGYlGeeJukRYhOE0Z47lMJ3MVoLTk/vowG3lTCCefowoS7JrTWI1+Km9r
wW0nqe9pt1pbgZEhMA1lZoylpvrKS/Fkd93duhJDCk34Hl4Gjs4iusQxnsaUwcPnHSu6jAuVOmZ0
8YcmV3jX8spDVVMYrd9VHLy5M1OT0/5rCjSgcdnCg9Q2eTsq2A4RhPmWucdXBEKj2/glRMSo7gIN
EYiZJK0xZqONUlJ2Ko3UmfuSf7cv7x0zltg5NtPfPqqYPYeLpUkOhsn6Bu1FwsZ3U01DDOSULsOr
zksWteXETz+qV/hIaQlJcQgwai0PwbWJUvP/XX40HmoR5C3zp3Xhn+XF7bXktAojAz99QFmS+0nO
kjkNoyehqp+BtRtUOV7UfjxLK8xquFiESca2daySejl7RihT05mQ2k94T/KPxsgA0MPmAlsC1GkM
qG0DRolMDQFyhosDXePytd8gfnT0df4iu8DZ7/R9b++p+xBIs/2AwByA4xguHRds27rE9gDAADIZ
8zgoartpPADaN5egkqjsUQdYqrh+29p6UdHSfuKl+jo2rP+XKm9nXPFz1n5qHdTyUxn/QOLB/vpG
0JXV0OUJI5vX/Y5LhssZol5fG3jtVp2xI8RGh9WALqJXGoXc1e+oc9N2Rhm/vxVk9iohi8xVYuA6
+W23f6NsidH5IgWFTCPSHtQ35SkCkac70r6A0qtKVol5cvDDRgc/lYksKmoRNF+d0b1X/bkgScUQ
A6UK1HafQj/O5K8kNi8u0AevsfRZ/PAxmNpvqUQDLJsEu2mVnv32NVkklqjdsaTYZWFS+rlzRVG5
9iSry2Amcx1WjL5RhkusLqJ9N9fneCE6IUYGrTxRmDxWElSi4lY08D2C0AVYR5PxDB8JlX//Fkct
PXTNCrrT+dkxD4w7pT44+SrwiVoWzPs1lusRHAKn3YREqVakrf8vn0E+7AlpDz/+UptJaA3QySus
QnPcxRksCGSwYSJsSqY8KUo1adEW6XfFyXw0DYUamkft2bkZ7LWwadP0+NpiFH8JkVsAv8BCWgHP
7zN3hFa2afT9L/YwPSVI+I99P/lp1765XHvqf6jYC2ArZiIv/1y/gdguqJYv7NdUpmqV5p2lMGsH
PMds61eNXwCwsN20vn+X++Ip0/UJUesVU7ezqHevKiDF6lelGRThKsNKTxpepXScYb5uU0p/gmYX
7IjkpDOEpqA9h32N57SiJ5to/HMoPjIStjh3FLWplUHqg68zaV4OZN0Uf1r8SA8Vx820udrj3npi
CsVrBIhwLIHVNoqGV820qTek0gU2dGytYsNLul7pUSeNucbeXY3ZFdaiEEmpZZRwx0tdu6OgB2Tf
RhHo1BVFcZsiXmPKdkEmgICuzcGAWO1slt4rfCmOXWeQroI1Ef2uchhWKhLNd5tG1NZ/frtSKsds
dW7NZgXhEXPMWEOUlij2K9t+Bat59ZsYxa8sMvyoDCmDa6c09WWBT/s9g8Dgl1F4inYflKyQjGXR
SzzM1nLoEmMaKwZ1xyB3mTaF2DdWYvIH3g9yrEJ4Tb7MXR3BVnYFg43Oylx+fUVB66R/MWh252tE
TqAenYUqWoqvPQ97RdnyPB9TV9JZrAbFJOX5BfJ+AaKaFkWYaD58I3L9Tnm+tzG1eeDcw3MPnaFv
UT1ch+qhJCY/9XAKUb3MGp5nByb6n/2WCbdgpi5yWgvqGm+ZrwGDDkK0St3XrjcCK5ZGTdvaA4QM
rn/bmoqULFYpwnlF5M1PHT6ms2/NCL+TnACij7TgiAIE7sLjssaHsQPWoRGe+moj6gCST/Re+q5m
6MLdYFbBY7+G2CX34V1jUSwuZl05GTdGFfq/tgMcDas2LQZtEq4BeSDpySW2lNcsWJKvQPMfKEHz
hD/CxD5xUYy7qI9iKdWj+W7qT2RqbRY9dSSPYxsXO0aASv9UAgmIfA6Vx90kVF7M6WZvvpD1NPeZ
B6BjOuNd6GBvysPao1XoqBrIFxNGMx+yP2caZ7A11+x31o3cTzi3pfW/EqkyNYg1bjvFW1LVMDZ0
A9izSjxXfadAD0D+Sl3Qn/LPiuA8mOJh8I6U04QZIooZyMNwWC9T5W8ZxOpo6Gnh204JgsuSG9Pa
zNHCBRRF2sO9Coa6kDXPIwAOsYDSSZq12UlIxHDPAZEXb52DqQCw1X03GQoEIx6bV8n/TBjMAkk5
91DUEeWEswXXZPhEHNUpHk/ixa3xRP62RjQM3dJw3f/O4Tm0cFENoaKa4FLty8WOrLYLc+DdzyA6
+LrproqmS/hMZ32hvfB2H03a3jJzFnDbeVTH6rGDlmHxZWRSjwE8Tt2F+u54Zymri/z4JhLOvKDm
qsDAVHNLHMvp8aDoPTppbWbKmCn+jN9vBdv9MSRyADULZTIaLCydjxcQFovZYZFvYxzv88fIf+O8
PyhGA0n2hoXrFtYSb9G05Td5DqqxUDvZl2VzKtlB+R3OULG9wIN/nsonrlwfeVci13IBB3w/aPvb
WM1kiNvJT2c5XFiX7lpslRoBP1d65IfmuUvsR/L1kjNwvrU4tVaouXwe7FEkGJUTjdhvu+VNW3Iq
Dmj46fAQeNUHh+ApPu1YJGiNCZrRw5OiRkqjTgVJSkm95s4D9pkS+sx8UO3921Q9tljlt3bDCEYD
u7WCdD2IoJzG3P79xo6Odz4NnqyNpEwJ0LaZAKXJc+sJUwW1JVkdNVDZfWsnO5SsjZhuGnPeDWa7
4OnuWliFMXTj8Gqsjwt5gEFpUEZjug5BXagzy+G/2FnCHeL6jcMo17UlipCA1St9FlwDEdAdXFDI
6VRAnOn//0xcRkoIYp3pEHwR/b5Iduu6kn0mXJ4ptxewXETKZnaO2Qz1avOaizuKOwY6r8hZpFsX
ndWmRhXv2LnJJIAs+GdgVG9RcBurXIq3CQng5y7UbOh45h0AO09bCZ+iv5pMt2LfN7cjKe/UYxml
yOqdCVw5RQl+SU6a7yW33hmSklMStZGTESFRur4B18kuPa9Sx38EVmIffkI+vaqdZOKecU9KdwPb
3+7BxPIhVrqddTm0yPc9rX/u8+weHMaTxxSkQMgBlfJahqfC1NCcshyj0KNj0CB20osBEmFUs9uZ
aCYf79lLKKAgu57/+CtmOcOLXOvQ2H8d3XLJZlsNL3TF65O7MLEopUCm/xPkSDMJk4cg4b8OBL7v
cvQ4hyEcxIGoybhQmPnzt7z8tv/MaQkCmJ6k089ufOkoY0Vaq8rC2RkmtAQqr7hgX2lGKm9bxhDZ
w17/nbytTzb8FGG54tHVJ8FLgPBeznZ3z/z9zxeDWhs9pllK1e8MBolYWvwl5Fhj0TTvVhOF67II
gW0s3+P26h5Tyzlv7HcJf0EvGxvJuTDa2Azf89y+gkyPt+wNQYcNxPaCzbFi1hK7ZK+afU7pcWvS
Whcl6bV8Edp8G4/NwXJjem+PL7i/2NOqubbNSxSS1FVW8+NtKHA0NUUkl1PLUN61Ru4lvlWOZRWF
kWTnxro+m4mJJ1anwbNgTxw+TJAIqSBOtpZLlKhkR0giw6924PcEEWc8TGazUuQwxcY/6IkJVJuI
WMIaDXWdAwouv1El7gqJkbEiMJjQ/++KOPRG2d87gQo8kkPFn0zkrlWeR57QWDr801OhLveJnwVu
S2l1P8mUBbMXWTVEOxv2AorxmTX8LWnzCBN+Fv/S707Dqb407wSCmEf2G01U86E8MSY9pmhz98sP
Lu6MoamZ1k17phsCazzPKl+zl5x0OBzT2Fu68Z0Y/y70gbBmeMf7g2XPYnZ5kr90/Q26lC80EbSu
XLxjrFN40ZhpC6JW5zw88z29iGOBbN4T59Ct73vYQvgrbcbHSmVZFXyM7F6kS/zWsYzBBUby9bKI
VVw1AbjjPI6bVsfwEgDvOB4p/Lz/dFqvrOvLiHs8Lnr+n7IqcrkPW0lPWGDrBjhcEgjCFQWHPyfE
MibFoVT4HxOe+KoBKu9qpm93yQyvbm4/6/oUkD4YhEcUF/YJ5WNVungs6Xa8qgS9jzcUPrHzxwtg
axmNV1q4VvT6aUTb36M5PdXvXE+69jMAWlnuJSw7z5G7AOgovvVLW1lTALicVaVbfuHAHDCnAMEC
3bAYtR+w+gfJpkPi4ItZVj/maxJ6in9+9uUW4bb5ZER3oUVrHKPQ2JDDUzO1UbQqN3aKVlMwDxjF
On6hEB5VmqD2Fws9U9IyjmzW9RPUVfD2SUCqKH3eqYDPG6W9qgOVO4Y5wnkyvaoxaU9HycgdXTk0
DrpPYYdDq2li7eKib/puZKTMQ6GTzmsTqAmUdnIbSSuIqF8BIQItsU6Rx56pHMhwupM7RjBhuLvK
KmI0ytKNCANmhD+MzmB9y4N6+hz0Eddk+q0Yzi/33SdPxR731l0cUykUmugelwYVjd5142K2Nsqd
+zelRZ0rd+1OM0pwQWI4Dmtv4cTlqM6LVvrrCS5KYRqn7wdS/rUqopYAzc0jBufk5nuII39xDZ/B
UPYZw6BxaPoJ5v85SVKqcLwI2Hxqn4xDSDOrnmo97tTbIFLCa0gaVLITvxXROzq9Wq5KAieTZO3S
cP+z8D0zJsfulMkO9weq6uABccZKzSnzjBTB8IpC8DoTEI2YixxIFKupIa7aELtG0JQb1gKdWt5M
uH6ukqy2taxn0fIEjeLs9I7efqWOWH4Aghow0uTjBsbGM4LGazh1zFKt5MUKpElNnUwc8QFzG7le
A6svgbnlWmDJPeYC/8I6baugz/30Q3uI0y6Xwf+Xv8OlL25hvnGJcYaZw9xhIIVpLJxenVThAwna
8OsxJKO+UUpKFfYerRZJhEvFmyMsZK8tkq/QQfboD6N0/C1+CY6poeSTYv9WyMxcf6eL2yDjHw/+
SUgD7+uaH3Qyhn6wS4F88XSYjiZlQCImA1r9zbtnssCBmMrFFiko6eu9FUK85SE+4yq0OfJuM8Z9
6BS5Ju3dYBrTYDSnxrqtZcElRpaIPyWtCvBSoKCHVAVen1etwzVznWKMnYcM7vyJMFAqG39A8fiX
5xBjt9Wtg4lcX+zh5wTow5suKn5OSXpfxJF4Q+2PO9+3HPG/GHRvzrqp9VP9ZMXD1vjqSXJs5cRp
Z8uMGIuk/hY86isbMbXAtblbw60uyYNgeD2U/9CTN4hTvtzW6WJ407Kxfq/GC+wLE86WN/A8nWTY
wrqquOu1+0UKkCqDzBQOp3KXrmFPCRQn1rgJZzR0H4VX0DRc7UP1oi7zfGCqG7b59vSmbMzQ1mlH
Vo10WSynMM6AZOfb8xC6cm6osS2xW56Ackky+Ad2RFvgbU9WZURx0Zqd/dK3DrYnSqGI/UdtmYQk
bHND7ErJaaxhNp57sE5WClLD2uT9SzEy2X4Ml4TsdFNPRLLjj1MwaGG1fIwvlnnp7Zlkyfm4tlb/
J6wyqVwIhUrO7QOBgMPiuhVB9570gvv8dn5uyMGqJYqzDUmnd+ShTiKsbEHFVRxYKZtUAkcCkdZr
I+UyH5nFzZEvZANRaMbyXrZTJugDPjXViU1hI6HPzZ2u2eK22/nbWG/+4taQNxmBYuVbiGap0SsR
jyYPwlITj86of5lzIbxfJrxoDa02Fz8uvj53DLTFV0b03RBbcXLMRwVZyrmBoJdga/XLzbjhwi6i
1pA8BA0Ghl6rGS4z8BpQgVL3+dCLOdablpOSc8Q2sGLhuLsz0g4hguAcjeJsrpkZ86AwAR9E37tS
4oxVynbPaXbRc5+aeUFZTG===
HR+cPoi2EC+0sO3WAiIjxBPvHt45b2dtbkFVli4YQ0RVp+kUOMdtMSOvMszXchzZy8jvmhak0atN
u8+Jsic8UBIiQR/0coDb0StzxcRleJdPD3sG6W0JFmz+8/Z0fCTmAd0WTxgH7dkF7XMXtjzQwC8E
7wrBV9t/dP0pvVglJBmFgwnJPR8FisrQ7kQIvU4dpZdsJOFgLwg7CWo0IRTgaHgyb3+FpiSAAbts
BxeoMIVLq2o0n/h/5wfRHuVYnhcMntpzcfLC6GD0sniIUBm/h2epZaQqClDKQ5FlPSB6/mzAcOP0
X1XuiRLs5c9o7mjtTI55loviWYz1TshQUECKiV4byxKDWNcdhT79WOY9mBLVA5rnVwf3x2q33KlY
Yxwf8nli5cfPsX7fVk+3BzYqFYNkjdpKpx5SMaWpEjn4XdZO5csg4PdbVpLj6GDH8uilsBl8xHGk
Jq9GotCEao3pYOg6BfxhZmkV6dT2ZoVjpn4EqXMop25ZKR6Be5ZGvRc/XtOtSEXLZv1IuNb08mM/
dS8X4ik+t5ZmzYj86RYel/Wv4GSvbly5m0PYANQW9/vULPJiQId3hG0auqmM3U5YI3G9FlUfrU/r
V+/82JVnLH8wb9P/7vv2qz+stmx9RubHMoDUeqwnlRjpKoHMRsUwRenoa2fTaVElgDxmKpPdQm9f
1qmEaMm26xMCso9NDIpSIJglUT/XzXfxMobfuY2o20BOSz7o3icNKEzsa/1IFuKRZiQMFO9miVvS
hxcC8qGECFDppc8isNqPo/4bYF7L+LNp20WTup6x0i/zU3tskd66jgdjWkH/9dt8BI+ZZDIQ/Bn/
azH/rOmxins4NzjEN+bQwIf0bbRdPlwe0Kl1dqj1VQm/zSInbnpKxTcWzwju9jEkXnOTPYpD+tdp
s2+RKw1vZK4As7HRUgX4NBCY7R0lIt1kJV9wDqBRXVrfC92lioZSMIdkalFAL5CwfYRpwJun8AI4
Vx2e3l1AT1eZTN5ygJjf6+KZHGpVsl6kHIGjPIWGsEmkVL9MNHKYOs/M2//+2FtO4fBI5sAthhWm
KctUUjUv6yoWTHevfQEgDttS/4lpGzUWyg600DvGYVLfFKEpmjw4MIbKiiiXKLkX4dCA9BkDi46L
dRTzbQ805KN9qqqHl4yF5MwybogAutHCuGmVNqFvsiOpaJxemPhIRYilbvCBfkFicEzMz0fmU8DU
hDsuVNDXpG2t1b4faYeI9YsQS4MR3QQvKSB7a8ngTGrCuQ8w9l8aXeIY2GxXLHQUlig+YOyCMukq
OfTGZAhhCKfccZHZZco6IcGYvSZOn58HYFd2h9c1FPprzqFCxb1pjH3Xend0s+2TfpeVD4p/NwuN
IlLno8kWTurOc2l6SIuB/wt1w6+D/PgUNMcvfGQYKU+bsJ+XOB0ZXSUlHiH81ei1G26WIK9AXj0X
+ZXWXXi7f3a935KeCnvuC6/kO4e/P94xkoxeJ5I76iK3ld+Q8An4D9voQteoGy3GK6y335/AI5E/
cvxx7DTXqcobvXOp/82UNtpZ8Q209u80D9m0L5o5QqXC0GhOjQJ7CFmbK4JpHDVtfyBJAras8/4A
oRlSP23AHsDH3tanpYmFnj1w5yzK91zYhSoeTIUOG0FsmtlUPVFj5KV24gz9SHzyKgMwxtLS1U8t
8Dyg+oXOy+7ZYqfeaaBxxdwGMW0mYn5KZA+F7/FZg4CiYsAfcWZpD3vjAcq5Gl8ZeS2D4G7tz4/d
l8d1SeICarSZbLuKOW5gaugueh/LaNSUqwz1LOgeWj9eQERbV/BzjtUkjrPtDrEZxw438lQFt7+s
l8RhQhuj4DX9KY5ItBoQbdGxxn52YmdGLt0vjGsqVj2WM8dSIjCJJLeH9Vrju0moGRDzpTaqsId4
1paF+0yiKjTTSpAT3jVGlXtu+9OuobAcMqJo6RUsft4dwXCku4uL5F8DPk3EBorrB9b+b1hLt6Oj
UD493gYdGijw422yyOE3PWSP0FjSc+MhV+DNzSz9hO87gQIxif4YGCl/gJBKvxfNV1DfUot3s0Xq
8zTZMSHi8FGAm0EjiU+dk87IE04rJRXS2oUmN76ggW35Jol3wBU1fu+GE7jRCxSxd90LeE9g8lLC
88VvI9uBxAU1NC2bPg59FNYoI88wfie/VeDBw392iCNwxnji8ZOVAdesIjcOL9qtuzsPhOC/KLbt
GYWtQPKX8shLGVYRZysmfHyWL0KSTyG1ck1mO3SA0rVgeou0QhR7/OW0PE/m21SDQ+VKGynFodta
8MfK4MmBVkuoRnm6B4SPWoWqDoVmiNrkBI2oNKcDII7ZlpP3ZJvfHcbi4VV/sl0QyvgfGjCd0e5c
pwSu6UC+VS3knVMr2J3SITWLt9T032VDjYaRlCRTrrvu1fHb9Kfd1HO5HgDWytQEQM+q5vqd/wvI
Xkrv+m7wNDf0UqMk+BUKdRtP4bmuhC9iJDpRB2/dG5kkGRyokqd2ItrDDWf2J9g0VQAMjSYEux7u
crDN++QESKYc4/p0PRQWRDR/Qe01dEJGykCYKZ+t/kp5nWtqbWXabM4pmdGFz/HlBfwEbnicoeFI
PIrA9hG2VUXTE1FDDX7OKttDCwyZuKSEq1sP0xpiQuM0lCJrH56wLbkxvETWDCM2KJtM5GwM8VhI
OyKzmcaItkX5EQsb6sqKzFKpb0lOf2r/bPzUz/MazxeqkhAZW8rzdbDRHjdSn/I/6QdjuQ1kFh/Y
LGggTz9jo9iFXS3zNbu0M4s1NCm9dpCQ6I5K2e3s/5xPJLqGD4BtIERlqqKzkHTuDRewy63oYySE
qkg0YXnE2NqIr3NjoaySE7ZDHIyLvIJJO9uUBYZ82WsT7HjUMSfujl9YRrMdhzLYllj+DXBvWQns
eE9wjD5MppqrFqeTIyUgckJIgS3SPYqfJ/LVnIwGg63Eo+xn8sYqhVLiGQiYGF6eA6SfLB01XI6n
jpVr6Gzor0M0GbrApmZ/ybQE8QjVyqNYgcsGGS2iLAlBrUHhE8gNkcQHafJPZYAWYkcYaeq5r3tY
eot3ArD3gzorQl0gQVeJMAhIGVSDqHRKIR/jUFyuwUbzKLGbcNIH/UXx6rjQ1tsMj7m9JURuav2X
ETe9OPF1H3Rt8hWIqpBITlyFmrFuZhcrmtEytpfqsTh2flyNNEiqQprZAOs8e2ZdgwbDDMmjICWL
miqu9P4I5MdO7+NTh8PIMkrYh6TZ+WmpXrkHmqB1w6qQn9OQmhDZ2ze2IOMN6b/FWx3pjsBZJC+I
X78ToWxK5kmJb4wk1WGKSAoLzlNbTVDhTvl+Vgg43loqLqLaP721NJjhEHbJI/wvoDVybTPwWhPU
fcWoHb10Bi0gkQQMnZNExlmLzFIXxgsXH2j5oJNbMvrut82A/yOhNpWs3lJc8xAkoIbKRfS/vfK9
S4E4U4FwbCgpT0ihPxlhWsHkto4vV6/AWKf82CrRtrxpZ2jy/r10ob7vLL6BZx/frovwYcEcNjJO
rRuXjab/NCudPcvw0n88LihDPN7KSQbfLS0minl4IFfnRnfBAEx1kQ6+dv1wAiMKePJWu6FljjEi
Q0hLAo/JpkGM+SBpz3A31o+86BLoSWmLhHu93d9llKD+DumElt1EhKp7/UX2ts8wiZFOxZFixRVt
x8LpA0ploQmG7m8Wj8cmzJOWbnT8bMXMWzlVxIUmnIBTSRJv7ZMGwWeNRgFynCmuQ0UuDa0YQ0az
t24PfNmZTwKHxGvwRdEbj6WY2KsZCqQLgIlVthtvOuLyX/FPCuPVAderZLyjKC/OXoEbHK52dBVk
svaudfnsqrexgJ1wUUhg+eq6bZZmMEC9W+EkD5B1CYLuAS/G4jtymayLKIG7xPAsiPo2IXX+49Qn
rOYLqV0oeav2ADYQ501iu66+NyMpBl72XUzAiGThsZh5kyy7SCS33t6J32kW6MMPWSStaf4pdbCG
TkUawUKHnXfGcvFWn+9EyECEwy+U833ypm5w3WyXcn1x9ycajJw7wPO+ri0BDUN6pH/BE4PX70GR
fo+/cIlzNHsZW7rBE8BUHE3yeWCivpuO6iDN5mmewUknKWV6IO5FJeGBV8F6ZP5wbBgKs4bWtc8l
J9nfy0iTmTzGubHcYyia7KXnuIlZutaOpDIp65niBmfKgMCdyROpJ6rP0x6qKPUVRYwztusnLRYr
9aPCqxOcTSGlrahHDIBara9E5ME1/2MgevCOg6gz8UTS9Gy5Huhk8CoH6NJ8BzEhOvOCuKm7hyFf
7N4E2i2ZseV+8jl8LBevpnfoUTZqpsU+88WCbr8lmLZz35aa+t3uiToa8KDQn2i/Tq1SO+snebk1
om8rNfc3BhTyYWFLnRCVpqtBFHM/RPnnylzVaLWcP/AJ6vwzGSET7PPFodoHgCAyOzbiyK63DdRY
/LVezhXaUXvqdZ8mw5NlstgkybhM5B9T0d1eE3wQl+wHvA8NPgA+YdrnKTrHoG8YIGcBHKCCJ7Qn
EMlioADF6DRBywueSlld1c/yMn4hJvlt4JA981JuSWRrMvznvFGLZH2PyoDHsVMcRPnBHqoL3Go6
jP3sck58SNNQ3yBs9b3HiUkrEKHSBrgzpopjfbjIzcOFWxGWZ8D5IFxb5C2B11MlPRa9Hr4C10Fs
wCT0Pe3G50tamnC95FbMCy/uh8Redk8JGVLvZW08C7WIBp27Icb//KVSNu4SVA3xW1d6XyrT+F2f
QcM3zGmrKTS2xZ8W35z0xt2+T68zmVwGFzVGkOr/0mJHB2HISQto+m7mWKlfMAAjWXKO7j8cthbi
r43ad6ByXHSjHjYJx05Mv1faC+U8tWqWzbH300774j6mNOb7wMPhP4q90GNn22iUMII8aapC/Bsu
iO30twX+RqvFyUZ0PnrGtd2ZSiZSaoT8aFO6/2q6/hYR3A+CsXyIymBKEcS36nmQ4lv7tr5yliBV
VjqxdyEHv0Wjb7CG9JKL3CSQyzfr2keUvGxMyzBl8q1SsqxsPQ8G+HO55INAOxIjHXQE7l9MBU+o
NgQA7uMTBqgC6crASctpAMBugOmC7+N3kmrCbrkReoTLNfOOpG8Rnjwq8wIq41MeD8If3gN/oKj3
Zb2VlW02j7E1ZO8OYvlR542p/kfLFcUt6l0uz5i3Z49ICdO3TbNABJSp6fVRxaapFna7thFlCc3M
V6ppGz+QGe/9QLsVdl7qu48u0MfSPi6mY8qp9/QuY5P/i3DD9gCYKVEiZlxPjk805Z9CsWnNmk5S
hzCmsqggps3PE6/vM3IP+vKL001MCIx4QN8Z9ohqJi0grElF7j6xlSfiTkB5Muht/l9L80wnACFP
MRUGYfevaxpeRSBxGcuqihB8nrTaWbprlKGJAghU78FZvc/+QuYWtYMD3E3/Fe7nCQKRNSvfSqIh
qvgY2AWzive4uc0evIj9etn6Dv9wD3JmIQJB3yNd7QAnTfCoYZNizevEy1O6QLjFz/pCHW8I7fLp
De6yTd2b9q+HAh2ITmWIJx1pKnD6JcKD4/w/ld/IH5DyAu6OV8otrFv0zJdVOYI7TtW5hl5qsVUO
17u2z6efVuGm7xC29l+n5yC10nriV28b2QG7za8QVxc1hhF6CTMc6QzGA9kSbcDwiWIyac+D5Gt3
Szy1ymfkMjSVAD8YJauwNGjIg98gLJKDx4Ukc47Gz/ZcbwI3gHSKrVkWRTMmkTg+dnu64PMYOMRI
fF0p8R9fKbvJZbz41IZC23NhnFs9n5b/eiZhZvTh9swxhbPQ7635et0TdmGYUgbjpEbKKcyn5dho
0EK7GGM/AXGj2xOs1OrloUoo+RRc/yOFduLGvtW2Y/rjPn7lhIXcbBDg/OCOZRaccCj/kA09x9xK
6cyG5mUjXnTrM9spJhhV36LGDHJbCdTynSszHoa4YjeVQeNSIYK2HDw5kr9wUoaTH0NCGH7BqRUw
17YJvo/2j7Y9QoEcmklsDyYHRjHDvbh/roN4p6TCTtto2Yk+b1OkFsAcrFlZW1GgDwYmeeqVlAkp
PRZ+xcT3cH9VmsUX5CFKyva5J9PROJ35NKz2Dxhr9k3s+lFMl7uDy9aSxNl04PFIh7AS8qYI80M1
ckkqzwJEtYmWPH9TTcvEGU81+pb+If0FR4PeoIAWa8SPbKziz9DvIgiIApLXrL4NvNqF/oxrn/SP
e84SLiLNS3RMwQoEp8+6HEdnze9XHsjSBp1etLJSnC3V75823ODzEB0eJIP/LpP/BMmgp4T8SD6J
hN1aofA+PtD7qvN2fFZ+IxWDVqeElNQmH25C5ToIfsBeIdC5egac1gCf1f/EZZF2Y2J/5CuNZu6V
JD7K4AAvXD7wt0GeR+kkjvRaO67QQGRh+C56FIsanglpNJLig24rYy0it/sMEs3RpK9EAfMsoNNO
gEmSo8xhm70/mHteXV1bRAevc2kKSr9mTkj/INgRl7vGHkdNezD+xLKJOBONS9OUj6n7QmyOkSUl
hM5eSGC1rL0U4cs9ATgf9drdjXpEcD7ED/tmwuUkYqfzHl4u6UlhG1HnLg0GIlDM5TrwOxM2vGDa
jXICzSNDLcpbH3HNzLWq0qSnKRVBaQTC2t3HpD2KAKOf1jWVXrEpI27q9thYbJa2dAR8sEyo1iGf
qfOknjia/0He5In+3VvSz+hkS4GpqvtNBrTLamPOewqCekVttDNRb6kMKA0Ll5OswJO5+04i/nNx
B9pkAX3/i8JIVMrvOa5FwvGxPkn1d6ChVGi6gvCToDOQRmE4U5n41JLdqFqEn9h6X3CnIWl1nCtF
wr7T1KJ+xzPEb+s1TbPTgwLCNigDBqmEpxmncSNPCdcnQ8BmTcATUdfc/NEhkgR2PCvCDOaYTJ3H
gvqvMCtSd1GSB1IhpcHS7tXduj9Z0bLWbCU2k4CrZowI8hiq9jir3E5Y9CgYj9wBLYPqmnpijpC9
xDo2WGr0gwk4FtVuHoa9AwNOi9+/P25GpRZHDhAa+YdaYESjEC1GUyGMNQnrC6yqPYNznKLstY5G
nlQXz/SVpOk5M7yctOlf3Ur82zwrzTWwxpPztF7QzNfEaC13v3cH4+Bmr8FGiFU1gcD7Y+XWoBWr
oS4n7E3H3sQujH+Wn+c8cfbpqCfmZWeaOxNArJexnrd18NlCYIGQnNsZ1D36V58I4WYXv9aAJVOh
Z4Rq3c8kC1A375OBePnkqHIM2CcX/XYMQrnQeW5O7tIk1txsszUHV1zAVGlX/ZSlkS6bf1aKq2ai
z6XbtWYaYEWuEduxyf9/CJgYOBmTDaUluRmK2ASiCuUBvnFauDn4j6L3K4j9eH+qbFIpipbPCaja
PGggUlyAnkYU3hG1NxxzEh+dkP8InIEOA5lPRSXVmVo+CDR3gQIZIyvw0ELQvF39gOkv+KobaUAi
iqs/+LTsBBeoebBE7p09MoJg6Vj6T5Ug5NMYzf0EONsyyEDZTEFlLjGMFl85aUF8B4vzpuh+gNwT
GIHchETjcmJBM/PfPYhn7Rb5IjGure091AS8RlslOme7Nu1/2Y3/aS+i8IqU8MSzhbIwp27+OXCF
BEN6sx8kTYeEjkCKasDX0OEWvH36ScxnKgvTVG/1NBDM+PU1Gm2s6PjcFrE5qiRfNRZLDOQ0zT9e
l0riybjXAiFhlkCsbQGDNNTJEotMI8AF+amJ4B/jluCceV3hNrD1y4gQZEm7AxClzKrCs8jS0I+1
2D7RA/NsYeUHel2hOxZdbjWl7WzejuePJmeea6FPv7J0opWLfSwkgUuljGBOpGhFJfHcxMLt2Ud9
jgQo/Ee97iLBpZDpe9GdICvC+EJo6uZ7gHvAEVe83lkeBwrOXWLAsyyKMMIbn4dY27XKXVuF+Tto
hPOOzahsLn1vEKqcN/7aZwWQI+TnbJvAXg0+NKzwQUIY5avwUW+cY3auIY3Vn6zN9sLQaFCgPguS
nsR6ceJqEaboTuKnAKqAsrdYeF27o6uAXG0bKxFYTuBpDNRL+5J2W/6YCPw8QdhCEugNhfs7mRKM
B52h1XxbosZ/oOSpvFPeX6VyFOT7UFurxxNZQTXyj7f3a6W023/+0o5aAADEONnhMoplQpwe3GG0
BJIHmHKtkx6qBOMZIq+rpptl/J+4jvQgpTtJ314PG1ZAmEwOsBvX6X/Ij6xsPkkFJUSRCZqvjO31
v1dJjvl+SRWjpYfK4YTWFYqHmiEQAB8+yNc91jqI5xJQD0rUkk11R1ngEBhAXoFhfreLzE1nx5V2
a/ShXgGmxH9DSepZGWjXV99/nyDLC5p5yFymAlBz+dSrduQdiQwjfykYGqb/LA5eBHygusGOQ2Z9
+gc5yLd5lAJqJ9VKtsTdLMp/8+266CKpjOQL/5bIv5Dg55345HSle2yPBTRtgVPDiMNHUFDaQ6Zs
Kug3f9M1JkTHTICT5+MZkT7NNGks11PNze0ICHylT1/0JsmJfGu1pTJQD/PdRLJBQGunRHN1qO3p
l0n7FnUuFkKwR8yM1cLiReHQXRs3WpVSVCkwzrmbL+yZCTtBMevxRGiOa2p1cizmIMotlTcDNtz7
ElnVmPOtBnE4DwfChjgAcIZY1PK5oAHb4AUqUFq53fGPryo5qi4GFu8Dahn5ZuvkyGAdfzVrfiDx
7FZZMdJPrqkxM/YKZ+3qCXXgDM7Bs3FOiAS3GSfCwYoMWuGV7Z/VTcolQYfQ6JtoX0S2R8pYBq1r
Gjmt9Mta9B1KRUCg/rz6KoVYj7uDx7nuBEw6N44fRWTxQLc7Ypd5ksREzgZ+dA14gs3oqX9rQKyH
YUXHKcgo1OEeHUiuTGOkUw1FerawHlbNUfKgHzVBrmbnVzU8/+aGkbMIIbWi0V3f9OItg7p0sRjG
FqbgllpEWtAFaGk9kj0CLgdgTCShZ8LWZCHBtn7YzVBcwKxMNTodQOZD5sPDwqaD7XFEvqr37Ytz
Jlz5A6oG6sF9du4eNSfkl4crwYfIniOWJ3ze4ea8WFSkqegmcyU2WZDwrg36w9nDurzbQ/UoIl22
ZXhfTQb4KUvOn7pw67lU4yEkcN1Tpur/Td8WPLRFDPWLVwlrB+5K+oD9HJbcK/3dgZklU28KO2mt
D76n5MlwjMzYwSLxmaE4GzkC6jfNKrVYazB7DF8RWJb6pmN0jj+ltCCgNTTNskTQVGkJo3XDzm6L
twv6jszf