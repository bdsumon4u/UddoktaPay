<?php //ICB0 74:0 81:2650                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPwX8cEGp1s7BlOiDnsxYa9u5kaeKzESM+xBFNof7jF9OnWEe8k+2WwQDHDcldMzgJWGxP4Xl
4kNqQBUj8G7kCQtuqDoxOjF+Lv6kXUSgOxG/h1Sghtwnb2Qy8leqaiD9yTyQVvIztU/c6yQ3etN7
DHSDlcJLnTDBZwR5lmNBoofi5HXtHMH1iaxh+WJBWWV3d5DYwzelCx301lbPc/vM6BbFf5UOsybw
R82RXgmrhyevFuZ4wRQJRrHCpVEP77NPSYbq3zAndu2E0KwdLurTvdFcMI4E6Dg8IgdwoUvtYDIl
Q52qBy7NU5dsq7fmrKtwK7bW+391yQXay3F/mZl2N1Kdo3EaCD7BAQLPzmXoP0rFD2M2RThC18xn
EN+rVu/DiJqD5J4PchD3v23qb9db3Y8fdOzZnba3VWEGiGd8nGH58uN3cgl4bjsaYfOqnJtHiZYq
lAHdIogHfG4Cauyu+GGbLvyi9BZv9E+xVEk8D/OKRR2o8etlcRzycqWmt8I6hPzbzK2/6n+zrDEp
t1qKNM9Ezbu2eVmHqZhKPrfdtkE+M/FeAabUkz3yA4TX1/IRRopG8/Dp8N1NuvtsSNTkn6oDZTfY
1DoJfoo+DXfNHZvp3ks7m/xbWhoW9Rb/nsz1n4wtEaBAnSg1jBxDARYFwhYd51VFeuOvCHVsKIKe
iyXyY5Pv37S9cQD1QBwwHOdBCZgoHKZ3TzpubzGN4u/vPc5/aLb4FVCZEWxnXkMkFo6NU5Y4mQbg
72idL2bg18LpZwN1v2AM8DwgrhZQULaYqFDC8xsytonAk4AGnznZ5kswQc24J38o5f27VLlR13jr
aV8xNvxmqQ6kb3gCoaOfK/dNIQX9CvRCejhXd0l8PLzuOXbN4rdpM/+InKXepxIvfGozuO6jk2GW
UIU+0cKDxsi2kXPgxbvbjjVCaX+RVSlRkbVyB5Y35K7F4ke6GQs2MgaPRp4ZSz28pRK4k2sAaCKf
TWxVVgWEzmpCxyqqTGLAmC0nJVlG300+8fN76wxR8UslPvn98b3hLgcpCcNfNjdDR1LgH5kjKkX6
5vU034LFHUndjIB/BJw9H3BSCCdy+pvgeNBIARtBW4oWp5RlkPAO8x/hdOQNPZffJFuEyhNTyBH3
Ll40bUl2W4p5StIb/nSQYL4BJzCDoGDao5wJzOMtzOlUDzQavH7y1VLshyFAEXCrTkYO11bV471H
D9u+oOxT+GYNV1U6/ih0JUcB1Q5hKxNLo3BxcGB1AJHrDYVKLDbkNPmtwhZKQIeICq5vJoOoXjsF
JcFLRdjRob9KAeHFlD3Pb01ckcVjblU28IdC38DFll5aCHgFxKnII0DzutLkBzqK4k0uruty2T4Q
5nCOwWBy8fSzYZN/HrE6DxFlg+l2EAZzKdl609xqepOf1KnVBhZHaVdo3GhMJ6KmT+10BbTIn4xO
zKNcWTYNBQARps3HFm/ITv/Je1+1DxzohnExrwqUftTtXhBrublWh0n1cHl6MUp/m4Mza76a6N9e
dItQKdB3Zx74x5jg+nIGuwry8YiSoUOk5smrl3VXbJl61IpT+z1H1MSkbgYxwTvmBPGfwR9zMyNm
vRwmql6D1BGknbYvTGC4dd36bVAdKhECrUP+R3aImgnWgOHiaKN1bEulb8mG3eUSw212HVQQmgtT
LFZrnFNgpGYjRPPFEySg4etpbepd/PMi3SwKgeAntQswVes16/XiAL+8kE9yuVlXfza0NZKFs7fi
1IjdVUgnGcA8JRuQNY/maW5LkgkKpk6nmhJvReBSwTRxkA5L3Sv17bwbnBCqD8CY+POnjs7r2X28
TD2MRR6oQwQ5a0AMgA+2DvoWdskYUObR3PzRrTl9jbGPHRD104l5DikrsfQ0qEZpzhRWxzxbCBhW
boSYSOVhcHcCc1sjaJExsJft5aHw2NMq85Egi6vjrmAhXWHRC1YccEtPoIrWgNsszJ1OjPYRj0nk
u3N88dcfXpGl8H6Ar7+02LWE52XefUC+uDF/WIDEO6gmbudXrpurO5G88kZU5JK9hIif/HDULMZc
1YUT3AhSR+FVAgTgvITJ/vrXo76IPe3zoMVpfGi3U8VtnE8ij0RebO+r0FuNcw9Frf62jB8kD5vJ
Bftz7Vy+6Xvbl5bPTvwyFTlonuP+J+vkJtbYQLkydeyzXJy8WzCkHemjUP+ijaoEyoHdD+kaJjlb
rQIGKBwg64216L26YziZWVqCVpEunB8mJ8MEareqdbx1NvzCupOk3I4pfXwiOIkMJSZ4NSLtix6B
5IAUNo+b414igMPi9w8gf/1y0zdalbbjlF2GMP0Go1XQV+6i7QPkTtD+0o/bdWD7+UEzZBPnPLtA
iM7W1ruO+samVUQi6CAQvv9/LCz50a9+QSU0EtvZVVlWeXMknkJ49n+mXNBk3gv79xNd50nG/dMg
Ex9y/XxcHKS/40GdsLG4vB81VrwH+///QCQySzSJOmpXNOvz3nmiDRphqCUanMPvrioSJpGadugb
CAkJxGGY0eITq4H3OLeUresWtK/pGPpvBovcPnWP7lgmJInf6w1baykdEmARwCVYBqq+ZvJQ6DHk
UgJtJfUjpA4vV/7zQf65CWKlfVRDHgLpQg5lGW9AL2kQs3G5ZeLXarPQ4AwvCMP0MXWJATMalKmu
XkB2370FXt4Zd9x1HeAzIO3rXN66LzexQ+h++7oHZ6dFTWokn23w/wxkCtJXhe8k/Ioq1d7KGP8L
Dn0tmr206QUCrHQwkfRi9yyiN6TtFL4X0QAbmKHNAP+k2F6ELBn5QZIrU38OuKptJHZKRMIh6nn1
WGHtaKc1lnbf+Gu6ibo4Xiw1tDvPclpaB5y//U+F+y0ZMWHgJIq7xqZxw/mg8mB0VP2Kuka/Xfsm
8JZnK5GvNia7dBfhE9gp9ZZ7hod9xeLi8r79YcXqxhWVfBHmsritcJI1vmaz5QZdgRsRJlM8KX95
8P/sA22ybY7isdTTYsiiNfCAXQeWe9Yd0B1kamqm1tv8tc2diQOxNiTnfCa/2wSHHH7h0GqXVOAJ
U3xgy3w+1S2VN2P1K6VecSYLq2HjnpKH5+wO801XmNhaZzKJe6xqBQSrI7ju4HF99DSqE/eD/os0
FdKh/7Z10MijdGOMjjH3Ze9vhwLzmS79hHNGISgO4KiSdO8O5BMjGLSS2ZatbMfu1FlyHVaWQKHp
USAEt+Lf8hk1SRN2qzO+25pF4gB48iWtAXqpHliKgNLpHIR2OpSSwdVlieL49ksSanDoccWvUgxB
wNqmcsT9K7aZ0vkJUf8SvUnOX3CA8NaBRtCC+HskuSMm6FbGPehgih4OCz6co6KWkp15VtmVtgoY
6SgQ1ym89JJtBPGeuzCff0Z8LdlVNrtOwOMFNsPv/Zj800BxJuJp0POaL+R8bdEWG6YXwYp8C37f
mUaOnoOqjdOPNVe4mCQvNG3yBC+KOztQY1kihPeXrFBamwQ6FrJdZD8gH8J1EGaAMRRFRAUjhIt4
pLHniwKuviZoIgCNBlP3aa2V9ozIwaSVkRbiVfASR9r1CcZy12zxuKt/pMO/b/fJpPUtG+OrM4ut
0l+UN0Dd4MV7L6BGQnwpYXK+M0b2I2CZioE48EFkp2Tqve12dcRabQd8K9n3kfkKRrFZ/rSl+p1k
RoYfXRSA3WWOCnWR22Z2BsOLibwDseOctoRof9lv0r8E4047IXqJK5EJVp6hFQEycgS/h09LJyp0
pHa5JHcGQ6drUO1vXMPuG2OJu6KsIMm7dY/ZD0VVSFIioA6EnY56mfSXa3QZ3cuFuqBwbVTkdFm4
HlzM5MC65FeAxqhddXhgRL9tZhNss2+4GFE0blcBNq+VR9QQEBJF8UYgfLQ9niTn8CncsB2jlaF3
c2/vH4Dm+4guwbTnh56tYEk2yMfLbndD2PQVDdQhvn6dOpDH4g4izg/8WBpyb93h/RuwczgNZuL5
1Noq2d4AEoN4JAp28j0YYPv9iBEjgskvuiIVOxyudRsxhFz/VFMJbgzzjcxDG9rQcBxBLn855gpp
tGbCI7lg2Tul7Fo3CnqXZu1HxQMWCbL3E/eXpGbxnNvA+5qUy6JPYWqHnqHw3iSplUqXEGpjDnOu
LNHbaj4TMXNhjWcXVIN+J/vi8W1PJl2gWJj+oLK7/pRR8uQ0ILQSOZcrNF2RPzSYYqOtxCx8NonP
pLpufvQGYom2C2PmNYfo/oH6S4Z6es5tbv8KemaIQvQi0WVJR25vn5RoHbbDo5jkPzo9dGzfPXvZ
EcGuFGq8SZFcRKejzY6nc6ThssVIcNOiPSBg8VyFsvg7g0YrE+Kirh21ukLrYYJuqngysjluD6+b
NRjmMyVM+Mu3XTUP1tEkKU5bkqODhuwtGS9iuUxZeZTeMJ/9Cfeq++tHSIR6qYs3nv50D/F0Y72c
mcAYCbKVgX/FsAW5E1h9a1AFLhnJV4atgQnfqheq3RvCzXrR6mv8LRDlOc913LpmbWE1DPrR7+M8
Vo3/qd+cOkudAbQ3J2HFqSY8FHhEGYEhYK+Tnd3IBJCM2cHEXrRAq+cqpYCA6/59B6Qb/m5FeSul
CriBoaJ3jUoISeQ849F3yrnK0/jtynrCTAZDqKCb4TSGcgidHqQIDHG7ZSU4f8gRdlLUbv9/0tP4
fkDu1Lrxn5djfMofBKO2yToNAp1ygWhGD1UtXtlne0hG7J5vCiwtm+x6/UD+wa8RCmufJHxvLCkv
jcnfpKj9FUrjbiZsaxPVsGyzioNOOAZsBib3NEQbVr70Z4T0X08NSh7GuFSfsy3bA5wE77zsPD7k
u4yn4scdfjXOoe6+Yr6+Pql3YQz8IZe1jY7tZdUABV+QPRNC317MZ+mpRg0epiSGcRqcmLKSknY5
bYr2J6Nn3wn+oQKEPzSwJK8/QieBWpg1TeI6D0KnkRbgWUimSTpbclM7UaiiTi6Hai79xBBV7Toj
6er2vSQkciKGrfT/As/2OvpGbce1T8rXAWZGt6adF+qA+qTpkY3DQbAW0PI44K2/JO7FUGCBzUY5
WplbqdP/8ei7BUdtf/la2joiHPh/3W4rTwQ5XScgbe/mo7UOmwSzSX2lAkq760/uaqMtF+LP+vEi
UR2qPoZCcDE8mBwT+CkHulY9T8MyM+pmzLKFOg9yo7HxLKrAoi6rJu96QzSp9h+z2nMDBNh1/I0s
gg9+/gPo96uGnuWK6Z/gS8gx22JHSy7/ZujUAiEeyoGBCYlb8qOcXQn9YT4I/0TjRdOZTVjsNkai
c/V1GZsgzM8HCAqZTDODCan7+I51Ft2ZWyEaGlBGOCIwV866qIh917Oqrhj8qjXLbREHYEKdfa3G
tvz4d43uWawO64GFSLaFqbK+ENEjTjosaGkAGd76xhGJpLi5Xeb/hCdQDTs06mV9+2oyPUeaXELX
n0zYfzfE415buMMvIlpxmQaqUWI3cBiau/8vAIhGlTgM6fgQBs8oej+jaT/VWA+QC+wplT19oKwi
JGdKDRky2YRbt4Jurafai2I8QiwFEMOk9e4Aumx1dh42JoY2l0xA2UWf3QiaWpH3zeiCU8i3Vu1Q
l97ITgg2WDlNK+wFNsGgLePTPkEaxNKY5awJEdTNZtj0Xue8iQT9gR2/TQ7leBw4bo3uMXHH6Pg2
cofaLozZLoMTcqeCPAfu+LVBomA5aArRGSNzqoNviAKFHnJNkNJGZyMSlQONcfZGrBzxXMue2ah4
UvCYWOZobnmYFideQgJevV7jsAt5DXZZZL9Esht+1YgPo4UdNvjTHdPDXq7rwOeE14hU2FJKZsVD
DJZlY6+PbAqWeZ99HdnYfMvZk/NYGfJThveuA6Qv5XDUoP43blmlLN2mqLxqxzSl237e0UGmSw3X
UJeiECXreA8YZ5mGJ9HzEMAKMVWaHrjo4FsinvnZ9kxzKiXdf5P/QxT4TH/x+0rduXnH9N5PzYXS
zl0Xa92Cus8KoiF2wANzV5HE9ACgm0j+5JxZpgQ/f/7U429rVyXWNM2MgKERs+8cCuJMLKDnJPlo
jnPd3s5ikC+zf03ouLUb+N+ObcX59N1/eFtKcyOMbYBP+k5EL6eTOEMWnrw47z+A4YN66zLFOj7T
DVSHOhe5CjNXJ21pJ4TIBOM/1Jg5DhM50zYZLsQHqTRZtW+VY6urdOgeMpsvcfIIcFTX/q3KsPx3
HXPstJ/Ex8r+oYv/7DPawzD5HMtH/CDcJvXI2f7xZaqFwOJ1SqTs3zvhIhAT4PIN322nD9F+t4Y2
/E2u53GIgeWsEV7gtoWDT7wXoP1FhjzzC+XdFjA8wKDW9l85voMyb979JRCKywlvfV94cMnOO4xi
9VfDqf0HV7w+OwHf91T/g+iAperjKNOfkh6xWVxN3vFQpn9D/A38rp4zr/4V6eGHxnhCMwvGqmqu
ep0ZP3D1IMc2/dS5iF83og7OPRqL3yk/K965WvYWNdGCqJuSZcnRV4i3eCze2HdEWsfgkMxVQjm==
HR+cPzn1gXfz0ozT3uy/EGSL8gb5d2EsrYXQKRNF3+qvflSdJt+uR7I3PgPMexMYTT/DqEW0nQ44
eVxnVSIlYVLpgsPYeh4UfdgFk4Iwlb5/5V9XY0F4UFoBTXUl1iikwLKrcnXZJUVxDnEmZPzt+y59
YSmlTl9FOaYLp20tFQEHQxsMyg6ty9Oh7ibNPcWUuPcXtkGpgZr3IO59JermFvsM1epXr+mxwVhA
Gnf3sG4IC/znDYXVmA//PL2ias6tfQGez5nfPGmKmfpz4b1lkGYmk2UiCoCpRswX7lbpREIEyUQz
oye4W85jycDo7NKKmEbG34gdeb8lMbvpzGVoDe6UkkFQnBWa0VOLnzlA/mKDJBx6doR1vRbcp8SJ
yoofgc1iKIRBAgFMUd7w3jOJgiIz1O3u4xpN+tMGuTthMTt/wu91LyuESJvYqybEb4HJVNcr7+aU
eus8SxYvQoQdFv8vKCvORXqEPnJln3d/yOQRUkCf4yy50EUvxqjsA9RicRhI8QzutAj9USrv7lpW
MXSTpCcRvixbQOGjQMz/xeDPO1GhbmKR5c1Z20+12TlJR2BDoQME82h502rQSxq3c8Wpzgr+eKnN
7KbRdfh5twsCLVwK90MYfkl59wyLNHyghUD2PtWTtLihHVRooEkx+ao7ro8CdJzOpBFbRJFRmITA
NVzC03DBHZRRKp7uPkzFysIbqPx5TeAC7rAJ5Oqg1CLwvjZdqVDW2Com5sshVgFSQ1GKhWLRHyE0
k2HGch4ks+8X009cC3OCDwiZx2TQDSynfrxOPnX28g7QthMnHaN3ki2nmkort34lEmlgPa8qqYbE
3G+4w/kGHkfGrN9Rc2rAipSQRVN5uzY4M0BeRCH4GY2bEdrEIUTjv+Fdvo4roJKAurhXQTJCQOc5
i1qiW3kTWD4RMqEW0s9pbVt/JdJsVhgmHdxeR9ZZnFflIIBNRS2LSp469VxHOOoAmrNnUyCz8SXi
p/S9KiytuQAkq6nJ3bzXu9DjUdLmHVSNYikProj4QGtmW5d3L4EsN6onL08AX4Ix4qFHrttDiXcr
Z91M6rc4sO38xPO/4cWTsabnvW6Zeagr1EBqwc+9ASEbo4yRQapdM983HwkSQmTq7OcclnR1/5vW
iHHZJ0BUPN2qzsK5eXY/RxGZGgGzsuHSLPLnfAN1pd4UFH+mI4pHQ3qMi7i1pjPlh2G+ULNR5EQB
l0MX9ldvM2UUINYh4NgIjHL3jNLU9KaAcWiMRLMrfqeOZtnMcspA5UnKwyVNy2l/ThxhqSrK0ns3
7McPZ8AnRJZSMwzty4FUWz6j2tqx9dPnAy9Z2Rig4LrWVMO0qBPJGclpWYoX1SqJfkkAofQSnub6
rzsPNt6crJ+mOTddW7CU/c2YoigApy5NUCmwtqTvuFRVdQSA8Nq8M1cgEm/Dz4Eoja1I0rIQXWwQ
PpkgDDSxWUC6S5X28odZ5MLT6nDZQsl+A7NAVn/R6lqiWAFz7TILxVu1q5XnFKNBdP022Fkc0mzg
C7+//zWoLUn1p4BBlplOK6mfzlzEVpyhK3esWJWJ3tK4hcW6BOD0eIT3+QAfNlKGXVbnxlPhJF34
Lv6YD0bxX6YvAt3h5jsK558qiwpOSLE4SuHvWXrF863ZUc/NMRV5R/XjhWWP++3PDeOMr8axsIm6
+KkDusD0ZWwYtjvea9A4KXawldFN1IkSieWujj1+DohQmWxlhBKfH+zxLVzYfCQiCzNa6SQ2dcBu
fTG+wpSbEocMxgzmrCZmZLMz2z+Rek/CwouKZ78K/52fB17Pcum1s1sEMePJYaGHd95p1SELicqI
GQ/93PVE/2raV1T3a5cy4A27Y218TQrXTcUxogxtz52I8MXXnCh4HMFv1+IClEv1BcTRmaPRS3r7
k6Hqsz4BKWDS0BSB2VQbA3yKULDhMJecJ8T4luYghCTvD+/xquvAoj64jnsFiB+3DyWEMGBMTrde
jwP4XpbhN/X6A1Sl/kGq8johgrg3aTUhZoXqsm+yD9FNotURdrr8iw+9rZ9PIRpLjwINSD9cng9g
o455XkyVGqC5PidXp28q0MwKXmKeWTMNSq4lxU4GClOCWI6I/BR7nMLwodRqXHw7NtcDLFnd5io/
q63fVOK5UeajbWtTpIF+XOZNw7OT0iroXtxhBRvZipdD9jufaQZRchTHNu8LgTw+3p6wCMMUYtBe
mv22UN/h/3YsS/xpLL408uzl1gCM8pKtFfGa8j4OhdjWgmXKs5dc90WGS6LW6bgv6GdMZWP3JNTG
vHbu3IHeiJrv5vTSMbY/EbcvshesQE3x4h8GaL1k0vgs7qhjIdVR1L+jZdnbARtE56DPbRywOZke
wQ2z7A0kA96hvjNdzwXoK7pwq1UymPRHd+e/dper3dEs+QzD7IHz31+iQfD7e2HIn5V5k3176l+K
mRFuAyIgUkAfYT4ahd3Rlx1mQ1tlyv6NFfDv4ESsLEAcmzhJC616iXtmX2JTZpNJGXKVimBKgviv
NnxC68IIGAvNgQwGuoAtqSzCUidAB5/6mvzSjFiFLE3H9OkT2KSIHKq5mX40qLpN1PbB7Su+J4gp
lcPKKMrZb2tW8dKjP9JKPkQOf6Cjx5wNr13L7VWj6r4M0gn/GFHUop0ap+rZxmPY80Mgzyu0XviJ
JNvtzccTSejZVIEd+YRaJxHbWnI0QtR37yWQ+2FOGBR2eYxfDM0tBch6uQbYjrx90V9AMpYT2j4u
w8pSBYtQD+l1RdtTRTm3+CSFU67mVgJBulduJV/OzsknzBg1iONE0uNzlEU3XAiVmKs2K5RwHq8Y
nEwcCoGXMwf64XvflKGBzv0M2a/o0MukhdLAL5ll8UKmAQcJJoX7vyw5JN2DgZk668GhgMPpjeso
qB19xdbjg8KYBBM5mrI7Axl7PgmhuCMlPpGvrouoMGItn7TCy5DLf/svrtjMB9McQf0mAEZimR5U
KqcHYCzedcIPSG9SD1gl6A8+Omh9wHUETg1gajm0GJTZun711IV29lV8igLcY3qbkANcyTmgLs/C
HnA7qwfzBi/xYOT+q0176cgPSgV6y6PiRZR3Zs4qMiN0le4ahWnqQqSChWtolFv8FyvMQ8KpA2aE
VsTNBWANi1kWK6CJ6vZ6AZEElOLmGfv626qv0aZpFhnxJU8N0Kl4d3B8j1wzxeAx5kiFDXqtzw+O
ABJRo5W+XAxwOQMd/NHGoO2Qo4iCdD5jY/+z5oRZT+MlkQbVP63OluuX4zWoOkyX22przY/EHrMo
FPw69+QVtEwEMSSeG+sEesz/pfzRSbfcuvpsH9NEbx2Z98jLu4XkVc71RHM2LKAgOFi7cRrXXe9D
OuU18+h4h7v/g5Ln7gzUHdREqNP87zAp/9p/zSmiqtfsV9wIJ9ynJ9wb4MWVMl9epxBqsd6sJfwF
1cEZU1Jnx+f2dvTAECabfCLcAwmYFqAFGb4x9OMn1IMMkh1glT0/G/R7dK+d8axNXCv1cxfZQ/Mc
6UXKJPiMzzZDXooY5nqT5LptvF5Mn4sRpEmFMOBcA+VkRXCLjVLAw3Y1efDR71lnPD8II1aVXhzP
IZ9EwazmXvO0VkkX2sz7E5yp2OQiuiXEN/jVPwMay8TMME0J2FYiaHe8yTCNrpSazL2RcT6bREAv
da5rV8YbrH3u1z58XS9QNIk8ldlXymNlVpguOk4PcMDnoTIyclmHrTDA51E4M6oo/r+f0o7rpSzk
XoWlGEcF4sWMe9y4hyoE+rXLpRWgkjufoEEcJZ5f2jILSxybNxrSTouKBxg4WwDpayWxCfeP0Whv
hAvaFt/SKWBcM09/3vW047T6k5SzVOWH8KtHzJPHoH/xGSA9P6YefbuksBRxjq7WyH+wJF27oCfy
XHrACGRSnS2UEwn+krhaB2iwKg9XzdV8oQrdUIr6TJaVxC72zo49Z2XCT/MqiT9eiGIYmOI0+tv7
S21o6KcJ5AlKwRq5rCtEx5fkOoDAKP14AuG4f+je+gjJdEKNurfK31zTaLkCVPYVef+uVB8qGuVr
C9oEAOopKONvR0QCv5Rul7HB/tVqdWMLuqmWzJ1F+zM/ctg4IKINgi5aT0KKAaq71jcgAfNvEYUK
7fvRWdlK+H772j7b2QmJ8GDwMKI/7I/fs4xuqtsEHeu7r2s7W6qZCg4x6gms0ToMKs1oadHkV0lk
xrW5pNSpH+Fusb4lj3Iyq75qhGY5G2DZ1rZNWEpGt7Z19fn60e7DH9JwWfecyq7ZrbrrAziYE/U4
jDFFYv+ZCFwDrDA3PE3SWuMLBgm0V8I3pp0YNRVdnQwCkmlwHALxNa90Fgih3FV8jEFpW6m3OVJk
4sQ19ORNuMCO9jGIWsh7m2YgJ8bf0oibUStVnGbDruyQMtAVicPyNVT+2BL8ZLLvgxMlxMRjw3bd
yBC774dg2xkwUEdIxLDnj/R70Uu/AKJ9jh9AhnF52ssXKykiFmg3mKmVbjE+VguaD5CDwCLGRFFt
1M9QVsTlCHrKn+WUjofsgepQK0XPil6mLo4gTYSJ+M4n3PsR6gjpBGacCRgWKOz5XOS6GmA9Z8D9
FHStBpTvvWN0D2W18q4IfffG6iw0oqgxPfs5JhUR+XdkwRI2iDlZ8nHi13AQFXTD68+NJYeeFagO
Zv/3QhiDq6PE22Tfx5f/AAfgnZHyNO/5RzB0eYTCx0UtpOB45zAx4Prl2mSd61kBdZ5K+T3RmDr3
OUyaFcgar+3d+KTnQqbsQO0uzhVSqe9r0r/KGuwQzVVoS8o+PaJLV5GXuEdO8YrNk2MP5Vo262/+
GM9E68afBVBENh+KmJ0KKVz5VF73DBXkvA3B/rJW/ftWANUvMnXrrMYESsqOLhJfGbTCoNOUcM4r
b79IkYagC+xaAleoR//ANo6yoYeiTPlKxiqHEGXLcrCurelZ0kqh7CsUFNbKXIzR8y510kSbjpWx
7sxGu0Vl0x4ug76IwXse8mtDKYLQ7eaHTNr61Qss6PR2EDWVgBNpEqxssKqZfPpJ7sxDUHc6gWjd
77vRif1p6kKWgRfAectDczM/b03QH9AICoxJWQjx+qvxpzmgYzaS4kvg66m+EAKui/DuN0KKnswf
vHaxFox0ZMUPIaI29mwz95a3shE8qPzRJfxaUWPEWBQ73X7Gg2ydIuLHd16NDfv/QweQoornh9qo
rh2NEfjnGAgyvT1G5JaWb7MpA91k+Qw4ylFUG9fXpVe4ycwbMt+BtQbVpSLFbsAnfT55ZYObI/yc
2a/0qMaZ0TEk1GX/Z/FrG8fngrymEceQdZ2bxIUHmE5RC+LDKzaS9aLKYy/kCGcHUzxNXjm9v8vo
G2TifgkiO1gelkrfr/e//ll3BCjsGRBB7DtkPGn9oJVuOo+4wxV01rNVVlV1A5WuWCMBX2oRvUoa
7DovjXL3UEzAqJim4YIqaabpJqw2kNjVPFcQi/YlTTFbebNL6yh7zDLSZBwB+ZdU45G1UkgQQZQx
sHWlfYUjo7lvYbuXm2089FvmX8IVh7an45Le1foxP0h8T1fSFObb6eptPpz/Jftzu9JOAXK+Zlpw
Jy2UreFCPPgHTrGi3TEdfYV/bmNMtro+t+OviyZK7OgSJRodyo9wK4kaS6UB5Z93rb2KNU/5yc63
t4PhsJPZ5vepgggCFMtAerPnfr887FuV5S+vSmwvoehnHCzD2D7BJtxr/loR/5QwfX+9RxsvB7zb
fWLGm/p9Lwqep3Qd41OFSsHg0jTEEkeMImWMbwp0Ag5E8ZzrRC8PDnLar8D3mpTlTzkgFpVCgBeN
awaW6D/gc5Z0JsMyNaZ3kUN0rTJ/nIlQbf4CrFYUzfUx7xCWsVTFDB6LaxPtEX8c3auNqO0NYXTL
P1GJjNPRK64+by0ljQn2YLAZ5WJotOtYRdSKtoO8Cufp4aqEgS1xRDpMy2b3OfFUZyExdnnVlFDJ
dap0Mvn91z9/0RJ+HKQmCJkiwbmNHcG7Q7UTnxaXAh3ZCuj7PNghOiBKHhzWlSJRtDanTqkjpwZA
5w6Ad+zV/1yOIIzJTcZUq8Y/ghAWbcj1OrCaLGjka6Fs4H8ApRjIXSmpoDDR8UB1Gi1K5Sbd2mGi
4DOAyT64p6GGlEWV4Jf3sgwXb7SpX76y+5F62G==