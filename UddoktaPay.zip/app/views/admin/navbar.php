<?php //ICB0 74:0 81:233e                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvi7aHQks6bPmCO4DRblTMSmIMbOFK0SqulFvg9/cnJpnbGeD64VJwQv7UVTWU6gIupIAyRf
vbq43UWloCduIsCiJs581Z66aJEV5nm6pQGQszQNSEdpdmSaiQYNadJrskZjKdtn0T6QxASnOUn2
65kHGbUMNso/WzrlJtw4J+fcIoif6qJ7G587m6hTcdAsY6QJcWWhmNuc81RZYAihf5NebS9W9sqe
cA6FpsMyenFAXwPIs6MPRBhIb+zzzzFJxLx105DIkCLpRIg/5lYF5K6dtStJTFTlRlTsYEq1qbGA
L1rZiznFx5pksdKcKe3uN6lAA4U3aVrey2onGtq23p94XL2IMPzGYIVZ6rCBaE5yTGxubiZpHIAW
Y9XWVroP+63KeQ+Bm3x6qBrjXbUYqCPxqWXyYazEZTXi6N6z0aGlP9Z340EoLFopSav5rNQWDUwo
K6C+C4A55p1Tb7UweH37oWtDFwwU4EuaTDf/po+SMxp7CPUQJ17wmTZ5UOcFsrRFbRvF6O3qJn5D
WJ16o8JtDcckdaHnfXqNdMuFREOKps4PVRnsu9dsKD/PZ6OhJH2pHDpomhEIjpbfDfg5uNczAjWb
t0kpr8AgPeGNlHmfEPm8QTSUagwNtktbN2MF+P39/CKjG224VzFs7SiKD1Y7TZy/G5q+G6hQzuf6
MluRYziMVfKTNZA/BXvb+DGTUbe70+sNr2Q6JvMoA8rRdiXM6arNwmDLgO/xD80pO8hKsY2bbUY1
P8vNOrNreuYkPuHxADxmvNCvkq/u3IOihOefHxePcPVirlrc+6bIRr2tWvNySl6dHecUrVePCNkc
8QD2Nl9+nlHtGJE9xANlxGQVBSJbS2R1o6oG0rupjv/gksNSXlFXWJyV52CbCDm7sTJvSflQHzYY
IyGG1dO1MduQADUehzptRUTPCv+ARMgXJm6s7jnBmfwWz/CaAeB9esRDUD+eSk6pdIQsllsVtZa2
1SKmyOIrZ5v68/ZW/Mg2MSK1vhrpn5ADAfQbp9f8DOs+po9ekeoNbYCNWaU2AbQTlyRC2SFs4fCz
0mrEaRq/wTdn/RRPam/3R63D/Ic1K2BZvOiv3BYLTGE3EPsDNsPSwwzVZhNF/huRpdrywZLYU4+G
AtqSVdiSWhTWnOW/HQhNa8SvM0u7PvUa95OCsKn94To71NMC1S8tdfjeDv0UnP2ijYIuuEUaWvyo
gssLPYGZONBZq1ihrtFGfj7zOmoG92KsNfBfcZiBHY73s7ozB4obTbI4YHyj/6n890CAUueb/RjI
kiDXCBsj/cWw+RmJ5loQyeuvkxumsvwFYYVR6279JZ26dwf57p1xnT026/D6csD2J4UDm37KZbba
6PR9Ob99jhssDszalpd/8JGFxKiCJkimQXhIOg6NnbFwA443B5MycRPm/Ie4E4YYxjil8PKdLk5L
lcS/vDAzKEdN+DA5HkykAq0exD8E0VTQYl+N+f9agJqOJcemqG/y2TW/Bh3VB6b8l22xD8I7AVtH
667zfkkX8FzZsv6WHyL4EtxZpbn8DtbXr/P7V9V8Nsl83uRBDBAGda0kCKagQN+LDYxQQp0YVj4g
W2qbfY3bnqvFJlj5h+1olEl6if3k0luCu7xhPkLntTvjXCLeFvY1h4mSxXPSVeAeRJO0ryAov9ov
0XEuCKqNjiz4JA+F3nnWzu9XrOxmimlc/krCUjHP6yWmnOxPIPNOJknYnpx/7L+Q7KfHY8DqJ37k
S25vt/oe3RPas4fIFTKpA7B5MUO03p6wFnImmh9/PDUaO9e9PMaxLd6qnLJwcE7cGycbwDG3BWU9
3UaMX+AKo7OFCk6AlKDkcb0DspfJdIvS3UTVh74xGCnCwz12FkoBQPPbEcjuuKTqe/SxlxPLUmCx
0DxUqzEmm2owDHC0a3NwuSzjBqtaVi2f690oqgk5kqDDFJFTvd3bIYrn6mGomhMq5qDgVpQJT20z
hstorgJsPg2pHZTZwJ8RkDhHxzu4s8A0WSdHhb2BbuQE/l4rL1OnD/NO/rHN90PXxdnEL25PfTFi
WHGgiJc5Uo9ISAxRbl3c4//DH51VoV5hqLy0CdR3a8BtZDeAawDTKSR7YvNLK7YBfvysNF4QDqkW
fuu5wy2F1H6x9SF3ieBG0xbPb0UlcmH+dUqKifGrG44PBNxROQgvP0q1vxuZhIHgCEo2WxcTtijM
cDC9o0NagRvYVhfBHvt5KletrGOakYNp7Nc+BLrrJxHvFm2uo8KacsfmRmxdGI/EYy/wmyCBtUUO
yU3bdwx1XPxrS2hbyHgEfc+Q1boC1YevLSKeeru+FmJ9f3uxlP3ryxy4oKOjJhpY4AMJf1oyglY7
QvHA35vdgyEyqGb192kLNnKQibuPx8dwCX/Guiy/8cRxucyvsaLYpMeEG35P/nov4SfhCRqv634I
cp7EaMYHQcCQtZaHFW/KWorezOQDbZG9cUFSlpJnqHYRCp+PyIXr1CfHKUGWhoG2tHMNQD0ZDjDS
fzZc9am/ICWhv17PjC55Sx5+iSQlHTVyeG7hsi/Ne2TWhfQw9KlcgkT75jOpnuo7wuIYq66DeRAI
TcApV2Kb79tcRLehWwCLpqPV1zNUvtSm2pxJpFAbIaOc3e0kaBRg90CXoLlOfiKcWViOqPNFXgC7
xS4vuxTbYMRb5m8AUWQj/05K5V4/bAIdxMggBm5C3egpJLO8AmRMiCIdJM2nMXKYQ+IYlLCTsU9v
RNSSvWeh2A1oKZ+tbyqx+6LYPsp3eifYfyjFj9pRCVFpzE7ffPzgpkswkOeIy6TLTWIklMiNsSUQ
07mgTlEZfEVFkcJAH9VwfYomRmnH0AFHXkkC/mIa9hnVUsUJ5m18F+lOpdi6xK5FQyq+gfwJnrLP
A/R5UruXI552PW34rAzVhmrjK6cQLFgJsajI3nKSZ+Y4gypzdlFHdl4nUYquOzp+kwa+6cs93VKC
aYff7ywM9SS4f0q2QT/tlVpJuCBc3gUzDiQPDkm8NhXNsiljvClNvFrbERx+9PDz55plsuNoZ+hv
a//e0Nz8DjFs6G5pW7dm2ww4d9BwMoLP7vN40L/W0ZrVOGG57gdfXIoxCyzClmZ2vgazAVW5pAiz
0efUXdN6kec1gPEUVaH70ktEC0kxQl//kc27bx9La+RZsCFlPUuW0mD3p4wKKZyxPyX+v+6rwoXz
lh+DoThr8mjhOPr4purWZvfxfhUexMVx8Cn+nlQLfpFg+9VewJ7J/4nPZgQWuO4lPJISS8eTcBx4
z/VyDv3fO4sxUtUWrKji3NXRE+Vu+Al9HBTAvnCYvjkT8ZSj2GCiX+lbEdmiKkAJu3V9GyuOIszC
NogsvBAgocJ+49A4aj5t4k0uilWpZv9qYEmRQegBQ8smGzoQH3/OJc0v/vJWt/rSvHtY3u0tRvq7
qjdkXR4x9uxm/Cz4YiBUduchT0Qy5teWuIb9fspT9vrJufkcsBHeYvHf/a75EX3XrgbCSp9+dWB/
CiF0PHQ4ecdTHE38UqGNZy2jGn+pPyWTHC7U+VhRXp0ecmFmiTQRYxdAu1HTrMJJxk3EVva6wzSc
WnVmkUOC44azjKiqlc3YVooPt7wFgN/gFs3x6CTQhx+dyfC2PKx9v3DmFjT+v4+g+jcjexVvp6HG
nmcS65CZkKwadjslarc5pzP2rg8JUQU3YG50Lr9hW88BZVKknUrg3XsGJUD4rD+0Gb26a9xdBzZW
ZvYtpHo+HzvSyrLU/H3KZaqzXU5p9DmfKqv7YgjCs2lgsdbiBY/J/QLLEGt+WauCnWn9kY7T2ILt
vrXyDjmeH55/xgcIa0CHEPD6bx/z63xPIDMYgK0FY9VU0BObV7FACmMMRT2V5ajwWxfK2muGyXMo
oF387A+28Sh0V94eMtKjFgN1XKb12Ul53HLPiY/PzmsjvxJfTnkBe1BFtC2ukV3+LdxfrI3jH0WV
LQotDv3OrIiQllE4evYnKZlRTfQsTv6Klm7b3QQs7nToThgwFcKe1s4HUIC55VdLQ2oGIn0CNZDr
GaE7ahaEIeFU4+ATn4+HvX1K5vAtJ4QuDxfPxnNIvyCm7ghx2hcgCmW7QyooxO3OtGqQZGIOe9eD
tspgN8bbErfPXQX34FC6HXnCNiiH8a+b1uVkd1eDfy5O5x48KXJNlfU8kTjBS66GLT+/2mNzS+KC
rvBa6+h+tV8/cQmdS1nMbORvQS0quVsyG4z4oRfGuw5zr16/deaJ0NLS73z2BL+tfljQX8aRA5Q+
+1ocFm3T/xY7kfH4YfJDnBGnLnTKtw2HpMnEM/yW1SqzfJ2Pn6x4+KqxQVxSzcbbNogL/3EdwALJ
pfLyQ7JBj4sZwFWsX0M0BHzUqXmAZDAz9XrWGxj+T6LItgbM6t7vtjqId/F7oCk+d+yzQNu5RQt2
TEJZ2kC/LTFRutrhLmQNgAGAbyFzuDryCgZi94//RrYLkHD+IjeZUyvGr4Kg9qYD8B0rvEJzV8y+
9slPW/D5d+Dd4/4Z6DVz8CPpQEIvPHfa6Id1lPjZlMkoNy0x28Fm6ij2DoGhol4o01fJJk9dc6Qs
LqPkm50c3oIvvnPZ3cdbEFTJ/TFMVzTSR+KJL8nBcs288vRJCgwDvsGZAuiACRHPQg3cfh27vINk
WaSvA4DXkDfJHA5Hh/JDE+Gs4IH3n+6CrP09mMv2GcgfsmsaY8Wo811S+YO/bjBvoCGEYBrxKGJi
PyUCLj98XeJ7hW/O88acccJF+VtEXUQB5iefNcm92JAHRsKOv/ypTfU08ROG0bw74jhX74H8+tmY
n1uCFM6ph7PVCJFDZkOpKve61neCnee3VzAJ869FpUckDa0AHA8kStbaPZtdoHmcif1c239Gh8z7
xUWRa6fmmT8tePvxPSNRJfTeg0MSSNBiV6kxc4kSJonJ3NCoZq3EV8xX17tHw8v5PoArvej2mIoE
I4Ux1MHxkDiWBkjJYC24erigw8bzb47ZVw4WUtHSErNHn+j8i6Mwh0u88uDiWHs9h2VJhUqJdAle
+RMCco24E6fFmJWXlE3Ege+TrjyiEywwT+g6ecoJ14/VUOHPkNEA64vetdSqSosDyFOsEZMtA2hu
eELyyMWnxPnLtegQHbJ5Q5oKc4giWZY2NWHA04VLUFDjEVtkd/CE4DbC9mRgCBjnBJxK/ibUBxXB
4BQiPzyXhYO+2weaG5y0wXDMixzulvVc3/zuKkEpx+7D5L8+EgjKhp5UryiwOAf+Dhb9bnPL1gXN
LSpLIVGjANDOP9lDj1lvsHt4yh4EUWXESRzbyrc6bWZdqtopUO8lzC0vHaReoI448IgidfKvpF+p
PtIULTrIqH8G6OG9y+LzQBTRKFjYuZqraiQjSIjULLKVAX5QMQjqzFXwIcS8ZGMebMy4mXmhVI3X
kCRBXdqJFekTMf9bz0Gm74ISW9gXFomctaILtya+XOlymnnIJOOpbvsIXEEBLO+AjLcAdJ+e1qBS
Dkw579gun1bu0qspNmAFqWlE0ZiT4eNgHd1DB5akwz3Atm5t/k3WNPNQUmBpCB13XLjIhm0sMR4H
O8odMnaYAK88Cm2UWmQ/cdeVPmpOpbh6wM82cKYOKIFNbjsxuNHb3g3knfdXESxQ7Siv2vRGv+EI
UN0AJ+w4CrgmCdE4eULIykgWKK8jtCZC3xVks8WibcLh1RMM/EUsfxBHPdm==
HR+cPvQikscOSW1E4XykIZLidDylJ5+25gZfvFPkDSxL5VnDs5S5wmq255KvvVk20ktsP1Ipz04v
FrXuiZk88i1izkTd4xjkOdj55I0RhU3h5TowozCbCmvcNMI1An4xRogQUuoPGeuN38I3lsmO1hiI
3gHOpykR59y/G9lutbVonA7BBkApjrpj/+l+GLlXXsZ96GAAht4YtKphrLArrejtmsp+PhpzFaww
uG2oJyyWj4Iy0svMVUxwS44LSBhixpYvzGxVguO80kjudz0+enx2IrCwXYbnCn/6lWdLcNakQ7fO
pv6zIdDH2ocqSFgkScUlQkUdDPXczQZYrtNrLl+vnMY9kX798byc0GSJtgR01f0GoTDKvcj90CHd
tIP1c5/d1wzV8pitdaZNrLownDbmF/YT0O3Zw7oGwNgjEUaYARzJJ1Bp4ILKSfS/f8mb7mb6b7z+
4pDjXZx5BSwJkyWbK0rdMyKMRkuUzr2KoSr2CmeCJ2QOUC31MW4nXE779fWU8uo58hE7pl2KayUp
uDdjKWgZSI5BdmSZ8SsFEwEy0+8UZimeDsGjVK1Tq24LfsZYKW/i5z4IdUgrMs3/GkmTYUAfO1Uj
R6ijzy1+HuJuxy4fXxAcTYqgDuaT6BHJnWB9KPXRBA3JBL71tuwJ6+Z4jhfH9h7VLHgdvi/eZbHQ
/wg4ayGQdia1X7Zk5+p2BiFwQpHCcm32x4N33DMeWWddeJkQM/ipdp5IiU7mJ/ciAHS6hsHlWRzD
GxEbXGe6ig2gXJc5FujhQA+X2iAnuu5fBKGO3JaHrcIUnaJNxqTS7sMt1DSr3v4hwbb76v40P6hw
h/ynE/m4R/md1Cd2B9UGwZdzk88gKzYIThZofDGJuMshYbGHqIy7h+b8gJ1j0Azmyb6NzTKo0hHE
M/SFgCto4hzgg/7k79QHG044yU/3TkA0LPQQ5puCv9OELqo/HSlSEeczijwYooKrRaRdAVf+QkVb
i124fYtRlaXVwuYGTZ0k8y+ElS+YO95dVR1/8JHae8S0SKvz3EknhWLDUZ3NL2EL5J1ZJAxC2sNH
SFz2j0vFfj4vex64to8KLk6EzfpJ2ZVP2cQRB1uP1k2oWOrCaJdqmv2t1pLHR8/8sJ5UhF3jAJdL
626oQnY20bE/Fa6m7F1IVvI3OPgFIAAxrsrZei7mZohflZEpGisaoW8mREKPop5zV2QgpnMS3uv6
Taw1dE7rH7ZTpiA9GYnMyVU4hCaWAE0BKcaLBHLyAWou+2gCrDsT1zCfTp18ueQ4U0pPydUCSmWJ
3SeDzqRzI2cSjcR5aCrnT0ZGOqFwQdyFQXSOZp7216+tean0vKvubv50tWry6M+fU0EXJ3VvUzrK
7A7EO/zjLfiqsxlddOoqT0IvHdR3EVXFK4ZU+SPtGv2u8uDZUNQF3YNOs3zMuRWObK5kkYf1m36J
if7SQvM4015EVUQkHCrvqVmq4jB9jbXvqRCbItVGHxB8x4Inb96ZOTQQt7XNCtr4ed26X8xeR6dZ
DBAbw5QU65jFLnDorYPaaPk+BhqsVDFYNabVG07W78qP5pUXVR5lXj0p67ALv5g5MwZKhlx3y4pB
osAO1lGdmDzXy7lsyz3jqgvHFug13GOU084AMkwrJ51MwQosgnjJpMn1K2rUl9CfPpWgCfLd4kqi
ShdpekF/iJFwie/ViDgMGrO5mK32U1lilM6Ua9o9AiLi/qWY08x+y5bEuzHC4M3hXqbEIMCFXIWA
1grE0LvbJ07wOU6w2bHBGX68ikttuV5Q9Z1u2LN6T33sOaKLbKhRDFQQf3VErNXPTIBgmJ1SHz2E
7hGG9p4P5Shcb2JPeTc3kwnAyrAq/2DK6cp94NMli5KJTe17XIQC1Pg5n83cf+axAWh6jKkBXSv/
IFI0qCS2sgszznovwxIwUL9qBbiEX3UwlWB/9rb1JyNolhB+O//syL24G1gWDddUVsM28vvrper3
K/dDLe4wbCUOCtBMHL7sTmzdYWoLi+AavS/LrvFXNBmjNK2a+iWEfpY3h5yb99d3yTxbq3MOt0Ut
loBJUXSCpi/wDtwM7bfMXKgVbtC6HorulbvziR6HgIv50yuEN0nuw1qIrFSuqmBSsDPE9+HrKYPd
/LyL+EDDVnflK/Zkzvbl6tGoWsVXFOCWKxXBHhBdtRmYUWYkXgOkRxSCprJ7gbLwEGOaq4C69bpc
Xf9Olt4BzHU3FotBO8Nk6oWZSLXZI3KKPozW8zJ1+3Q4+yf2JwltiVUxjRWdpxzow6bN3SjZ6IvO
vYaBLogmY/tvGMEuFsHA42dEOzjmbW8ovsGGbknWPp4aPYHDPuwk8ZeHOtIil6L8ew2vAZ7Z2d6f
y3E3S01SGNzRfzzZyk22hcx+uB+2DeR2qAVM6z+K6P9px08I1csqAodm6FyAuNt/Q+1ZKELWcnHk
JBGV9R+zh2WZ+wKrVUViwDPbljFLvG4rdMaz4ABVN7X2Lkw4tu+oMZQxh2jSt0j+aixiNqPdtYKS
HrVNRbkllJXIXpNN0lJ53WAs3MV1MQMpGDvv9ObBnM2tHdOvteTgtMxq0wJQN1DsYT1WgdzLUXkN
bX/ImZvWA96/g6GusEwlDHeEK1kqUNxL8kaxz9TrXhOtksXFqyUh+AyHSTBpvj5urZ326FwBJR4J
wTpl01Orl1Sfvkxt11NXoWx32VaW5f2GWM+WNGihXwI9Pt32bk9X1zeZoADBZ2hzxmIHX+FWkK9B
TGBg22SNEzPvTgM3yvG2/qGSRh2AMUTw1DB9Qjk1fHOLe1VBK+OIQNOM/LbMiN+azMbKE3in0wxa
Vwk/Gx68spCIScqtSTNupELvU7+ogO1u6ID4iioZTkK4TtS8sSgdFdJr5CAOJqNW/jRHkXb66W9d
cbBZLocH3HA3L23hHg3tbhTcspCsJHWotb5u3p97qDcPjxJsBmYvS8oPwj/PJ2C68305bFxizayx
NdeGDc8HLL0FFVflPQpSkTPrpQfeWoNYgIRV/bXipcT1uVcq0UYHoCtNACPAEd7irqyHYdWMR68A
/nGx+1vAaDmFgeQIdrbnTe21iOrDmZEkyBMWWcxl+FpADPs4iaTmruVfELebx2DDEX4bS4B6iVLR
afpQsuxJgCWInRgmhrsT5XNcahbaD/EHMvfdEf+lncoo3A5nn90kjPP1Uzc0Shi6OV1sDGBv+8IU
hkmb0RzM+JwSDIyHOKvwsbUzu7JF8TyhxbbYUt3ohFIjU8ysWvB4s3UYSuJ7zWw2TnDYW0bYr7lh
bbpzShn0yq08RVYf3XQ8z8emaaqNb2+j24BBV8ijE41e9U6StjgiGlVDHM/E4SHYjv4tLL1xtqMN
QV5+ayn8Ww1sNn2PrEvRRCUQmWO2sDg6NGCsucGo8vPP76RJFhtiu+oWcIFWPVihbJAeTcZPLVnL
O9845SFu5j5oyASkbu6H5bnk/soDFMRa1l+dgRwz9m03vCuApHOd+uXGw6c/mNL7TVcm3N+d+Vwx
g0Vl75zZTL+kxlUGdIu2/QQvwlqhQVowYPLT8hvjS6FaFx5Sh42I2rTkCj/taUJ+iwv0Hc3oqBnG
QK7bQW3UcKqVamZtxEVwvBQaaj/+4sDDxfNrnhkQiuAJrA+O3JcR/28zSUh3HIbGgzAfibGqOet3
qMzmnCy6lJeC+fv+T/uburrCThTPNXC0G89grfM8b/tkpkulavxiCH/EeRG85kJicC28nmcz120D
s5a0UeAN9Y70cUi6oT4xG689Ht9Yj4Ktn8zEoYrpD+Wm4ADlVtZQxnajOIKBiIJ3CiVQ5NPJecBw
QzD/SR0YVEnydjroTgmntbityIBWH/B3JjQOtnFs3THMj7pdA0xhhr1etRSZ7yyM1kpZjGFLsr/8
851zLhA7I+bjBlVlx9psfrAbbuRedX0VxFgoob83FOnV/nt3sIMJLsxriGXEzuxS3wumFXUVsHO9
+7UxWgR6DGzeLH5PNJYY4+Ri8RFZ6y2YoTT2kLbfetsMbsCgHjpjFKTpqhB+zfEP5bo58zGtx2Bh
yXgUUvqF9erUSIC7/HIIb1b9XMw6FG4H66bzgX0txaMhdcEv5MgEEksi7OE9Z34MiNyLANM539vs
ONelWRss2/JJD2E+5xKxEDO05r/PXLpIQokmDpFlxcs4+it7PLTqQz/zIvOZJ0QInltA/vW200ZR
9X8JIyCTTnblbL1wNcUmaMcwe8VevFzt3djG2923z9JdB7JRnE/hTGSQpnp3Dk7rOjgNIoLFZBuK
6U/BGMMshkoREgboY3DAh6wApvE5q/c/g57c+jH8k3kZnaHEZvRcRE6a12/RgV32vWTZ9OHA4p9b
K76iDTxRyAvEXD115ATAEocpIgLuQiyBY4BGt2ICYf0X7//1eK+Hz8KRb6VG2dqbLoLcO3cvSFyp
vA3OjgeDdooYQMKL9BLwgLYkBT7yuKvSseFNY6t/B1pBWBO8Kw2LsakJjZ8Fm2DiPTZ9xNDkXOGc
GDiuF/+rhKjgPbmkir4fRSgeHCp9Vp1CIhNE637KbBTedqWdpr6OW3xyMRHl2n/EKMdoCfsCs5Ta
GWjyQnnPj/86BCtiB+B3LScI6eDVTdT04CsV2/XISVuEion3UiQg/pihmtfsLGG4RSpB58+5KC66
pCDDRlBzKPg+48RfRK7iqqdVDViiTWIp7puiXjZVjLNva9QJCme9Ce5iiU9euPvWNRhBQNOZSW99
cC5G1iVc23bbEMSu/EGLPpD2QDmUB7QIgUJNs4+c/cOqvDKWN5j0kvg2/dB6/dSQTTUwGI7VtNDX
65twnf2kCgfsKtVevDAnGvNCgvrdTXbNFbwI5jsZMcbD/o9vqbIivC53s9MWYdOVABqbb9g2oWqG
tBUoQzHUd6aEjG0mPZww90COsPfIQSVG/mB3jpFIwSZEVAxg3p7I7gIBGkqalyqhj7NF6ROxEqbb
44v32WePe6fMT52Av+vdJc/w45+6pOZTquME3mlY0fnL2qqmL48fwvfgQgS83CT1kT92o3tbSqRz
qhtmfGRuHkpURYelfFW8tv4MvY3x4kpPjtccT9eq3fSTA8dzfbdLColXE0MEQwJK/2aTy4GjmXUM
EKftoY+6giNz2Um+2gZ9WO6x8+sLNFCsPF9wCHc4HVZ0rMgMGgcvX4mE/AFRw+HgT4pJurwIxDcE
M6isUXWAaXqIvvk2ZuVXow/95V9P