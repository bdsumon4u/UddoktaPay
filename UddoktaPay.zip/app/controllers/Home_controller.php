<?php //ICB0 74:0 81:2a56                                                     ?><?php //00cba
// *************************************************************************
// *                                                                       *
// * UddoktaPay - The Complete Self-Hosted Payment Management Software.    *
// * Which is made for small entrepreneurs in Bangladesh.                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:3.3.1                                                         *
// * Build Date:19 Jun 2023                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don't comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyHOzmhI6Cmjt8PYAHWUTKlPWqd2EHW3d83FTFQTZau8xts486Pbvu4aImvtzo2cidTtXrzz
2RhiIVsw43Q1t75JCCTerLms5GsvoOLa8+g9RT4up/6VAcodw3jec0ouPvwW7cdgsa8Om/If2bql
sCyXdLxzTYl9ET/MpbS1U05ICPy8qPvKM3NLtr62MOn21GWeWHtpuQcwpuJmy98ciB4+6hK1+Ce0
UL7XMdscrdlrA+MqWNfkTroRGnrFBTGiKDei0A1G0PgMs2fUVgdas64AbTVP02SqHsO6V4oseCRI
h0u/W8oXwWpuO73s9gtVX1zxtouoqNya20FgNsF4Eq4uzFvp3DUE5ErR+m/54adrmUW59Q8lnT78
l4z4MZC7J2JhWzjZuniaVNMRLnxJ2A7dA5JJPGfmIrKNl94/snKbvBd6G0fnNSS+kbTUUagxSOqR
onUShq/sorZ8EV+0TtPZGou1Lp8MlLZdkccobodgwFbJJRaZS1TGZw6Y+z4uSWMf0IMkKlUb6EgI
pkgxxacbkNcaY2gdXS8CSwk1NnuQKVFtGYmSGxqpqgZdHIS9fwQINUo62RPfntuBg8Xg2woiKwhV
PnQChhLul4SScZ7Fv8fqzVh2gZJJJC4eyk6NhmUmSpF9Wrqw52jJKDsweer1J2tdbZMMNLHdmz8P
Kl/Ydi4EmmqvetgYdyR8sA/gQdKZEww6/9DKchtla6O9uUU7ZvcV75XbXf3P5jIDKzKTlOHQnhU/
5j0HFzyxwxz6S+4sX0JgqUnuocsWIacpQxSoVO9kXV5l18t0bSDLUqmUGlnVMuqQdMxm8031ssgF
/g4k+EbT5lwq6mwRFKtdUxA08om0MPQikY+URYqpPfQVHlKGWePXOTkUtWIBj/ARHulaJWdxWBdd
1C/Jlw0hPi7ZS3JlBCFh6deryl+Gqh3KtLUe4ke0Q6lF4KXm4gKRWlpghdKMqOfVRY3WaFq1sQYU
1cIggIyAG8Bfg3AONcevg0QM8BoNINOHQeZ6FoG4/rFU/a+vSvoPFUIl72GiyZDg9p72jybzxZy1
G6QtgeJjy9B0OBrxzPMLgQ9i/A5Zp7eWGgia3mPHuz1n0+K5KlvP4qs08Q+FBpzUbYe8Akija3xm
c5fI4E/5mdrtb/AkT5jY/hIqXl8QAFc2v/0P7QudVJzBO395B7pUe7YyshBbxDtGupC8//uSl0Rx
9wO0HqbyxyFrmA1CuVpu6AwGCM/46tXePExwSIncfuDZd6c4IMp1i6ismA3Mh+4TAKo7jTM7sGng
8cM1LPKqCWWjE+5YZo5Ok/1J8wDrSb70Csj3GmTql3UMeT9YdbNGqarrevHRGJjhdrQrzVo0wpkf
rK3GDsjyGKG2UqHfTkhnYSGNu2kkevXXHJ+IHrUcraVK/rDIP9ZNTO26dB+Lq8wdeegjxd67L2sL
JpxoJAvC7cXUQlnZOgQ06e/MqcEC1vfl1PN+zoFxoSHWcTHq1LXkHxMcbYUZNGElPc8PVY2KiAYY
nDbjteYw6ymkTr8w/Cn0BeXNoDukKBjxcK6ZBo9o5baovFwja96wSJdVFrrhezU4saNLdYs3oTtk
VNDNGogOzxLP7ciaWTq4hEm+T6cs8Q8E/oLZtNEKhuz8Grsk6eOEK81p7nUtuPQ0b6g6U1f7YBEd
oeAJ5XQh0nPPvfyg3HQyylpanKc2HcPVcDGhUAxAjo0ARbgrJlyI4cnrmDGac0Ukpkz7onpNpOYb
IDOasILxanf/IB/TO+DeNk3i+zxV/cSDEs2NqRjhD/2JBYOxR0MtCMnXPdZqLUzuts6/RogxCx0q
M0hHDnCJ/BbMLYHTnUSfXXuI44MI1riiNgGCh2Q+aY9gPA+owbSfXf6aijMNQJEw3f6xpqSQOpwK
Jt1gzYP8wznUeMzQ67vcFSByzAQxfuNKPQFUqcAMpGluMiLhyQbWpTON0Rmub/mMYRAGwFQ4ba72
Ddkxu36PxeCZx+faPR2+9TTXaQOhhGFRWwccGOewrK18JyzJJoY09h1ie2oTrZVUGHqoeOINvvc8
3yp9RfTFuGy9//VQw1QMlm9OAuM0dYqIvTUOci9gtMM5Y/a/78gw2mC9xxE6/AYu7a+nGJ3EEp2f
BTLnUO5IheXzBQ7qWK1TQu1c3BLnR72xiWEW220fRFAazwm2yN5zhZj6knVQdeP4v5q1KNcPqTWZ
ZLgT8MX5MzPC5ZEm1E7PTdA37nvuE2tKI9+wuFPyjjUEqydkrTpnpJuQjjWIluEN4fJikI8SG/Ab
qWIK52/xy0HcrM0wqoUR+l8KO9IRM/MvHowfkxj8KfuX0GCDAQ02MnUgxsgIlZOfxWauW5f9a5Dd
udMZHdkZRp3Rm5i8GjlQ1se2LmxFXkhLAyZlOFrJV4QwaMoQ4ajYd0hpp5opcI2RYYcDpjACRS7B
g7rNNn+nTu3kn2culPf70VJIOLkd+G9tfn+g1tzGNZuNfAt9agd4Yakt9jTME6wNKs2eiM5oXjwM
Vcgs43CeDiT1q/ZZ7ytXBVhKuj6GVWsBfN07Ps/H8QsQeP36O1551fKHUUSOQQ2cbU1i9IG1hO2w
RuBMJF6md9FNBgmdrbAahNX3gh/ugDEmg55WP0q2HvD67t47ENTV/G8gEtUXAWBmGNB+co5AoGlQ
q6zEgAh/LPqaStGl/TOscBy8AbiwntaFsHPksm0Y8CjVEgZKOrlWhtAjkOuXosC25LPA+Ov4uXMQ
j/hnpTBMZ9OcYlX/mYxGSiylOVyq6IniSCXekC9yp+Qe0G7HDyFVmlkQv9o31xuod/n4qqQRn5Zi
ix4TFQ0JV8XrC50mcWkTwte1GH3bmVBbmj72TtStTH1SFz2PL+a14dmsc9pniXT6TE3uBtIIqtb7
gDKV0x4cwSd7PemIxaB8brMH+0fXglFw/70Q+5rgvXrzxjoWjgFZeAAfpICNXohn4vKvpdNBvi7V
0xCCwwmiPn4tkRk1TMATqiOeVnxoGakvMnCCNeDCEbDYX9WYA5BJ+n1SGSiiXTn0PBKJQ4KNEeG7
/su54nuQ47SoS03LxqHtArVCIiBh67ve+XWLg+ruqwuhqmezhSnXCEzG7Xo4wuii/oY6UZVKX2Uy
l5Pg2Tuo86J77ayzSFh5hkr0go0/j0kWPg1aSK37U/7bXMfMqrYNIbL0GEdpxc88kCy9mRRYzkL9
MBTsm4VSQf5cP1c9/mi5wUebBA5D+PXydNG/s9xNko7WI3hW9Ps28Ux/kyX4lINBWgKP3IEKBrn2
1N8Axt/Wrq8nZ2QwMLfMK4+HKormwCD9E8+w/B3QellS2jn0cWgdXyi9s90BLaNHjkiRXbS5BVdB
HR4MISWav66SG7+Hc+z+PtxqHDzGcQf9GQOS0QyEbzXqw7hndRa/Mr3j+x0CCAGQqPH1XhLimilX
eDtleM+CbCV8Ch0eVcUikmnG5rx/8BWszyHDaVaRaYM44Oh7eO3OuB3o1WdpgZQ83rd1xDKaZ71A
OgOb9hmSabl3xoSnzTLLx16bFLGb1F0uEiDajOwUma00XD0suLKwfrvHRrCI5yMkKGhvdMu295EP
q3hwTelADtkGxEiS0g6MfeXc0B+SmefpGPNhYt8rJhhoyl2UC03+qbA/2YoyvuvzQ62wJJ1xfKzw
Ia0jBz6tpNGzV1AXmFW1ZYdb/0M0vIHus+VkvB3l06Mn0yY8KJTfrnxdti3pHGzk0eCLS+zk13Kz
bnZkSlPs7LkaqUjkhhhNT67+AiyKgVq6rGMRahSQl7cVYEc/oOPbeERQ6t/+H8Ju7BmYa88pk9Vq
fUEYd4arjfu8GF48gLMNh8RPaLS+7ijwxSfhqKXuImu+Rd4Vy8TpJdKnA8iB8oaxAU4W7F2M3YAu
61J2wzdPnnF5J0CWS4ZZdpYxqqDX8nydqXvOmXEDQCCgDN4Hen1LGNQv23+vgTcTYdV9++y5PRiY
/82RgoMehxiq6Q76VLviv0hpFrPPm2g0Ow3V0sTWTZbLTMlLz8UODUyap1XFxN4hL03psfitPYr7
OQM1ZHgAY37kmvpH5WlzdOn7y1yK2UdD0POgNpOFDIdEzgMus7kzIvKg/6DVVhZaJbGrHIaajLI1
K8g/3+OUrzV4uakb/iwsTWlpNGsDalB1ALbZ/sH+PE9JCpvl257TLVppvX40TIXSKHdvGAgJTHXu
dn79FRzfiNwymQ+gqhf9aCoHVo8f+DdRyDjUEOFMx1pZSYEXzeHEo1Vbq7kQPksCgKzcSYxz5D4i
rqsA/4X4CK1MuLLvG243ZN+MzzeQdE9z7H0EAiFFbfn4glo11v3MbBqaJ6iXRNIHIQVvt7iR45QC
kiZTRsJmwy8QLTbA/Isbm6BR7/X1i7nPfU4gOY2tHqwg93/1wu/g1sqzEWdShNkZvIc0llzdm7N2
3gJbiRuaWfwjG0qnL0as9solRgOgc2tA2HE1m8KWhWnxFuzp/tJi1VO7H4XwKIAXwaXJHCkCmrii
FkDSqw4fMwL06HXe3j+ccFZ+freLO9xKFb3IGEpDwv2E5jrEAEVRT3lcgLoR8dpIvnnFuyYaZChK
U+z5OlcXM4pM9LXdX9TqFSHA9MePRIdcPRt+/iOxfgUrbwxojXWDIYmVQ4h7JbwTqbZWcUGsL5PD
7dRmkM0wEw3kTKeCFXD3flZb/rYCDCEvl199yhk7q2k+dlEO71j/Cq73nJj2VwSLJBZPlj6oVUGQ
lduqzUcTxy8+s1Tjk29Yq9qeNDUN7NWV31ZWdxfrsAaROtZ6BV3Pz/ANTkgCkmv7xmh3HgRSk/KN
aozgD9WlBjTh71XY8XUt+8kY5wlBwWLahE/fyej3NV/COP6a/DWtDO/Ydl19+Rs6c+h3kBhpIVLv
gEEky+QvS73g6os/hFKVNQazk8nNUeq4/fa4+x/YmwykUHWbWU797O6RfFDKcaQkSP/A6GJehikl
1blWKTwif7P6aCEUlZiopwvKBwQKV5MlKRAhJU9ne/+xsdSzRs45IuOMfAHs/U3ptW07d7XzD1bm
E5Wc4tAKx5cH/67NaFWV5LjvedCP5gIG/bPat9glvMrNLB/w8DNWV6iFHt2T41G1xMXCJ8KOT/sI
5USn87lGEMktqTt+LgC6mdzpO3KsA7jpsKt+har85lfZxPXYTs9/ATTNTBijdWMi/hzOcu2Av6I8
V/C781FhH6YHhOYJVVb26HSH9HBbKnBXvamT+S/6KequjMqfXuC+PVPwE23TdaL84EO0+XFK3ZOQ
MV8bvYLTHqcH8bzsaSJDcXUnKBfEsTfSLDm6Da8o+Ims5EUkTcO7U4OrnETxUdZHT6dPBIABI0xu
FbUDRRL1NIIfLDiJ9LpFK9ATB5U8/LkBoao3dimDU5kxtAGdhHkFZj29XmLigukFRMsFT0thW3T6
mRkRSgLXuJVTwplCCb8Ovc5DsxwrGtphui9jQYVBLnK+Cv4exW7gzdWqOixrw/aEooZWqEr7QMYr
7X1lJWC4gozVdX+SsYSJ8RWoOkbqxkW6/jyN2yvV0XK0zMz06px/CZ3O+8TvaBATxSW27ahGVcCB
rfZUXwjb4dzh/D0dH67sVOfrkgbncVmzV6854i9DWl0R+wRIDHj8ALbReYEbpFAel6TFTo/RYkwB
YNjL06eO7O6puNvjzYMqVNkt1ItAsSTO3xd6e4i4+KlbC5ZuuPsTXwnTxkY+92jRBIum8c6ehOVA
HWlEVeORP7l+oAc0cUwNGIwlV1OzOEwglUrQyCzdeTUazowEWsffkpi6RQQM8GrbC/RmG9TiIXpJ
JOEWAzxg+emE7BaJsne1q9BsKjc/Tjf+4xvMa23lNr5FQsSCKkkVCk/Lg77P+nZwvE3/MH2AMLUC
bEhUhTkOEPFzFISxxjJTM3181C5G63ResFEUO5/eZoDnQex0JfWRAFb/CMZ/KFzlGEUToMPcX2pM
xaKI31MajkO27dE8gi3hjeXnqSVB63zNo67VTXBcm96Du5VfaKfqbe0rSw2SLsUyDH/v1SzBYgZx
lcQ5Hw4jxWpZt0gYi7s6ISs7mSrTQmTwRi9NgwgwijqOg+8sHcxQBDz7Xlq9SDGmArdCaWwym4yC
pswrC8W1Zun876uWLw6Sq9rVJtvWYyGa9wVRoMP3qbcY0vxWnMZCWfk+3tGAlv8+RUHAnGmwV+uR
Lyau96+CruUaROs4xKAudyIA0pNMsyRsUG1yqpCEucmvwZhmvvWLOHju/QT0/yPLtSn2cMZRgKc/
5phJCAeBUehFcdGDwCqDATYCUqHOgXAvNub+dQeYcuTsorixLrRoAvXV++Wz9w9+azj7SV7zdIh5
a4MrL1qNIOYOo82giypS82O7fmuR1X6Per7wwlfjodxX96bsJJqcZ86trIjKhyAiNLkBErefnpv3
e+BsLUpJUIrI51tSMo3BPARQ1sS0qktinzGTEVjeYbpLNIj2MINfv/yM1V5MzzA+el5bx3lOIBta
Kj9psT7Y1nwnDrJCDgTb7YvnnqdwLKwYLY0XO7bVqW8BXGCmwjsXRHARxX6O+SPj1+GUgcdpFdjs
zFudjLruj9GOKcXIuQT9Rri51ng9Ym+R76xvpDcb1CYg0unS6sEu49YN5VxWnpJr+MsgXA30PTcc
+XTF8OYqc8MXj3ABq5pZMaPI3mhPyuBUSj5tld88xOTA6nX6NShw/CtZYyXDi3aCfY6B4woKGefF
RZWmQYlX8hmiwlnbwsPYnJQokA8jXQbm4PzF3UPEfGaiMqa5EgCJ1aYBq2ityQr1mKkZedXNy/hj
SUdcCHooWsL8c6QicEORyq4Y28YM9DWER7gPBqybxH7cgN3biGagg0/G5wMbBupN+POEW7GI5cwt
8aEh7Qs+Fq8fo+/ZWmTRRNn4EPJ15XhysCh/MY1RRQ6Z6dsQNDJZptCAkEXOYBh67lyNPasomz7H
/D1JO484ixxfKLY6s4rEg/S2Qts1Z9FU0t4C5HpvAOl//B6o4PgKEV/2lndSAW5KaMSxa2Jj0f8K
kP27ua8hUldzuUc2k2dT00uM5HOoQf9eJiIj4c94QZj0/e9gA5laoVCvAt8EpKOV4eWkWkkueB55
gwEKceqf0ejVtw0mJECT5rg6XwnBJYVaH2rvUsqp64nRBe7gfW1iCJNoenQwWtClWNgOk3OUkbLM
eLMV49fnMMGwcCmz4gT49YusxZeqZtTbMzpTTrZ60RJTEbRP7FndT+RJdeIUpRDYNskmvJRGu11r
h5KWmJDaoBwxZAQNXPQ3iiSC8OeZfKgqdTA+vlLN+FgzLyqZInXcSmZUJS3MJz2BZEReyqcjb4E8
3EQasQ0RJv0ULmBVLEMXCwmXTmCArbh54IwAJLhcLM1aI7IYlyjoAoxELXXX7Z3p+qwt5vd68msk
Je7p75TivCCDkqX+u1U4m9kEX6ifbDIiVjVTdCHMb1pI8JsU9JLeN1dMJi1Dmut+wh7HziC16He3
IYTYnblNb/YlVTEveOa3ZBICRoyZ=
HR+cPtlua++ORMZ04Z06p0VILN/HFhlIraz/yPpFLZQ+9uB2itgJ9tJ7VDJ/d6N/31AWf4+Dz0R3
6hoXwv/cVyrP54PElLY+0oD4Za3PuPCP9IKrB3d9+sUOP5wpwh1sJzYOfkxB2QrISbUpiG6cbWHA
NqgCXMagH/tJ1zGCKkV6LYaFvPSSGXObtHUdvl/6/SGxHiBK7Gpk4Stc8tywaifBl8BFuSKxg0lP
yd5Q/pWVUVuOWvZ9ds80XXHD1Fsp6sxChdlOXXu2uD+Xk0Lqz3+Lr4gm0/Q1Ecned6ZhFJzu0WjP
jYIENGFjUckUaNGEToowM2JUJUi++jhibq7+XtlwmXb8Sj9wY9QYv25AaVH0L6cqdwdrmTO7308Z
Y9LexjcNtBRBhJffp9xY+c/beiGIygVC140Awo/RAUhB7KRRCYdodPU2e8EdkkyCVy4aq+r1EJsi
2G3ObrDeizRnnlHEbkzLpDsZCc6w8WMyhR1SadESXOf48a0Ng6WejMriiQaTtB95ZODRbQN1h3Ce
CpAAx3SfEtNbrGYJpKCAXdl9fwbo11yOSQj/ueZxHtCoSDQdZ73v4flo8i3aSBBxYhaKDG+012eL
iXS1T3ge+jSngEG19gxnW9l9oqyDI8Ndnm3UdV5h3ZY2f4gx9pOF0NlsoSjmQtV1byKOTe21NdgA
V4HOkPPVqls7OKyFyaZmG4pC8hNYyze2tj9277LS6S4fljsJje+8LKOfXNVB2EnE2cMN1wbJpwgt
ya/58TP+PXBIGCPoZmGUql1heZvpdQWbUGijT5fROTT2CrYSxxIgL5swhh/nTrkGRq1rHJfKjLpC
vzVbI2p+t1MEm5kCdMCpbKUvxlMynLZkciyLT9ZWVgDMEM8tiXdEI8DRA1yjIU77oIuWlS3NMm9G
3F+qQtgdfLal7rhdmsfUfOjsASEOOW+/omSumT9yFVeh1A7BfegRn8GuaLAywtDLKDtcxJB+z44A
PbN8s6CQEL5uzxNrU9F0OflwUmq0uDjCs7F6wEoPLV+MML5SVh2aea61WFx7eLwH8d3p1i6ktb6J
mn2Mnq2P1utVIy/pCtnMcwdRhQEzoWpY+eiw49MWnjM60d1o8SLu8TArrvfqHW5zll2Q69AvcQFh
jBtTxMdXGTcaxo52HHYHTKTktEnW0ujuZtoUNPnnK+l+TELKmQ6ldT6sYfKqYXb3399NJJTP80I8
wMaTbbX6h8RN9FpQRuBK1H8tuwR+YIO7PGXRTHir57lVNT1mqxARcSC6q5DFLaUz/JgNL3uAiURB
kS2ddTGLmnkMFNW4EkBJLsZrbBO9leAiDHXQuOPE0P0xgFgb2F51j+qCSKfWD6AdvvlBHYCQPtvC
tXPC47S0b0QyIAOwInReMfFykOAC7NuTNpaG62lgk7k0HgS8C9t19ctC7BNqcCnZzn8wMygUmmyd
Y3EoQ6nUqhNGvrUU1TOvapOEbG3Q0iVbIXRJk9z9bOuPUjy0MBcNZo8j8+aTZupVaMBUU5rYiaJH
X7Ta5bTKquXHvbKC9VlXxgRQeKLgZSePLKfks7W2u4xgLmLSEMUWgCjRPzC0LTiEVidTLvlGVsbX
Jkt2xzGLMfHTJ7l6/x3sni4H+F4LXeaMHx76tsPySSuiAzlLPqYQgcC9KCCWArZWaGJ9IgQPAGqf
y/uUaOZPn8kLjPlM8VQhMhSVSQFVZyIOiITPLWrSB6ofBMk6mCiU3wIDgWi4a6bo46R/RhUKiTOi
qBzWRkIW3FO9dnRhH+DaNmUgAieLoVt1fsKXtUR9VyyxDWjnlJB2+i4Dw1wA6IpLPm0w6Pmqtdf2
+KjyPbCFmClRTgrMoHYlMVNvbi2V4eN2JFLVt3+p98rNf37yhx5Ts7gKys35UvZ2C+/F70ckzoXn
ZiFxZ9WGUPsAaDLG+DWiGQG1JLN112iLY+hnwwus52mFvWzXMwqkem9pWwt1FeXIaFBbFu/KNNZC
NvceQj+TE429ucopKNnvp+bBy9U4XYf1sKfp+n+AKn94+jcVgS+QzehKJDCOgHG0Y8xfAWNY6fE+
CHPDw1WBlItwnKlPK2azvjmDyHVU9FzCRT26NJPL8H3i0/ZW0L6NEXrLkH+r0tRplRl3kFNtzsTu
9F7doIza7U5BdvjzjX+Qp3V9UyrBEUXCoCMle6tvsOtCxlnpMUMce7ux1jDGM0o2skckiARndSWI
Y7BsAN+QO6KSbi1RdwIjQGaDXgQ+/KwB9HIo+YL0tD+g/UUr1EvMK/hjRTjChd8aQRSl48RrW09r
pKsaW0UPwF/yr6Dx7DbHSgcHCq8dgSnuWmRVBlYuAeztu6AYhMUTYXzthYgpHjdBNbw2+V+QmITo
PlF8v0oBkiM4rYpGy/hZXFE4KWRsuo3DuBIdscea2QrNmn/kWpHvA921Ek1QSP/hPTCHeGgWx4gC
V4Pkm8HnH+HFtxWjWTk8meZzlYyn3DfiadZuoMtIn2vL18LP/apVy5X5+sSJSAupu7c6fLwZjrJ4
gYlI2Z26LsPEnlIlRzE4lf9za7660V3CIl7TcdUsAFTKgR6oStw7j4pfTb4L7S+cbjkXAgpMC3Dp
bB9pb+A06IubZnaMwuIT/9NaEZY1oQe3b4s+b3VjzadC8QlkB8YCo0yFaQP1HGEnm07Taxv5uVlp
1xefvpCZOjnloLhVsaGfRYanFW4epBcj5nBP0V4OvxKUnqmJE9WtzKVjp9Lqm8k5rxMKSsUQqsWe
aO4SO1STuI2cKgD6K7wAgaF464qormhGR7KesZz53oj2KPgA9OPb0TpK1OJfvhOH35QbsyHl8LFN
78VY9rrkJVRfogYAhZH00gXqSj0VsvTPlqx24juS5hjcpR5MgAFCbOfydrOjPUXDWhZVh8BJu03F
PuX97X/CnCbIoKLeVq6EkuV1y1qB3wqioFoHsTEW96N6AinMVGl27q7BuHeeDx2XQaoAGvJkGIA7
LRHHAPoGgCk6OArsrQ+/kp59hOaOIPs8brRnfFHGe3+YZTGKKtgIQMP5Qb/p2ZJBE0UL4OHl/bZq
Kb77OKRECw53Vvahs+evaZlJRN/zuEa8ko/Hy2iXL7wNIfXE3lePU3rxwc7Eu86tSsK4g17AGSJx
2cR5q0Fu5V9vt0DVeMhLBzzfmZwcN/Um7XHGNvPU+oR5qVXBdUL2sgldUuCZU7qFAencBGB3e9W5
5fYtpVFSKELsqw0YomVPvILKnuNshUoL9QxOBvFC8gM+kGDzRnYYRSBTlh8lyELFdesEpD9jMANr
Rt7DR5lURh9XyzqowGyzOi8ZVS0ifnZAvMHfJlr3/j3q/HTG8mOgmx3ixIFnvRqvov9MQ7K2ky8v
LQZSRrpdYpJBf7D2zvE+yUJrtcfcSyw6n6aGLGPT+ZgewTliPMNcUbUPvn/QO6Ca06ZjVvEIfOwo
XzIxoqn3YweNkyalmfLBsQc933cNofN8RGoQsoMay1lcmMNmBBbq4dWxq75NC7ygmf75l9ucTrUL
YvGtAgZOuysGbpfmzLhCU9nuaYvGw8SnWDUgypFjkQqriKIRxf+/Sb6+rxR7faVd3l2c63BELEDJ
MmPSEN0oiPR0zSgq6r5UVhm9j7dkABCwXLGTVT2fwykkcxKJfWPR0S8qWPPGobnMXZIbVZ5pVdKO
RQnymmieonJz9ybYsc2ebxr1QIIvItdBM+793kotq/fuFW+k0VMINeb4nin8KK6xGEfzxryVi3bE
VOwAG613SiUYmnCglyoj74IGHifseOnHyZaVa/d2cexYg4zDsrXcDIHqe6kFXMQUHyWzzkBPvxeA
z9ydV5mCo5+DCUS2S17PpGx/zbU1xivYZokOym/wuCrTrPt3MXz0WTKbcTM6fDhrZY8Hx4wPx/hb
O1Gc/qgjubWB0TudDljm8JJUacYaOsu1cgD/5zwIViFwxJjL59uoU5FtPqUW7tCvnuWJRvKYfIoa
H8yAcMk0NohLxllyz0qwjsEGL+kXTOlAwBkxE6eGAnHAOaCNyOyUF+ZvWD5PRHyFHbvNammh2QpW
IvJnV+8Nmoha96PBmXScevW0+0qIAtVQH/0baXZ4zDgtPVPHg0HwhEkuLZfEBXoEg1bjHLG/vwoc
FH2mQpCPiiRvW4diRU2Hq1XnI9zBragxiVr4rMxsRnBPktGtWN8zRHKrYONQQV/uwOLSYd4sox2C
mY60VoJmnm0XVh7TSFWXiJ4A3Z59RfUZQrCHCKVvnf2vU37XTcW03L6Am43OMs8q3OEzGk9CzT4J
MQRTsEC4zIe/AxTODzSkVNX66Kzy89g4ucLIr43SI5a2KT51PwFNpxIkSIV7AbEQ9/FhRw0FZloV
L1emqlNFH+mSPe1tWXmkjwi1iTRUzdmgjIwHcwGhVjlabLxpdaQrI4N0DxlFpA+TTfADlKlt/m+C
O8HTqML0fVENIy3ifK/UIOmvkwg9tmhejsqkjuGJXlsUYzIFnl+EXrCXwGrFtwfc/LBS28n2ho6F
08fy1lxbhoWLC85MbH1aap4J/wNpL5LBxPNjo0akLA8XtZ3rozzxlAQASX3bpA92mmqioLIo41Iw
m8CGHLb/3NP9xZlQdH9qyj9vqwTy+ktGTkaPtTPwfFIvkCC7/cEszVMKFld0vG5TNqJ1pcrXMurs
+K7xlYNmnsxwkcxDeWXMYlN9pDBgnYR9zVEr/qIgz05Kj58Or5TnuKIzl10EriwW1mCE9nA6wmg/
C+JTG9hkNJBYRXbLYMR9HW1iCjDL/5joUnl/izk74yOnQ4rH5j1xGYWxmerDW78QD5vaNDZtjC5t
e76j+E4KhEQTpatdiidLPus06BLl/Nzya0C+rGTN/y4k+tEDTtgosrpc+9e3xrJ/LZIr18+m8Riz
DPGjQDvlLH7RLx105Ptcsfly13bBjfQnjTzHA0bSRyG7+8+CJRcvIe6CzRNSfjlf5P/pNb2suMnX
MWv6AJSqofK0aeGScyqzTgMqyTSDclG/9jOpHeVpOc5OQMOPJqk82Hg5cPnwOcyI3XD6kNgbY7q3
ZLcs86OzVGbiT3cpm+YgwgBv2Psh9VsbjKNjPTI/vXach5l0dJPGCBa8tpDiTU0dBxBMbKbdZAr9
1AxNF/AKjJiEiHdh4JBW0/WJAILBHBbbMYRTaiiOkjM5RUVvzCQKRD+jD2yRGfut33v0rrrt5LLZ
CYPG4GdOka78Hgzo6SGESMliPF/PvwiJSXoxsSJdmbaSHyyFbJlVQHaATaKjc+EqH/xxyqKa5Np+
tQkX8Ts0IGiqOMCwtLu6dXllSYdwTU+TAztBvgx8jlEiL3sjQmLBiAh1Ls3TeEUKICkj7YqPIh8w
ZS0ZA0RC6MeVv+M+4PSHH5wHc/paadc5pAK5LYuidkrqbENDxI7SGqPAKV6YCDu5dkEkI90HjscA
yCAMxyhfniQaOwYfaHijibYqWhGoMyuAFwgb5kjaV8p2Gf1OjVg0tFj3cNaWcG/b1BvueiEGYafd
J7EbiHacyQUsdGqknil5tByFHsX6YzIZBHwvxynwqs3c87/8/QJMBp117cUjVkywYwzBKuJbH1uD
Xojod/ot69k/0BYJyNPbgJhn/VSWCdGj3R1KqJwe8QwrNONXn3hIptyhTj7Bl4g8rk9+Mpwky0uW
hxeZ01V9xJCcNWq2Pe4mmmXVFzEEvwMiMIu305AOVTTTJyyn4/NMv0FuBQyluFi1qsT0418HM5Ub
Hrc97cn9QRQM/8DdvJGYna+Q+IPpfZb3Px5GfUA+qfraX4nn2TLUoA2gzHiLWnJxAQSk/xKAUTWv
HGdiR/W4P84zeJGteoPojVa6WmZ+54pVt2ECsNOMfqFD+Utoxyuj31IzWSiik5zVr7w9MZvmI4n7
CbEspVjBVSnBCd1MA+kwLrN3xcoQh2S1bOS1UpcYI/7OuL5mb2li+O2/tOEXPKnFGmZ2t1WcFdB1
9feQgxpQG2KpWsaxt8SYlnOLABj6+x0TxJgMXsgReN/3Q0EWulIQPcNGnQbWv5fiTRZEH7mUTF1E
sZ+KNo/jQAbKCIBs6gBXJCKxlK+Mpj4nsEEI60gRfcirSa3PAPykYi7TodYqrRRgMg77AKFnkL+z
ldNoMoGx0zI9l/ZRgsLldMmYomqDBaNmFYK67RhhYWZ3AfSb7SYaQgKeVA1tFHIVUlsrzpBPEaPg
RIZ9xj2O0HMjfWWVEPCn0K1durApkooQk+Whmk14HeB/r/eRBarq8TpUlpxhhdqDD6c6GTxYwXU8
2mDuapEB1HFxGZQ9AjK+5S/abc6rV/F8TDiTxlCK7OFynJejUpC3vOqUWe/Gv9CHhILJXNmglbF3
R4pasvkejPsniMBLipkzVuXosQjSvO80j6ohcuUr64On8b62y2b51uqU/2wvM4yv1ir2C4DJkVX3
DeKFJMnVsmPHL73c/1DQseeiXSVk/EaC8bI5vcIRxxfw7Pv3zGNDp9zBFjq6szNUYINnZDRo38Tc
XKzfKn4PbE0gZWY+MA4EhHU6/LeNv0C+zD+uS3ciVR7vQdYT+Rr8ZDWf2ioWaVxF2dmGYUz+mWXd
up1Rz3TMM8yDrlbn85ofTaceWnocrdOYdv1rkzH4OeCo1NiHqoY9ajDwVn1oq2fvSFIQ9hNEY+FX
Du9nia101wpIa1E41Wt4yJcoQKWdSCnZYsQg0Qc4to/7zWFyhad9QmZZWUMBkWChe0DmhjGBG1Aj
+BZuMmta/uYCw8k/0MRj0z51VbveI7EmFnERM37K1X+TMw8iDEcJeBjgBtys8aEA0FW9XaAyvu2Q
LsfvSvEguVJLD9ePIblSiPUbd531ESFx5q40BAT9RT23CF4jtPsdda9F4D96Lepiw1zPltVs42xU
7PRjeSA35pgHOWtFpl2UiP18t/AGZM6npUWGR8M6Q04iWf6mTou+g7drxz+oqTow2HCFi8fPiCoY
BgcHAciMB2Omr0L2Mm3GNWxjJeYXQgRAyKFz5RgaW8g6xfCXn9NtqsSCCkqekdkLy9oLEKEiOEyA
2mF7q1LayKeFlPjZtnwSR3vcrANafIllcIm=